/**
 * Created by lxq on 2015/7/29.
 */
define(['angularAMD',
], function (angularAMD) {
    angularAMD .directive('classificationItem', [ function () {
        return {
            restrict:'E',
			replace: true,
            templateUrl:'interaction/classified/directive/classification-item/classification-item.html',
            scope: {itemData:'=itemData', itemsData:'=itemsData'},
            controller:['$scope','$rootScope','$timeout','$filter',function($scope,$rootScope,$timeout,$filter){
            	$scope.CARD_TYPE = {
                	IMAGE: "image",
                	TEXT: "text"
                };
				$scope.PLACE_HOLDER = $filter('translate')('classified.class_name_placeholder');
            	$scope.CARD_MAX_SIZE = 4;
            	$scope.CARD_TEXT_MAXLEN = 15;
            	$scope.wordTipStyle = { float: 'right' };

            	if(!$.isArray($scope.itemData.items)) $scope.itemData.items = [];

				//删除当前分类
				$scope.removeCategory = function() {
					$rootScope.moduleScope.openDelCategoryPopBox($scope.itemData);
				};

				//新增选项
            	$scope.addItemCard = function(card_type, $event) {
            		if(!$scope.itemData.items || $scope.itemData.items.length < 4) {
            			$scope.itemData.items.push({type:card_type, content:''});

						//排版问题fixed: 若只有两个选项，且一图一文，需要将图片选项放置在文字选项前面
						if(card_type === $scope.CARD_TYPE.IMAGE && $scope.itemData.items.length === 2 && $scope.itemData.items[0].type === $scope.CARD_TYPE.TEXT) {
							var temp = $scope.itemData.items[0];
							$scope.itemData.items[0] = $scope.itemData.items[1];
							$scope.itemData.items[1] = temp;
						}

            			//自动激活输入框或图片选择器
            			$timeout(function(){
							if(card_type === $scope.CARD_TYPE.IMAGE) {
								$($event.target).parents(".list_box").find("li .list_text:last").blur();
								$($event.target).parents(".list_box").find("li .list_img:last").click();
							} else {
								$($event.target).parents(".list_box").find("li .list_text:last").focus();
							}
                        }, 100);
            		}
                };

				//删除当前选项
				$scope.removeCard = function(index) {
					$scope.itemData.items.splice(index, 1);
				};

				//图片选择窗口关闭事件
				$scope.afterAddAssets = function(card, index) {
					if(!card.content) {
						$scope.itemData.items.splice(index, 1);
					}
				};

                //资源文件的限制使用
                $scope.resourceValidParam = {
                	imageType:['image/jpg', 'image/jpeg', 'image/webp', 'image/gif', 'image/png', 'image/bmp'], 
                    imageSize:1*1024*1024
                };
            }]
        };
    }])

});