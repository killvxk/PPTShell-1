/* global angular */
/* global $ */
define(['angularAMD', 'components/jquery-plugin/jquery.mousewheel/3.1.13/jquery.mousewheel',
    //'css!components/directive-custom/div-loading/loading'
], function (angularAMD) {

    var ImgTrans = function (img, options) {
        //处理参数
        this.options = $.extend(true, this._defaultOptions, options);
        //选择并创建模式
        this._initProcessor();
        //开始运行
        this._initialize(img, options);
    };

    ImgTrans.prototype = {
        //默认参数
        _defaultOptions: {
            processors: 'css3|filter',
            mouseZoom: true,
            onRemove: function () {
            },
            onDispose: function () {
            },
            triggerEvent: 'dblclick',
            needCreateBtns: true,
            actionSelectors: {
                right: 'js-right',
                original: 'js-original',
                vertical: 'js-vertical',
                horizontal: 'js-horizontal',
                remove: 'js-remove',
                dispose: 'js-dispose'
            }
        },
        //初始化：准备各种变量、创建容器层
        _initialize: function (img, options) {
            this._support = false;//是否支持变换
            this._editing = false;

            this._radian = 0;//旋转变换参数(弧度)
            this._x = 1;//水平变换参数 原始缩放比例是1 水平翻转时false（正数表示无翻转 负数表示有翻转）
            this._y = 1;//垂直变换参数 原始缩放比例是1 水平翻转时false（正数表示无翻转 负数表示有翻转）
            //this._zoom = 1;//x y 都是同时缩放 所以整体缩放比例就是 x、y中任意一个的绝对值 Math.abs(this._x)
            this._original = false;

            this._img = $(img);
            this._wrap = this._img.parent();

            this._originalWidth = 0;
            this._originalHeight = 0;
            this.getImageOriginalSize();

            var that = this;
            if (this.options.triggerSource) {
                this._triggerSource = $(document.getElementById(this.options.triggerSource));
            } else {
                this._triggerSource = this._img;
            }

            this._triggerSource[this.options.triggerEvent](function () {
                if (!that._editing) {

                    that.resetData();
                    that._createContainer();

                    typeof that._init == 'function' && that._init();
                    that._editing = true;
                    that.options.triggerEventHandler && that.options.triggerEventHandler(that._editing);

                    $(that._img).trigger("init", that);
                } else {
                    that.dispose();
                }
            });
        },
        //选择并添加变换处理器；添加各种变换方法
        _initProcessor: function () {
            var that = this, processors = ImgTrans.processors;
            $.each(that.options.processors.toLowerCase().split('|'), function (k, v) {
                var processor = processors[v];
                if (processor && processor.support()) {
                    //添加变换处理  可能存在覆盖
                    $.extend(that, processor);

                    //添加变换方法。这个应该叫什么模式了？装饰器？
                    $.each(ImgTrans.transforms, function (name, func) {
                        that[name] = function () {
                            func.apply(that, [].slice.call(arguments));

                            this._radian = this._radian % (2 * Math.PI);
                            that.show();
                            that.setData();
                        }
                    });
                    that._support = true;
                    return false;//jquery中要这样终止each
                }
            });

            //所有的模式都不支持 抛出错误
            if (!this._support) {
                throw new Error("not support");
            }
        },
        _createContainer: function () {
            if (this.options.needCreateBtns) {
                this._wrap.prepend(
                    '<div>' +
                    '   <a class="js-right" translate="directive.image_tansform">90°翻转</a>' +
                    '   <a class="js-original " translate="directive.image_tansform1">原尺寸</a>' +
                    '   <a class="js-vertical" translate="directive.image_tansform2">垂直翻转</a>' +
                    '   <a class="js-horizontal" translate="directive.image_tansform3">水平翻转</a>' +
                    '   <a class="js-remove" translate="directive.image_tansform4">删除</a>' +
                    '   <a class="js-dispose" translate="directive.image_tansform5">退出编辑</a>' +
                    '</div>');
                $(".js-right", this._wrap).click($.proxy(this.right, this));
                $(".js-original", this._wrap).click($.proxy(this.notZoon, this));
                $(".js-vertical", this._wrap).click($.proxy(this.vertical, this));
                $(".js-horizontal", this._wrap).click($.proxy(this.horizontal, this));
                $(".js-remove", this._wrap).click($.proxy(this.remove, this));
                $(".js-dispose", this._wrap).click($.proxy(this.dispose, this));
            } else {
                $(this.options.actionSelectors.right).unbind('click.imgTrans').bind('click.imgTrans', $.proxy(this.right, this));
                $(this.options.actionSelectors.original).unbind('click.imgTrans').bind('click.imgTrans', $.proxy(this.notZoon, this));
                $(this.options.actionSelectors.vertical).unbind('click.imgTrans').bind('click.imgTrans', $.proxy(this.vertical, this));
                $(this.options.actionSelectors.horizontal).unbind('click.imgTrans').bind('click.imgTrans', $.proxy(this.horizontal, this));
                $(this.options.actionSelectors.remove).unbind('click.imgTrans').bind('click.imgTrans', $.proxy(this.remove, this));
                $(this.options.actionSelectors.dispose).unbind('click.imgTrans').bind('click.imgTrans', $.proxy(this.dispose, this));
            }

        },
        getImageOriginalSize: function () {
        },
        resetData: function () {
            var element = $(this._img);

            element.attr('radian') && (this._radian = parseFloat(element.attr('radian')));
            element.attr('x') && (this._x = parseFloat(element.attr('x')));
            element.attr('y') && (this._y = parseFloat(element.attr('y')));
        },
        setData: function () {
            $(this._img).attr({
                'radian': this._radian,
                'x': this._x,
                'y': this._y,
                'zoom': Math.abs(this._x),
                'original': Math.abs(this._x) == 1,//TODO:还要判断的图片是否是原大小
                'vertical': this._y < 0,
                'horizontal': this._x < 0
            });
        },
        remove: function () {
            //TODO:删除确认框
            if (confirm("确定要删除吗？")) {
                this._wrap.remove();
                typeof this.options.onRemove == 'function' && this.options.onRemove();
            }
        },
        //退出编辑
        dispose: function () {
            this._editing = false;
            this.options.triggerEventHandler && this.options.triggerEventHandler(this._editing);

            typeof this.options.onExit == 'function' && this.options.onExit();

            $(this._img).trigger("dispose", this);
        }
    };

    ImgTrans.processors = function () {
        //获取变换参数函数
        function getMatrix(radian, x, y) {
            var Cos = Math.cos(radian), Sin = Math.sin(radian);
            return {
                M11: Cos * x, M12: -Sin * y,
                M21: Sin * x, M22: Cos * y
            };
        }

        return {
            css3: {
                _css3Transform: null,
                support: function () {
                    var that = this, style = document.createElement("div").style, flag = false;
                    $.each(['transform', 'MozTransform', 'webkitTransform', 'OTransform', 'msTransform'], function (k, v) {
                        if (v in style) {
                            that._css3Transform = v;//保存类名后面设置的时候要用
                            flag = true;//
                            return false;
                        }
                    });
                    return flag;
                },
                _init: function () {
                },
                show: function () {
                    var matrix = getMatrix(this._radian, this._y, this._x);

                    /**
                     * 修复bug-41282: 101PPT内嵌的浏览器兼容transform -webkit-transform，若当前元素已经有了-webkit-transform样式，只改变transform样式，效果无效
                     */
                    if(this._css3Transform != 'webkitTransform' && !!this._img.css('-webkit-transform') && this._img.css('-webkit-transform') != 'none') {
                        //this._img.css({'-webkit-transform': ''});
                        //设置变形样式
                        this._img.css(this._css3Transform, "matrix(" +
                            matrix.M11.toFixed(16) + "," + matrix.M21.toFixed(16) + "," +
                            matrix.M12.toFixed(16) + "," + matrix.M22.toFixed(16) + ", 0, 0)")
                            .css('webkitTransform', "matrix(" +
                            matrix.M11.toFixed(16) + "," + matrix.M21.toFixed(16) + "," +
                            matrix.M12.toFixed(16) + "," + matrix.M22.toFixed(16) + ", 0, 0)");

                    } else {
                        //设置变形样式
                        this._img.css(this._css3Transform, "matrix(" +
                            matrix.M11.toFixed(16) + "," + matrix.M21.toFixed(16) + "," +
                            matrix.M12.toFixed(16) + "," + matrix.M22.toFixed(16) + ", 0, 0)");
                    }
                }
            },
            filter: {//滤镜设置
                support: function () {
                    return "filters" in document.createElement("div");
                },
                init: function () {
                    //设置滤镜
                    this._img.css({
                        'filter': 'progid:DXImageTransform.Microsoft.Matrix(SizingMethod="auto expand")',
                        'visibility': 'visible'
                    });
                },
                show: function () {
                    var img = this._img[0];
                    var matrix = getMatrix(this._radian, this._y, this._x);
                    //设置滤镜 Dx= 155, Dy= 232.5,
                    this._img.css('filter', "progid:DXImageTransform.Microsoft.Matrix(M11="
                        + matrix.M11.toFixed(16) + ",M12=" + matrix.M12.toFixed(16) + ",M21="
                        + matrix.M21.toFixed(16) + ",M22=" + matrix.M22.toFixed(16) + ",SizingMethod='auto expand')");
                }
            }
        };
    }();

    //变换方法
    ImgTrans.transforms = {
        //垂直翻转
        vertical: function () {
            this._radian = Math.PI - this._radian;
            this._y *= -1;
        },
        //水平翻转
        horizontal: function () {
            this._radian = Math.PI - this._radian;
            this._x *= -1;
        },
        //根据弧度旋转
        rotate: function (radian) {
            this._radian = radian;
        },
        //向左转90度
        left: function () {
            this._radian -= Math.PI / 2;
        },
        //向右转90度
        right: function () {
            this._radian += Math.PI / 2;
        },
        //根据角度旋转
        rotatebydegress: function (degress) {
            this._radian = degress * Math.PI / 180;
        },
        //缩放
        scale: function () {
            function getZoom(scale, zoom) {
                return scale > 0 && scale > -zoom ? zoom :
                    scale < 0 && scale < zoom ? -zoom : 0;
            }

            return function (zoom) {
                if (zoom) {
                    var hZoom = getZoom(this._y, zoom), vZoom = getZoom(this._x, zoom);
                    if (hZoom && vZoom) {
                        this._y += hZoom;
                        this._x += vZoom;
                    }
                }
            }
        }(),
        //放大
        zoomin: function () {
            this.scale(0.1);
        },
        //缩小
        zoomout: function () {
            this.scale(-0.1);
        },
        changeWidth: function () {
            this._img.width();
        },
        notZoon: function () {
            this._y < 0 ? this._y = -1 : this._y = 1;
            this._x < 0 ? this._x = -1 : this._x = 1;
            //除了变换中可能做了缩放，还可能有定义样式width、height，属性width、height
            this._img.css({width: 'auto', height: 'auto'});
            this._img.attr({width: null, height: null});
            this._img.find('img').css({width: 'auto', height: 'auto'});
            this._original = !this._original;
        },
    };

    //滚轮缩放扩展
    ImgTrans.prototype._initialize = (function () {
        var init = ImgTrans.prototype._initialize,
            methods = {
                "init": function (evt, imgTransInstance) {
                    imgTransInstance._mzZoom = $.proxy(zoom, imgTransInstance);
                    $(imgTransInstance._wrap).on('mousewheel', imgTransInstance._mzZoom);
                },
                "dispose": function (evt, imgTransInstance) {
                    $(imgTransInstance._wrap).off('mousewheel', imgTransInstance._mzZoom);
                    imgTransInstance._mzZoom = null;
                }
            };
        //缩放函数
        function zoom(evt) {
            this.scale(evt.deltaY * 0.1);
            evt.preventDefault();
        };
        return function (img) {

            if (this.options && this.options.mouseZoom !== false) {
                //扩展钩子
                $.each(methods, function (name, method) {
                    $(img).off(name, method).on(name, method);
                });
            }
            init.apply(this, arguments);
        }
    })();

    //拖动改大小扩展
    ImgTrans.prototype._initialize = (function () {
        var init = ImgTrans.prototype._initialize,
            methods = {
                "init": function (evt, imgTransInstance) {
                    imgTransInstance._mdX = imgTransInstance._mdY = imgTransInstance._mdRadian = 0;
                    imgTransInstance._mdSTART = $.proxy(start, imgTransInstance);
                    imgTransInstance._mdMOVE = $.proxy(move, imgTransInstance);
                    imgTransInstance._mdSTOP = $.proxy(stop, imgTransInstance);
                    $('.coldot_topleft,.coldot_topright,.coldot_bottomright', imgTransInstance._wrap).on("mousedown", imgTransInstance._mdSTART);
                },
                "dispose": function (evt, imgTransInstance) {
                    $('.coldot_topleft,.coldot_topright,.coldot_bottomright', imgTransInstance._wrap).off("mousedown", imgTransInstance._mdSTART);
                    imgTransInstance._mdSTOP();
                    imgTransInstance._mdSTART = imgTransInstance._mdMOVE = imgTransInstance._mdSTOP = null;
                }
            };
        //开始函数
        function start(evt) {
            var rect = $(this._img).position();
            this._mdWidth = $(this._img).width();
            this._mdHeight = $(this._img).height();
            this._mdPageX = evt.pageX;
            this._mdPageY = evt.pageY;
            this._mdX = rect.left + $(this._img).width() / 2;
            this._mdY = rect.top + $(this._img).height() / 2;

            this.coldotTarget = "";
            var $target = $(evt.target);
            if ($target.hasClass("coldot_topleft")) {
                this.coldotTarget = "coldot_topleft";
            } else if ($target.hasClass("coldot_topright")) {
                this.coldotTarget = "coldot_topright";
            } else if ($target.hasClass("coldot_bottomright")) {
                this.coldotTarget = "coldot_bottomright";
            }

            $(window).on("mousemove", this._mdMOVE);
            $(window).on("mouseup", this._mdSTOP);
            if ('onlosecapture' in this._wrap[0]) {
                $(this._wrap).on("losecapture", this._mdSTOP);
                this._wrap[0].setCapture();
            }
            $(window).on("blur", this._mdSTOP);
            evt.preventDefault();
        };
        //拖动函数
        function move(evt) {
            var newW, newH;
            switch (this.coldotTarget) {
                case "coldot_topleft":
                    newW = this._mdWidth - (evt.pageX - this._mdPageX);
                    newH = this._mdHeight - (evt.pageY - this._mdPageY);
                    break;
                case "coldot_topright":
                    newW = this._mdWidth + (evt.pageX - this._mdPageX);
                    newH = this._mdHeight - (evt.pageY - this._mdPageY);
                    break;
                case "coldot_bottomright":
                    newW = this._mdWidth + (evt.pageX - this._mdPageX);
                    newH = this._mdHeight + (evt.pageY - this._mdPageY);
                    break;
                default:
                    ;
            }

            this._img.css({width: newW, height: newH});
            this._img.find('img').css({width: newW, height: newH});

            window.getSelection ? window.getSelection().removeAllRanges() : document.selection.empty();
        };
        //停止函数
        function stop(evt) {
            $(window).off("mousemove", this._mdMOVE);
            $(window).off("mouseup", this._mdSTOP);
            if ('onlosecapture' in this._wrap[0]) {
                $(this._wrap).off("losecapture", this._mdSTOP);
                this._wrap[0].releaseCapture();
            }
            $(window).off("blur", this._mdSTOP);
            if (this._editing) {
                //$('img').removeClass().addClass('img_remove_class')
            }
        };
        //_initialize 接收 图片对象
        return function (img) {
            //扩展钩子
            $.each(methods, function (name, method) {
                $(img).off(name, method).on(name, method);
            });
            init.apply(this, arguments);
        }
    })();

    //拖动旋转扩展
    ImgTrans.prototype._initialize = (function () {
        var init = ImgTrans.prototype._initialize,
            methods = {
                "init": function (evt, imgTransInstance) {
                    imgTransInstance._mrX = imgTransInstance._mrY = imgTransInstance._mrRadian = 0;
                    imgTransInstance._mrSTART = $.proxy(start, imgTransInstance);
                    imgTransInstance._mrMOVE = $.proxy(move, imgTransInstance);
                    imgTransInstance._mrSTOP = $.proxy(stop, imgTransInstance);
                    $('.coldot_roll', imgTransInstance._wrap).on("mousedown", imgTransInstance._mrSTART);
                },
                "dispose": function (evt, imgTransInstance) {
                    $('.coldot_roll', imgTransInstance._wrap).off("mousedown", imgTransInstance._mrSTART);
                    imgTransInstance._mrSTOP();
                    imgTransInstance._mrSTART = imgTransInstance._mrMOVE = imgTransInstance._mrSTOP = null;
                }
            };
        //开始函数
        function start(evt) {
            //缩放比例
            var percent = 1;
            var style = $('.exam_wood').css('transform');
            if (style != undefined) {
                var arr = style.split('(');
                if ($.isArray(arr) && arr.length > 1) {
                    percent = arr[1].split(',')[0];
                }
            }
            var rect = $(this._wrap).offset();
            //div * 缩放比的一半即为旋转中心点
            this._mrX = rect.left + $(this._wrap).width() / 2 * percent;
            this._mrY = rect.top + $(this._img).height() / 2;
            this._mrRadian = Math.atan2(evt.clientY - this._mrY, evt.clientX - this._mrX) - this._radian;
            $(window).on("mousemove", this._mrMOVE);
            $(window).on("mouseup", this._mrSTOP);
            if ('onlosecapture' in this._wrap[0]) {
                $(this._wrap).on("losecapture", this._mrSTOP);
                this._wrap[0].setCapture();
            }
            $(window).on("blur", this._mrSTOP);
            evt.preventDefault();
        };
        //拖动函数
        function move(evt) {
            this.rotate(Math.atan2(evt.clientY - this._mrY, evt.clientX - this._mrX) - this._mrRadian);
            window.getSelection ? window.getSelection().removeAllRanges() : document.selection.empty();
        };
        //停止函数
        function stop(evt) {
            $(window).off("mousemove", this._mrMOVE);
            $(window).off("mouseup", this._mrSTOP);
            if ('onlosecapture' in this._wrap[0]) {
                $(this._wrap).off("losecapture", this._mrSTOP);
                this._wrap[0].releaseCapture();
            }
            $(window).off("blur", this._mrSTOP);
        };
        //_initialize 接收 图片对象
        return function (img) {
            //扩展钩子
            $.each(methods, function (name, method) {
                $(img).off(name, method).on(name, method);
            });
            init.apply(this, arguments);
        }
    })();

    var LONG_ZERO_STR = "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
    var SN_REG = new RegExp('((\\d+[.\\d]*)[Ee]{1}([+-]?)(\\d+))', 'ig');
    var convertToFloat = function (number) {
        if (!number) return number;

        var numberStr = number.toString();
        if ((numberStr.indexOf('E') != -1) || (numberStr.indexOf('e') != -1)) {
            var result = new RegExp('^((\\d+[.\\d]*)[Ee]{1}([+-]?)(\\d+))$', 'ig').exec(number);

            if (result != null) {
                var n = result[2], s = result[3], p = result[4];
                if (s === '+') {
                    var pointIndex = Math.max(n.indexOf("."), 0);
                    n = n.replace('.', '');
                    n = n + LONG_ZERO_STR.substring(0, Math.min(LONG_ZERO_STR.length, p) - (n.length - pointIndex) - 1);

                    return n;
                } else {
                    var pointIndex = n.indexOf(".");
                    n = n.replace('.', '');
                    if (pointIndex < 0) {
                        n = "0." + LONG_ZERO_STR.substring(0, Math.min(LONG_ZERO_STR.length, p) - n.length) + n;
                    } else {
                        n = "0." + LONG_ZERO_STR.substring(0, Math.min(LONG_ZERO_STR.length, p) - pointIndex) + n;
                    }

                    return n;
                }
            }
        }

        return number;
    };

    angularAMD.directive('imgTrans', [function () {
        return {
            restrict: 'A',
            scope: {
                description: '=descriptionData',
                triggerEvent: '@triggerEvent',
                imgTransSelfPosition: '@imgTransSelfPosition' //是否由自己定位
            },
            controller: ['$scope', '$filter', function ($scope, $filter) {
                $scope.imgSrc = $filter("filterRefPath")($scope.description.asset);
            }],
            //templateUrl: 'components/directive-custom/image-transform/image-transform.html',
            link: function ($scope, element, attrs) {
                if (angular.isObject($scope.description.other)) {
                    element.attr($scope.description.other);
                }

                function writeAttr2Descriprtion() {
                    $scope.description.other = {};
                    element.attr('radian') && ($scope.description.other.radian = element.attr('radian'));
                    element.attr('x') && ($scope.description.other.x = element.attr('x'));
                    element.attr('y') && ($scope.description.other.y = element.attr('y'));
                    element.attr('zoom') && ($scope.description.other.zoom = element.attr('zoom'));
                    element.attr('original') && ($scope.description.other.original = element.attr('original'));
                    element.attr('vertical') && ($scope.description.other.vertical = element.attr('vertical'));
                    element.attr('horizontal') && ($scope.description.other.horizontal = element.attr('horizontal'));
                    //img 去除 top margin-top
                    element.attr('style') && ($scope.description.other.style = element.clone(true).css('top', '').css('margin-top', '').attr('style'));
//                      element.css('transform') && ($scope.description.other.style = 'transform:'+element.css('transform'));

                    //transform webkit兼容性处理、matrix科学计数法问题处理
                    if ($scope.description.other.style && $scope.description.other.style.indexOf("transform") > -1) {
                        if ($scope.description.other.style.indexOf("-webkit-transform") === -1) {
                            var webkitTransform = $scope.description.other.style.replace("transform", "-webkit-transform");
                            $scope.description.other.style = $scope.description.other.style + ";" + webkitTransform;
                        }

                        $scope.description.other.style = $scope.description.other.style.replace(SN_REG, function ($0) {
                            return convertToFloat($0);
                        });
                    }
                }

                var options = {
                    imgSrc: $scope.imgSrc,
                    triggerEvent: $scope.triggerEvent || 'dblclick',
                    triggerSource: attrs.triggerSource,
                    needCreateBtns: false,
                    actionSelectors: $scope.$eval(attrs.imgTransActionSelectors)
                };

                if ($scope.description.asset_type == 'image') {
                    options.triggerEventHandler = function (isEditing) {
                        if (isEditing) {
                            element.parent().bind('mouseleave', function () {
                                writeAttr2Descriprtion();
                            });
                        } else {
                            writeAttr2Descriprtion();
                            element.parent().unbind('mouseleave');
                        }
                    };
                }

                //$scope.imgTrans = 
                new ImgTrans(element, options);

                //是否自动定位： imgTransSelfPosition为true时，不进行自动定位
                if (!$scope.imgTransSelfPosition || $scope.imgTransSelfPosition == 'false') {
                    //水平垂直居中、img和div同高同宽 ：定时器
                    var timer = window.setInterval(function () {
                        if (element.outerHeight() > 6) {
                            element.css('top', '50%');
                            element.css('margin-top', -element.outerHeight() / 2);
                            //element.find('img').removeClass().addClass('img_remove_class');
                            element.find('img').css({width: element.width(), height: element.height()});
                            clearInterval(timer);
                        }
                    }, 10);
                } else {
                    window.setTimeout(function () {
                        //通过三角点拖动改变大小的反写
                        if ($scope.description.other && $scope.description.other['style'] && $scope.description.other['style'].indexOf('width') > -1) {
                            element.find('img').css({width: element.width(), height: element.height()});
                        }
                    }, 10);
                }
            }
        };
    }])
});