var Path = require("path");
var Fs = require("fs")
var checkDir = function(filepath, callback){
    Fs.stat(filepath, function(err,stats){
        if(err){
            mkdir(filepath, callback);
        } else{
            callback();
            return;
        }
    });
}
var mkdir = function(filepath, callback){
    var parentDir = Path.dirname(filepath);
    checkDir(parentDir, function(){
        Fs.mkdir(filepath, 777, callback);
    })
}
exports.checkDir = checkDir;
exports.mkdir = mkdir;

