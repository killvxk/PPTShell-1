/**
 * Created by Administrator on 2015/4/2.
 */
define(['angularAMD'], function (angularAMD) {
    'use strict';
    angularAMD
        .constant('keyTokenInfo', 'CUSTOM_EDITOR_TOKEN_INFO')
        .constant('keyTokenInfoEncrypt', '13465c85caab4dfd8b1cb5093131c6d0')
        .service('UserDataService', ['$window', 'keyTokenInfo', '$rootScope','keyTokenInfoEncrypt', '$stateParams', 'CustomEditorService',
            function (win, keyTokenInfo, $rootScope,keyTokenInfoEncrypt,$stateParams, CustomEditorService) {
                return {
                    setTokenInfo: function (strData) {
                        strData = CryptoJS.TripleDES.decrypt(decodeURIComponent(strData), keyTokenInfoEncrypt).toString(CryptoJS.enc.Utf8);
                        win.sessionStorage.setItem(keyTokenInfo, strData);
                        $rootScope.token_info = JSON.parse(strData);
                    },
                    remove: function () {
                        win.sessionStorage.removeItem(keyTokenInfo);
                        $rootScope.token_info = undefined; //app.js Line101 angular.isDefined($rootScope.userObj)
                    },
                    getTokenInfo: function () {
                        if (!$rootScope.token_info) {
                            $rootScope.token_info = win.sessionStorage.getItem(keyTokenInfo);
                            if ($rootScope.token_info) {
                                $rootScope.token_info = JSON.parse($rootScope.token_info);
                            }
                        }
                        return  $rootScope.token_info;
                    },
                    /** 设置、获取登录用户信息 END */

                    /***/
                    checkUserActivity: function($btnDescription) {
                        /**
                         * 通过H5 LocalStorage
                         * 判断当前用户($stateParams.token_info)是否[初次打开]该习题编辑器($stateParams.question_type);
                         * 若是，自动弹出题型描述;
                         */
                        //if(win.localStorage) {
                        //    var key = 'Description_';
                        //    if($rootScope.token_info) {
                        //        key += $stateParams.question_type + '&' + $rootScope.token_info.user_id;
                        //    } else {
                        //        key += $stateParams.question_type;
                        //    }
                        //    if(!win.localStorage.getItem(key)) {
                        //        win.localStorage.setItem(key, true);
                        //
                        //        $btnDescription.click();
                        //    }
                        //}
                         CustomEditorService.readQuestionAccessRecord().then(function(data) { //习题本地化 不支持H5的LocalStorage,改用本地文件实现
                             var key = $stateParams.question_type + '_access_timestamp';
                             if(!data || !data.accessRecord || !data.accessRecord[key]) {
                                 var accessRecord;
                                 if(!data || !data.accessRecord) {
                                     accessRecord = {};
                                 } else {
                                     accessRecord = data.accessRecord;
                                 }

                                 accessRecord[key] = new Date().valueOf();
                                 $btnDescription.click();

                                 CustomEditorService.saveQuestionAccessRecord({accessRecord: accessRecord});
                             }
                        }, function(err) {
                             console.log('Error to read question_access_record');
                             console.log(err);
                        });
                    }
                };
        }])
    ;
});