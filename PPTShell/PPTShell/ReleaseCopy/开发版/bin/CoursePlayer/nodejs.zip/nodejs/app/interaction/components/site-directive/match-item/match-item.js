/**
 * Created by px on 2015/6/9.
 */
define(['angularAMD'
], function (angularAMD) {
    angularAMD .directive('matchItem', [ function () {
        return {
            restrict:'E',
            templateUrl:'interaction/components/site-directive/match-item/match-item.html',
            scope: {
            	itemsData:'=itemsData',
            	itemNew:'=itemData',
            	indexNew:'@itemIndex',
            	maxlength:'=maxlength',
            	moduleSubtype:'@',
            	delData:'=',
            	imageSize:'@',
            	isCommonValid:'@',
                /*commonValidParam:'=',*/
                selfValidation:'=',
            	addImage:'&addImage',
            	addText:'&addText'},
            controller:['$rootScope', '$scope','$timeout',function($rootScope, $scope,$timeout){
                $scope.commonValidParam = {
                    imageType:['image/jpg', 'image/jpeg', 'image/webp', 'image/gif', 'image/png', 'image/bmp'],
                    imageSize:1*1024*1024
                };
                var newData = null;
                if($scope.moduleSubtype=='image2text'){
                    newData = {
                        source:{
                            item_type:"image",
                            href:""
                        },
                        target:{
                            item_type:"text",
                            text:""
                        }
                    }
                }else if($scope.moduleSubtype=='image2image'){
                    newData = {
                        source:{
                            item_type:"image",
                            href:""
                        },
                        target:{
                            item_type:"image",
                            href:""
                        }
                    }
                }else{
                    newData = {
                        source:{
                            item_type:"text",
                            text:""
                        },
                        target:{
                            item_type:"text",
                            text:""
                        }
                    }
                }
                if(!$scope.itemNew || !$scope.itemNew.source){
                    angular.copy(newData,$scope.itemsData[$scope.indexNew]);
                }
                $scope.delMatchItem = function(itemOld,index){
                    //至少要有3个。少于三个时的删除，只清空选项的内容，不删除选项
                    if($scope.itemsData.length<=3){
                         angular.copy(newData,itemOld);
                    }else{
                        $scope.itemsData.splice(index,1);
                        $scope.delData.data = angular.copy(itemOld);
                    }
                }
                $scope.clickText = function(data,thisObj){
                    data.isEditText=true
                    $timeout(function(){
                        $(thisObj.target).prev().prev().find("textarea").focus();
                    },100)

                }
                $scope.addAssets = function(type, itemType) {
                	if($scope.addImage) {
                		var isValid = $scope.addImage();
                	}
                }
                $scope.textAreaBlur = function(itemType, $event) {
                	if(itemType == "source") {
                		$scope.itemNew.source.isEditText=false;
                	} else {
                		$scope.itemNew.target.isEditText=false;
                	}
                	
                	if($scope.addText) {
                		var isValid = $scope.addText();
                		if(!isValid) {
                			$timeout(function(){
                                $($event.target).focus();
                            },100);
                		}
                	}
                };
                
                var startTime;
                $scope.onMousedown = function(event) {
                	startTime = new Date().getTime();
                	$(event.target).attr("cancelClick", false);
                };

                $scope.onMouseup = function(event, href) {
                	var interval = new Date().getTime() - startTime;
                	if(interval >= 300) {
                		$(event.target).attr("cancelClick", true);
                		
                		var moduleScope = $rootScope.moduleScope;
                		moduleScope.imagePreviewHref = href.replace("?size=" + $scope.imageSize, "?");
                		moduleScope.isImagePreview = true;
                		
                		return false;
                	}
                };

                $scope.editorText = function(data,thisObj){
                    data.isEditText=true
                    $timeout(function(){
                        $(thisObj.target).closest(".itemcon").find("textarea").focus();
                    },100)
                };
            }]
        };
    }])

});