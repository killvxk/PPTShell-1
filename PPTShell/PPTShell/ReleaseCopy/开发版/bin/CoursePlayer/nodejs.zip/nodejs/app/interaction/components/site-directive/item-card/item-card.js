/**
 * Created by lxq on 2015/7/29.
 */
define(['angularAMD'
], function (angularAMD) {
    angularAMD .directive('itemCard', [ function () {
        return {
            restrict:'E',
            templateUrl:'components/site-directive/item-card/item-card.html',
            scope: {
            	cardList:'=cardList',
            	cardData:'=cardData',
            	typeColumn:'@', 
            	contentColumn:'@', 
            	maxlength:'=maxlength', 
            	imageSize:'@',
            	isCommonValid:'@',
                commonValidParam:'='
            },
            controller:['$scope','$timeout',function($scope,$timeout){
                $scope.removeCard = function() {
                	var cardIndex = $.inArray($scope.cardData, $scope.cardList);
                	if(cardIndex > -1) {
                		$scope.cardList.splice(cardIndex, 1);
                	}
                }
                
                $scope.textAreaBlur = function() {
                	$scope.cardData.isEditText=false;
                }
                
                $scope.addAssets = function() {
                	
                }
                
                $scope.clickText = function($event) {
                	$scope.cardData.isEditText=true
                    $timeout(function(){
                        $($event.target).prev().find("textarea").focus();
                    },100)
                }
            }]
        };
    }])

});