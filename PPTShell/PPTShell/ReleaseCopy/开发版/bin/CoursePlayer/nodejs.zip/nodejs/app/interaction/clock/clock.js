/**
 * clock
 * 2015-12-16 10:59:43
 */

define(['app', 'clock/directive/clock.directive'], function (app) {
    'use strict';
    app.controller('clock_ctrl', [
        '$scope', 'skin_service', '$stateParams', 'CustomEditorService', '$rootScope', '$filter',
        function ($scope, skin_service, $stateParams, CustomEditorService, $rootScope, $filter) {
            $rootScope.moduleScope = $scope;
            $scope.errorModel = {};
            $scope.clock = {
                placeholder: {title: "请输入标题"},
            }

            $scope.model = {
                "id": "",
                "module_code": "nd_clock", // 题目类型
                "title": "", //标题
                "skin": {
                    code: "wood",
                    css_url: "",
                    name: $filter('translate')('app.skin.wood'),
                    package_url: ""
                },
                "timer": {
                    "timer_type": "sequence",  //计时器类型: ["sequence", "countdown"]
                    "time_minute": "0",    //倒计时初始设置-分钟，timer_type="countdown"时有效
                    "time_second": "0"     //倒计时初始设置-秒，timer_type="countdown"时有效
                },
                "properties": [	//模块静态数据模型
                    {
                        "name": "question_id",
                        "display_name": "题目ID",
                        "type": "string",
                        "value": "",
                        "is_localized": false
                    },
                    {
                        "name": "question_url",
                        "display_name": "题目内容",
                        "type": "jsonFile",
                        "value": "",
                        "is_localized": false
                    }
                ],
                "content": {
                }
            };

            //数据加载
            var loadingData = function (id) {
                $scope.isloadingData = true;
                CustomEditorService.getQuestionInfoById(id)//删除_V2
                    .then(function (rtnData) {
                        if (!rtnData) {
                            $scope.errorModel.errorText = $filter('translate')('app.unvalidno');
                        } else {
                            if (rtnData.skin.code != '') {
                                $scope.model = $scope.decodeData(rtnData, true);
                            } else {
                                $scope.model.id = rtnData.id;
                            }

                            try{
                                AddonClockThree_create().initClock($scope.model.content.isLink,$scope.model.content.showOuterDivision,$scope.model.content.showSeconds,$scope.model.content.hourDegree,$scope.model.content.minDegree,$scope.model.content.secondDegree);
                            }catch(e) {
                            }

                            skin_service.set_skin_by_code($scope.model.skin.code, "v1");
                            $scope.errorModel.errorText = "";
                            $scope.isloadingData = false;
                        }
                    }, function (error) {
                        $scope.errorModel.errorText = $filter('translate')('app.question.get.error');
                    })
            };

            //入口
            if (!$stateParams.id) { //新增
                skin_service.set_skin_by_code($scope.model.skin.code, "v1");
            } else { //修改
                loadingData($stateParams.id);
            }

            $scope.$on('changgedSkin', function () {
                $rootScope.scaleHtml();
            });

            //数据验证
            $scope.validPostData = function () {

                return true;
            };

            //数据模型-编码
            $scope.encodeData = function (model) {
                var addon = AddonClockThree_create();
                var temp = $(addon.view);
                model.content.isLink = addon.config.isLink;
                model.content.showOuterDivision = addon.config.showOuterDivision;
                model.content.showSeconds = addon.config.showSeconds;
                model.content.hourDegree = addon.getHourDegree(temp.find('.hour_hand'));
                model.content.minDegree = addon.getDegree(temp.find('.minute_hand'));
                var secondAngle = addon.getDegree(temp.find('.second_hand'));
                if(!addon.config.showSeconds) {
                    model.content.secondDegree = (addon.time.current.getSeconds() * 6 + 90) % 360;
                } else {
                    model.content.secondDegree = secondAngle;
                }
                return model;
            };

            //数据模型-解码
            $scope.decodeData = function (model, isInitLoad) {
                return model;
            };
        }
    ]);
});
