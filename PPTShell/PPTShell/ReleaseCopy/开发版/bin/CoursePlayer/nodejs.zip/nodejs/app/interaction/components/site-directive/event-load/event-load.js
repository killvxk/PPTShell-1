/**
 * HTML节点加载指令
 * 
 */
define(['angularAMD'
], function (angularAMD) {
    angularAMD.directive('eventLoad', [ function () {
        return {
			restrict: 'A',
			scope: { onLoad:'&' },
            link: function(scope, element, attr, ng) {
            	if(scope.onLoad) {
	            	element.on('load', function(){
						var phase = scope.$root.$$phase;
						if (phase == '$apply' || phase == '$digest') {
							scope.onLoad();
						} else {
							scope.$apply(scope.onLoad);
						}
	            	});
            	}
            }
        };
    }]);

});
