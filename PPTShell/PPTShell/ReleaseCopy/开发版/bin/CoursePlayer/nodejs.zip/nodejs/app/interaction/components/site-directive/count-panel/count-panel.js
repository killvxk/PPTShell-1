/**
 * Created by zy on 2015/7/6.
 */
define(['angularAMD'
], function (angularAMD) {

    angularAMD.directive('countPanel', [ function () {
        return {
            restrict:'E',
            templateUrl:'components/site-directive/count-panel/count-panel.html',
            scope: {
                inputData:'=countData',
                error:'=error'
            },
            replace: true,
            link:function(scope,element,attrs){
            	

            	var cArr = ['0','1','2','3','4','5','6','7','8','9','×','+','','-','','÷'] ; 
                scope.keybaord = function(){
                	var keyCode = window.event.keyCode ;
                	if( keyCode>=96 && keyCode<108 || keyCode === 109 || keyCode === 111 ){
                		var c = cArr[keyCode-96] ; 
                		if(!scope.getNum(c)){
                    		window.event.preventDefault();
                    		window.event.stopPropagation();	
                		} ; 
                	}else if(  keyCode==8 ){
                		
                	}else {
                		window.event.preventDefault();
                		window.event.stopPropagation();
                	}
                }
                
            	var numReg = /[×÷+-]/ ; 
                scope.getNum = function(c){
                	
                	

                    var n=scope.inputData.search(numReg);
                    if( n>-1 && scope.inputData.length > n ){
                    	scope.error = false ;               	
                    
                    }
                	
                    
            		if(!scope.inputData){
            			if(/(^0|[×÷+-])/.test(c)) return  false; 
            		}
            		var flag = numReg.test(c) ; 
            		//如果连续输入运算符要替换
            		if(flag){

                			if(/[×÷+-]$/.test(scope.inputData)){
                				scope.inputData = scope.inputData.replace(/[×÷+-]$/,c)
                				return false; 
                			}else if(numReg.test(scope.inputData )) {
                				return false; 
                			}
            			
            		}else{
            			var l =  scope.inputData.length
            			var strNum  =  l>=6?scope.inputData.substring(l-5,l):scope.inputData;
            			if( l>=5 && /^\d{5}$/.test(strNum)){
            				return false; 
            			}
            			if(/[×÷+-]$/.test(scope.inputData) && c === '0' ){
            				return false;
            			}            			
            			
            		}
            		scope.inputData=scope.inputData+c;
                    
                };
                
//                scope.$watch('error',function(newValue,oldValue){
//                	debugger;
//                	console.log('error',newValue,oldValue);
//                });
                //退格删除
                scope.deleteNum=function(){
                    scope.inputData=scope.inputData.replace(/.$/,'');
                }
            }
        };
    }])

});
