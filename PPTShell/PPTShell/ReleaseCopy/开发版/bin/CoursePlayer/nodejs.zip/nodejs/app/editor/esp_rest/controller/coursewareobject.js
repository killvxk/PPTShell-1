/**
 * Created by ChenST on 2016/1/18.
 */

var fs = require('fs');
var Q = require('q');
var uuid = require('node-uuid');
var ncp = require('ncp').ncp;
var DOMParser = require('xmldom').DOMParser;
var xpath = require('xpath');
var util = require('util');
var Form = require('multiparty').Form;
var path = require('path');
var mime = require('mime');
var Manager = require('./../support/manager').Manager;
var Template = require('./../support/template').Template;
var espUtil = require('./../support/esp-utils').espUtil;
var fsExtend = require('./../support/fs-ext');
var assetSup = require('./../support/asset-sup');

var ASSET_DIR = 'assets';

var fail = function (res, err) {
    if (err) {
        // 如果是数组,只需发送第一个错误.
        if (util.isArray(err)) {
            return res.status(500).send(err[0]);
        }
        return res.status(500).send(err);
    }
};

var ok = function (res, data, type) {
    if (data) {
        if (type === 'json') {
            return res.json(data);
        } else if (type === 'xml') {
            res.set('Content-Type', 'application/xml');
            res.send(data);
        } else {
            res.send(data);
        }

    } else {
        return res.send();
    }
};

/* * * * * * * * * * * * * * * * * {REST-API-METHOD} * * * * * * * * * * * * * * * */

/**
 * 创建颗粒.
 * @param req
 * @param res
 */
var create = function (req, res) {

    var metadata = req.body || {};
    var objectId = uuid.v4();
    var manager = new Manager(objectId);
    var template = new Template('empty', true);

    ncp.limit = 1;
    Q.nfcall(ncp, template.templateDir, manager.resourceDir).then(function () {

        metadata.identifier = objectId;

        Q.nfcall(fs.writeFile, manager.metadataJsonPath(), JSON.stringify(metadata)).then(function () {
            ok(res, metadata);
        }).catch(function (err) {
            fail(res, err);
        });

    }).catch(function (err) {
        fail(res, err);
    });
};

/**
 * 通过模版创建颗粒.
 * @param req
 * @param res
 */
var createFromTemplate = function (req, res) {
    var tempalteCode = req.query.template_code || 'blank';
    var objectId = uuid.v4();

    var manager = new Manager(objectId);
    var template = new Template(tempalteCode);

    ncp.limit = 1;
    Q.nfcall(ncp, template.templateDir, manager.resourceDir, {
        filter: function (src) {
            // editor-config.js 和 logo.png 不用拷贝.
            if (path.join(template.templateDir, 'editor-config.js') === src) {
                return false;
            }

            if (path.join(template.templateDir, 'logo.png') === src) {
                return false;
            }

            return true;
        }
    }).then(function () {

        Q.nfcall(fs.readFile, manager.metadataJsonPath(), 'utf-8').then(function (data) {
            // 填充元数据.
            var metadata = JSON.parse(data);
            metadata.identifier = objectId;
            metadata.custom_properties.template_code = tempalteCode;

            return metadata;
        }).then(function (metadata) {
            // 写回元数据.
            Q.nfcall(fs.writeFile, manager.metadataJsonPath(), JSON.stringify(metadata)).then(function () {
                ok(res, metadata);
            });
        }).catch(function (err) {
            fail(res, err);
        })
    }).catch(function (err) {
        fail(res, err);
    });

};

/**
 * 获取颗粒元数据.
 * @param req
 * @param res
 */
var get = function (req, res) {
    var objectId = req.params.id;
    var manager = new Manager(objectId);

    Q.nfcall(fs.readFile, manager.metadataJsonPath(), 'utf-8').then(function (data) {
        var metadata = JSON.parse(data);
        // FIXME 临时添加..
        metadata.physics_path = manager.resourceDir;
        ok(res, metadata);
    }, function (err) {
        fail(res, err);
    });

};

/**
 * 获取Main.
 * @param req
 * @param res
 */
var getMain = function (req, res) {
    var objectId = req.params.id;
    var manager = new Manager(objectId);

    Q.nfcall(fs.readFile, manager.mainPath(), 'utf-8').then(function (data) {
        ok(res, data, 'xml');
    }, function (err) {
        fail(res, err);
    });

};

function doGenerateSdpPackage(objectId, mainContent) {

    var manager = new Manager(objectId);

    var doc = new DOMParser().parseFromString(mainContent);

    var pageNodes = xpath.select('/coursewareObject/pages/page', doc);

    // 打包对象.
    var sdpPackage = {
        version: 'v0.1',
        targets: [
            {
                name: 'default',
                adds: [{src: '*'}],
                groups: []
            }
        ]
    };


    var mainGroup = {name: 'main.xml', adds: []};
    var groups = [];

    var promises = [];
    var pageIds = [];

    for (var i = 0; i < pageNodes.length; i++) {
        (function (i) {
            var pageId = pageNodes[i].getAttribute('id');
            pageIds.push(pageId);
            promises.push(Q.nfcall(fs.readFile, manager.pagePath(pageId), 'utf-8'));
        })(i);
    }

    // 并行执行.
    Q.all(promises).then(function (pagContents) {

        for (var i = 0; i < pagContents.length; i++) {
            var pageId = pageIds[i];
            mainGroup.adds.push({type: 'file', src: manager.relativePagePath(pageId)});

            var pageGroup = {name: pageIds[i], adds: []};
            //获取page的resources.
            var pageContent = pagContents[i];
            var pageDoc = new DOMParser().parseFromString(pageContent);
            var resourceNodes = xpath.select('/page/modules/module/resources/resource', pageDoc);

            for (var j = 0; j < resourceNodes.length; j++) {
                (function (j) {
                    var type = resourceNodes[j].getAttribute('type');
                    var href = resourceNodes[j].getAttribute('href');
                    // 取得资源的依赖.
                    var depency = espUtil.pack.resourceDependency(type, href);
                    pageGroup.adds.push(depency);
                })(j)

            }
            groups.push(pageGroup);
        }

        groups.push(mainGroup);

        sdpPackage.targets[0].groups = groups;

        return sdpPackage;
    }).then(function (sdpPackage) {

        var sdpPackageXml = espUtil.pack.generateSdpPackage(sdpPackage);

        Q.nfcall(fs.writeFile, manager.sdpPackagePath(), sdpPackageXml).then(function () {
            console.log('sdp-package-success');
        }).catch(function (err) {
            console.log(err);
        })

    }).catch(function (err) {
        console.log(err)
    });

}

/**
 * 更新Main.
 * @param req
 * @param res
 */
var updateMain = function (req, res) {
    var objectId = req.params.id;
    var mainContent = req.body;
    var manager = new Manager(objectId);

    Q.nfcall(fs.writeFile, manager.mainPath(), mainContent).then(function () {

        // FIXME 生成sdp-package.xml(异步).
        //  doGenerateSdpPackage(objectId, mainContent);

        ok(res);
    }, function (err) {
        fail(res, err);
    });

};

/**
 * 获取Page的Xml内容.
 * @param req
 * @param res
 */
var getPage = function (req, res) {
    var objectId = req.params.id;
    var pageId = req.params.pageId;
    var manager = new Manager(objectId);

    Q.nfcall(fs.readFile, manager.pagePath(pageId), 'utf-8').then(function (data) {
        ok(res, data, 'xml');
    }, function (err) {
        fail(res, err);
    });

};

/**
 * 创建页面.
 * @param req
 * @param res
 */
var createPage = function (req, res) {
    var objectId = req.params.id;
    var pageId = uuid.v4();
    var pageContent = req.body;

    var manager = new Manager(objectId);

    Q.nfcall(fs.writeFile, manager.pagePath(pageId), pageContent).then(function () {
        ok(res, pageId);
    }, function (err) {
        fail(res, err);
    });

};
/**
 * 更新Page的内容.
 * @param req
 * @param res
 */
var updatePage = function (req, res) {
    var objectId = req.params.id;
    var pageId = req.params.pageId;
    var pageContent = req.body;
    var manager = new Manager(objectId);

    Q.nfcall(fs.writeFile, manager.pagePath(pageId), pageContent).then(function (data) {
        ok(res);
    }, function (err) {
        fail(res, err);
    });

};

/*
 * 自动创建目录.
 */
function autoMkdir(path, callback) {
    Q.nfcall(fs.stat, path).then(callback, function (err) {
        //创建目录.
        Q.nfcall(fs.mkdir, path, 777, callback);
    });
}

function convertResourceFileInfo(objectId, info) {
    var manager = new Manager(objectId);
    var _path = info.path;
    var relativePath = espUtil.util.pathSlice(_path, manager.resourceDir);

    var identifier = path.basename(relativePath);
    var title = identifier.substring(37);
    var metadata = {
        'identifier': identifier,
        'title': title,
        'tech_info': {
            'href': {
                'format': mime.lookup(relativePath),
                'location': relativePath,
                'requirements': []
            }
        }
    };

    // 如果有宽度,添加分辨率.
    if (info.width) {
        metadata.tech_info.href.requirements.push({
            type: "QUOTA",
            name: "resolution",
            value: info.width ? util.format('%s*%s', info.width, info.height) : ''
        });
    }

    return metadata;
}

/**
 * 上传资源文件.
 * @param req
 * @param res
 */
var uploadResourceFile = function (req, res) {
    var objectId = req.params.id;
    var manager = new Manager(objectId);

    // 上传的资源图片放在assets目录下面.
    var savePath = path.join(manager.resourcePath(), ASSET_DIR);

    autoMkdir(savePath, function () {
        var form = new Form({uploadDir: savePath});
        form.parse(req, function (err, fields, files) {

            var file = files.file[0];

            var newName = util.format('%s_%s', uuid.v4(), file.originalFilename);
            var newPath = path.join(ASSET_DIR, newName);

            //进行重命名.
            Q.nfcall(fs.rename, file.path, manager.resourceFilePath(newPath)).then(function () {

                assetSup.parseAsset(manager.resourceFilePath(newPath)).then(function (info) {
                    ok(res, convertResourceFileInfo(objectId, info));
                }).fail(function (err) {
                    fail(res, err);
                });
            }, function (err) {
                fail(res, err);
            })
        });
    });

};

/* * * * * * * * * * * * * * * * * {REST-API-METHOD-FOR-DEBUG} * * * * * * * * * * * * * * * */

/**
 * 拷贝颗粒.
 * @param req
 * @param res
 */
var copy = function (req, res) {
    var objectId = req.params.id;
    var toObjectId = req.query.to || uuid.v4();

    var manager = new Manager(objectId);
    var toManager = new Manager(toObjectId);

    ncp.limit = 1;
    Q.nfcall(ncp, manager.resourceDir, toManager.resourceDir).then(function () {
        ok(res, toObjectId);
    }).catch(function (err) {
        fail(res, err);
    });
};

/**
 * 查找颗粒的资源文件列表.
 * @param req
 * @param res
 */
var searchResourceFiles = function (req, res) {

    var objectId = req.params.id;
    var type = req.query.type || '';
    var manager = new Manager(objectId);

    var searchPath = path.join(manager.resourcePath(), ASSET_DIR);

    Q.nfcall(fsExtend.walk, searchPath).then(function (files) {
        //返回相对路径.
        files = files || [];
        var promises = [];
        for (var i = 0; i < files.length; i++) {

            // 不使用条件.
            if (type === '') {
                promises.push(assetSup.parseAsset(files[i]));
            } else {
                // 使用条件查询.
                var ndCode = assetSup.getNdCode(files[i]);
                if (ndCode === type) {
                    promises.push(assetSup.parseAsset(files[i]));
                }
            }

        }

        //并行执行.
        Q.all(promises).then(function (infos) {
            var items = [];
            infos = infos || [];
            for (var i = 0; i < infos.length; i++) {
                var metadata = convertResourceFileInfo(objectId, infos[i]);
                items.push(metadata);
            }
            ok(res, items);
        }).fail(function (err) {
            fail(res, err);
        });

    }, function (err) {
        fail(res, err);
    });
};

module.exports.create = create;
module.exports.createFromTemplate = createFromTemplate;
module.exports.get = get;
module.exports.getMain = getMain;
module.exports.updateMain = updateMain;
module.exports.getPage = getPage;
module.exports.updatePage = updatePage;
module.exports.createPage = createPage;
module.exports.uploadResourceFile = uploadResourceFile;
module.exports.copy = copy;
module.exports.searchResourceFiles = searchResourceFiles;