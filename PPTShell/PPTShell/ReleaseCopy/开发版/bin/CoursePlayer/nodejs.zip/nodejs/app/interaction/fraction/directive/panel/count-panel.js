/**
 * Created by zy on 2015/7/6.
 */
define(['angularAMD'
], function (angularAMD) {
    angularAMD .directive('countPanel', [ function () {
        return {
            restrict:'E',
            templateUrl:'interaction/fraction/directive/panel/count-panel.html',
            scope: {
                inputData:'=countData',
                nextStep :'=nextStep'
            },
            replace: true,
            link:function(scope,element,attrs){
            	

            	var cArr = ['0','1','2','3','4','5','6','7','8','9','×','+','','-','','/'] ; 
                scope.keybaord = function(){
                	var keyCode = window.event.keyCode ;
                	if( keyCode>=96 && keyCode<108 || keyCode === 109 || keyCode === 111 ){
                		var c = cArr[keyCode-96] ; 
                	
                    		window.event.stopPropagation();	
                		
                	}else if(  keyCode==8 ){
                		
                	}else {
                		window.event.preventDefault();
                		window.event.stopPropagation();
                	}
                }
                scope.keyup = function(){
                	if( /^\d{1,6}\/[1-9]\d{0,5}[+-]\d{1,6}\/[1-9]\d{0,5}$/.test(scope.inputData) === true ){
                		angular.element("#next_step").css({background:"rgb(69, 153, 249)",color: '#FFF'}); 
                    }else {
                    	angular.element("#next_step").css({background:"#FFF",color: '#888'}); 
                    }
                	
                }
                
            	 
                scope.getNum = function(c){
                	

            		if(!scope.inputData){
            			if(/(^0|[\/+-])/.test(c)) return  false; 
            		}
            		var flag = /[+-]/.test(c) ; 
            		//如果连续输入运算符要替换
            		if(flag){

                			if(/[+-]$/.test(scope.inputData)){
                				scope.inputData = scope.inputData.replace(/[+-]$/,c)
                				return false; 
                			}else if(/[+-]/.test(scope.inputData ) || scope.inputData && /[0-9]$/.test(scope.inputData) === false ) {
                				return false; 
                			}
            			
            		}else{
            			var l =  scope.inputData.length
            			var strNum  =  l>=7?scope.inputData.substring(l-6,l):scope.inputData;
            			if( l>=6 && /^\d{6}$/.test(strNum) && /^\d$/.test(c)){
            				return false; 
            			}
            			
            			if(/[\/+-]$/.test(scope.inputData) && c === '0' ){
            				return false;
            				//当最后一个数为数字的时候才可以输入/
            			}else if( scope.inputData && /[0-9]$/.test(scope.inputData) === false  && c === '/' ){
            				return false;
            			}else if(  /\/\d\d*$/.test(scope.inputData) && c === '/'  ){
            				return false;
            			}            			
            			
            		}
            		scope.inputData=scope.inputData+c;
            		scope.keyup();
                    
                };
                
//                scope.$watch('error',function(newValue,oldValue){
//                	debugger;
//                	console.log('error',newValue,oldValue);
//                });
                //退格删除
                scope.deleteNum=function(){
                    scope.inputData=scope.inputData.replace(/.$/,'');
                    scope.keyup();
                }
            }
        };
    }])

});
