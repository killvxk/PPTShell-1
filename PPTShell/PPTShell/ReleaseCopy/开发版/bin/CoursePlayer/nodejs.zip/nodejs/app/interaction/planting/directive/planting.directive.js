define([
    'components/site-directive/assets-select/assets-select',
    'components/site-directive/error-tip/error-tip',
    'components/site-directive/edit-box/new-edit-box',
    'components/site-directive/foot-tool/time-box/new-time-box',
    'components/site-directive/foot-tool/foot-tool'
], function () {

});