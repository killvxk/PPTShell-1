requirejs.config({
	paths:{
		'text' : 'lib/require/2.1.11/require-text',
		'json' : 'lib/require/2.1.11/require-json',
		'css':'lib/require/2.1.11/require-css',

		'jlang':'lib/jlang/1.0.0/jlang',
		'jquery':'lib/jquery/1.11.2/jquery',
		'angular_':'lib/angular/1.4.4/angular',
		'angular':'lib/angular/1.4.4/angular-tool',
		'exception':'lib/exception/1.0.0/exception',
		'prompter':'lib/prompter/1.0.0/prompter',
		'slides':'lib/slides/1.0.0/slides',
		'slides-angular':'lib/slides/1.0.0/slides-angular',
		'plupload':'lib/plu/2.1.2/plupload.full.min',

		'espService':'esp-lib/esp-service/1.3.0/esp-service',
		'espModel':'esp-lib/esp-model/1.3.0/esp-model',
		'espEnvironment':'esp-lib/esp-environment/1.3.0/esp-environment'
	},
	map: {
		'*':{
		}
	},
	shim:{
		'jlang':{
			exports:'jlang'
		},
		'angular_':{
			deps:['jquery'],
			exports:'angular'
		},
		'angular':{
			deps:['angular_'],
			exports:'angular'
		},
		'plupload':{
			exports:'plupload'
		},
		'*':{
			deps:['json!config.json']
		}
	}
});
define('environmentConfig', ['json!config.json'], function (config) {
	var version = config.version;
	if(!version && config.debug === true){
		version = new Date().getTime();
	}
	version && requirejs.config({
		urlArgs:'_version_=' + version
	});
	return config;
});

define('js-library',['jquery', 'espEnvironment'], function ($, espEnvironment) {
	var libraries = {};
	var defaultLibraryVersion = '1.0.0';
	function reqNext(req, paths, i, result, done, fail){
		var path = paths[i];
		if(!path){
			done(result);
			return;
		}
		req([path], function (r) {
			result[i] = r;
			reqNext(req, paths, i + 1, result, done, fail);
		}, function (e) {
			fail(e);
		});
	}
	return {
		load : function(name, req, onLoad, config) {
			var version = defaultLibraryVersion, idx = name.indexOf(':');
			if(idx != -1){
				version = name.substring(idx + 1);
				name = name.substring(0, idx);
			}
			var library = libraries[name];
			if(library){
				if(library.state === 1){
					onLoad(library.exports);
				}else if(library.state === -1){
					onLoad.error(library.exports);
				}else{
					library.waiting.push(onLoad);
				}
				return;
			}
			library = libraries[name] = {version: version, load: 0, waiting: [onLoad]};
			var url = espEnvironment.url.jsLibraryRoot(name, version);
			req(['json!' + url('package.json')], function (packageConfig) {
				var dependencies = packageConfig.dependencies || [],
					scripts = packageConfig.script || [],
					styles = packageConfig.css || [];
				var paths = [];
				$.each(dependencies, function(i, dep){
					var depName, depVersion;
					if(typeof dep === 'string'){
						depName = dep;
						depVersion = defaultLibraryVersion;
					}else{
						depName = dep.name;
						depVersion = dep.version || defaultLibraryVersion;
					}
					depName && paths.push('js-library!' + depName + ':' + depVersion);
				});
				$.each(styles, function(i, style){
					paths.push('css!' + url(style));
				});
				$.each(scripts, function(i, script){
					paths.push(url(script));
				});
				reqNext(req, paths, 0, [], function (result) {
					library.exports = result;
					$.each(library.waiting, function (i, fn) {
						fn(library.exports);
					});
					library.waiting.length = 0;
					library.state = 1;
				}, function (e) {
					library.exports = e;
					$.each(library.waiting, function (i, fn) {
						fn.error(library.exports);
					});
					library.waiting.length = 0;
					library.state = -1;
				});
			}, function (e) {
				onLoad.error(e);
			});
		}
	};
});
