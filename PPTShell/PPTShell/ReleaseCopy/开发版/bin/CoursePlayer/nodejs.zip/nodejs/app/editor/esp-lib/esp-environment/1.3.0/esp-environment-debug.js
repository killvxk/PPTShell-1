/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
], function (
) {
    var servers = {
        coursewareobjectPlayer: 'http://esp-editor.pre1.web.nd',
        cs: 'http://sdpcs.beta.web.sdp.101.com'
    };
    return {
        service: 'file',
        coursewareobjectPreview: servers.coursewareobjectPlayer + '/ndplayer/{id}/show?type=coursewareobject&rnd=1452855109479&startPageIndex=0&player-code=wang&_lang_=zh_CN&userId=2107212393&userName=liaolixia&domain=web.nd',
        modulePresenterRoot: '/presenters/{id}',
        coursewareobjectTemplateRoot: '/coursewareobject_template/{id}',
        coursewareobjectRoot: '/coursewareobject/{id}.pkg',
        moduleEditorRoot: '/modules/{id}',
        referencePath: servers.cs + '/v0.1/static',
        "supports": {
            "asset": false
        }
    };
});