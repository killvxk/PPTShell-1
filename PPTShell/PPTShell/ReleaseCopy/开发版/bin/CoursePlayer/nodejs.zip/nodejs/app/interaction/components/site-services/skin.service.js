/**
 * Created by Administrator on 2015/6/18.
 */
define(['angularAMD'
], function (angularAMD) {
    angularAMD.factory('skin_service', ['CustomEditorService','$rootScope','$q','$stateParams','$http', function (CustomEditorService,$rootScope,$q,$stateParams,$http) {
        //皮肤数据结构
        //    [{
        //        "name": "天空",      //皮肤名称
        //        "code": "sky",      //皮肤标识
        //        "css_url": "sky/sky.css",   //css地址
        //        "package_url": "/assets/skin/"//打包下载地址
        //    }]
        var skins = null,
            requesting=false;//get_skins中用来控制是否发起请求
        //服务公开的方法
        var publicFun = {
            remove_all_skin: function () {
                angular.element(".themecss").remove();
            },
            get_skins: function () {
                var defered = $q.defer(),interval = 0;
                if(!skins){
                    if(!requesting){
                        requesting = true;

                        //CustomEditorService.getSkins()
                        $http.get('/interaction/components/site-directive/select-skin/skin.json').then(function(d){
                            skins = d.data[$stateParams.area]||[];
                            requesting = false;
                        },function(err,a,b,c){
                            requesting = false;
                            window.console && console.log(err);
                        });
                    }

                    interval = setInterval(function(){
                        if(skins){
                            clearInterval(interval);
                            defered.resolve(skins);
                        }
                    },20);
                }else{
                    defered.resolve(skins);
                }
                return defered.promise;
            },
            set_skin: function (skin,version) {
            	if(!version){
            		version = '' ; 
            	}else{
            		version = '_'+version;
            	}
                this.remove_all_skin();

                //用本地站点下的样式和样式图片 内容服务上只放给module用的
//                var css_url = '/'+ $stateParams.area+'/assets/css/'+skin.code+'.css';
                //20150716 国际化处理
                var lang = $stateParams._lang_;
                if($stateParams._lang_) {
                	if($stateParams._lang_.indexOf("es_") == 0) {
                		lang = "es";
                	}
                } else {
                	lang = "zh_CN";
                }
                
                //设置公共皮肤样式
                var css_url = 'interaction/i18n/'+ lang + '/common/assets/css/'+skin.code+version+'.css';
                var style = angular.element("<link>", {
                    'rel': 'stylesheet',
                    'class': 'themecss',
                    'type':'text/css',
                    'href': css_url
                });
                angular.element("head").append(style);
                
                //设置各自皮肤样式
                css_url = 'interaction/i18n/'+ lang + '/' + $stateParams.area+'/assets/css/'+skin.code+'.css';
//                console.log("css url is ",css_url);
                style = angular.element("<link>", {
                    'rel': 'stylesheet',
                    'class': 'themecss',
                    'type':'text/css',
                    'href': css_url
                });
                style.bind('load',function(){
                	$rootScope.$broadcast('changgedSkin');
                });
                angular.element("head").append(style);
            },
            set_skin_by_code: function (code,version) {
//            	console.log("code is ",code,skins);
                var that = this;
                if(!skins){
                    this.get_skins().then(function(data){
//                    	console.log("code is ",code,data);
                        for(var i= 0;i<data.length;i++){
                            if(code == data[i].code){                            	
                                that.set_skin(data[i],version);
                            }
                        }
                    });
                }else{
                    for(var i= 0;i<skins.length;i++){
                        if(code == skins[i].code){
                            that.set_skin(skins[i],version);
                        }
                    }
                }
            }
        };

        //$rootScope.$digest();
        return publicFun;
    }]);
});