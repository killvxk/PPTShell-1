/**
 * Created by px on 2015/6/11.
 */

define(['angularAMD'], function (angularAMD) {
    angularAMD.directive('timeBox', [function () {
        return {
            restrict: 'EA',
            templateUrl: 'interaction/components/site-directive/time-box/time-box.html',
            scope: false,
            replace:true
        };
    }])
});