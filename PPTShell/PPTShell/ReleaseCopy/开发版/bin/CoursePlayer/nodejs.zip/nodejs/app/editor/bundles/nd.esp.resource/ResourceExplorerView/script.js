define(['angular'],function(angular){
	return function(){
		this.name = 'nd.esp.resource.ResourceExplorerView';
		this.title = 'Resource Explorer';
		var typeDefs = [];
		this.registerType = function(typeDef){
			if($.isArray(typeDef)){
				for(var i=0;i<typeDef.length;i++){
					this.registerType(typeDef[i]);
				}
			}else{
				if($.isFunction(typeDef)){
					typeDef = new typeDef();
				}
				typeDefs.push(typeDef||{});
			}
		};
		this.render = function(view){
			angular.quickstart(view.getElement(),{
				templateUrl:'bundles/nd.esp.resource/ResourceExplorerView/template.html',
				controller:['$scope', function($scope){
					$scope.iconBaseUrl = 'bundles/nd.esp.resource/ResourceExplorerView/images/';
					$scope.resourceTypes = typeDefs;
					/*$scope.resourceTypes = [{
						name:'courseware',
						title:'课件',
						icon:'courseware.png',
					},{
						name:'assessment',
						title:'习题',
						icon:'exercises.png',
					},{
						name:'image',
						title:'图片',
						icon:'picture.png',
					},{
						name:'audio',
						title:'音频',
						icon:'audio.png',
					},{
						name:'video',
						title:'视频',
						icon:'video.png',
					},{
						name:'flash',
						title:'Flash',
						icon:'flash.png',
					}];*/
				}]
			});
		};
	};
});