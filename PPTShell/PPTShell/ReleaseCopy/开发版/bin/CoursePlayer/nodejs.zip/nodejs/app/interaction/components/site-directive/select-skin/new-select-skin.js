/**
 * Created by tyx on 2015/6/11.
 */
define(['angularAMD'
], function (angularAMD) {
    angularAMD.directive('newSelectSkin', ['skin_service','$stateParams', function (skin_service,$stateParams) {
        return {
            restrict: 'EA',
            scope: {},
            templateUrl: 'interaction/components/site-directive/select-skin/new-select-skin.html',
            replace:true,
            link: function ($scope, element, attrs) {
                var pageScope = $scope.$parent.originScope;
                skin_service.get_skins().then(function (data) {
                    $scope.list = data;
                    angular.forEach($scope.list,function(item){
                        item.cover_url = 'interaction/'+ $stateParams.area+'/assets/css/'+item.code+'.png?'+require.s.contexts._.config.urlArgs;
                    });
                });

                $scope.selectSkin = function (skin) {                    

                    skin_service.set_skin(skin);

                    //皮肤数据存到题型module中
                    angular.extend(pageScope.model.skin, skin);
                    //关闭popup
                    $scope.$parent.$parent.hide();
                }
            }
        };
    }])

});