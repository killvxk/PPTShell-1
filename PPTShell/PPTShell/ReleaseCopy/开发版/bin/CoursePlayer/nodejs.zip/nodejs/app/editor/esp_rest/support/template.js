/**
 * Created by ChenST on 2016/1/18.
 */

var config = require('./../config').config;
var path = require('path');
var util = require('util');

var Template = function (templateCode, isSystem) {
    // 如果系统自带,从内部找.
    if (isSystem) {
        this.templateDir = path.join(__dirname, '..', 'template', templateCode);
    } else {
        this.templateDir = path.join(__dirname, '..', '..', 'coursewareobject_template', templateCode);
    }

}

module.exports.Template = Template;