
/**
 * Created by px on 2015/06/25.
 */
define(['angularAMD',
    'components/site-directive/assets-select/assets-select',
    'components/site-directive/error-tip/error-tip',
    'components/site-directive/edit-box/new-edit-box',
    'components/site-directive/foot-tool/time-box/new-time-box',
    'components/site-directive/foot-tool/foot-tool',
    'components/site-directive/select-skin/select-skin',
    'components/site-directive/contenteditable/contenteditable',
    'components/site-directive/image-transform/image-transform',
    'table/directive/description/description',
    'table-options',
    'table/directive/setting/setting'
], function (angularAMD) {
    angularAMD
        .directive('limitMaxLength', [ function () {
            return {
                restrict: 'A',
                scope: { maxlength : "=maxlength" , 'dataValue':"=dataValue"},
                link: function(scope, element) {
                    element.on('keyup',function(e){
                        // console.log(e.keyCode);
                        var str = element.html();
                        if(e.keyCode===13 &&  str.length>scope.maxlength){
                            element.html(str.substr(0,scope.maxlength));
                        }

                        if(str.length>scope.maxlength && /([\u4e00-\u9fa5]|[\uFE30-\uFFA0])$/.test(str)){
                            element.html(str.substr(0,scope.maxlength));
                            //element .select() ;
                            var range = document.createRange();
                            var sel = window.getSelection();
                            range.setStart(element[0].childNodes[0], scope.maxlength);
                            range.collapse(true);
                            sel.removeAllRanges();
                            sel.addRange(range);
                        }
                    });
                    var oper = true ;
                    element[0].onkeypress = function(e){
                        console.log('keyCode',e.keyCode)
                        oper = true ;
                    }
                    element.on('keydown',function(e){
                        oper = false ;
                        //console.log('keydown',element.html())
                        //console.log('keyCode',e.keyCode)
                        if(e.keyCode===13 &&  str.length>scope.maxlength){
                            element.html(str.substr(0,scope.maxlength));
                        }else if( e.keyCode===8){

                        }else if(element.html().length>=scope.maxlength){

                            e.preventDefault();
                            return false;

                        }

                    });
                }
            };

        }])

});