/**
 * balance
 * 2015-10-14 14:24:33
 */
define(['app', 'uuid', 'balance/directive/balance.directive'], function(app, uuid) {
	'use strict';
	app.controller('balance_ctrl', [
		'$scope', 'skin_service', '$stateParams', 'CustomEditorService', '$rootScope', '$filter',
		function($scope, skin_service, $stateParams, CustomEditorService, $rootScope, $filter) {
			$rootScope.moduleScope = $scope;
			$scope.errorModel = {};

			$scope.model = {
				"id": "",
				"module_code": "nd_balance", // 题目类型
				"title": "天平", //标题
				"skin": {
					code: "wood",
					css_url: "",
					name: $filter('translate')('app.skin.wood'),
					package_url: ""
				},
				"timer": {
					"timer_type": "sequence", //计时器类型: ["sequence", "countdown"]
					"time_minute": "0", //倒计时初始设置-分钟，timer_type="countdown"时有效
					"time_second": "0" //倒计时初始设置-秒，timer_type="countdown"时有效
				},
				"properties": [ //模块静态数据模型
					{
						"name": "question_id",
						"display_name": "题目ID",
						"type": "string",
						"value": "",
						"is_localized": false
					}, {
						"name": "question_url",
						"display_name": "题目内容",
						"type": "jsonFile",
						"value": "",
						"is_localized": false
					}
				],
				"content": { //Editor数据模型正文
				}
			};

			//数据加载
			var loadingData = function(id) {
				$scope.isloadingData = true;
				CustomEditorService.getQuestionInfoById(id)
					.then(function(rtnData) {
						if (!rtnData) {
							$scope.errorModel.errorText = $filter('translate')('app.unvalidno');
						} else {
							if (rtnData.skin.code != '') {
								$scope.model = $scope.decodeData(rtnData, true);
							} else {
								$scope.model.id = rtnData.id;
							}

							skin_service.set_skin_by_code($scope.model.skin.code, "v1");
							$scope.errorModel.errorText = "";
							$scope.isloadingData = false;
						}
					}, function(error) {
						$scope.errorModel.errorText = $filter('translate')('app.question.get.error');
					})
			};

			//入口
			if (!$stateParams.id) { //新增
				skin_service.set_skin_by_code($scope.model.skin.code, "v1");
			} else { //修改
				loadingData($stateParams.id);
			}

			$scope.$on('changgedSkin', function() {
				$rootScope.scaleHtml();
			});

			$scope.footerGoods = [{
				name: 'cup-0',
				cssClass: '',
				type: 'goods',
				weight: '100',
				space: '11',
				src: 'goods11-1.png' //空水杯（100g）
			}, {
				name: 'cup-70',
				cssClass: '',
				type: 'goods',
				weight: '250',
				space: '11',
				src: 'goods11-2.png' //装70%水的水杯（250g）
			}, {
				name: 'teapot',
				cssClass: 'w21',
				type: 'goods',
				weight: '200',
				space: '21',
				src: 'goods21-1.png' //茶壶（200g）
			}, {
				name: 'teacup',
				cssClass: '',
				type: 'goods',
				weight: '100',
				space: '11',
				src: 'goods11-3.png' //茶杯（100g）
			}, {
				name: 'flowerpot',
				cssClass: 'w22',
				type: 'goods',
				weight: '3000',
				space: '22',
				src: 'goods22-1.png' //花盆（3kg）
			}, {
				name: 'flowervase',
				cssClass: 'w12',
				type: 'goods',
				weight: '1000',
				space: '12',
				src: 'goods12-1.png' //花瓶（1kg）
			}, {
				name: 'inkpot',
				cssClass: '',
				type: 'goods',
				weight: '50',
				space: '11',
				src: 'goods11-4.png' //墨水瓶（50g）
			}, {
				name: 'pencilcase',
				cssClass: 'w21',
				type: 'goods',
				weight: '50',
				space: '21',
				src: 'goods21-2.png' //铅笔盒（50g）
			}, {
				name: 'baseball',
				cssClass: 'w22',
				type: 'goods',
				weight: '300',
				space: '22',
				src: 'goods22-2.png' //排球（300g）
			}, {
				name: 'ball',
				cssClass: '',
				type: 'goods',
				weight: '100',
				space: '11',
				src: 'goods11-5.png' //皮球（100g）
			}, {
				name: 'cat-vase-2000-500',
				cssClass: 'w33',
				type: 'goods',
				weight: '2500',
				space: '33',
				src: 'goods33-1.png' //标记“xkg”的猫（2kg）抱住标记“0.5kg”的花纹球（0.5kg）
			}, {
				name: 'box-2500',
				cssClass: 'w22',
				type: 'goods',
				weight: '2500',
				space: '22',
				src: 'goods22-3.png' //标记“2.5kg”盒子（2.5kg）
			}, {
				name: 'smallball',
				cssClass: '',
				type: 'goods',
				weight: '50',
				space: '11',
				src: 'goods11-6.png' //小球（50g）
			}, {
				name: 'cuboid',
				cssClass: 'w12',
				type: 'goods',
				weight: '50',
				space: '12',
				src: 'goods12-2.png' //长立方体（50g）
			}, {
				name: 'cuboid-x-60',
				cssClass: 'w12',
				type: 'goods',
				weight: '60',
				space: '12',
				src: 'goods12-3.png' //内写“x”的长立方体（60g）
			}, {
				name: 'cube',
				cssClass: '',
				type: 'goods',
				weight: '10',
				space: '11',
				src: 'goods11-7.png' //立方格子（10g）
			}, {
				name: 'blue-white-porcelain',
				cssClass: 'w23',
				type: 'goods',
				weight: '150',
				space: '23',
				src: 'goods23-1.png' //青花瓷（150g）
			}, {
				name: 'smallball-x-25',
				cssClass: 'w12',
				type: 'goods',
				weight: '25',
				space: '12',
				src: 'goods12-4.png' //标记“xg”的小球（25g）
			}];
			$scope.footerLeverage = [{
				name: '',
				type: 'leverage',
				weight: '5',
				space: '11',
				src: 'leverage1.png'
			}, {
				name: '',
				type: 'leverage',
				weight: '10',
				space: '11',
				src: 'leverage2.png'
			}, {
				name: '',
				type: 'leverage',
				weight: '20',
				space: '11',
				src: 'leverage3.png'
			}, {
				name: '',
				type: 'leverage',
				weight: '50',
				space: '11',
				src: 'leverage4.png'
			}, {
				name: '',
				type: 'leverage',
				weight: '100',
				space: '11',
				src: 'leverage5.png'
			}, {
				name: '',
				type: 'leverage',
				weight: '500',
				space: '11',
				src: 'leverage6.png'
			}, {
				name: '',
				type: 'leverage',
				weight: '1000',
				space: '11',
				src: 'leverage7.png'
			}, {
				name: '',
				type: 'leverage',
				weight: '2000',
				space: '11',
				src: 'leverage8.png'
			}];
			//左边天平盘子
			$scope.leftPlateBoxItems = [];
			//右边天平盘子
			$scope.rightPlateBoxItems = [];
			var plateBox = [
				[0, 0, 0],
				[0, 0, 0],
				[0, 0, 0]
			];

			//浏览器窗口变化自适应图标大小
			$scope.rate = 54;
			var resizeFunc = function() {
				var clientWidth = window.document.body.clientWidth;
				if (clientWidth >= 1315) {
					$scope.rate = 54 / 1.226;
				} else if (clientWidth >= 1160) {
					$scope.rate = 54 / 1.36;
				} else {
					$scope.rate = 54 / 1.63;
				}

				$scope.$apply();
			};
			resizeFunc();
			$(window).resize(resizeFunc);

			var findSpace = function(item) {
				for (var j = 0; j < 3; j++) {
					for (var k = 0; k < 3; k++) {
						//plateBox为1表示格子被占用
						if (plateBox[j][k] == 1) {
							continue;
						}

						var space = item.space + '';
						var w = Number(space[0]),
							h = Number(space[1]);
						var haveSpace = true;
						for (var hj = j, hjLen = h + j; hj < hjLen; hj++) {
							for (var wk = k, wkLen = w + k; wk < wkLen; wk++) {
								if (plateBox[hj] == undefined || plateBox[hj][wk] == undefined || plateBox[hj][wk] == 1) {
									haveSpace = false;
									break;
								}
							}
						}
						if (!haveSpace) {
							break;
						}
						for (var hj = j, hjLen = h + j; hj < hjLen; hj++) {
							for (var wk = k, wkLen = w + k; wk < wkLen; wk++) {
								plateBox[hj][wk] = 1;
							}
						}

						item.left = k;
						item.bottom = j;
						return true;
					}
				}
				return false;
			};
			var arrange = function(items, newItem) {
				var pos = {
					left: 0,
					bottom: 0
				};
				plateBox = [
					[0, 0, 0],
					[0, 0, 0],
					[0, 0, 0]
				];
				//从占用空间小到大排序
				for (var i = 0, iLen = items.length; i < iLen; i++) {
					var curItem = items[i];
					for (var j = i + 1, jLen = items.length; j < jLen; j++) {
						if (curItem.space > items[j].space) {
							curItem = items[j];
							items.splice(i, 0, curItem);
							items.splice(j + 1, 1);
						}
					}
				}
				for (var i = items.length - 1; i >= 0; i--) {
					if (!findSpace(items[i])) {
						for (var i = 0, iLen = items.length; i < iLen; i++) {
							if (items[i].id == newItem.id) {
								items.splice(i, 1);
								break;
							}
						}
						arrange(items);
						break;
					};
				}
				return pos;
			};
			var moveNewItem = function(e, dragDiv, $plate, container) {
				var $dragDiv = $(dragDiv);
				var newItem;
				if (e.pageX > $plate.offset().left && e.pageX < $plate.offset().left + $plate.width() && e.pageY > $plate.offset().top && e.pageY < $plate.offset().top + $plate.height()) {
					//物品或砝码有在天平盘子区域中
					if (!dragDiv.id) {
						//从底部侯选区拖到盘子里
						newItem = {
							id: uuid.v4(),
							name: $dragDiv.data('name'),
							type: $dragDiv.data('type'),
							src: $dragDiv.data('src').split('.')[0] + '-small' + '.png',
							weight: $dragDiv.data('weight'),
							space: $dragDiv.data('space'),
							cssClass: $dragDiv.attr('class')
						};
					} else {
						//从一个盘拖到另外一个盘
						var haveIt = false;
						for (var i = 0, iLen = container.length; i < iLen; i++) {
							if (container[i].id == dragDiv.id) {
								haveIt = true;
								break;
							}
						}
						//如果在同一个盘子里拖，无须新增新的
						if (!haveIt) {
							newItem = {
								id: dragDiv.id,
								name: $dragDiv.data('name'),
								type: $dragDiv.data('type'),
								src: $dragDiv.data('src'),
								weight: $dragDiv.data('weight'),
								space: $dragDiv.data('space'),
								cssClass: $dragDiv.attr('class')
							};
						}

					}
					if (newItem) {
						container.splice(0, 0, newItem);
						arrange(container, newItem);
					}
				} else {
					//天平或砝码不在天平盘子区域中
					if (dragDiv.id) {
						for (var i = 0, iLen = container.length; i < iLen; i++) {
							if (container[i].id == dragDiv.id) {
								container.splice(i, 1);
								arrange(container);
								break;
							}
						}
					}
				}
			};
			var weigh = function() {
				var leftWeight = 0;
				var rightWeight = 0;
				for (var i = 0, iLen = $scope.leftPlateBoxItems.length; i < iLen; i++) {
					leftWeight += $scope.leftPlateBoxItems[i].weight;
				}
				for (var i = 0, iLen = $scope.rightPlateBoxItems.length; i < iLen; i++) {
					rightWeight += $scope.rightPlateBoxItems[i].weight;
				}
				$('#balancesPlateBox').removeClass('heavy_left');
				$('#balancesPlateBox').removeClass('heavy_right');
				if (leftWeight > rightWeight) {
					$('#balancesPlateBox').addClass('heavy_left');
				} else if (leftWeight < rightWeight) {
					$('#balancesPlateBox').addClass('heavy_right');
				} else if (leftWeight == rightWeight) {
					$('#balancesPlateBox').removeClass('heavy_left');
					$('#balancesPlateBox').removeClass('heavy_right');
				}
			};
			//移动交换
			$scope.move = function(e, index, dragDiv, originDragDiv) {
				var $leftPlateBox = $('#leftPlateBox');
				var $rightPlateBox = $('#rightPlateBox');
				//左边天平盘子的操作
				moveNewItem(e, dragDiv, $leftPlateBox, $scope.leftPlateBoxItems);
				//右边天平盘子的操作
				moveNewItem(e, dragDiv, $rightPlateBox, $scope.rightPlateBoxItems);
				//称重
				weigh();
				$scope.$apply();
			};
			//拖动属性
			$scope.options = {
				opacity: 100,
				keepOrigin: true,
				callback: $scope.move
			};

			//底部物品移动
			$scope.leftFooterGoods = function() {
				var $footerGoods = $('#footerGoods');
				$footerGoods.animate({
					scrollLeft: $footerGoods.scrollLeft() - $footerGoods.width()
				}, 200);
			};
			//底部物品移动
			$scope.rightFooterGoods = function() {
				var $footerGoods = $('#footerGoods');
				$footerGoods.animate({
					scrollLeft: $footerGoods.scrollLeft() + $footerGoods.width()
				}, 200);
			};

			//数据验证
			$scope.validPostData = function() {
				if ($.trim($scope.model.title) === '') {
					$scope.errorModel.errorText = $filter('translate')('balance.no_title');
					$("#moduleTitle").focus();
					return false;
				}
				return true;
			};

			//数据模型-编码
			$scope.encodeData = function(model) {
				$scope.model.content.balanceData = {
					leftPlateBox: $scope.leftPlateBoxItems,
					rightPlateBox: $scope.rightPlateBoxItems
				};
				return model;
			};

			//数据模型-解码
			$scope.decodeData = function(model, isInitLoad) {
				$scope.leftPlateBoxItems = model.content.balanceData.leftPlateBox;
				$scope.rightPlateBoxItems = model.content.balanceData.rightPlateBox;
				//称重
				weigh();
				return model;
			};
		}
	]);
});