var AddonMathAxis =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _appPresenter = __webpack_require__(1);

	var _appPresenter2 = _interopRequireDefault(_appPresenter);

	exports['default'] = function () {
	  return _appPresenter2['default'];
	};

	module.exports = exports['default'];

/***/ },
/* 1 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenterRun = __webpack_require__(2);

	var _presenterRun2 = _interopRequireDefault(_presenterRun);

	//import createPreview from './presenter/createPreview'

	var _presenterSetState = __webpack_require__(77);

	var _presenterSetState2 = _interopRequireDefault(_presenterSetState);

	var _presenterGetState = __webpack_require__(78);

	var _presenterGetState2 = _interopRequireDefault(_presenterGetState);

	var _presenterSetBasePath = __webpack_require__(79);

	var _presenterSetBasePath2 = _interopRequireDefault(_presenterSetBasePath);

	var _presenterHandleCallBack = __webpack_require__(80);

	var _presenterHandleCallBack2 = _interopRequireDefault(_presenterHandleCallBack);

	var _presenterPageChange = __webpack_require__(81);

	var _presenterPageChange2 = _interopRequireDefault(_presenterPageChange);

	var _presenterDestroy = __webpack_require__(82);

	var _presenterDestroy2 = _interopRequireDefault(_presenterDestroy);

	var _presenterShapeAxisView = __webpack_require__(34);

	var _presenterModuleControl = __webpack_require__(6);

	var _presenterGetQuestionInfo = __webpack_require__(83);

	var _presenterGetQuestionInfo2 = _interopRequireDefault(_presenterGetQuestionInfo);

	var _presenterSetPlayerController = __webpack_require__(84);

	var _presenterSetPlayerController2 = _interopRequireDefault(_presenterSetPlayerController);

	var _presenterOnEventReceived = __webpack_require__(85);

	var _presenterOnEventReceived2 = _interopRequireDefault(_presenterOnEventReceived);

	var _presenterSendEventToCalc = __webpack_require__(73);

	var _presenterSendEventToCalc2 = _interopRequireDefault(_presenterSendEventToCalc);

	var _presenterSendEventToState = __webpack_require__(86);

	var _presenterSendEventToState2 = _interopRequireDefault(_presenterSendEventToState);

	var _presenterSetUrlParams = __webpack_require__(87);

	var _presenterSetUrlParams2 = _interopRequireDefault(_presenterSetUrlParams);

	var _presenterSubmitControl = __webpack_require__(72);

	var _presenterMathaxisTimer = __webpack_require__(74);

	var _presenterRuntime = __webpack_require__(5);

	exports['default'] = {
	    run: _presenterRun2['default'],
	    destroy: _presenterDestroy2['default'],
	    //createPreview,
	    setState: _presenterSetState2['default'],
	    getState: _presenterGetState2['default'],
	    handleCallBack: _presenterHandleCallBack2['default'],
	    setBasePath: _presenterSetBasePath2['default'],
	    pageShow: _presenterModuleControl.pageShow,
	    pageChange: _presenterPageChange2['default'], //翻页注销
	    initEditorCanvas: _presenterShapeAxisView.initEditorCanvas,
	    getAxisExamModel: _presenterModuleControl.getAxisExamModel,
	    setAxisExamModle: _presenterModuleControl.setAxisExamModle,
	    moduleStart: _presenterModuleControl.moduleStart,
	    initTeacherMobile: _presenterRuntime.initTeacherMobile,
	    initStudentMobile: _presenterRuntime.initStudentMobile,
	    initProjectionMobile: _presenterRuntime.initProjectionMobile,
	    initWeb: _presenterRuntime.initWeb,
	    initTeacherPc: _presenterRuntime.initTeacherPc,
	    getQuestionInfo: _presenterGetQuestionInfo2['default'],
	    setPlayerController: _presenterSetPlayerController2['default'],
	    onEventReceived: _presenterOnEventReceived2['default'],
	    sendEventToCalc: _presenterSendEventToCalc2['default'],
	    sendEventToState: _presenterSendEventToState2['default'],
	    setUrlParams: _presenterSetUrlParams2['default'],
	    getResult: _presenterSubmitControl.getResult,
	    getAnswerContent: _presenterSubmitControl.getAnswerContent,
	    getI18n: _presenterSubmitControl.getI18n,
	    getWrongPopup: _presenterSubmitControl.getWrongPopup,
	    registerTimer: _presenterMathaxisTimer.registerTimer,
	    syncTime: _presenterMathaxisTimer.syncTime,
	    moduleStartLoadData: _presenterModuleControl.moduleStartLoadData

	};
	module.exports = exports['default'];

/***/ },
/* 2 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 运行环境下, 初始化Module的方法
	 * @param view 运行视图(DOM对象)
	 * @param model Module的模型, Key-Value结构
	 * @remark 该方法为Module生命周期方法,仅在Module初始化时执行一次
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenterLogic = __webpack_require__(3);

	var _presenterLogic2 = _interopRequireDefault(_presenterLogic);

	exports['default'] = function (view, model, value, scope) {
	  (0, _presenterLogic2['default'])(view, model, false, scope);
	};

	module.exports = exports['default'];

/***/ },
/* 3 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Module的逻辑
	 * @param view 视图对象, 根据是否为预览状态传入不同的视图对象
	 * @param model 模型对象
	 * @param isPreview 是否为编辑环境, true=编辑环境, false=运行环境
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _constants = __webpack_require__(4);

	var _moduleControl = __webpack_require__(6);

	exports['default'] = function (view, model, isPreview, scope) {
	    // 将 model 值赋给 this
	    _presenter2['default'].model = model;
	    // 将 view 赋值给 this
	    _presenter2['default'].view = view;
	    //presenter.isWeb=true;
	    _presenter2['default'].scope = scope;

	    //预览的时候走的pageshow，不走这里
	    if (!_presenter2['default'].isWeb && !_presenter2['default'].isTeacherPc && !_presenter2['default'].isStudentMobile) {
	        (0, _moduleControl.moduleStart)();
	        console.log('this is presenter logic start');
	    }
	    // 显示3D图形的形状
	};

	module.exports = exports['default'];

/***/ },
/* 4 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _runtime = __webpack_require__(5);

	var _runtime2 = _interopRequireDefault(_runtime);

	// 当前 addon 的名称
	var addonName = 'mathaxis';
	exports.addonName = addonName;
	// 与 native 通信的事件名
	// 数轴颜色
	var lineColor = '#333';
	exports.lineColor = lineColor;
	// 定义 addon 的可活动大小
	var REAL_ESTATE = {
	    //width: 1130,
	    //height: 160,
	    width: 952,
	    height: 400,
	    offsetLeft: 199.328125,
	    offsetTop: 57.53125,
	    frontage: 850,
	    endPosition: 0

	};
	exports.REAL_ESTATE = REAL_ESTATE;
	var answerValue = [];
	exports.answerValue = answerValue;
	var MAXMARKNUM = 10;
	exports.MAXMARKNUM = MAXMARKNUM;
	var callNativePath = 'com.nd.pad.icr.ui.IcrJsBridge';
	exports.callNativePath = callNativePath;
	var eventName = 'NumberLine';

	exports.eventName = eventName;
	var CHARACTER = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'];

	exports.CHARACTER = CHARACTER;
	var EXAM_TYPE = {
	    Coord_Point_Note: 11, //F在坐标点标出已知数字
	    Coord_Point_Number: 12, //在已知坐标轴上的点填写数字
	    Calculate_Note: 21, //在坐标轴上标出已知计算式的结果
	    Calculate_Number: 22 };

	exports.EXAM_TYPE = EXAM_TYPE;
	//已知坐标轴图填写完整的计算式
	var SCODE_COPE = {
	    INTEGER_SCOPE: 40,
	    NATURAL_SCOPE: 20
	};
	exports.SCODE_COPE = SCODE_COPE;
	var baseColor = '#FF0000';
	exports.baseColor = baseColor;

/***/ },
/* 5 */
/***/ function(module, exports, __webpack_require__) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	exports.initTeacherMobile = initTeacherMobile;
	exports.initStudentMobile = initStudentMobile;
	exports.initProjectionMobile = initProjectionMobile;
	exports.initWeb = initWeb;
	exports.initTeacherPc = initTeacherPc;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	function initTeacherMobile() {
	    _presenter2["default"].isTeacherMobile = true;
	}

	;

	function initStudentMobile() {
	    "use strict";
	    _presenter2["default"].isStudentMobile = true;
	}

	;

	function initProjectionMobile() {
	    _presenter2["default"].isProjectionMobile = true;
	}

	;

	function initWeb() {
	    "use strict";
	    _presenter2["default"].isWeb = true;
	}

	;

	function initTeacherPc() {
	    _presenter2["default"].isTeacherPc = true;
	}

	;

	exports["default"] = {
	    initTeacherMobile: initTeacherMobile,
	    initStudentMobile: initStudentMobile,
	    initProjectionMobile: initProjectionMobile,
	    initWeb: initWeb,
	    initTeacherPc: initTeacherPc
	};

/***/ },
/* 6 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by zhoujunzhou on 2016/1/4.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.moduleStartLoadData = moduleStartLoadData;
	exports.pageShow = pageShow;
	exports.moduleStart = moduleStart;
	exports.isApp = isApp;
	exports.getAxisExamModel = getAxisExamModel;
	exports.setAxisExamModle = setAxisExamModle;
	exports.moduleClose = moduleClose;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _runtime = __webpack_require__(5);

	var _runtime2 = _interopRequireDefault(_runtime);

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _DomViewDomViewManager = __webpack_require__(7);

	var _ShapeDecoData = __webpack_require__(57);

	var _constants = __webpack_require__(4);

	var _threeManger = __webpack_require__(10);

	var _EditorCoordNoteModel = __webpack_require__(40);

	var _EditorCoordNoteModel2 = _interopRequireDefault(_EditorCoordNoteModel);

	var _EditorCoordNumberModel = __webpack_require__(45);

	var _EditorCoordNumberModel2 = _interopRequireDefault(_EditorCoordNumberModel);

	var _EditorCalcNoteModel = __webpack_require__(46);

	var _EditorCalcNoteModel2 = _interopRequireDefault(_EditorCalcNoteModel);

	var _EditorCalcNumberModel = __webpack_require__(48);

	var _EditorCalcNumberModel2 = _interopRequireDefault(_EditorCalcNumberModel);

	var _EditorParseModel = __webpack_require__(70);

	var _event = __webpack_require__(71);

	var _submitControl = __webpack_require__(72);

	var _ShapeAddMarkPoint = __webpack_require__(28);

	var _UtilsToolbar = __webpack_require__(11);

	var _mathaxisTimer = __webpack_require__(74);

	var _EventDocumentEvent = __webpack_require__(9);

	var _UtilsAddCurve = __webpack_require__(49);

	var _DomViewTypeDomEvent = __webpack_require__(8);

	var _ShapeAxisView = __webpack_require__(34);

	var axisExamModel = undefined;

	function moduleStartLoadData(scope) {

	    var tempModel = getAxisExamModel();
	    /**fix bug：从习题新建课件也会走该入口**/
	    if (tempModel) {
	        _presenter2['default'].isReEdit = true;
	    }

	    _presenter2['default'].scope = scope;

	    moduleStart();
	}

	function pageShow() {

	    console.log(' MathAxis pageShow ');
	    moduleStart(_presenter2['default'].scope);
	}

	function moduleStart() {
	    console.log('isTeacherMobile:', _presenter2['default'].isTeacherMobile);
	    console.log('isTeacherPc:', _presenter2['default'].isTeacherPc);
	    console.log('isStudentMobile:', _presenter2['default'].isStudentMobile);
	    console.log('isWeb:', _presenter2['default'].isWeb);
	    console.log('isProjectionMobile:', _presenter2['default'].isProjectionMobile);
	    console.log('isReEdit:', _presenter2['default'].isReEdit);
	    console.log('isPPTShell:', _presenter2['default'].isPPTShell);
	    //发送可以提交事件
	    //presenter.sendEventToCalc('notsubmit');
	    //presenter.isWeb = true;
	    //presenter.isReEdit = true;

	    _presenter2['default'].isFullPPT = true; //备课端为false

	    if (_presenter2['default'].isTeacherPc || _presenter2['default'].isPPTShell) {
	        //$(presenter.view).find(".com_layout").addClass("layout_whiteboard")
	    }

	    if (!_presenter2['default'].isTeacherMobile && !_presenter2['default'].isTeacherPc && !_presenter2['default'].isStudentMobile && !_presenter2['default'].isWeb && !_presenter2['default'].isReEdit) {
	        _presenter2['default'].isFirstTime = true;
	        (0, _DomViewDomViewManager.start)();
	        (0, _DomViewDomViewManager.showSelectTypeContainer)();
	    } else if (_presenter2['default'].isTeacherMobile || _presenter2['default'].isStudentMobile || _presenter2['default'].isWeb || _presenter2['default'].isTeacherPc) {
	        //针对PC版教师端
	        if (_presenter2['default'].isTeacherPc && !_presenter2['default'].isFullPPT) {
	            _constants.REAL_ESTATE.width = $(_presenter2['default'].view).find('.com_lay_board').width() / 2;
	            _constants.REAL_ESTATE.height = $(_presenter2['default'].view).find('.com_lay_board').height();
	            $(_presenter2['default'].view).find('.numberline-canvas').css({
	                'left': _constants.REAL_ESTATE.width / 2
	            });
	        } else if (_presenter2['default'].isFullPPT) {
	            _constants.REAL_ESTATE.width = $(_presenter2['default'].view).find('.com_lay_board').width();
	            _constants.REAL_ESTATE.height = $(_presenter2['default'].view).find('.com_lay_board').height() - 20;
	        } else {
	            _constants.REAL_ESTATE.width = $(_presenter2['default'].view).find('.com_lay_board').width();
	            _constants.REAL_ESTATE.height = $(_presenter2['default'].view).find('.com_lay_board').height();
	        }

	        //if (presenter.isTeacherPc && !presenter.isPPTShell) {
	        //    REAL_ESTATE.width = $(presenter.view).find('.com_lay_board').width();
	        //    REAL_ESTATE.height = $(presenter.view).find('.com_lay_board').height();
	        //    $(presenter.view).find('.numberline-canvas').css({
	        //        'left': REAL_ESTATE.width / 2
	        //    });
	        //} else {
	        //REAL_ESTATE.width = $(presenter.view).find('.com_lay_board').width();
	        //REAL_ESTATE.height = $(presenter.view).find('.com_lay_board').height();
	        //}

	        (0, _threeManger.threeStart)();
	        presenterStudentStart();
	    } else if (_presenter2['default'].isReEdit) {
	        //let examModel = new CoordNoteModel();
	        //let examModel = new CoordNumberModel();
	        //let examModel=new CalcNoteModel();
	        //let examModel=new CalcNumberModel();
	        //examModel.create();
	        //setAxisExamModle(examModel);
	        startByReEdit();
	        setTimeout(function () {
	            (0, _threeManger.threeStart)();
	            (0, _ShapeAxisView.initEditorCanvas)(false);
	            getAxisExamModel().updateDomValue();
	        }, 1000);
	        _presenter2['default'].isReEdit = false;
	    }

	    //显示提交按钮
	    if (_presenter2['default'].isStudentMobile) {

	        //发送显示提交按钮
	        _presenter2['default'].sendEventToCalc('show');
	        //发送可以提交按钮
	        _presenter2['default'].sendEventToCalc('submit');
	    }

	    if (_presenter2['default'].isStudentMobile) {
	        (0, _event.registerNativeListener)('ExamCallback', _submitControl.examCallBack);
	    }

	    //如果是学生端或是web端需要显示时钟
	    if (_presenter2['default'].isStudentMobile || _presenter2['default'].isWeb || _presenter2['default'].isPPTShell) {
	        (0, _mathaxisTimer.initTimer)();
	    }

	    if (_presenter2['default'].isWeb || _presenter2['default'].isPPTShell) {
	        (0, _submitControl.showWebSubmit)();
	    }
	}

	function isApp() {
	    return _presenter2['default'].isTeacherMobile || _presenter2['default'].isStudentMobile || _presenter2['default'].isWeb || _presenter2['default'].isTeacherPc || _presenter2['default'].isPPTShell;
	}

	function startByReEdit() {
	    (0, _DomViewDomViewManager.start)();
	    var tempModel = getAxisExamModel();
	    var examModel = (0, _EditorParseModel.parseModel)(tempModel, true);
	    //examModel.setIntegerNotUpdate(true);
	    //examModel.create();
	    console.log('examModel', examModel);
	    (0, _DomViewTypeDomEvent.enterSelectType)(examModel);
	    var examType = examModel.examType;
	    if (examType == _constants.EXAM_TYPE.Coord_Point_Note) {
	        examModel.create(tempModel.valueArray);
	    } else if (examType == _constants.EXAM_TYPE.Coord_Point_Number) {
	        examModel.create(tempModel.valueArray);
	    } else if (examType == _constants.EXAM_TYPE.Calculate_Note) {
	        examModel.create(tempModel.valueArray, tempModel.symbolArray);
	    } else if (examType == _constants.EXAM_TYPE.Calculate_Number) {
	        examModel.create(tempModel.valueArray, tempModel.symbolArray);
	    }
	}

	function presenterStudentStart() {
	    console.log('presenter STAR!');
	    if (!_presenter2['default'].model.question_url) {
	        console.log('data unreceived ');
	        return;
	    }
	    var examModel = (0, _EditorParseModel.parseModel)(_presenter2['default'].model.question_url.content.examModel); //此处使用备课端生成的数据
	    //let examModel=new CoordNoteModel().create();
	    //let examModel = new CoordNumberModel().create();
	    //let examModel=new CalcNoteModel().create();
	    //let examModel=new CalcNumberModel().create();
	    //console.log('examModel is', examModel);
	    setAxisExamModle(examModel);
	    (0, _ShapeDecoData.decoData)();
	}

	function getAxisExamModel() {
	    return axisExamModel;
	}

	function setAxisExamModle(vlaue) {
	    axisExamModel = vlaue;
	}

	function moduleClose() {
	    console.log('============= moduleClose');
	    //是否显示当前addon隐藏
	    (0, _EventDocumentEvent.clearCount)();
	    (0, _UtilsAddCurve.setRegulationCount)(0);
	    (0, _DomViewDomViewManager.close)();
	    axisExamModel = null;
	    (0, _UtilsToolbar.setToolbarStatus)(null);
	    //setMaxSize(null);
	    (0, _ShapeAddMarkPoint.resetCollection)();
	    (0, _threeManger.destroyThree)();
	    (0, _event.unbindNativeListener)('ExamCallback');
	    (0, _event.unbindNativeListener)('ExamInfoCallback');
	    _presenter2['default'].renderer = null;
	    if (_mathaxisTimer.AxisTimer) {
	        _mathaxisTimer.AxisTimer.onDestory();
	        //AxisTimer = null;
	    }

	    //destroyThree();
	    //if (isContainerViewShow()) {
	    //    hideContainerView();
	    //    domViewRelease();
	    //    threeClose();
	    //}
	}

	function onWindowResize() {
	    setTimeout(function () {
	        resizeEven();
	    }, 200);
	}
	function resizeEven() {
	    var container = $(_presenter2['default'].view).find('.number_lines_area')[0];
	    console.log(_constants.REAL_ESTATE.width, 'resize');
	    if (container.offsetWidth != 0) {
	        _constants.REAL_ESTATE.width = container.offsetWidth;
	        _constants.REAL_ESTATE.height = container.offsetHeight;
	        console.log(_constants.REAL_ESTATE.width, 'resize to');
	        $(_presenter2['default'].view).find('.numberline-canvas').css({
	            'left': '1%'
	        });
	        _threeManger.camera.left = _constants.REAL_ESTATE.width / -2;
	        _threeManger.camera.right = _constants.REAL_ESTATE.width / 2;
	        _threeManger.camera.top = _constants.REAL_ESTATE.height / 2;
	        _threeManger.camera.bottom = _constants.REAL_ESTATE.height / -2;
	        _threeManger.camera.updateProjectionMatrix();
	        _threeManger.renderer.setSize(_constants.REAL_ESTATE.width, _constants.REAL_ESTATE.height);
	        if (_constants.REAL_ESTATE.width < _constants.REAL_ESTATE.frontage) {}
	    }
	}

/***/ },
/* 7 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by zhoujunzhou on 2016/1/4.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.start = start;
	exports.close = close;
	exports.getNumberBox = getNumberBox;
	exports.showSelectTypeContainer = showSelectTypeContainer;
	exports.hideSelectTypeContainer = hideSelectTypeContainer;
	exports.showMainContainer = showMainContainer;
	exports.hideMainContainer = hideMainContainer;
	exports.clearBuildDiv = clearBuildDiv;
	exports.selectTabDom = selectTabDom;
	exports.clearTypeSelect = clearTypeSelect;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _TypeDomEvent = __webpack_require__(8);

	var _EditExamDomEvent = __webpack_require__(69);

	var _ShapeAxisView = __webpack_require__(34);

	function start() {
	    (0, _TypeDomEvent.selectTypeDomEvent)();
	    (0, _EditExamDomEvent.bindButtonEvent)();
	}

	function close() {}

	function getNumberBox() {
	    //return $(presenter.view).find(".number_position_box")
	    return $(_presenter2['default'].view).find(".input-number-value");
	}

	function showSelectTypeContainer() {
	    $(_presenter2['default'].view).find('.select-type-container').show();
	}

	function hideSelectTypeContainer() {
	    $(_presenter2['default'].view).find('.select-type-container').hide();
	}

	function showMainContainer() {
	    $(_presenter2['default'].view).find('.mathaxis-main-container').show();
	}

	function hideMainContainer() {
	    $(_presenter2['default'].view).find('.mathaxis-main-container').hide();
	}

	function clearBuildDiv() {
	    console.log('clearBuildDiv');
	    getNumberBox().empty();
	}

	function selectTabDom(isNatural) {
	    console.log("isNatural", isNatural);
	    if (isNatural) {
	        $(_presenter2['default'].view).find('.btn_natural_num').addClass('on');
	        $(_presenter2['default'].view).find('.btn_natural_num').addClass('pointer-events-none');
	        $(_presenter2['default'].view).find('.btn_integer_num').removeClass('on');
	        $(_presenter2['default'].view).find('.btn_integer_num').removeClass('pointer-events-none');
	    } else {
	        $(_presenter2['default'].view).find('.btn_integer_num').addClass('on');
	        $(_presenter2['default'].view).find('.btn_integer_num').addClass('pointer-events-none');
	        $(_presenter2['default'].view).find('.btn_natural_num').removeClass('on');
	        $(_presenter2['default'].view).find('.btn_natural_num').removeClass('pointer-events-none');
	    }
	}

	function clearTypeSelect() {

	    $(_presenter2['default'].view).find('.coordpoint_note').removeClass('on');
	    $(_presenter2['default'].view).find('.coordpoint_number').removeClass('on');
	    $(_presenter2['default'].view).find('.calc_note').removeClass('on');
	    $(_presenter2['default'].view).find('.calc_number').removeClass('on');
	}

/***/ },
/* 8 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by zhoujunzhou on 2016/1/4.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.selectTypeDomEvent = selectTypeDomEvent;
	exports.enterSelectType = enterSelectType;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _constants = __webpack_require__(4);

	var _DomViewManager = __webpack_require__(7);

	var _EventDocumentEvent = __webpack_require__(9);

	var _EventDocumentEvent2 = _interopRequireDefault(_EventDocumentEvent);

	var _moduleControl = __webpack_require__(6);

	var _EditorCoordNoteModel = __webpack_require__(40);

	var _EditorCoordNoteModel2 = _interopRequireDefault(_EditorCoordNoteModel);

	var _EditorCoordNumberModel = __webpack_require__(45);

	var _EditorCoordNumberModel2 = _interopRequireDefault(_EditorCoordNumberModel);

	var _EditorCalcNoteModel = __webpack_require__(46);

	var _EditorCalcNoteModel2 = _interopRequireDefault(_EditorCalcNoteModel);

	var _EditorCalcNumberModel = __webpack_require__(48);

	var _EditorCalcNumberModel2 = _interopRequireDefault(_EditorCalcNumberModel);

	var _threeManger = __webpack_require__(10);

	var _ShapeAddMarkPoint = __webpack_require__(28);

	var _UtilsToolbar = __webpack_require__(11);

	var _UtilsAddCurve = __webpack_require__(49);

	var _ShapeAxisView = __webpack_require__(34);

	function selectTypeDomEvent() {

	    $(_presenter2['default'].view).find('.select-type-container').off('click').on('click touchstart', function (e) {
	        e.preventDefault();
	        var exmalModel = undefined;
	        var target = e.target;
	        var title = undefined;
	        if ($(target).hasClass('calculate')) {
	            //选择了加减运算题型
	            $(target).addClass('pointer-events-none');
	            $(target).addClass('on');
	            $(_presenter2['default'].view).find('.coord_point').removeClass('pointer-events-none');
	            $(_presenter2['default'].view).find('.coord_point').removeClass('on');

	            $(_presenter2['default'].view).find('.numline_choice_child_main').addClass('child_main_second');
	        } else if ($(target).hasClass('coord_point')) {
	            $(target).addClass('pointer-events-none');
	            $(target).addClass('on');
	            $(_presenter2['default'].view).find('.calculate').removeClass('pointer-events-none');
	            $(_presenter2['default'].view).find('.calculate').removeClass('on');
	            $(_presenter2['default'].view).find('.numline_choice_child_main').removeClass('child_main_second');
	        } else if ($(target).hasClass('coordpoint_note')) {
	            //选择在坐标轴上标出已知数字点
	            exmalModel = new _EditorCoordNoteModel2['default']();
	        } else if ($(target).hasClass('coordpoint_number')) {
	            //在已知坐标点上填写数字
	            exmalModel = new _EditorCoordNumberModel2['default']();
	        } else if ($(target).hasClass('calc_note')) {
	            //标出已知计算式的结果
	            exmalModel = new _EditorCalcNoteModel2['default']();
	        } else if ($(target).hasClass('calc_number')) {
	            //填写计算式
	            exmalModel = new _EditorCalcNumberModel2['default']();
	        }
	        if (exmalModel) {
	            exmalModel.create();
	            enterSelectType(exmalModel);
	        }
	    });
	}

	function enterSelectType(baseExamModel) {
	    (0, _moduleControl.setAxisExamModle)(baseExamModel);
	    (0, _DomViewManager.hideSelectTypeContainer)();
	    (0, _DomViewManager.showMainContainer)();
	    (0, _DomViewManager.selectTabDom)(baseExamModel.isInteger);
	    if (!_presenter2['default'].renderer) {
	        console.log('before', _constants.REAL_ESTATE.width, _constants.REAL_ESTATE.height);
	        (0, _threeManger.threeStart)();
	        console.log('after', _constants.REAL_ESTATE.width, _constants.REAL_ESTATE.height);
	    }
	    if (_presenter2['default'].renderer && _presenter2['default'].isFirstTime) {
	        console.log('before', _constants.REAL_ESTATE.width, _constants.REAL_ESTATE.height);
	        (0, _EventDocumentEvent.clearCount)();
	        (0, _UtilsAddCurve.setRegulationCount)(0);
	        (0, _UtilsToolbar.setToolbarStatus)(null);
	        (0, _ShapeAddMarkPoint.resetCollection)();
	        _presenter2['default'].renderer = null;
	        (0, _threeManger.threeStart)();
	        console.log('after', _constants.REAL_ESTATE.width, _constants.REAL_ESTATE.height);
	    }
	    if (baseExamModel.valueArray) {
	        (0, _ShapeAxisView.initEditorCanvas)(false);
	    }
	    if (!_presenter2['default'].isReEdit) {
	        _presenter2['default'].scope.$apply(function (scope) {
	            if (scope.model.title == '') {
	                scope.model.title = setTitle(baseExamModel.examType);
	                console.log('title change to', scope.model.title);
	            }
	        });
	    } else {
	        if (_presenter2['default'].scope.model.title == '') {
	            _presenter2['default'].scope.model.title = setTitle(baseExamModel.examType);
	        }
	    }
	}

	function setTitle(examType) {
	    if (examType == _constants.EXAM_TYPE.Coord_Point_Note) {
	        return '请在数轴上标出以下数字';
	    } else if (examType == _constants.EXAM_TYPE.Coord_Point_Number) {
	        return '请根据数轴上的坐标点填空';
	    } else if (examType == _constants.EXAM_TYPE.Calculate_Note) {
	        return '请在坐标轴上标出计算式的结果';
	    } else if (examType == _constants.EXAM_TYPE.Calculate_Number) {
	        return '已知坐标轴图填写完整的计算式';
	    }
	}

/***/ },
/* 9 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/12/18.
	 */

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.clearCount = clearCount;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _threeManger = __webpack_require__(10);

	var _ShapeNumberLine = __webpack_require__(35);

	var _ShapeNumberLine2 = _interopRequireDefault(_ShapeNumberLine);

	var _constants = __webpack_require__(4);

	var _UtilsUpdateUnit = __webpack_require__(31);

	var _UtilsUpdateUnit2 = _interopRequireDefault(_UtilsUpdateUnit);

	var _UtilsMoveMarkPoint = __webpack_require__(53);

	// import moveObject from '../Utils/moveObject'

	var _UtilsUpdateLine = __webpack_require__(58);

	var _UtilsUpdateLine2 = _interopRequireDefault(_UtilsUpdateLine);

	var _UtilsUpdateVertices = __webpack_require__(21);

	var _UtilsUpdateVertices2 = _interopRequireDefault(_UtilsUpdateVertices);

	var _UtilsAddCurve = __webpack_require__(49);

	var _UtilsAddCurve2 = _interopRequireDefault(_UtilsAddCurve);

	var _UtilsAddDot = __webpack_require__(51);

	var _UtilsAddDot2 = _interopRequireDefault(_UtilsAddDot);

	var _UtilsToolbarJs = __webpack_require__(11);

	var _ShapeAddMarkPoint = __webpack_require__(28);

	var _EventUnitController = __webpack_require__(59);

	var _EventUnitController2 = _interopRequireDefault(_EventUnitController);

	var _unitSelect = __webpack_require__(60);

	var _unitSelect2 = _interopRequireDefault(_unitSelect);

	var _UtilsUpdateSection = __webpack_require__(61);

	var _UtilsUpdateSection2 = _interopRequireDefault(_UtilsUpdateSection);

	var _UtilsUpdatePointStatus = __webpack_require__(62);

	var _UtilsUpdatePointStatus2 = _interopRequireDefault(_UtilsUpdatePointStatus);

	var _ShapeSection = __webpack_require__(63);

	var _ShapeSection2 = _interopRequireDefault(_ShapeSection);

	var _ShapePoint = __webpack_require__(18);

	var _ShapePoint2 = _interopRequireDefault(_ShapePoint);

	var _ShapeSectionLine = __webpack_require__(16);

	var _UtilsComputeSection = __webpack_require__(23);

	var _UtilsComputeSection2 = _interopRequireDefault(_UtilsComputeSection);

	var _UtilsAdjustPosition = __webpack_require__(64);

	var _UtilsAdjustPosition2 = _interopRequireDefault(_UtilsAdjustPosition);

	var _UtilsAdjustDistance = __webpack_require__(65);

	var _UtilsAdjustDistance2 = _interopRequireDefault(_UtilsAdjustDistance);

	var _UtilsCheckUpdate = __webpack_require__(66);

	var _UtilsCheckUpdate2 = _interopRequireDefault(_UtilsCheckUpdate);

	var _UtilsSetColor = __webpack_require__(67);

	var _UtilsSetColor2 = _interopRequireDefault(_UtilsSetColor);

	var _UtilsSetZPosition = __webpack_require__(68);

	var _UtilsSetZPosition2 = _interopRequireDefault(_UtilsSetZPosition);

	var _UtilsEditeMarkPointText = __webpack_require__(56);

	var _UtilsUpMarkPoint = __webpack_require__(54);

	var _UtilsDestroyThreeObject = __webpack_require__(52);

	var _UtilsDestroyThreeObject2 = _interopRequireDefault(_UtilsDestroyThreeObject);

	var _UtilsDialog = __webpack_require__(12);

	var _UtilsDialog2 = _interopRequireDefault(_UtilsDialog);

	var _EditorConnectPointControl = __webpack_require__(44);

	var _EditorConnectPointControl2 = _interopRequireDefault(_EditorConnectPointControl);

	var _moduleControl = __webpack_require__(6);

	var _UtilsGetSections = __webpack_require__(13);

	var _UtilsGetSections2 = _interopRequireDefault(_UtilsGetSections);

	var _EditorCoordNoteModel = __webpack_require__(40);

	var _EditorCoordNoteModel2 = _interopRequireDefault(_EditorCoordNoteModel);

	var _EditorCoordNumberModel = __webpack_require__(45);

	var _EditorCoordNumberModel2 = _interopRequireDefault(_EditorCoordNumberModel);

	var _EditorCalcNoteModel = __webpack_require__(46);

	var _EditorCalcNoteModel2 = _interopRequireDefault(_EditorCalcNoteModel);

	var _EditorCalcNumberModel = __webpack_require__(48);

	var _EditorCalcNumberModel2 = _interopRequireDefault(_EditorCalcNumberModel);

	var _UtilsRefreshSection = __webpack_require__(26);

	var _UtilsRefreshSection2 = _interopRequireDefault(_UtilsRefreshSection);

	var _UtilsIsShowUnitController = __webpack_require__(27);

	var _UtilsIsShowUnitController2 = _interopRequireDefault(_UtilsIsShowUnitController);

	var _ShapeAxisView = __webpack_require__(34);

	var _ShapeMarkPoint = __webpack_require__(30);

	var pointCount = 0;
	var regulationClickIndex = 0;
	var regulationClick = [];
	var symbolArray = [];
	var symbolIndex = 0;
	var tempPosition = 0;
	var answerIndex = 1;
	var tempStartPoint = undefined;

	exports['default'] = function () {
	    'use strict';
	    var rendererDom = _threeManger.renderer.domElement;
	    var offset = new THREE.Vector3();
	    var mouseData = {};
	    var container = $(_presenter2['default'].view).find('.numberline-canvas'); //数轴题查找对象为numberline-canvas
	    var selectedObj = undefined; // 当前选中对象
	    var intersectsPlane = undefined;
	    var intersectsDis = undefined;
	    var parent = _threeManger.scene.getObjectByName("group"); // 数轴所在group对象
	    var isDown = false;
	    var setTextTimeOut = null;
	    var fingerDisOld = 0,
	        fingerDis = 0; // 多点触控-两点间距离
	    var turn = false;
	    var moveLeft = false;
	    var moveRight = false;
	    var hideIndex = undefined;
	    rendererDom.addEventListener('mousedown', onDocumentMousedown, false);
	    rendererDom.addEventListener('touchstart', onDocumentMousedown, false);
	    //rendererDom.addEventListener('mousewheel', function () {
	    //    scale(event.wheelDelta);
	    //}, false);
	    var value = (0, _moduleControl.getAxisExamModel)().isInteger;
	    if (value) {
	        hideIndex = _threeManger.scene.getObjectByName("line").children.length - 1;
	        _threeManger.scene.getObjectByName("line").children[hideIndex].visible = false;
	        console.log('hide ', hideIndex);
	    } else {
	        hideIndex = Math.floor(_threeManger.scene.getObjectByName("line").children.length / 2);
	        _threeManger.scene.getObjectByName("line").children[hideIndex].visible = false;
	        console.log('hide ', hideIndex);
	    }

	    window.addEventListener('resize', onWindowResize, false);

	    function onDocumentMousedown(event) {

	        event.preventDefault();
	        // 如果是多点触控，就执行缩放操作，mousedown里的其他代码不再执行
	        if (event.targetTouches && event.targetTouches.length > 1) {
	            fingerDis = fingerDisOld = 0;
	        } else {
	            var pointer = event.targetTouches ? event.targetTouches[0] : event;
	            _threeManger.mouse.x = (pointer.clientX - container.offset().left) / _constants.REAL_ESTATE.width * 2 - 1;
	            _threeManger.mouse.y = -((pointer.clientY - container.offset().top) / _constants.REAL_ESTATE.height) * 2 + 1;
	            _threeManger.raycaster.setFromCamera(_threeManger.mouse, _threeManger.camera);
	            var intersects = _threeManger.raycaster.intersectObjects([parent], true);

	            (0, _unitSelect2['default'])(parent, false);
	            (0, _UtilsEditeMarkPointText.editeMarkPointText)(parent, false); //清除标识点字母的编辑状态
	            var _value = (0, _moduleControl.getAxisExamModel)().isInteger;

	            _threeManger.scene.getObjectByName("line").children[hideIndex].visible = false;

	            if (!intersects.length) {
	                var _value2 = (0, _moduleControl.getAxisExamModel)().isInteger;
	                _threeManger.scene.getObjectByName("line").children[hideIndex].visible = false;
	                _presenter2['default'].renderer();
	                return false;
	            }
	            ;
	            selectedObj = intersects[0].object;
	            intersectsPlane = _threeManger.raycaster.intersectObjects([_threeManger.plane]);
	            if (intersectsPlane.length > 0) {
	                mouseData.startPoint = intersectsPlane[0].point;
	                mouseData.recordDistance = 0;
	                // if(selectedObj.name == 'outCircle' || selectedObj.name == 'tinyArrow' || selectedObj.name == 'torus' || selectedObj.name == 'inCircle' ||
	                //   selectedObj.name == 'sectionLine' || selectedObj.name == 'startSide' || selectedObj.name == 'sectionText' || selectedObj.name == 'endSide'){
	                //     // mouseData.recordPoint = new THREE.Vector3();
	                // mouseData.recordDistance = 0;
	                //     // mouseData.recordPoint.x = mouseData.startPoint.x;
	                //     // mouseData.recordPoint.y = 0;
	                // }else{
	                //     // mouseData.recordPoint = null;
	                // }
	            }
	            isDown = true;
	            if (selectedObj.name == "text" || selectedObj.name == "showText") {
	                console.log(_UtilsToolbarJs.toolbarStatus._action);
	                if (_UtilsToolbarJs.toolbarStatus._action == 'interval' || _UtilsToolbarJs.toolbarStatus._action == 'regulation' || _UtilsToolbarJs.toolbarStatus._action == 'mark') {
	                    return;
	                }
	                if (parent.getObjectByName('section') || parent.getObjectByName('markPoint') || parent.getObjectByName('regulation')) {
	                    return;
	                }

	                setTextTimeOut = setTimeout(function () {
	                    (0, _unitSelect2['default'])(parent, true);
	                }, 1000);
	            }
	        }

	        rendererDom.addEventListener('mousemove', onDocumentMouseMove, false);
	        rendererDom.addEventListener('mouseup', onDocumentMouseUp, false);
	        rendererDom.addEventListener('mouseout', onDocumentMouseUp, false);

	        rendererDom.addEventListener('touchmove', onDocumentMouseMove, false);
	        rendererDom.addEventListener('touchend', onDocumentMouseUp, false);
	        rendererDom.addEventListener("touchcancel", onDocumentMouseUp, false);
	        rendererDom.addEventListener('touchleave', onDocumentMouseUp, false);
	    }

	    function onDocumentMouseMove(event) {
	        _threeManger.scene.getObjectByName("line").children[hideIndex].visible = false;

	        // 如果是多点触控，就执行缩放操作，mousedown里的其他代码不再执行
	        if (event.targetTouches && event.targetTouches.length > 1) {
	            //multipleTouch(event);
	            return false;
	        }
	        var pointer = event.targetTouches ? event.targetTouches[0] : event;
	        if (!selectedObj) return false;

	        _threeManger.mouse.x = (pointer.clientX - container.offset().left) / _constants.REAL_ESTATE.width * 2 - 1;
	        _threeManger.mouse.y = -((pointer.clientY - container.offset().top) / _constants.REAL_ESTATE.height) * 2 + 1;

	        _threeManger.raycaster.setFromCamera(_threeManger.mouse, _threeManger.camera);
	        var movePoint = _threeManger.raycaster.intersectObjects([_threeManger.plane])[0];
	        if (!movePoint) return;
	        mouseData.movePoint = movePoint.point;
	        var distanceX = mouseData.movePoint.x - mouseData.startPoint.x;
	        if (distanceX > 0) {
	            moveRight = true;
	        } else if (distanceX < 0) {
	            moveLeft = true;
	        }
	        if (moveRight && moveLeft) {
	            turn = true;
	            console.log('isturn', turn);
	            moveLeft = false;
	            moveRight = false;
	        }
	        if (Math.abs(distanceX) < 8 && Math.abs(mouseData.movePoint.y - mouseData.startPoint.y) < 8) {
	            return;
	        }
	        isDown = false;
	        var regulation = null;
	        switch (selectedObj.name) {
	            // 坐标轴体
	            case 'group':
	                //numLineMove();//数轴题固定数轴注释
	                break;
	            // 右控制点
	            case 'controllerRightCenter':
	            case 'controllerRight':
	                var controllerRight = selectedObj.name == "controllerRightCenter" ? selectedObj.parent : selectedObj;
	                intersectsDis = mouseData.movePoint.x - mouseData.startPoint.x;
	                var sideData = sideControll();
	                var w = _constants.REAL_ESTATE.width / 2 - parent.data.unitLength;
	                if (parent.position.x + sideData.CB < -w && intersectsDis < 0) {
	                    return;
	                }
	                if (controllerRight.position.x + distanceX > parent.data.unitLength * 1.5) {
	                    controllerRight.position.x += distanceX;
	                    (0, _UtilsUpdateLine2['default'])('controllerRight', parent, controllerRight);
	                }
	                _presenter2['default'].renderer();
	                break;
	            // 左控制点
	            case 'controllerLeftCenter':
	            case 'controllerLeft':
	                var controllerLeft = selectedObj.name == "controllerLeftCenter" ? selectedObj.parent : selectedObj;
	                intersectsDis = mouseData.movePoint.x - mouseData.startPoint.x;
	                var sideData = sideControll();
	                var w = _constants.REAL_ESTATE.width / 2 - parent.data.unitLength;
	                if (parent.position.x - sideData.CA > w && intersectsDis > 0) {
	                    return;
	                }
	                if (controllerLeft.position.x + distanceX < -parent.data.unitLength * 1.5) {
	                    controllerLeft.position.x += distanceX;
	                    (0, _UtilsUpdateLine2['default'])('controllerLeft', parent, controllerLeft);
	                }
	                _presenter2['default'].renderer();
	                break;
	            // 刻度控制点
	            case 'unitControllerCenter':
	            case 'unitController':
	                var unitObj = selectedObj.name == "unitControllerCenter" ? selectedObj.parent : selectedObj;
	                (0, _EventUnitController2['default'])(parent, unitObj, distanceX);
	                _presenter2['default'].renderer();
	                break;
	            case 'markPointCircle':
	                //标识点移动
	                distanceX = (0, _UtilsAdjustDistance2['default'])(mouseData, parent);
	                if (distanceX != 0 && _UtilsToolbarJs.toolbarStatus._action == 'mark') {
	                    if ($(_presenter2['default'].view).find('.on')[0].className.indexOf(selectedObj.parent.userData.clsName) == -1) {
	                        $(_presenter2['default'].view).find('.on').removeClass('on');
	                        $(_presenter2['default'].view).find('.' + selectedObj.parent.userData.clsName).addClass('on');
	                        console.log('Actived button changed ');
	                    }
	                    mouseData.activedObj ? null : mouseData.activedObj = (0, _UtilsSetColor2['default'])(selectedObj, '0xffef87', parent);
	                    var isAllow = (0, _UtilsEditeMarkPointText.getAllowBoolean)(); //标识点总开关
	                    if (isAllow) {
	                        var examModel = (0, _moduleControl.getAxisExamModel)();
	                        var examType = examModel.examType;
	                        if (examType == _constants.EXAM_TYPE.Coord_Point_Note) {
	                            //数轴题拖动时绘制连线
	                            if (examModel.isInteger == false) {
	                                (0, _UtilsMoveMarkPoint.moveMarkPoint)(selectedObj.parent, distanceX, parent);
	                                mouseData.clsName = examModel.connectContorl.getSelectBtnClsName();
	                                var posit = new THREE.Vector3();
	                                posit.x = selectedObj.parent.position.x + _ShapeAxisView.offsetXY;
	                                posit.y = _ShapeAxisView.offsetY;
	                                examModel.connectContorl.drawConnectLine(selectedObj.parent.userData.clsName, posit);
	                            } else {
	                                (0, _UtilsMoveMarkPoint.moveMarkPoint)(selectedObj.parent, distanceX, parent);
	                                mouseData.clsName = examModel.connectContorl.getSelectBtnClsName();
	                                var posit = new THREE.Vector3();
	                                posit.x = selectedObj.parent.position.x - _ShapeAxisView.offsetX + _ShapeAxisView.offsetXY;
	                                posit.y = _ShapeAxisView.offsetY;
	                                examModel.connectContorl.drawConnectLine(selectedObj.parent.userData.clsName, posit);
	                            }
	                        }
	                        _presenter2['default'].renderer();
	                        mouseData.recordDistance -= distanceX;
	                    } else {
	                        //dialog.tips('我想移动，发现存在相同标识点')
	                    }
	                }
	                break;
	            case 'interval':

	                break;
	            // case 'torus':
	            //     distanceX = adjustDistance(mouseData, parent);
	            //     if (!moveObject(selectedObj.parent, (distanceX), parent)) {
	            //         mouseData.recordDistance -= distanceX;
	            //     }
	            //     break;
	            // case 'tinyArrow':
	            //     distanceX = adjustDistance(mouseData, parent);
	            //     if (!moveObject(selectedObj.parent.parent, (distanceX), parent)) {
	            //         mouseData.recordDistance -= distanceX;
	            //     }
	            //     break;
	            case 'outCircle':
	            case 'inCircle':
	                distanceX = (0, _UtilsAdjustDistance2['default'])(mouseData, parent);
	                if (distanceX != 0) {
	                    var secondRegulation = undefined;
	                    if (selectedObj.parent.parent.name == 'section' && _UtilsToolbarJs.toolbarStatus._action == 'interval') {
	                        mouseData.activedObj ? null : mouseData.activedObj = (0, _UtilsSetColor2['default'])(selectedObj.parent.getObjectByName('outCircle'), '0xffef87', parent);
	                        (0, _UtilsUpdateSection2['default'])(selectedObj.parent, distanceX);
	                        mouseData.recordDistance -= distanceX;
	                    }
	                    if (selectedObj.parent.parent.name == 'regulation0') {
	                        regulation = selectedObj.parent.parent; //nicemark
	                        if (selectedObj.parent.name == 'outset') {
	                            break;
	                        } //起始点不能移动
	                        if (!(0, _UtilsCheckUpdate2['default'])(selectedObj.parent.name, regulation, parent, distanceX)) {
	                            mouseData.activedObj ? null : mouseData.activedObj = (0, _UtilsSetColor2['default'])(selectedObj.parent.getObjectByName('outCircle'), '0xffef87', parent);
	                            mouseData.recordDistance -= distanceX;
	                        }
	                    } else if (selectedObj.parent.pointCount == 1 || selectedObj.parent.pointCount == 2) {
	                        regulation = _threeManger.scene.getObjectByName('regulation0');
	                        secondRegulation = _threeManger.scene.getObjectByName('regulation1');
	                        moveTwoRegulation(regulation, secondRegulation, distanceX);
	                    } else if (selectedObj.parent.pointCount == 3 || selectedObj.parent.pointCount == 4) {
	                        var copyPoint = _threeManger.scene.getObjectByName('outset4');
	                        //moveCopyStartPoint(copyPoint,distanceX);
	                        regulation = _threeManger.scene.getObjectByName('regulation1');
	                        secondRegulation = _threeManger.scene.getObjectByName('regulation2');
	                        moveTwoRegulation(regulation, secondRegulation, distanceX);
	                    } else if (selectedObj.parent.pointCount == 5 || selectedObj.parent.pointCount == 6) {
	                        var copyPoint = _threeManger.scene.getObjectByName('outset6');
	                        //moveCopyStartPoint(copyPoint,distanceX);
	                        regulation = _threeManger.scene.getObjectByName('regulation2');
	                        secondRegulation = _threeManger.scene.getObjectByName('regulation3');
	                        moveTwoRegulation(regulation, secondRegulation, distanceX);
	                    } else if (selectedObj.parent.pointCount == 7 || selectedObj.parent.pointCount == 8) {
	                        regulation = _threeManger.scene.getObjectByName('regulation3');
	                        if (!(0, _UtilsCheckUpdate2['default'])('terminal', regulation, parent, distanceX)) {
	                            mouseData.activedObj ? null : mouseData.activedObj = (0, _UtilsSetColor2['default'])(selectedObj.parent.getObjectByName('outCircle'), '0xffef87', parent);
	                            mouseData.recordDistance -= distanceX;
	                        }
	                    }

	                    //if ((selectedObj.parent.parent.name == 'regulation0'||selectedObj.parent.parent.name == 'regulation'+(regulationCount-1) )&& toolbarStatus._action == 'regulation'&&(selectedObj.parent.pointCount==0||selectedObj.parent.pointCount==pointCount-1)) {
	                    //    regulation = selectedObj.parent.parent;//nicemark
	                    //    let index=selectedObj.parent.pointCount-1;
	                    //    let secondRegulation=scene.getObjectByName('regulation'+(index-1));
	                    //    if(selectedObj.parent.name=='outset'&&secondRegulation!==undefined){
	                    //        if (!checkUpdate('terminal', secondRegulation, parent, distanceX)&&!checkUpdate(selectedObj.parent.name, regulation, parent, distanceX)) {
	                    //            let tempPoint=new THREE.Object3D();
	                    //            tempPoint.copy(toolbarStatus.endPoint);
	                    //            toolbarStatus.startPoint=tempPoint;
	                    //            toolbarStatus.startPoint.name= 'outset';
	                    //            toolbarStatus.startPoint.pointCount=pointCount;
	                    //            mouseData.activedObj ? null : mouseData.activedObj = setColor(selectedObj.parent.getObjectByName('outCircle'), '0xffef87', parent);
	                    //            mouseData.recordDistance -= distanceX;
	                    //        }
	                    //    }else {
	                    //        if (!checkUpdate(selectedObj.parent.name, regulation, parent, distanceX)) {
	                    //            let tempPoint=new THREE.Object3D();
	                    //            tempPoint.copy(toolbarStatus.endPoint);
	                    //            toolbarStatus.startPoint=tempPoint;
	                    //            toolbarStatus.startPoint.name= 'outset';
	                    //            toolbarStatus.startPoint.pointCount=pointCount;
	                    //            mouseData.activedObj ? null : mouseData.activedObj = setColor(selectedObj.parent.getObjectByName('outCircle'), '0xffef87', parent);
	                    //            mouseData.recordDistance -= distanceX;
	                    //        }
	                    //    }
	                    //
	                    //}else {
	                    //    regulation = selectedObj.parent.parent;//nicemark
	                    //    let index=selectedObj.parent.pointCount-1;
	                    //    if(selectedObj.parent.name=='terminal'&&index!=regulationCount&&selectedObj.parent.pointCount!=pointCount-1){
	                    //        let secondRegulation=scene.getObjectByName('regulation'+(index+1));
	                    //        if (!checkUpdate(selectedObj.parent.name, regulation, parent, distanceX)&&!checkUpdate('outset', secondRegulation, parent, distanceX)) {
	                    //            let tempPoint=new THREE.Object3D();
	                    //            tempPoint.copy(toolbarStatus.endPoint);
	                    //            toolbarStatus.startPoint=tempPoint;
	                    //            toolbarStatus.startPoint.name= 'outset';
	                    //            mouseData.activedObj ? null : mouseData.activedObj = setColor(selectedObj.parent.getObjectByName('outCircle'), '0xffef87', parent);
	                    //            mouseData.recordDistance -= distanceX;
	                    //            console.log(secondRegulation,selectedObj.parent.name,'re1');
	                    //        }
	                    //
	                    //    }else if(selectedObj.parent.name=='outset'&&(selectedObj.parent.pointCount==pointCount-1||selectedObj.parent.pointCount==pointCount-2||selectedObj.parent.pointCount==pointCount-3)){
	                    //        let secondRegulation=scene.getObjectByName('regulation'+(index));
	                    //        if (!checkUpdate(selectedObj.parent.name, regulation, parent, distanceX)&&!checkUpdate('terminal', secondRegulation, parent, distanceX)) {
	                    //            let tempPoint=new THREE.Object3D();
	                    //            tempPoint.copy(toolbarStatus.endPoint);
	                    //            toolbarStatus.startPoint=tempPoint;
	                    //            toolbarStatus.startPoint.name= 'outset';
	                    //            mouseData.activedObj ? null : mouseData.activedObj = setColor(selectedObj.parent.getObjectByName('outCircle'), '0xffef87', parent);
	                    //            mouseData.recordDistance -= distanceX;
	                    //            console.log(secondRegulation,selectedObj.parent.name,'re1');
	                    //        }
	                    //    }else{
	                    //        let secondRegulation=scene.getObjectByName('regulation'+index);
	                    //        if (!checkUpdate(selectedObj.parent.name, regulation, parent, distanceX)&&!checkUpdate('terminal', secondRegulation, parent, distanceX)) {
	                    //            let tempPoint=new THREE.Object3D();
	                    //            tempPoint.copy(toolbarStatus.endPoint);
	                    //            toolbarStatus.startPoint=tempPoint;
	                    //            toolbarStatus.startPoint.name= 'outset';
	                    //            mouseData.activedObj ? null : mouseData.activedObj = setColor(selectedObj.parent.getObjectByName('outCircle'), '0xffef87', parent);
	                    //            mouseData.recordDistance -= distanceX;
	                    //            console.log(secondRegulation,selectedObj.parent.name,'re1');
	                    //        }
	                    //
	                    //    }
	                    //
	                    //}
	                }
	                _presenter2['default'].renderer();
	                break;
	            // case 'startSide':
	            // case 'endSide':
	            // case 'sectionLine':
	            // case 'sectionText':

	            //     distanceX = adjustDistance(mouseData, parent);
	            //     if (selectedObj.parent.name == 'section') {
	            //         if(!updateSection(selectedObj, distanceX)) {
	            //           mouseData.recordDistance -= distanceX;
	            //         }
	            //     }
	            //     break;
	        }
	        mouseData.startPoint.copy(mouseData.movePoint);
	    }

	    function moveCopyStartPoint(outset, distanceX) {
	        (0, _UtilsMoveMarkPoint.moveMarkPoint)(outset, distanceX, parent);
	        //mouseData.recordDistance -= distanceX;
	    }

	    function moveTwoRegulation(regulation, secondRegulation, distanceX) {
	        if (secondRegulation === undefined) {
	            if (!(0, _UtilsCheckUpdate2['default'])('terminal', regulation, parent, distanceX)) {
	                mouseData.activedObj ? null : mouseData.activedObj = (0, _UtilsSetColor2['default'])(selectedObj.parent.getObjectByName('outCircle'), '0xffef87', parent);
	                mouseData.recordDistance -= distanceX;
	            }
	        } else {
	            if (!(0, _UtilsCheckUpdate2['default'])('terminal', regulation, parent, distanceX, secondRegulation)) {
	                mouseData.activedObj ? null : mouseData.activedObj = (0, _UtilsSetColor2['default'])(selectedObj.parent.getObjectByName('outCircle'), '0xffef87', parent);
	                mouseData.recordDistance -= distanceX; //bad mark
	            }
	        }
	    }

	    function onDocumentMouseUp(event) {
	        _threeManger.scene.getObjectByName("line").children[hideIndex].visible = false;
	        if (selectedObj) {
	            if (_UtilsToolbarJs.toolbarStatus._action == "clean" && isDown) {
	                //清楚标识点操作，勿删。
	                var markPoint = selectedObj.parent;
	                if (markPoint.name == 'markPoint') {
	                    var isAllow = (0, _UtilsEditeMarkPointText.getAllowBoolean)(); //标识点总开关
	                    if (isAllow) {
	                        var removeText = markPoint.userData.markText;
	                        console.log('移除的字体为=' + removeText);
	                        (0, _UtilsMoveMarkPoint.initArray)(markPoint);
	                        markPoint.parent.remove(markPoint);
	                        (0, _ShapeAddMarkPoint.clear)(removeText);
	                        _presenter2['default'].renderer();
	                    } else {
	                        //dialog.tips('我想清除标识点，发现存在相同标识点')
	                    }
	                }
	                getTopParent(markPoint);
	            } else {
	                if (isDown) {
	                    (0, _UtilsAdjustPosition2['default'])(mouseData.startPoint, parent);
	                    switch (_UtilsToolbarJs.toolbarStatus._action) {
	                        case 'mark':
	                            var isAllow = (0, _UtilsEditeMarkPointText.getAllowBoolean)(); //标识点总开关
	                            var numberLineObject = _threeManger.scene.getObjectByName('group');
	                            console.log('numberLineObject:', numberLineObject);

	                            if (isAllow && selectedObj.name !== 'markPointCircle' && selectedObj.name == 'group') {
	                                var _examModel = (0, _moduleControl.getAxisExamModel)();
	                                var examType = _examModel.examType;
	                                var mesh = _threeManger.scene.children[1];
	                                var index = undefined;
	                                var exist = false;
	                                if (_examModel.isInteger == false) {
	                                    if (mouseData.startPoint.x >= _constants.REAL_ESTATE.endPosition) {
	                                        break;
	                                    }
	                                } else {
	                                    if (mouseData.startPoint.x >= _constants.REAL_ESTATE.endPosition - _ShapeAxisView.offsetX) {
	                                        break;
	                                    }
	                                }
	                                if (examType == _constants.EXAM_TYPE.Coord_Point_Note) {
	                                    mouseData.clsName = $(_presenter2['default'].view).find('.on')[0].className.substr(16, 20);
	                                    //mouseData.clsName= 'axis_input_element_0';
	                                    for (var i = 0; i < mesh.children.length; i++) {
	                                        if (mesh.children[i].userData.clsName == mouseData.clsName) {
	                                            index = i;
	                                            exist = true;
	                                        }
	                                    }
	                                    console.log('remvoe index', index, 'exit', exist);
	                                    if (exist) {
	                                        console.log('remvoe ed index', index);
	                                        var removeText = mesh.children[index].userData.markText;
	                                        mesh.children[index].parent.remove(mesh.children[index]);
	                                        (0, _ShapeAddMarkPoint.clear)(removeText);
	                                    }
	                                    if (_examModel.isInteger == false) {
	                                        var markPoint = (0, _ShapeAddMarkPoint.AddMarkPoint)(mouseData.startPoint, mouseData.clsName);
	                                        if (markPoint) {
	                                            var _position = new THREE.Vector3();
	                                            _position.x = markPoint.position.x + _ShapeAxisView.offsetXY;
	                                            _position.y = _ShapeAxisView.offsetY;
	                                            _examModel.connectContorl.drawConnectLine(mouseData.clsName, _position);
	                                        }
	                                        (0, _UtilsSetZPosition2['default'])(markPoint);
	                                        markPoint = null;
	                                        //selectedObj.name = null;
	                                        if (mouseData.clsName == 'axis_input_element_0') {
	                                            _examModel.setResValue(0, (0, _ShapeMarkPoint.getTheValue)(mouseData.startPoint.x));
	                                        } else if (mouseData.clsName == 'axis_input_element_1') {
	                                            _examModel.setResValue(1, (0, _ShapeMarkPoint.getTheValue)(mouseData.startPoint.x));
	                                        } else if (mouseData.clsName == 'axis_input_element_2') {
	                                            _examModel.setResValue(2, (0, _ShapeMarkPoint.getTheValue)(mouseData.startPoint.x));
	                                        } else if (mouseData.clsName == 'axis_input_element_3') {
	                                            _examModel.setResValue(3, (0, _ShapeMarkPoint.getTheValue)(mouseData.startPoint.x));
	                                        }
	                                        if ($(_presenter2['default'].view).find('.on')[0].className.indexOf(selectedObj.parent.userData.clsName) == -1) {
	                                            //mark
	                                            $(_presenter2['default'].view).find('.on').removeClass('on');
	                                            $(_presenter2['default'].view).find('.' + mouseData.clsName).addClass('on');
	                                        }
	                                    }
	                                    if (_examModel.isInteger == true) {
	                                        console.log('add index', index);
	                                        if (mouseData.startPoint.x >= _constants.REAL_ESTATE.endPosition - _ShapeAxisView.offsetX) {
	                                            return;
	                                        }
	                                        var newPoint = new THREE.Vector3();
	                                        newPoint.x = mouseData.startPoint.x;
	                                        var markPoint = (0, _ShapeAddMarkPoint.AddMarkPoint)(newPoint, mouseData.clsName);
	                                        if (markPoint) {
	                                            var _position2 = new THREE.Vector3();
	                                            _position2.x = markPoint.position.x - _ShapeAxisView.offsetX + _ShapeAxisView.offsetXY;
	                                            _position2.y = _ShapeAxisView.offsetY;
	                                            _examModel.connectContorl.drawConnectLine(mouseData.clsName, _position2);
	                                            (0, _UtilsSetZPosition2['default'])(markPoint);
	                                            markPoint = null;
	                                            //selectedObj.name = null;
	                                        }
	                                        if (mouseData.clsName == 'axis_input_element_0') {
	                                            _examModel.setResValue(0, (0, _ShapeMarkPoint.getTheValue)(mouseData.startPoint.x + _ShapeAxisView.offsetX));
	                                        } else if (mouseData.clsName == 'axis_input_element_1') {
	                                            _examModel.setResValue(1, (0, _ShapeMarkPoint.getTheValue)(mouseData.startPoint.x + _ShapeAxisView.offsetX));
	                                        } else if (mouseData.clsName == 'axis_input_element_2') {
	                                            _examModel.setResValue(2, (0, _ShapeMarkPoint.getTheValue)(mouseData.startPoint.x + _ShapeAxisView.offsetX));
	                                        } else if (mouseData.clsName == 'axis_input_element_3') {
	                                            _examModel.setResValue(3, (0, _ShapeMarkPoint.getTheValue)(mouseData.startPoint.x + _ShapeAxisView.offsetX));
	                                        }
	                                        if ($(_presenter2['default'].view).find('.on')[0].className.indexOf(selectedObj.parent.userData.clsName) == -1) {
	                                            $(_presenter2['default'].view).find('.on').removeClass('on');
	                                            $(_presenter2['default'].view).find('.' + mouseData.clsName).addClass('on');
	                                        }
	                                    }
	                                }
	                                if (examType == _constants.EXAM_TYPE.Calculate_Note) {
	                                    var newPoint = new THREE.Vector3();
	                                    newPoint.x = mouseData.startPoint.x;
	                                    var markPoint = (0, _ShapeAddMarkPoint.AddMarkPoint)(newPoint, mouseData.clsName);
	                                }
	                            } else {
	                                //dialog.tips('我想AddMarkPoint，发现存在相同标识点')
	                            }

	                            _presenter2['default'].renderer();
	                            break;
	                        case 'interval':
	                            if (selectedObj.parent.parent && selectedObj.parent.parent.name == 'section') {
	                                selectedObj.name == 'outCircle' || selectedObj.name == 'inCircle' ? (0, _UtilsUpdatePointStatus2['default'])(selectedObj.parent) : null;
	                            }
	                            // if(selectedObj.name == 'outCircle' || selectedObj.name =='inCircle'){
	                            //      ? updatePointStatus(selectedObj.parent) : null;
	                            // }
	                            else {
	                                    if (_UtilsToolbarJs.toolbarStatus.sectionAttr.length > 0) {
	                                        if (mouseData.startPoint <= parent.data.pointB && mouseData.startPoint >= parent.data.pointA) {
	                                            if (_UtilsToolbarJs.toolbarStatus.startPoint) {
	                                                if (Math.abs(mouseData.startPoint.x - parent.position.x - _UtilsToolbarJs.toolbarStatus.startPoint.position.x) >= 40) {
	                                                    var sectionGroup = undefined,
	                                                        text = undefined,
	                                                        startSide = undefined,
	                                                        endSide = undefined,
	                                                        line = undefined,
	                                                        sectionText = undefined,
	                                                        sectionPosition = undefined,
	                                                        color = undefined;
	                                                    mouseData.startPoint.y = 0;
	                                                    sectionGroup = new THREE.Object3D();
	                                                    sectionGroup.data = {};
	                                                    color = _UtilsToolbarJs.toolbarStatus.sectionAttr[0].sectionColor;
	                                                    _UtilsToolbarJs.toolbarStatus.endPoint = (0, _ShapePoint2['default'])(parent.data.lineWidth, color);
	                                                    _UtilsToolbarJs.toolbarStatus.endPoint.position.x = mouseData.startPoint.x - parent.position.x;
	                                                    _UtilsToolbarJs.toolbarStatus.endPoint.position.z = 0.1;
	                                                    _UtilsToolbarJs.toolbarStatus.endPoint.name = 'endPoint';

	                                                    startSide = (0, _ShapeSectionLine.createSide)(_UtilsToolbarJs.toolbarStatus.startPoint.position, _UtilsToolbarJs.toolbarStatus.sectionAttr[0].sectionHeight, parent.data.lineWidth, color);
	                                                    startSide.side.name = 'startSide';
	                                                    endSide = (0, _ShapeSectionLine.createSide)(_UtilsToolbarJs.toolbarStatus.endPoint.position, _UtilsToolbarJs.toolbarStatus.sectionAttr[0].sectionHeight, parent.data.lineWidth, color);
	                                                    endSide.side.name = 'endSide';
	                                                    startSide.upVector.y -= parent.data.lineWidth / 2;
	                                                    endSide.upVector.y -= parent.data.lineWidth / 2;
	                                                    line = (0, _ShapeSectionLine.createLine)(startSide.upVector, endSide.upVector, parent.data.lineWidth, color);
	                                                    sectionPosition = new THREE.Vector2((startSide.upVector.x + endSide.upVector.x) / 2, _UtilsToolbarJs.toolbarStatus.sectionAttr[0].sectionHeight + 15);

	                                                    sectionGroup.add(startSide.side);
	                                                    sectionGroup.add(endSide.side);
	                                                    sectionGroup.add(line);
	                                                    sectionGroup.add(_UtilsToolbarJs.toolbarStatus.endPoint);
	                                                    sectionGroup.add(_UtilsToolbarJs.toolbarStatus.startPoint);
	                                                    parent.add(sectionGroup);

	                                                    text = (0, _UtilsComputeSection2['default'])(sectionGroup, _UtilsToolbarJs.toolbarStatus.startPoint.position, _UtilsToolbarJs.toolbarStatus.endPoint.position);
	                                                    sectionText = (0, _ShapeSectionLine.createText)(text, sectionPosition, color);
	                                                    sectionGroup.add(sectionText);

	                                                    sectionGroup.data.startVector = _UtilsToolbarJs.toolbarStatus.startPoint.position;
	                                                    sectionGroup.data.endVector = _UtilsToolbarJs.toolbarStatus.endPoint.position;
	                                                    sectionGroup.data.startHeight = _UtilsToolbarJs.toolbarStatus.sectionAttr[0].sectionHeight;
	                                                    sectionGroup.data.endHeight = _UtilsToolbarJs.toolbarStatus.sectionAttr[0].sectionHeight;
	                                                    sectionGroup.data.startSideVector = startSide.upVector;
	                                                    sectionGroup.data.endSideVector = endSide.upVector;
	                                                    sectionGroup.data.sectionColor = color;
	                                                    sectionGroup.name = 'section';
	                                                    (0, _UtilsSetZPosition2['default'])(sectionGroup);
	                                                    // 刷新交并集
	                                                    (0, _UtilsRefreshSection2['default'])(parent);

	                                                    var sections = (0, _UtilsGetSections2['default'])(parent).sections;
	                                                    if (sections.length >= 2) {
	                                                        $('.mix').removeClass('btn_disable');
	                                                        $('.union').removeClass('btn_disable');
	                                                    }

	                                                    _UtilsToolbarJs.toolbarStatus.referInterval.push(_UtilsToolbarJs.toolbarStatus.startPoint);
	                                                    _UtilsToolbarJs.toolbarStatus.referInterval.push(_UtilsToolbarJs.toolbarStatus.endPoint);
	                                                    _UtilsToolbarJs.toolbarStatus.sectionAttr.splice(0, 1);
	                                                    _UtilsToolbarJs.toolbarStatus.startPoint = null;
	                                                }
	                                            } else {
	                                                mouseData.startPoint.y = 0;
	                                                _UtilsToolbarJs.toolbarStatus.startPoint = (0, _ShapePoint2['default'])(parent.data.lineWidth, _UtilsToolbarJs.toolbarStatus.sectionAttr[0].sectionColor);
	                                                _UtilsToolbarJs.toolbarStatus.startPoint.position.x = mouseData.startPoint.x - parent.position.x;
	                                                _UtilsToolbarJs.toolbarStatus.startPoint.position.z = 0.1;
	                                                _UtilsToolbarJs.toolbarStatus.startPoint.name = 'startPoint';
	                                                parent.add(_UtilsToolbarJs.toolbarStatus.startPoint);
	                                                (0, _UtilsSetZPosition2['default'])(_UtilsToolbarJs.toolbarStatus.startPoint);
	                                            }
	                                        }
	                                    }
	                                }
	                            _presenter2['default'].renderer();
	                            break;
	                        case 'regulation':
	                            //nicemark
	                            var examModel = (0, _moduleControl.getAxisExamModel)();
	                            if (_UtilsToolbarJs.toolbarStatus.lineColor.length) {
	                                var pointText = ((mouseData.startPoint.x - parent.position.x) / parent.data.unitLength).toFixed(1);
	                                if (mouseData.startPoint.x - parent.position.x <= parent.data.pointB.x && mouseData.startPoint.x - parent.position.x >= parent.data.pointA.x) {
	                                    if (_UtilsToolbarJs.toolbarStatus.startPoint && _UtilsAddCurve.regulationCount == 0) {
	                                        if (Math.abs(mouseData.startPoint.x - parent.position.x - _UtilsToolbarJs.toolbarStatus.startPoint.position.x) >= 20) {

	                                            /**fix bug:35902 自然数范围点击越界。**/
	                                            var offsetXPadding = undefined;
	                                            if (examModel.isInteger) {
	                                                offsetXPadding = _constants.REAL_ESTATE.endPosition - _ShapeAxisView.offsetX;
	                                            } else {
	                                                offsetXPadding = _constants.REAL_ESTATE.endPosition;
	                                            }
	                                            /** end fix bug**/
	                                            if (mouseData.startPoint.x >= offsetXPadding) {

	                                                console.log("first x break");

	                                                break;
	                                            }
	                                            _UtilsToolbarJs.toolbarStatus.endPoint = (0, _ShapePoint2['default'])(parent.data.lineWidth, _UtilsToolbarJs.toolbarStatus.lineColor[0], parent.data.smallUnitVisible ? pointText : undefined, new THREE.Vector2(0, -30), pointCount);
	                                            pointCount++;
	                                            console.log('first end point added, pointCount is:', pointCount);
	                                            _UtilsToolbarJs.toolbarStatus.endPoint.position.x = mouseData.startPoint.x - parent.position.x;
	                                            _UtilsToolbarJs.toolbarStatus.endPoint.name = 'terminal';
	                                            var curve = new _UtilsAddCurve2['default'](_UtilsToolbarJs.toolbarStatus, parent.position, parent.data.unitLength / parent.data.unitMultiple);
	                                            curve.add(_UtilsToolbarJs.toolbarStatus.startPoint);
	                                            curve.add(_UtilsToolbarJs.toolbarStatus.endPoint);
	                                            parent.add(curve);
	                                            (0, _UtilsSetZPosition2['default'])(curve);
	                                            if (pointCount != 8) {
	                                                //let tempPoint=new THREE.Object3D();
	                                                //tempPoint.copy(toolbarStatus.endPoint);
	                                                tempStartPoint = _UtilsToolbarJs.toolbarStatus.startPoint;
	                                                _UtilsToolbarJs.toolbarStatus.startPoint = _UtilsToolbarJs.toolbarStatus.endPoint;
	                                                _UtilsToolbarJs.toolbarStatus.startPoint.name = 'terminal';
	                                                _UtilsToolbarJs.toolbarStatus.startPoint.pointCount = pointCount;
	                                                pointCount++;
	                                                _constants.answerValue[0] = examModel.userResValue[0];
	                                                if (examModel.isInteger) {
	                                                    if (mouseData.startPoint.x + _ShapeAxisView.offsetX - tempStartPoint.position.x > 0) {
	                                                        //try
	                                                        _constants.answerValue[answerIndex] = (0, _ShapeMarkPoint.getTheValue)(mouseData.startPoint.x + _ShapeAxisView.offsetX - tempStartPoint.position.x);
	                                                        symbolArray[symbolIndex] = "1";
	                                                        tempPosition = mouseData.startPoint.x;
	                                                    } else {
	                                                        _constants.answerValue[answerIndex] = (0, _ShapeMarkPoint.getTheValue)(Math.abs(mouseData.startPoint.x + _ShapeAxisView.offsetX - tempStartPoint.position.x));
	                                                        symbolArray[symbolIndex] = "-1";
	                                                        tempPosition = mouseData.startPoint.x;
	                                                    }
	                                                } else {
	                                                    if (mouseData.startPoint.x - tempStartPoint.position.x > 0) {
	                                                        _constants.answerValue[answerIndex] = (0, _ShapeMarkPoint.getTheValue)(mouseData.startPoint.x - tempStartPoint.position.x);
	                                                        symbolArray[symbolIndex] = "1";
	                                                        tempPosition = mouseData.startPoint.x;
	                                                    } else {
	                                                        _constants.answerValue[answerIndex] = (0, _ShapeMarkPoint.getTheValue)(Math.abs(mouseData.startPoint.x - tempStartPoint.position.x));
	                                                        symbolArray[symbolIndex] = "-1";
	                                                        tempPosition = mouseData.startPoint.x;
	                                                    }
	                                                }
	                                                symbolIndex++;
	                                                answerIndex++;
	                                                console.log('answerValue is', _constants.answerValue);
	                                                console.log('symbolValue is', symbolArray);
	                                                examModel.setUserRes(_constants.answerValue, symbolArray);
	                                                console.log('setUserRes executed,getUserRes is', examModel.getUserRes());
	                                            }
	                                        }
	                                    } else if (_UtilsToolbarJs.toolbarStatus.startPoint && _UtilsAddCurve.regulationCount != 0 && selectedObj.parent.name != 'outset' && selectedObj.parent.name != 'terminal') {
	                                        //if (mouseData.startPoint.x >= REAL_ESTATE.endPosition) {

	                                        /**fix bug:35902 自然数范围点击越界。**/
	                                        var offsetXPadding = undefined;
	                                        if (examModel.isInteger) {
	                                            offsetXPadding = _constants.REAL_ESTATE.endPosition - _ShapeAxisView.offsetX;
	                                        } else {
	                                            offsetXPadding = _constants.REAL_ESTATE.endPosition;
	                                        }
	                                        /**end fix bug**/

	                                        if (mouseData.startPoint.x >= offsetXPadding) {

	                                            console.log("second x break");

	                                            break;
	                                        }
	                                        symbolIndex--;
	                                        answerIndex--;
	                                        pointCount = pointCount - 2;
	                                        var regulation = parent.getObjectByName('regulation0');
	                                        (0, _UtilsAddCurve.setRegulationCount)(_UtilsAddCurve.regulationCount - 1);
	                                        regulation.parent.remove(regulation);
	                                        _UtilsToolbarJs.toolbarStatus.startPoint = tempStartPoint;
	                                        if (Math.abs(mouseData.startPoint.x - parent.position.x - _UtilsToolbarJs.toolbarStatus.startPoint.position.x) >= 20) {
	                                            _UtilsToolbarJs.toolbarStatus.endPoint = (0, _ShapePoint2['default'])(parent.data.lineWidth, _UtilsToolbarJs.toolbarStatus.lineColor[0], parent.data.smallUnitVisible ? pointText : undefined, new THREE.Vector2(0, -30), pointCount);
	                                            pointCount++;
	                                            console.log('second end point added, pointCount is:', pointCount);
	                                            _UtilsToolbarJs.toolbarStatus.endPoint.position.x = mouseData.startPoint.x - parent.position.x;
	                                            _UtilsToolbarJs.toolbarStatus.endPoint.name = 'terminal';
	                                            var curve = new _UtilsAddCurve2['default'](_UtilsToolbarJs.toolbarStatus, parent.position, parent.data.unitLength / parent.data.unitMultiple);
	                                            curve.add(_UtilsToolbarJs.toolbarStatus.startPoint);
	                                            curve.add(_UtilsToolbarJs.toolbarStatus.endPoint);
	                                            parent.add(curve);
	                                            (0, _UtilsSetZPosition2['default'])(curve);
	                                            if (pointCount != 8) {
	                                                pointCount++;
	                                                if (examModel.isInteger) {
	                                                    if (mouseData.startPoint.x + _ShapeAxisView.offsetX - tempStartPoint.position.x > 0) {
	                                                        //try
	                                                        _constants.answerValue[answerIndex] = (0, _ShapeMarkPoint.getTheValue)(mouseData.startPoint.x + _ShapeAxisView.offsetX - tempStartPoint.position.x);
	                                                        symbolArray[symbolIndex] = "1";
	                                                        tempPosition = mouseData.startPoint.x;
	                                                    } else {
	                                                        _constants.answerValue[answerIndex] = (0, _ShapeMarkPoint.getTheValue)(Math.abs(mouseData.startPoint.x + _ShapeAxisView.offsetX - tempStartPoint.position.x));
	                                                        symbolArray[symbolIndex] = "-1";
	                                                        tempPosition = mouseData.startPoint.x;
	                                                    }
	                                                } else {
	                                                    if (mouseData.startPoint.x - tempStartPoint.position.x > 0) {
	                                                        _constants.answerValue[answerIndex] = (0, _ShapeMarkPoint.getTheValue)(mouseData.startPoint.x - tempStartPoint.position.x);
	                                                        symbolArray[symbolIndex] = "1";
	                                                        tempPosition = mouseData.startPoint.x;
	                                                    } else {
	                                                        _constants.answerValue[answerIndex] = (0, _ShapeMarkPoint.getTheValue)(Math.abs(mouseData.startPoint.x - tempStartPoint.position.x));
	                                                        symbolArray[symbolIndex] = "-1";
	                                                        tempPosition = mouseData.startPoint.x;
	                                                    }
	                                                }
	                                                symbolIndex++;
	                                                answerIndex++;
	                                                examModel.setUserRes(_constants.answerValue, symbolArray);
	                                            }
	                                        }
	                                    } else if (selectedObj.parent.name == 'outset' || selectedObj.parent.name == 'terminal') {
	                                        break;
	                                    } else {
	                                        //try//try
	                                        _UtilsToolbarJs.toolbarStatus.startPoint = (0, _ShapePoint2['default'])(parent.data.lineWidth, _UtilsToolbarJs.toolbarStatus.lineColor[0], parent.data.smallUnitVisible ? pointText : undefined, new THREE.Vector2(0, -30), pointCount);
	                                        _UtilsToolbarJs.toolbarStatus.startPoint.position.x = mouseData.startPoint.x - parent.position.x;
	                                        _UtilsToolbarJs.toolbarStatus.startPoint.name = 'outset';
	                                        parent.add(_UtilsToolbarJs.toolbarStatus.startPoint);
	                                        (0, _UtilsSetZPosition2['default'])(_UtilsToolbarJs.toolbarStatus.startPoint);
	                                        pointCount++;
	                                        if (examModel.isInteger) {
	                                            _constants.answerValue[answerIndex] = (0, _ShapeMarkPoint.getTheValue)(mouseData.startPoint.x + _ShapeAxisView.offsetX);
	                                            regulationClick[regulationClickIndex] = (0, _ShapeMarkPoint.getTheValue)(mouseData.startPoint.x + _ShapeAxisView.offsetX);
	                                            tempPosition = mouseData.startPoint.x + _ShapeAxisView.offsetX;
	                                        } else {
	                                            _constants.answerValue[answerIndex] = (0, _ShapeMarkPoint.getTheValue)(mouseData.startPoint.x);
	                                            regulationClick[regulationClickIndex] = (0, _ShapeMarkPoint.getTheValue)(mouseData.startPoint.x);
	                                            tempPosition = mouseData.startPoint.x;
	                                        }
	                                        regulationClickIndex++;
	                                        answerIndex++;
	                                        //examModel.setUserRes(answerValue, []);//第一下点击不传值
	                                        console.log('setUserRes executed,getUserRes is', examModel.getUserRes());
	                                    }
	                                }
	                            }
	                            _presenter2['default'].renderer();
	                            break;

	                    }
	                } else if (!isDown && _UtilsToolbarJs.toolbarStatus._action == 'mark') {
	                    console.log($(_presenter2['default'].view).find('.on'), 'it is on');
	                    var examModel = (0, _moduleControl.getAxisExamModel)();
	                    if (examModel.isInteger == false) {
	                        if (selectedObj.parent.userData.clsName == 'axis_input_element_0') {
	                            examModel.setResValue(0, (0, _ShapeMarkPoint.getTheValue)(selectedObj.parent.position.x));
	                        } else if (selectedObj.parent.userData.clsName == 'axis_input_element_1') {
	                            examModel.setResValue(1, (0, _ShapeMarkPoint.getTheValue)(selectedObj.parent.position.x));
	                        } else if (selectedObj.parent.userData.clsName == 'axis_input_element_2') {
	                            examModel.setResValue(2, (0, _ShapeMarkPoint.getTheValue)(selectedObj.parent.position.x));
	                        } else if (selectedObj.parent.userData.clsName == 'axis_input_element_3') {
	                            examModel.setResValue(3, (0, _ShapeMarkPoint.getTheValue)(selectedObj.parent.position.x));
	                        }
	                    } else {
	                        if (selectedObj.parent.userData.clsName == 'axis_input_element_0') {
	                            examModel.setResValue(0, (0, _ShapeMarkPoint.getTheValue)(selectedObj.parent.position.x));
	                        } else if (selectedObj.parent.userData.clsName == 'axis_input_element_1') {
	                            examModel.setResValue(1, (0, _ShapeMarkPoint.getTheValue)(selectedObj.parent.position.x));
	                        } else if (selectedObj.parent.userData.clsName == 'axis_input_element_2') {
	                            examModel.setResValue(2, (0, _ShapeMarkPoint.getTheValue)(selectedObj.parent.position.x));
	                        } else if (selectedObj.parent.userData.clsName == 'axis_input_element_3') {
	                            examModel.setResValue(3, (0, _ShapeMarkPoint.getTheValue)(selectedObj.parent.position.x));
	                        }
	                    }
	                    console.log('answerValue is ', _constants.answerValue);
	                } else if (!isDown && _UtilsToolbarJs.toolbarStatus._action == 'regulation' && selectedObj.name != 'group') {
	                    var examModel = (0, _moduleControl.getAxisExamModel)();
	                    if (selectedObj.parent.name == 'outset') {
	                        var terminal = selectedObj.parent.parent.getObjectByName('terminal');
	                        //if (examModel.isInteger) {
	                        _constants.answerValue[0] = (0, _ShapeMarkPoint.getTheValue)(selectedObj.parent.position.x);
	                        _constants.answerValue[1] = (0, _ShapeMarkPoint.getTheValue)(Math.abs(terminal.position.x - selectedObj.parent.position.x));
	                        if (terminal.position.x - selectedObj.parent.position.x > 0) {
	                            symbolArray[0] = 1;
	                        } else {
	                            symbolArray[0] = -1;
	                        }
	                        tempPosition = selectedObj.parent.position.x;
	                        //} else {
	                        //    answerValue[0] = getTheValue(mouseData.startPoint.x);
	                        //    answerValue[1] = getTheValue(terminal.position.x - selectedObj.parent.position.x);
	                        //    tempPosition = mouseData.startPoint.x;
	                        //    if (terminal.position.x - selectedObj.parent.position.x > 0) {
	                        //        symbolArray[0] = 1;
	                        //    } else {
	                        //        symbolArray[0] = -1;
	                        //    }
	                        //}
	                    } else if (selectedObj.parent.name == 'terminal') {
	                            var outset = selectedObj.parent.parent.getObjectByName('outset');
	                            //if (examModel.isInteger) {
	                            _constants.answerValue[1] = (0, _ShapeMarkPoint.getTheValue)(Math.abs(selectedObj.parent.position.x - outset.position.x));
	                            //answerValue[1] = getTheValue(selectedObj.parent.position.x);
	                            tempPosition = selectedObj.parent.position.x;
	                            if (selectedObj.parent.position.x - outset.position.x > 0) {
	                                symbolArray[0] = 1;
	                            } else {
	                                symbolArray[0] = -1;
	                            }
	                            //} else {
	                            //    answerValue[1] = getTheValue(mouseData.startPoint.x);
	                            //    tempPosition = selectedObj.parent.position.x;
	                            //    if (selectedObj.parent.position.x - outset.position.x > 0) {
	                            //        symbolArray[0] = 1;
	                            //    } else {
	                            //        symbolArray[0] = -1;
	                            //    }
	                            //}
	                        }
	                    console.log('when mouse up ', _constants.answerValue, symbolArray);
	                    examModel.setUserRes(_constants.answerValue, symbolArray);
	                    console.log('setUserRes executed,getUserRes is', examModel.getUserRes());
	                    _presenter2['default'].renderer();
	                }

	                var position = undefined,
	                    remainLength = undefined;
	                switch (selectedObj.name) {
	                    case 'controllerRight':
	                        position = selectedObj.position;
	                        remainLength = (position.x - parent.data.controllerDis) % parent.data.unitLength;
	                        if (remainLength <= parent.data.unitLength / 2) {
	                            position.x += parent.data.unitLength / 2 - remainLength;
	                        } else {
	                            position.x -= remainLength - parent.data.unitLength / 2;
	                        }
	                        selectedObj.position.copy(position);
	                        (0, _UtilsUpdateLine2['default'])('controllerRight', parent, selectedObj);
	                        break;
	                    case 'controllerLeft':
	                        position = selectedObj.position;
	                        remainLength = (position.x + parent.data.controllerDis) % parent.data.unitLength;
	                        if (remainLength <= parent.data.unitLength / 2) {
	                            position.x -= parent.data.unitLength / 2 + remainLength;
	                        } else {
	                            position.x += remainLength + parent.data.unitLength / 2;
	                        }
	                        selectedObj.position.copy(position);
	                        (0, _UtilsUpdateLine2['default'])('controllerLeft', parent, selectedObj);
	                        break;
	                    case 'outCircle':
	                    case 'inCircle':
	                        if (selectedObj.parent.parent.name == 'section') {
	                            (0, _UtilsUpdateSection2['default'])(selectedObj.parent, 0, 'up');
	                        }
	                        break;
	                    // case 'startSide':
	                    // case 'endSide':
	                    // case 'sectionLine':
	                    // case 'sectionText':
	                    //     if (selectedObj.parent.name == 'section') {
	                    //         updateSection(selectedObj, 0, 'up');
	                    //     }
	                    //     break;
	                    case 'markPointText':
	                        (0, _UtilsEditeMarkPointText.editeMarkPointText)(selectedObj, true); //进入标识点的编辑状态
	                        break;
	                    case 'markPointCircle':
	                        //移动鼠标抬起判断标识点的最后位置
	                        (0, _UtilsUpMarkPoint.upMarkPoint)(selectedObj, (0, _ShapeAddMarkPoint.getPositionCollection)(), parent);
	                        (0, _UtilsMoveMarkPoint.setMoveStatus)(false);
	                        //移动标识点抬起的时候刷新各个标识点的位置坐标
	                        (0, _UtilsMoveMarkPoint.refreshArray)(selectedObj.parent.parent);
	                        (0, _UtilsMoveMarkPoint.changeisFirst)();
	                        break;
	                }
	                mouseData.activedObj ? ((0, _UtilsSetColor2['default'])(mouseData.activedObj.obj, mouseData.activedObj.originColor), mouseData.activedObj = null) : null;
	                isDown = false;
	                selectedObj = null;
	            }
	        }
	        clearTimeout(setTextTimeOut);
	        setTextTimeOut = null;
	        // offset = new THREE.Vector3();
	        mouseData = {};
	        container.css({ cursor: "default" });
	        _presenter2['default'].renderer();
	        rendererDom.removeEventListener('mousemove', onDocumentMouseMove, false);
	        rendererDom.removeEventListener('mouseup', onDocumentMouseUp, false);
	        rendererDom.removeEventListener('mouseout', onDocumentMouseUp, false);

	        rendererDom.removeEventListener('touchmove', onDocumentMouseMove, false);
	        rendererDom.removeEventListener('touchend', onDocumentMouseUp, false);
	        rendererDom.removeEventListener("touchcancel", onDocumentMouseUp, false);
	        rendererDom.removeEventListener('touchleave', onDocumentMouseUp, false);
	    }

	    function numLineMove() {
	        container.css({ cursor: "move" });
	        var intersectsPlane = _threeManger.raycaster.intersectObjects([_threeManger.plane]);
	        var point1 = intersectsPlane[0].point;
	        var point2 = point1.clone();
	        var distance = point1.sub(mouseData.startPoint);

	        var sideData = sideControll();
	        parent.position.copy(parent.position.add(distance));
	        if (parent.position.x >= sideData.right) {
	            parent.position.x = sideData.right;
	        }
	        if (parent.position.x <= sideData.left) {
	            parent.position.x = sideData.left;
	        }
	        if (parent.position.y >= sideData.top) {
	            parent.position.y = sideData.top;
	        }
	        if (parent.position.y <= sideData.bottom) {
	            parent.position.y = sideData.bottom;
	        }
	        mouseData.startPoint.copy(point2);
	    }

	    // 数轴边界控制
	    function sideControll() {
	        var unitLength = parent.data.unitLength;
	        var center = new THREE.Vector3(0, 0, 0);
	        var vectorCB = new THREE.Vector2().subVectors(center, parent.data.pointB);
	        var vectorCA = new THREE.Vector2().subVectors(center, parent.data.pointA);
	        var left = -_constants.REAL_ESTATE.width / 2 - vectorCB.length() + unitLength;
	        var right = _constants.REAL_ESTATE.width / 2 + vectorCA.length() - unitLength;
	        var top = _constants.REAL_ESTATE.height / 2 - 20;
	        var bottom = -_constants.REAL_ESTATE.height / 2 + 30;

	        var disLeft = parent.position.x - left;
	        var disRight = parent.position.x - right;
	        return {
	            left: left,
	            right: right,
	            top: top,
	            bottom: bottom,
	            disLeft: disLeft,
	            disRight: disRight,
	            CB: vectorCB.length(),
	            CA: vectorCA.length()
	        };
	    }

	    // 数轴缩放

	    function scale(dis) {
	        var isEdit = isEditFn();
	        if (isEdit) return; // 如果数轴已被编辑(有标识点，区间，增减线等)，不可缩放;
	        var unitController = parent.getObjectByName('unitController');
	        var pointA = parent.data.pointA;
	        var pointB = parent.data.pointB;
	        var unitMultiple = parent.data.unitMultiple;
	        var unitLength = parent.data.unitLength;
	        var lineWidth = parent.data.lineWidth;
	        var unitHeight = parent.data.unitHeight;
	        var vectorCB = new THREE.Vector2().subVectors(new THREE.Vector3(0, 0, 0), parent.data.pointB);

	        if (vectorCB.length() > 300) {
	            if (dis < 0 && unitLength >= 50) {
	                unitLength -= 10;
	            }
	            if (dis > 0 && unitLength <= 290) {
	                unitLength += 10;
	            }
	        } else {
	            if (dis < 0 && unitLength >= 50) {
	                unitLength -= 10;
	            }
	            if (dis > 0 && unitLength <= vectorCB.length() - 50) {
	                unitLength += 10;
	            }
	        }

	        // 循环缩放
	        if (unitLength <= 40) {
	            unitMultiple *= 2;
	            unitLength = 80;
	        }
	        if (unitLength > 80) {
	            unitMultiple /= 2;
	            unitLength = 40;
	        }
	        // 处理刻度值变化0.1~1000，
	        if (unitMultiple < 0.1 || unitMultiple > 1000) {
	            return false;
	        }
	        // 调整刻度值
	        var arrTemp = [0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 50, 100, 200, 500, 1000];
	        if (arrTemp.indexOf(unitMultiple) == -1) {
	            unitMultiple = findClosest(arrTemp, unitMultiple);
	        }

	        (0, _UtilsUpdateUnit2['default'])(parent, pointA, pointB, unitMultiple, unitLength, lineWidth, unitHeight);
	        parent.data.unitLength = unitLength;
	        parent.data.unitMultiple = unitMultiple;
	        unitController.position.x = unitLength;
	    }

	    // 多点触控
	    function multipleTouch(event) {
	        var touchA = new THREE.Vector3(),
	            touchB = new THREE.Vector3(); // 两点坐标
	        var isEnlarge = 0; //  缩小还是放大
	        // 移动过程中如果松开一个手指，就不再继续执行
	        var finger1 = event.targetTouches[0];
	        var finger2 = event.targetTouches[1];
	        touchA.x = (finger1.clientX - container.offset().left) / _constants.REAL_ESTATE.width * 2 - 1;
	        touchA.y = -((finger1.clientY - container.offset().top) / _constants.REAL_ESTATE.height) * 2 + 1;
	        touchB.x = (finger2.clientX - container.offset().left) / _constants.REAL_ESTATE.width * 2 - 1;
	        touchB.y = -((finger2.clientY - container.offset().top) / _constants.REAL_ESTATE.height) * 2 + 1;

	        fingerDis = touchA.distanceTo(touchB);
	        isEnlarge = (fingerDisOld - fingerDis).toFixed(2);
	        if (isEnlarge != 0) {
	            scale(isEnlarge);
	        }
	        fingerDisOld = fingerDis;
	    }

	    // 选中高亮
	    // function highlight(obj) {
	    //     let oldObjName = parent.userData.oldObjName;
	    //     if (obj.name == oldObjName) {
	    //         return false
	    //     }
	    //     console.log(parent.userData.color);
	    //     if (parent.userData.oldObjName) {
	    //         scene.getObjectByName(oldObjName).material.color.set(parent.userData.color);
	    //     }

	    //     parent.userData.color = obj.material.color;
	    //     parent.userData.oldObjName = obj.name;

	    //     obj.material.color.set(0xff0000);
	    // }

	    // 查找最近值
	    function findClosest(arr, num) {
	        var ret = arr[0];
	        var distance = Math.abs(ret - num);
	        for (var i = 1; i < arr.length; i++) {
	            var newDistance = Math.abs(arr[i] - num);
	            if (newDistance < distance) {
	                distance = newDistance;
	                ret = arr[i];
	            }
	        }
	        return ret;
	    }

	    // 判断数轴上是否有标识点，区间，增减线等；
	    function isEditFn() {
	        var isEdit = undefined;
	        var markPoint = _threeManger.scene.getObjectByName("markPoint"); // 标识点
	        var torus = _threeManger.scene.getObjectByName("torus"); // 增减线
	        var section = _threeManger.scene.getObjectByName("section"); // 区间
	        // TODO 交集并集
	        if (markPoint || torus || section) {
	            isEdit = true;
	        }
	        return isEdit;
	    }

	    // 获取制定父元素 用于删除区间，增减线
	    function getTopParent(obj) {
	        if (obj.name == "regulation" || obj.name == "section") {
	            if (obj.name == "regulation") {
	                _UtilsToolbarJs.toolbarStatus.lineColor.unshift(obj.color);
	            }
	            if (obj.name == "section") {
	                var objData = { sectionColor: obj.data.sectionColor, sectionHeight: obj.data.endHeight };
	                _UtilsToolbarJs.toolbarStatus.sectionAttr.unshift(objData);
	                (0, _UtilsUpdateSection2['default'])(obj.children[0], 0);
	                deleteSectionPoint(obj);
	            }

	            obj.parent.remove(obj);
	            (0, _UtilsRefreshSection2['default'])(parent);
	            var sections = (0, _UtilsGetSections2['default'])(parent).sections;
	            if (sections.length < 2) {
	                $('.mix').addClass('btn_disable');
	                $('.union').addClass('btn_disable');
	            }
	            if (sections.length == 0) {
	                _UtilsToolbarJs.toolbarStatus.isShowIntersection = false;
	                _UtilsToolbarJs.toolbarStatus.isShowUnion = false;
	            }
	        } else {
	            (0, _UtilsIsShowUnitController2['default'])(parent);
	            if (!obj.parent) return;
	            getTopParent(obj.parent);
	        }
	        (0, _UtilsIsShowUnitController2['default'])(parent);
	    }

	    function onWindowResize() {
	        var container = $(_presenter2['default'].view).find('.numberline-canvas')[0];
	        console.log(_constants.REAL_ESTATE.width);
	        _constants.REAL_ESTATE.width = container.offsetWidth;
	        _constants.REAL_ESTATE.height = container.offsetHeight;
	        console.log(_constants.REAL_ESTATE.width);

	        _threeManger.camera.left = _constants.REAL_ESTATE.width / -2;
	        _threeManger.camera.right = _constants.REAL_ESTATE.width / 2;
	        _threeManger.camera.top = _constants.REAL_ESTATE.height / 2;
	        _threeManger.camera.bottom = _constants.REAL_ESTATE.height / -2;
	        _threeManger.camera.updateProjectionMatrix();
	        _threeManger.renderer.setSize(_constants.REAL_ESTATE.width, _constants.REAL_ESTATE.height);
	    }

	    // 删除区间端点数组中已删除的区间端点
	    function deleteSectionPoint(obj) {
	        var startPoint = obj.getObjectByName('startPoint');
	        var endPoint = obj.getObjectByName('endPoint');
	        var point = undefined,
	            startCount = undefined,
	            endCount = undefined;
	        for (var i = 0; i < _UtilsToolbarJs.toolbarStatus.referInterval.length; i++) {
	            point = _UtilsToolbarJs.toolbarStatus.referInterval[i];
	            if (startPoint.id == point.id) {
	                _UtilsToolbarJs.toolbarStatus.referInterval.splice(i, 1);
	            }
	        }
	        for (var i = 0; i < _UtilsToolbarJs.toolbarStatus.referInterval.length; i++) {
	            point = _UtilsToolbarJs.toolbarStatus.referInterval[i];
	            if (endPoint.id == point.id) {
	                _UtilsToolbarJs.toolbarStatus.referInterval.splice(i, 1);
	            }
	        }
	    }
	};

	function clearCount() {
	    pointCount = 0;
	    regulationClickIndex = 0;
	    regulationClick = [];
	    symbolArray = [];
	    symbolIndex = 0;
	    tempPosition = 0;
	    answerIndex = 1;
	    console.log('clear all count');
	}

/***/ },
/* 10 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.threeStart = threeStart;
	exports.addThreeShape = addThreeShape;
	exports.resizeThree = resizeThree;
	exports.destroyThree = destroyThree;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _constants = __webpack_require__(4);

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _UtilsToolbar = __webpack_require__(11);

	var _UtilsToolbar2 = _interopRequireDefault(_UtilsToolbar);

	var _UtilsDestroyThreeObjectJs = __webpack_require__(52);

	var _UtilsDestroyThreeObjectJs2 = _interopRequireDefault(_UtilsDestroyThreeObjectJs);

	var renderer;
	var scene;
	var camera;
	var raycaster;
	var intersectObjs;
	var mouse;
	var currentAnimate = undefined;
	var plane = undefined;

	function initThreeForEditor() {
	    resizeThree();
	    //let container = $(presenter.view).find('.2D-canvas').get(0);
	    //创建渲染
	    exports.renderer = renderer = new THREE.WebGLRenderer({
	        canvas: $(_presenter2['default'].view).find('.numberline-canvas')[0],
	        antialias: true, //抗锯齿
	        alpha: true // apply transparent attribute
	    });
	    onWindowResize();
	    window.addEventListener('resize', onWindowResize, false); //窗口变化时适配
	    renderer.setClearColor(0xFFFFFF, 0);
	    renderer.setSize($(_presenter2['default'].view).find('.numberline-canvas').width(), $(_presenter2['default'].view).find('.numberline-canvas').height());
	    _constants.REAL_ESTATE.width = $(_presenter2['default'].view).find('.numberline-canvas').width();
	    _constants.REAL_ESTATE.height = $(_presenter2['default'].view).find('.numberline-canvas').height();
	    console.log('changed REAL_ESTATE.width ', _constants.REAL_ESTATE.width, _constants.REAL_ESTATE.height);
	}

	function initThree() {
	    resizeThree();
	    //let container = $(presenter.view).find('.2D-canvas').get(0);
	    //创建渲染
	    exports.renderer = renderer = new THREE.WebGLRenderer({
	        canvas: $(_presenter2['default'].view).find('.numberline-canvas')[0],
	        antialias: true, //抗锯齿
	        alpha: true // apply transparent attribute
	    });
	    renderer.setClearColor(0xFFFFFF, 0);
	    renderer.setSize(_constants.REAL_ESTATE.width, _constants.REAL_ESTATE.height);
	}

	function initScene() {
	    exports.scene = scene = new THREE.Scene();
	    //scene.add(new THREE.AxisHelper(100, 100));
	}

	function initCamera() {
	    //创建Camera
	    var RATIO = 2;
	    exports.camera = camera = new THREE.OrthographicCamera(_constants.REAL_ESTATE.width / -RATIO, _constants.REAL_ESTATE.width / RATIO, _constants.REAL_ESTATE.height / RATIO, _constants.REAL_ESTATE.height / -RATIO, -20000, 20000);
	    camera.position.x = 0;
	    camera.position.y = 0;
	    camera.position.z = 0;
	    camera.lookAt({ x: 0, y: 0, z: 0 });
	}

	function initRaycaster() {
	    //添加点击检测
	    exports.raycaster = raycaster = new THREE.Raycaster();
	    raycaster.linePrecision = 1;
	    exports.intersectObjs = intersectObjs = [];
	    exports.mouse = mouse = new THREE.Vector2();
	}
	function animate() {
	    //currentAnimate = requestAnimationFrame(animate);
	    //render();
	}
	function render() {
	    if (renderer) {
	        renderer.render(scene, camera);
	    }
	}
	function addPlane() {
	    exports.plane = plane = new THREE.Mesh(new THREE.PlaneBufferGeometry(_constants.REAL_ESTATE.width * 2, _constants.REAL_ESTATE.height * 2, 10, 10), new THREE.MeshBasicMaterial({ color: 0xeeeeee, visible: false }));
	    scene.add(plane);
	}

	function threeStart() {
	    if (!_presenter2['default'].isTeacherMobile && !_presenter2['default'].isTeacherPc && !_presenter2['default'].isStudentMobile && !_presenter2['default'].isWeb || _presenter2['default'].isReEdit) {
	        console.log('init reedit');
	        initCamera();
	        initScene();
	        initThreeForEditor();
	        addPlane();
	        initRaycaster();
	        //animate();
	        (0, _UtilsToolbar2['default'])();
	        _presenter2['default'].renderer = render;
	        _presenter2['default'].renderer();
	    } else {
	        initThree();
	        initCamera();
	        initScene();
	        addPlane();
	        initRaycaster();
	        //animate();
	        (0, _UtilsToolbar2['default'])();
	        _presenter2['default'].renderer = render;
	        _presenter2['default'].renderer();
	    }
	}

	function addThreeShape(threeShape) {}

	function resizeThree(width, height) {

	    var offset = $(_presenter2['default'].view).find('.numberline-canvas').offset();
	    "use strict";

	    _constants.REAL_ESTATE.offsetLeft = offset.left;
	    _constants.REAL_ESTATE.offsetTop = offset.top;
	}

	//export function destroy() {
	//    "use strict";
	//    renderer.dispose();
	//    renderer.domElement = null;
	//    //helperTool.dispose()//数轴题注释
	//    window.cancelAnimationFrame(currentAnimate);
	//
	//    renderer = null;
	//    scene = null;
	//    camera = null;
	//    raycaster = null;
	//    intersectObjs = null;
	//    mouse = null;
	//    //helperTool = null;//数轴题注释
	//}

	function destroyThree() {
	    (0, _UtilsDestroyThreeObjectJs2['default'])(camera);
	    (0, _UtilsDestroyThreeObjectJs2['default'])(scene);
	    (0, _UtilsDestroyThreeObjectJs2['default'])(renderer);
	    $(renderer.domElement).remove();
	    $(renderer.domElement).splice(0);
	    $(renderer.domElement)[0] = null;
	    exports.renderer = renderer = null;
	    exports.camera = camera = null;
	    exports.mouse = mouse = null;
	    exports.scene = scene = null;
	    exports.raycaster = raycaster = null;
	    exports.intersectObjs = intersectObjs = null;
	    window.cancelAnimationFrame(currentAnimate);
	}

	function onWindowResize() {
	    //setTimeout(function () {
	    resizeEven();
	    //}, 200);
	}
	function resizeEven() {
	    var container = $(_presenter2['default'].view).find('.number_lines_area')[0];
	    if (container.offsetWidth != 0) {
	        _constants.REAL_ESTATE.width = container.offsetWidth;
	        _constants.REAL_ESTATE.height = container.offsetHeight;
	        console.log(_constants.REAL_ESTATE.width, 'resize to');
	        //$(presenter.view).find('.numberline-canvas').css({
	        //    'left':'1%'
	        //})
	        camera.left = _constants.REAL_ESTATE.width / -2;
	        camera.right = _constants.REAL_ESTATE.width / 2;
	        camera.top = _constants.REAL_ESTATE.height / 2;
	        camera.bottom = _constants.REAL_ESTATE.height / -2;
	        camera.updateProjectionMatrix();
	        renderer.setSize(_constants.REAL_ESTATE.width, _constants.REAL_ESTATE.height);
	        if (_constants.REAL_ESTATE.width < _constants.REAL_ESTATE.frontage) {}
	    }
	    //initEditorCanvas(false);

	    console.log('resizeEven REAL_ESTATE.width ', _constants.REAL_ESTATE.width);
	    render();
	}

	exports.renderer = renderer;
	exports.scene = scene;
	exports.camera = camera;
	exports.raycaster = raycaster;
	exports.intersectObjs = intersectObjs;
	exports.mouse = mouse;
	exports.plane = plane;

/***/ },
/* 11 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.setToolbarStatus = setToolbarStatus;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _threeManger = __webpack_require__(10);

	var _UtilsDialog = __webpack_require__(12);

	var _UtilsDialog2 = _interopRequireDefault(_UtilsDialog);

	var _getSections = __webpack_require__(13);

	var _getSections2 = _interopRequireDefault(_getSections);

	var _updateIntersection = __webpack_require__(14);

	var _updateIntersection2 = _interopRequireDefault(_updateIntersection);

	var _updateUnion = __webpack_require__(24);

	var _updateUnion2 = _interopRequireDefault(_updateUnion);

	var _refreshSection = __webpack_require__(26);

	var _refreshSection2 = _interopRequireDefault(_refreshSection);

	var _isShowUnitController = __webpack_require__(27);

	var _isShowUnitController2 = _interopRequireDefault(_isShowUnitController);

	var _ShapeAddMarkPoint = __webpack_require__(28);

	var toolbarStatus = {
	    lineColor: [],
	    // copy
	    lineColorCopy: ['#03ACF6', '#00AE9D', '#0372D2', '#0D8617', '#737602', '#FBDD20', '#E64A09', '#F8374E', '#B52CF8', '#6A30E7'],

	    sectionAttr: [{ sectionColor: '#03ACF6', sectionHeight: 30 }, { sectionColor: '#00AE9D', sectionHeight: 60 }, { sectionColor: '#0372D2', sectionHeight: 90 }, { sectionColor: '#0D8617', sectionHeight: 120 }, { sectionColor: '#737602', sectionHeight: 150 }, { sectionColor: '#FBDD20', sectionHeight: 180 }, { sectionColor: '#E64A09', sectionHeight: 210 }, { sectionColor: '#F8374E', sectionHeight: 240 }, { sectionColor: '#B52CF8', sectionHeight: 270 }, { sectionColor: '#6A30E7', sectionHeight: 300 }],
	    // copy
	    sectionAttrCopy: [{ sectionColor: '#03ACF6', sectionHeight: 30 }, { sectionColor: '#00AE9D', sectionHeight: 60 }, { sectionColor: '#0372D2', sectionHeight: 90 }, { sectionColor: '#0D8617', sectionHeight: 120 }, { sectionColor: '#737602', sectionHeight: 150 }, { sectionColor: '#FBDD20', sectionHeight: 180 }, { sectionColor: '#E64A09', sectionHeight: 210 }, { sectionColor: '#F8374E', sectionHeight: 240 }, { sectionColor: '#B52CF8', sectionHeight: 270 }, { sectionColor: '#6A30E7', sectionHeight: 300 }],
	    unionAttr: {
	        unionColor: '#6924F9',
	        unionHeight: -70
	    },
	    intersectionAttr: {
	        intersectionColor: '#088213',
	        intersectionHeight: -40
	    },

	    selectColor: '#FEEE87',
	    referMark: [],
	    referInterval: [],
	    referRegulation: [],
	    refreshStartPoints: false,
	    refreshEndPoints: false,
	    isShowIntersection: false,
	    isShowUnion: false,
	    _action: ''
	},
	    markPintArray = undefined;

	exports['default'] = function () {

	    $(_presenter2['default'].view).find('.tool_btns').off('click touchstart').on('click touchstart', function (e) {
	        e.preventDefault();
	        var target = $(e.target).parent();
	        var action = target.data("action");
	        if ($(target).hasClass('number_lines_btn_on')) {
	            $(target).removeClass('number_lines_btn_on');
	            toolbarStatus._action = '';
	            $('.mix').css({ 'display': 'none' });
	            $('.union').css({ 'display': 'none' });
	        } else {

	            if ($(this).find('.number_lines_btn_on').length && action != "mix" && action != "union") {
	                toolbarStatus.startPoint ? toolbarStatus.startPoint.parent.remove(toolbarStatus.startPoint) : null;
	                toolbarStatus.startPoint = null;
	                $(this).find('.number_lines_btn_on').removeClass('number_lines_btn_on');
	            }

	            switch (action) {
	                case 'mark':
	                case 'regulation':
	                case 'clean':
	                    toolbarStatus._action = action;
	                    $(target).addClass('number_lines_btn_on');
	                    (0, _isShowUnitController2['default'])(_threeManger.scene.getObjectByName('group'), toolbarStatus._action);
	                    break;
	                case 'interval':
	                    toolbarStatus._action = action;
	                    $(target).addClass('number_lines_btn_on');
	                    $('.mix').show();
	                    $('.union').show();
	                    var canShow = (0, _getSections2['default'])(_threeManger.scene.getObjectByName('group')).canShow;
	                    if (canShow) {
	                        $('.mix').hide();
	                        $('.union').hide();
	                    }
	                    (0, _isShowUnitController2['default'])(_threeManger.scene.getObjectByName('group'), toolbarStatus._action);
	                    break;
	                case 'mix':
	                    var sections = (0, _getSections2['default'])(_threeManger.scene.getObjectByName('group')).sections;
	                    if (sections.length >= 2) {
	                        toolbarStatus.isShowIntersection = true;
	                        (0, _updateIntersection2['default'])(_threeManger.scene.getObjectByName('group'));
	                    }
	                    break;
	                case 'union':
	                    var sections2 = (0, _getSections2['default'])(_threeManger.scene.getObjectByName('group')).sections;
	                    if (sections2.length >= 2) {
	                        toolbarStatus.isShowUnion = true;
	                        (0, _updateUnion2['default'])(_threeManger.scene.getObjectByName('group'));
	                    }
	                    break;
	                case 'clear_all':
	                    var group = _threeManger.scene.getObjectByName("group");
	                    var isNoPoint = group.getObjectByName("markPoint");
	                    toolbarStatus._action = action;
	                    //没有可清除对象不弹窗
	                    if (toolbarStatus.lineColor.length == 10 && toolbarStatus.sectionAttr.length == 10 && !isNoPoint) return;
	                    var hasDialog = document.querySelector('.dialog_alert');
	                    if (hasDialog) return;
	                    _UtilsDialog2['default'].alert('“清空”将清空数轴上的所有内容  是否确定“清空”？"', function (key) {
	                        _UtilsDialog2['default'].remove(key);
	                        // 数轴所在group对象
	                        markPintArray = [];
	                        var group_markPoint = group.children;
	                        for (var _i = 0; _i < group_markPoint.length; _i++) {
	                            if (group_markPoint[_i].name == 'markPoint' || group_markPoint[_i].name == 'section' || group_markPoint[_i].name == 'regulation') {
	                                markPintArray.push(group.children[_i]);
	                            }
	                        }
	                        for (var i = 0; i < markPintArray.length; i++) {
	                            markPintArray[i].parent.remove(markPintArray[i]);
	                        }
	                        // 重置区间，交并集
	                        (0, _refreshSection2['default'])(group);
	                        toolbarStatus.isShowIntersection = false;
	                        toolbarStatus.isShowUnion = false;
	                        $('.mix').addClass('btn_disable');
	                        $('.union').addClass('btn_disable');
	                        // 显示刻度控制器
	                        (0, _isShowUnitController2['default'])(group);
	                        (0, _ShapeAddMarkPoint.resetCollection)();
	                        // 重置lineColor,sectionAttr
	                        toolbarStatus.lineColor = [];
	                        toolbarStatus.lineColor = toolbarStatus.lineColor.concat(toolbarStatus.lineColorCopy);
	                        toolbarStatus.sectionAttr = [];
	                        toolbarStatus.sectionAttr = toolbarStatus.sectionAttr.concat(toolbarStatus.sectionAttrCopy);
	                        toolbarStatus._action = null;
	                    });
	                    break;
	            }
	        }
	    });
	};

	function setToolbarStatus(value) {
	    toolbarStatus.startPoint = value;
	    toolbarStatus.endPoint = value;
	}

	exports.toolbarStatus = toolbarStatus;

/***/ },
/* 12 */
/***/ function(module, exports, __webpack_require__) {

	// by zyl
	'use strict';
	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var dialog = {
	    alert: function alert(msg, callback) {
	        var key = parseInt(Math.random().toFixed(10) * 10000000000);
	        var dom = '<div class="num_msg_box dialog_alert" id="msgBox' + key + '" >\n                            <div class="msg_wrap">\n                                <div class="msg_text">' + msg + '</div>\n                                <div class="btn_group">\n                                    <div class="cancel" data-key="' + key + '">取 消</div>\n                                    <div class="confirm" data-key="' + key + '">确 定</div>\n                                </div>\n                            </div>\n                        </div>';

	        $(_presenter2['default'].view).append(dom);
	        $(".cancel").on('click touchend', function (e) {
	            e.preventDefault();
	            dialog.remove($(this).data("key"));
	        });
	        $(".confirm").on('click touchend', function (e) {
	            e.preventDefault();
	            callback($(this).data("key"));
	        });
	        console.log("alert");
	    },
	    msg: (function (_msg) {
	        function msg() {
	            return _msg.apply(this, arguments);
	        }

	        msg.toString = function () {
	            return _msg.toString();
	        };

	        return msg;
	    })(function () {
	        var key = parseInt(Math.random().toFixed(10) * 10000000000);
	        var dom = '<div class="num_msg_box dialog_msg" id="msgBox' + key + '" >\n                            <div class="msg_wrap">\n                                <div class="msg_text">' + msg + '</div>\n                                <div class="btn_group">\n                                    <div class="confirm" data-key="' + key + '">确 定</div>\n                                </div>\n                            </div>\n                        </div>';

	        $(_presenter2['default'].view).append(dom);

	        $(".confirm").on('click touchend', function (e) {
	            e.preventDefault();
	            dialog.remove($(this).data("key"));
	        }, false);
	    }),
	    // 自动消失
	    tips: function tips(msg) {
	        var key = parseInt(Math.random().toFixed(10) * 10000000000);
	        var dom = '<div class="num_msg_box dialog_tips" id="msgBox' + key + '" >\n                            <div class="msg_wrap">\n                                <div class="msg_text">' + msg + '</div>\n                            </div>\n                        </div>';

	        $(_presenter2['default'].view).append(dom);
	        var timer = setTimeout(function () {
	            dialog.remove(key);
	        }, 2000);
	    },
	    remove: function remove(key) {
	        $(_presenter2['default'].view).find($("#msgBox" + key)).remove();
	    }
	};

	exports['default'] = dialog;
	module.exports = exports['default'];

/***/ },
/* 13 */
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	exports['default'] = function (group) {
	  var sections = [];
	  var children = group.children;
	  for (var i = 0; i < children.length; i++) {
	    if (children[i].name == 'section') {
	      sections.push(children[i]);
	    }
	  }
	  if (sections.length >= 2) {
	    return {
	      canShow: true,
	      sections: sections
	    };
	  } else {
	    return {
	      canShow: false,
	      sections: sections
	    };
	  }
	};

	module.exports = exports['default'];

/***/ },
/* 14 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _ShapeIntersection = __webpack_require__(15);

	var _ShapeIntersection2 = _interopRequireDefault(_ShapeIntersection);

	var _getSections = __webpack_require__(13);

	var _getSections2 = _interopRequireDefault(_getSections);

	var _toolbar = __webpack_require__(11);

	var _getIntersection = __webpack_require__(19);

	var _getIntersection2 = _interopRequireDefault(_getIntersection);

	var _updateVertices = __webpack_require__(21);

	var _updateVertices2 = _interopRequireDefault(_updateVertices);

	var _computeSection = __webpack_require__(23);

	var _computeSection2 = _interopRequireDefault(_computeSection);

	var _addText = __webpack_require__(17);

	var _addText2 = _interopRequireDefault(_addText);

	var _calculatMethod = __webpack_require__(20);

	exports['default'] = function (shape) {
	  var intersection = undefined,
	      intersectionObj = undefined,
	      sections = undefined,
	      sectionObjs = [],
	      color = undefined,
	      height = undefined,
	      lineWidth = undefined,
	      intersectionStartSide = undefined,
	      intersectionEndSide = undefined,
	      intersectionLine = undefined,
	      intersectionStartPoint = undefined,
	      intersectionEndPoint = undefined,
	      text = undefined,
	      sectionText = undefined,
	      intersectionStartSideVector = undefined,
	      intersectionEndSideVector = undefined;

	  lineWidth = shape.data.lineWidth;
	  color = _toolbar.toolbarStatus.intersectionAttr.intersectionColor;
	  height = _toolbar.toolbarStatus.intersectionAttr.intersectionHeight;
	  sections = (0, _getSections2['default'])(shape).sections;
	  if (sections.length > 0) {
	    sectionObjs = (0, _getIntersection2['default'])(sections);
	    intersectionObj = (0, _calculatMethod.intersectionSection)(sectionObjs);
	    intersection = shape.getObjectByName('intersection');
	    if (intersectionObj) {
	      if (!intersection) {
	        // 未创建交集时，创建交集
	        intersection = (0, _ShapeIntersection2['default'])(intersectionObj.leftPoint, intersectionObj.leftIsSolid, intersectionObj.rightPoint, intersectionObj.rightIsSolid, height, color, lineWidth);
	        shape.add(intersection);
	        // 创建交集文字
	        text = (0, _computeSection2['default'])(intersection, intersectionObj.leftPoint, intersectionObj.rightPoint);
	        sectionText = (0, _addText2['default'])(text, new THREE.Vector2((intersectionObj.leftPoint.x + intersectionObj.rightPoint.x) / 2, height - 10), 128, 16, '16px', color);
	        sectionText._dynamicTexture.clear().drawText(text, undefined, 16, color);
	        sectionText.name = "intersectionText";

	        intersection.add(sectionText);
	      } else {
	        // 已存在交集时，更新交集
	        if (!intersection.visible) {
	          intersection.visible = true;
	        }
	        intersectionStartPoint = intersection.getObjectByName('intersectionStartPoint');
	        intersectionEndPoint = intersection.getObjectByName('intersectionEndPoint');
	        intersectionStartSide = intersection.getObjectByName('intersectionStartSide');
	        intersectionEndSide = intersection.getObjectByName('intersectionEndSide');
	        intersectionLine = intersection.getObjectByName('intersectionLine');
	        sectionText = intersection.getObjectByName('intersectionText');

	        // 修改端点状态及位置
	        if (intersectionStartPoint.position.x <= intersectionEndPoint.position.x) {
	          intersectionStartPoint.position.x = intersectionObj.leftPoint.x;
	          intersectionEndPoint.position.x = intersectionObj.rightPoint.x;
	        } else {
	          intersectionStartPoint.position.x = intersectionObj.rightPoint.x;
	          intersectionEndPoint.position.x = intersectionObj.leftPoint.x;
	        }

	        intersectionStartPoint.position.y = 0;
	        intersectionEndPoint.position.y = 0;
	        if (intersectionObj.leftIsSolid) {
	          intersectionStartPoint.getObjectByName('inCircle').visible = false;
	          intersectionStartPoint.data.status = true;
	        } else {
	          intersectionStartPoint.getObjectByName('inCircle').visible = true;
	          intersectionStartPoint.data.status = false;
	        }
	        if (intersectionObj.rightIsSolid) {
	          intersectionEndPoint.getObjectByName('inCircle').visible = false;
	          intersectionEndPoint.data.status = true;
	        } else {
	          intersectionEndPoint.getObjectByName('inCircle').visible = true;
	          intersectionEndPoint.data.status = false;
	        }

	        // 更新三线
	        intersectionStartSideVector = new THREE.Vector3(intersectionObj.leftPoint.x, height, 0);
	        intersectionEndSideVector = new THREE.Vector3(intersectionObj.rightPoint.x, height, 0);
	        (0, _updateVertices2['default'])(intersectionStartSide, intersectionObj.leftPoint, intersectionStartSideVector, lineWidth);
	        (0, _updateVertices2['default'])(intersectionEndSide, intersectionObj.rightPoint, intersectionEndSideVector, lineWidth);
	        (0, _updateVertices2['default'])(intersectionLine, new THREE.Vector3(intersectionStartSideVector.x, intersectionStartSideVector.y + lineWidth / 2), new THREE.Vector3(intersectionEndSideVector.x, intersectionEndSideVector.y + lineWidth / 2), lineWidth);

	        // 计算应该显示的文字
	        text = (0, _computeSection2['default'])(intersection, intersectionObj.leftPoint, intersectionObj.rightPoint);
	        // 刷新文字
	        sectionText._dynamicTexture.clear().drawText(text, undefined, 16, color);
	        sectionText.position.x = (intersectionObj.leftPoint.x + intersectionObj.rightPoint.x) / 2;
	        sectionText.position.y = height - 10;
	      }
	    } else {
	      if (intersection) {
	        intersection.visible = false;
	      }
	    }
	  } else {
	    intersection = shape.getObjectByName('intersection');
	    if (intersection) {
	      intersection.visible = false;
	    }
	  }
	};

	module.exports = exports['default'];

/***/ },
/* 15 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _ShapeSectionLine = __webpack_require__(16);

	var _ShapePoint = __webpack_require__(18);

	var _ShapePoint2 = _interopRequireDefault(_ShapePoint);

	exports['default'] = function (startPoint, startIsSolid, endPoint, endIsSolid, height, color, lineWidth) {
	  var intersection = new THREE.Object3D();
	  var startSide = undefined,
	      endSide = undefined,
	      line = undefined,
	      start = undefined,
	      end = undefined;
	  // 创建左端点
	  start = (0, _ShapePoint2['default'])(lineWidth, color);
	  start.position.x = startPoint.x;
	  start.position.z = 0.1;
	  start.name = 'intersectionStartPoint';
	  start.data = {};
	  start.data.status = false;
	  if (startIsSolid) {
	    start.getObjectByName('inCircle').visible = false;
	    start.data.status = true;
	  }
	  // 创建右端点
	  end = (0, _ShapePoint2['default'])(lineWidth, color);
	  end.position.x = endPoint.x;
	  end.position.z = 0.1;
	  end.name = 'intersectionEndPoint';
	  end.data = {};
	  end.data.status = false;
	  if (endIsSolid) {
	    end.getObjectByName('inCircle').visible = false;
	    end.data.status = true;
	  }
	  // 创建交集左边线
	  startSide = (0, _ShapeSectionLine.createSide)(startPoint, height, lineWidth, color);
	  startSide.side.name = 'intersectionStartSide';
	  // 创建交集右边线
	  endSide = (0, _ShapeSectionLine.createSide)(endPoint, height, lineWidth, color);
	  endSide.side.name = 'intersectionEndSide';
	  startSide.upVector.y = startSide.upVector.y + lineWidth / 2;
	  endSide.upVector.y = endSide.upVector.y + lineWidth / 2;
	  // 创建交集下边线
	  line = (0, _ShapeSectionLine.createLine)(startSide.upVector, endSide.upVector, lineWidth, color);
	  line.name = 'intersectionLine';

	  intersection.add(start);
	  intersection.add(end);
	  intersection.add(startSide.side);
	  intersection.add(endSide.side);
	  intersection.add(line);

	  intersection.name = 'intersection';
	  return intersection;
	};

	module.exports = exports['default'];

/***/ },
/* 16 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});
	exports.createSide = createSide;
	exports.createLine = createLine;
	exports.createText = createText;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _UtilsAddText = __webpack_require__(17);

	var _UtilsAddText2 = _interopRequireDefault(_UtilsAddText);

	// 创建两边

	function createSide(downVector, height, lineWidth, color) {
	  var shape = new THREE.Shape();
	  var upVector = new THREE.Vector3(downVector.x, downVector.y + height, 0);
	  shape.moveTo(downVector.x + lineWidth / 2, 0);
	  shape.lineTo(upVector.x + lineWidth / 2, height);
	  shape.lineTo(upVector.x - lineWidth / 2, height);
	  shape.lineTo(downVector.x - lineWidth / 2, 0);
	  shape.lineTo(downVector.x + lineWidth / 2, 0);
	  var geometry = new THREE.ShapeGeometry(shape);
	  var side = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({
	    color: color
	  }));
	  return {
	    side: side,
	    upVector: upVector
	  };
	}

	// 创建横线

	function createLine(startVector, endVector, lineWidth, color) {
	  var shape = new THREE.Shape();
	  shape.moveTo(startVector.x, startVector.y - lineWidth / 2);
	  shape.lineTo(endVector.x, endVector.y - lineWidth / 2);
	  shape.lineTo(endVector.x, endVector.y + lineWidth / 2);
	  shape.lineTo(startVector.x, startVector.y + lineWidth / 2);
	  shape.lineTo(startVector.x, startVector.y - lineWidth / 2);
	  var geometry = new THREE.ShapeGeometry(shape);
	  var line = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({
	    color: color
	  }));
	  line.name = 'sectionLine';
	  return line;
	}

	// 创建文字

	function createText(text, postion, color) {
	  var sectionText = (0, _UtilsAddText2['default'])(text, postion, 128, 16, '16px', color);
	  sectionText._dynamicTexture.clear().drawText(text, undefined, 16, color);
	  sectionText.name = "sectionText";
	  return sectionText;
	}

/***/ },
/* 17 */
/***/ function(module, exports) {

	/*

	@param text 所要绘制的文字
	@param position 存放位置
	@param width 文字的宽高

	*/
	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	exports['default'] = function (text, position, width, height) {
		var fontSize = arguments.length <= 4 || arguments[4] === undefined ? '16px' : arguments[4];
		var fontColor = arguments.length <= 5 || arguments[5] === undefined ? 'black' : arguments[5];

		var dynamicTexture = new THREEx.DynamicTexture(width, height);
		dynamicTexture.context.font = 'bolder ' + fontSize + ' Arial';
		var geometry = new THREE.CubeGeometry(width, height, 0);

		var textField = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({
			map: dynamicTexture.texture,
			transparent: true
		}));

		textField.position.x = position.x;
		textField.position.y = position.y;
		textField._dynamicTexture = dynamicTexture;
		textField._dynamicTexture.drawText(text, undefined, height / 2, fontColor);
		return textField;
	};

	module.exports = exports['default'];

/***/ },
/* 18 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _UtilsAddText = __webpack_require__(17);

	var _UtilsAddText2 = _interopRequireDefault(_UtilsAddText);

	var _constants = __webpack_require__(4);

	exports['default'] = function (lineWidth, color, text, position, count) {
	  var dependColor = undefined;
	  if (color === 'customize') {
	    //数轴题定制颜色
	    dependColor = _constants.baseColor;
	    color = 0xffffff;
	  } else {
	    dependColor = 0xffffff;
	    color = _constants.baseColor;
	  }
	  var point = new THREE.Object3D();
	  var outCircleGeometry = new THREE.CircleGeometry(lineWidth * 1.5, 64);
	  var outCircle = new THREE.Mesh(outCircleGeometry, new THREE.MeshBasicMaterial({
	    color: color,
	    transparent: false,
	    opacity: 1
	  }));
	  outCircle.name = 'outCircle';
	  var inCircleGeometry = new THREE.CircleGeometry(lineWidth * 1, 64);
	  var inCircle = new THREE.Mesh(inCircleGeometry, new THREE.MeshBasicMaterial({
	    color: dependColor,
	    transparent: false,
	    opacity: 1
	  }));
	  inCircle.name = 'inCircle';
	  point.pointCount = count;
	  point.add(inCircle);
	  point.add(outCircle);
	  if (text !== undefined) {
	    var textObj = (0, _UtilsAddText2['default'])(text, position, 64, 32);
	    if (('' + text) % 1 == 0) {
	      textObj.visible = false;
	    }
	    textObj.name = 'positionText';
	    point.add(textObj);
	  }
	  point.userData.radius = lineWidth * 1.5;
	  point.userData.color = color;
	  point.data = {};
	  point.data.status = false;
	  return point;
	};

	module.exports = exports['default'];

/***/ },
/* 19 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	var _calculatMethod = __webpack_require__(20);

	exports['default'] = function (sections) {
	  var section = undefined,
	      sectionObj = undefined,
	      sectionObjs = [],
	      startPoint = undefined,
	      endPoint = undefined;
	  for (var i = 0; i < sections.length; i++) {
	    section = sections[i];
	    startPoint = section.getObjectByName('startPoint');
	    endPoint = section.getObjectByName('endPoint');
	    sectionObj = (0, _calculatMethod.creatSection)(startPoint.position, startPoint.data.status, endPoint.position, endPoint.data.status);
	    sectionObjs.push(sectionObj);
	  }
	  return sectionObjs;
	};

	module.exports = exports['default'];

/***/ },
/* 20 */
/***/ function(module, exports) {

	/**
	 * Created by Administrator on 2015/12/23.
	 */

	/*
	 * 参数是圆上任意三点坐标
	 */
	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	exports.calculatCircleCenter = calculatCircleCenter;
	exports.intersectionSection = intersectionSection;
	exports.unionSection = unionSection;
	exports.setSectionNull = setSectionNull;
	exports.creatSection = creatSection;

	function calculatCircleCenter(pointB, pointA, pointC) {

	    var vectorAB = new THREE.Vector2().subVectors(pointA, pointB),
	        vectorAC = new THREE.Vector2().subVectors(pointA, pointC),
	        vectorBC = new THREE.Vector2().subVectors(pointB, pointC);

	    var sumAB = new THREE.Vector2().addVectors(pointA, pointB),
	        sumAC = new THREE.Vector2().addVectors(pointA, pointC),
	        sumBC = new THREE.Vector2().addVectors(pointB, pointC);

	    var middleAB = new THREE.Vector2(sumAB.x / 2, sumAB.y / 2),
	        middleAC = new THREE.Vector2(sumAC.x / 2, sumAC.y / 2),
	        middleBC = new THREE.Vector2(sumBC.x / 2, sumBC.y / 2);

	    var vectorUse1 = undefined,
	        vectorUse2 = undefined;
	    var circleX = undefined,
	        circleY = undefined;

	    var divisor = vectorAC.x * (middleAB.y * vectorAB.y + middleAB.x * vectorAB.x) - vectorAB.x * (middleAC.y * vectorAC.y + middleAC.x * vectorAC.x);
	    var dividend = vectorAB.y * vectorAC.x - vectorAB.x * vectorAC.y;
	    circleY = divisor / dividend;
	    circleX = (middleAB.y * vectorAB.y + middleAB.x * vectorAB.x - vectorAB.y * circleY) / vectorAB.x;

	    var radiusSqurts = Math.pow(circleX - pointA.x, 2) + Math.pow(circleY - pointA.y, 2),
	        radiusLen = Math.sqrt(radiusSqurts);

	    var circle = new THREE.Vector2(circleX, circleY);

	    return {
	        centerPoint: circle,
	        radius: radiusLen
	    };
	}

	/*
	 *  求交集区间
	 *  @param sectionGroup 区间的数组
	 *  @param curSection 返回交集
	 */

	function intersectionSection(sectionsGroup) {

	    var sectionGroup = sectionGroupSort(sectionsGroup);
	    var curSection = sectionGroup[0];
	    if (sectionGroup.length == 1) return null;

	    for (var i = 1; i < sectionGroup.length; i++) {

	        var curLeftPotX = curSection.leftPoint.x,
	            curRightPotX = curSection.rightPoint.x;

	        //获得下一个区间点的坐标
	        var nextSection = sectionGroup[i];
	        var nextLeftPotX = nextSection.leftPoint.x,
	            nextRightPotX = nextSection.rightPoint.x;

	        if (nextLeftPotX > curRightPotX || nextRightPotX < curLeftPotX) {
	            return null;
	        } else if (curLeftPotX <= nextLeftPotX && nextLeftPotX <= curRightPotX) {
	            //next左端点在cur内

	            var newLeftPoint = nextSection.leftPoint,
	                newLeftIsSolid = nextSection.leftIsSolid;

	            //下一个区间左端点在两端点上
	            if (nextLeftPotX == curLeftPotX) {
	                //下个区间的左端点和当前区间左端点重合
	                if (!curSection.leftIsSolid) {
	                    newLeftPoint = curSection.leftPoint;
	                    newLeftIsSolid = curSection.leftIsSolid;
	                }
	            } else if (nextLeftPotX == curRightPotX) {
	                //下个区间的左端点和当前区间右端点重合

	                if (curSection.rightIsSolid && nextSection.leftIsSolid) {
	                    newLeftPoint = nextSection.leftPoint;
	                    newLeftIsSolid = nextSection.leftIsSolid;
	                } else {

	                    return null;
	                }
	            }

	            curSection.leftPoint = newLeftPoint;
	            curSection.leftIsSolid = newLeftIsSolid;

	            if (nextRightPotX == curRightPotX) {

	                if (curSection.rightIsSolid) {
	                    curSection.rightPoint = nextSection.rightPoint;
	                    curSection.rightIsSolid = nextSection.rightIsSolid;
	                }
	            } else if (nextRightPotX < curRightPotX) {
	                //next右端点也在cur内
	                curSection.rightPoint = nextSection.rightPoint;
	                curSection.rightIsSolid = nextSection.rightIsSolid;
	            }
	        } else {
	            //next左端点在cur左端点左边

	            //下一个区间左端点在两端点上
	            if (nextRightPotX == curRightPotX) {
	                //下个区间的右端点和当前区间左端点重合
	                if (!nextSection.rightIsSolid) {
	                    curSection.rightPoint = nextSection.rightPoint;
	                    curSection.rightIsSolid = nextSection.rightIsSolid;
	                }
	            } else if (nextRightPotX == curLeftPotX) {
	                //下个区间的右端点和当前区间左端点重合

	                if (curSection.rightIsSolid && nextSection.leftIsSolid) {
	                    curSection.rightPoint = nextSection.rightPoint;
	                    curSection.rightIsSolid = nextSection.rightIsSolid;
	                } else {
	                    return null;
	                }
	            } else if (curLeftPotX < nextRightPotX < curRightPotX) {
	                curSection.rightPoint = nextSection.rightPoint;
	                curSection.rightIsSolid = nextSection.rightIsSolid;
	            }
	        }
	    }

	    return curSection;
	}

	/*
	 *  求并集区间
	 *  @param sectionGroup 区间的数组
	 *  返回区间的集合数组
	 */

	function unionSection(sectionsGroup) {

	    var sectionGroup = sectionGroupSort(sectionsGroup);
	    var firstSection = sectionGroup[0];
	    var unionGroup = [firstSection];
	    if (sectionGroup.length == 1) return null;

	    for (var i = 1; i < sectionGroup.length; i++) {

	        //获得下一个区间点的坐标
	        var nextSection = sectionGroup[i];
	        var nextLeftPotX = nextSection.leftPoint.x,
	            nextRightPotX = nextSection.rightPoint.x;

	        var rightPotInSection = undefined,
	            //右端点所在的区间
	        mergerSection = undefined,
	            //创建合并后新的集合
	        deleLength = undefined;

	        var leftPotIndex = undefined,
	            rightPotIndex = undefined,
	            rightPointObj = undefined;

	        //判断下一个区间左端点是否在当前区间内
	        var leftPointObj = pointInSectionIndex(nextSection.leftPoint, unionGroup, 0, nextSection.leftIsSolid);

	        //判断点重合，并且重合点都为空心
	        if (leftPointObj.inSection) {
	            if (leftPointObj.inSectionIndex == -100 && leftPointObj.rightBothHollow) {
	                //和端点重合并且都是空心
	                leftPointObj.inSection = false;
	                leftPointObj.fromSectionIndex = leftPointObj.realIndex;
	                leftPointObj.toSectionIndex = leftPointObj.realIndex + 1;
	            }
	        }

	        if (leftPointObj.inSection) {
	            //区间左端点在集合内

	            //左端点所在区间的索引
	            leftPotIndex = leftPointObj.inSectionIndex == -100 ? leftPointObj.realIndex : leftPointObj.inSectionIndex;

	            //左端点所在的区间
	            var leftPotInSection = unionGroup[leftPotIndex];

	            //判断当前左端点是否和所在集合端点重合，确定端点实空心的状态
	            changePointStatus(unionGroup, leftPotIndex, nextSection.leftPoint, nextSection.leftIsSolid);

	            //判断下一个区间右端点是否在当前区间内
	            rightPointObj = pointInSectionIndex(nextSection.rightPoint, unionGroup, leftPotIndex);

	            if (rightPointObj.inSection) {
	                if (rightPointObj.inSectionIndex == -100 && rightPointObj.leftBothHollow) {
	                    //和端点重合并且都是空心
	                    rightPointObj.inSection = false;
	                    rightPointObj.fromSectionIndex = leftPointObj.realIndex - 1;
	                    rightPointObj.toSectionIndex = leftPointObj.realIndex;
	                }
	            }

	            if (rightPointObj.inSection) {
	                //区间右端点在集合内

	                //右端点所在区间的索引
	                rightPotIndex = rightPointObj.inSectionIndex == -100 ? rightPointObj.realIndex : rightPointObj.inSectionIndex;
	                changePointStatus(unionGroup, rightPotIndex, nextSection.rightPoint, nextSection.rightIsSolid);

	                //右端点所在的区间
	                rightPotInSection = unionGroup[rightPotIndex];

	                if (rightPotIndex == leftPointObj.inSectionIndex) {//区间两点都在同个区间内
	                } else {

	                        //创建合并后新的集合
	                        mergerSection = creatSection(leftPotInSection.leftPoint, leftPotInSection.leftIsSolid, rightPotInSection.rightPoint, rightPotInSection.rightIsSolid);

	                        deleLength = rightPotIndex - leftPotIndex + 1; //要删除的索引的长度
	                        //删除连接的，插入新的集合
	                        unionGroup.splice(leftPotIndex, deleLength + 1, mergerSection);
	                    }
	            } else {
	                //右端点不在集合内

	                //rightPotInSection = unionGroup[rightPotIndex];
	                //创建合并后新的集合
	                mergerSection = creatSection(leftPotInSection.leftPoint, leftPotInSection.leftIsSolid, nextSection.rightPoint, nextSection.rightIsSolid);

	                deleLength = rightPointObj.fromSectionIndex - leftPotIndex + 1;
	                //删除连接的，插入新的集合
	                unionGroup.splice(leftPotIndex, deleLength, mergerSection);
	            }
	        } else {
	            //左端点不在区域内

	            var leftPotBetweenIndex = leftPointObj.fromSectionIndex; //左端点左边区间的索引
	            var leftPotAndIndex = leftPointObj.toSectionIndex; //左端点右边区间的索引

	            rightPointObj = pointInSectionIndex(nextSection.rightPoint, unionGroup, leftPotBetweenIndex);

	            if (rightPointObj.inSection) {
	                //右端点在集合内

	                rightPotIndex = rightPointObj.inSectionIndex; //右端点所在区间的索引
	                changePointStatus(unionGroup, rightPotIndex, nextSection.rightPoint, nextSection.rightIsSolid);

	                //右端点所在的区间
	                rightPotInSection = unionGroup[rightPotIndex];

	                //创建合并后新的集合
	                mergerSection = creatSection(nextSection.leftPoint, nextSection.leftIsSolid, rightPotInSection.rightPoint, rightPotInSection.rightIsSolid);

	                deleLength = rightPointObj.inSectionIndex - leftPotBetweenIndex + 1;
	                //删除连接的，插入新的集合
	                unionGroup.splice(leftPotBetweenIndex, deleLength, mergerSection);
	            } else {

	                var rightPotBetweenIndex = rightPointObj.fromSectionIndex; //右端点左边区间的索引
	                var rightPotAndIndex = rightPointObj.toSectionIndex; //右端点右边区间的索引

	                deleLength = rightPointObj.fromSectionIndex - leftPotAndIndex + 1;

	                if (rightPotAndIndex == 0 || leftPotBetweenIndex == 0) deleLength = 0;

	                var startIndex = undefined;
	                if (leftPotBetweenIndex == unionGroup.length) {
	                    startIndex = unionGroup.length;
	                } else {
	                    startIndex = leftPotAndIndex;
	                }

	                //删除连接的，插入新的集合
	                unionGroup.splice(leftPotAndIndex, deleLength, nextSection);
	            }
	        }
	    }

	    return unionGroup;
	}

	/*
	 *  点重合情况下修改点的状态
	 */
	function changePointStatus(unionGroup, index, point, isSolid) {

	    //所在的集合
	    var inSection = unionGroup[index];
	    if (point == inSection.leftPoint) {
	        //和左端点重合
	        if (isSolid) {
	            unionGroup[index].leftIsSolid = isSolid;
	        }
	    } else if (point == inSection.rightPoint) {
	        if (isSolid) {
	            unionGroup[index].rightIsSolid = isSolid;
	        }
	    }
	}

	/*
	 *  区间置空
	 */

	function setSectionNull(section) {
	    section.leftPoint = null;
	    section.leftIsSolid = null;
	    section.rightPoint = null;
	    section.rightIsSolid = null;
	}

	/*
	 *  区间排序
	 */
	function sectionGroupSort(sectionsGroup) {

	    var tempLeftPotXGroup = [],
	        sectionGroup = [],
	        tempSection = [];

	    //sectionGroup = sectionsGroup;

	    for (var i = 0; i < sectionsGroup.length; i++) {

	        var temObj = Object.assign({}, sectionsGroup[i]);
	        sectionGroup.push(temObj);

	        var section = sectionsGroup[i];
	        tempLeftPotXGroup.push(section.leftPoint.x);
	    }

	    //tempLeftPotXGroup从小到大排序
	    tempLeftPotXGroup.sort(function (a, b) {
	        return a - b;
	    });

	    //将section的数据排序好放到tempSection数组中
	    for (var i = 0; i < tempLeftPotXGroup.length; i++) {
	        var leftPotX = tempLeftPotXGroup[i];

	        for (var j = 0; j < sectionGroup.length; j++) {
	            var section = sectionGroup[j];
	            if (section.leftPoint.x == leftPotX) {
	                tempSection.push(section);

	                //移除已经放入临时数组的集合，减少遍历次数
	                var index = sectionGroup.indexOf(section);
	                sectionGroup.splice(index, 1);
	                break;
	            }
	        }
	    }

	    //将排序好的区间数组重新赋值给传入的区间数组sectionGroup
	    return tempSection;
	}

	/*
	 *  点是否在区间内的索引
	 *  @param point 判断的点
	 *  @param sectionGroup 排序好的区间数组
	 *  @param index 开始索引的位置
	 */
	function pointInSectionIndex(point, sectionGroup, startIndex, pointStatus) {

	    for (var i = startIndex; i < sectionGroup.length; i++) {
	        var section = sectionGroup[i];

	        if (i == 0) {
	            //点在最小的集合左边
	            if (point.x < section.leftPoint.x) {
	                return {
	                    inSection: false,
	                    fromSectionIndex: -1,
	                    toSectionIndex: 0
	                };
	            }
	        }

	        if (section.leftPoint.x <= point.x && point.x <= section.rightPoint.x) {
	            //在区间内

	            if (point.x == section.leftPoint.x) {
	                if (pointStatus == false && section.leftIsSolid == false) {
	                    //与左端点重合 都为空心
	                    return {
	                        inSection: true,
	                        inSectionIndex: -100,
	                        realIndex: i,
	                        leftBothHollow: true,
	                        rightBothHollow: false
	                    };
	                }
	            } else if (point.x == section.rightPoint.x) {
	                if (pointStatus == false && section.rightIsSolid == false) {
	                    return {
	                        inSection: true,
	                        inSectionIndex: -100,
	                        realIndex: i,
	                        leftBothHollow: false,
	                        rightBothHollow: true
	                    };
	                }
	            }

	            return {
	                inSection: true,
	                inSectionIndex: i
	            };
	        }

	        if (i == sectionGroup.length - 1) {
	            //点在最大集合右边
	            if (point.x > section.rightPoint.x) {
	                return {
	                    inSection: false,
	                    fromSectionIndex: sectionGroup.length - 1,
	                    toSectionIndex: sectionGroup.length
	                };
	            }
	        }

	        var nextSection = sectionGroup[i + 1];
	        if (section.rightPoint.x < point.x && point.x < nextSection.leftPoint.x) {
	            //不在区间内，在两个区间的间隔中
	            return {
	                inSection: false,
	                fromSectionIndex: i,
	                toSectionIndex: i + 1
	            };
	        }
	    }
	}

	/*
	 *  创建区间的对象
	 */

	function creatSection(leftPoint, leftIsSolid, rightPoint, rightIsSolid) {

	    if (leftPoint.x <= rightPoint.x) {

	        return {
	            leftPoint: leftPoint,
	            leftIsSolid: leftIsSolid,
	            rightPoint: rightPoint,
	            rightIsSolid: rightIsSolid
	        };
	    } else {

	        return {
	            leftPoint: rightPoint,
	            leftIsSolid: rightIsSolid,
	            rightPoint: leftPoint,
	            rightIsSolid: leftIsSolid
	        };
	    }
	}

/***/ },
/* 21 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	var _rotateAngle = __webpack_require__(22);

	exports['default'] = function (shape, pointA, pointB, lineWidth) {
	  var length = lineWidth / 2;
	  var vector1 = (0, _rotateAngle.rotationAngleVector)(pointB, pointA, 90, true).vector.setLength(length);
	  var vector2 = (0, _rotateAngle.rotationAngleVector)(pointB, pointA, 90, false).vector.setLength(length);
	  var vertices = [];
	  var orgVertices = shape.geometry.vertices;

	  vertices.push(new THREE.Vector2().addVectors(pointA, vector2));
	  vertices.push(new THREE.Vector2().addVectors(pointB, vector2));
	  vertices.push(new THREE.Vector2().addVectors(pointB, vector1));
	  vertices.push(new THREE.Vector2().addVectors(pointA, vector1));

	  for (var i = 0; i < orgVertices.length; i++) {
	    orgVertices[i].x = vertices[i].x;
	    orgVertices[i].y = vertices[i].y;
	  }
	  shape.geometry.verticesNeedUpdate = true;
	  shape.geometry.computeBoundingSphere();
	};

	module.exports = exports['default'];

/***/ },
/* 22 */
/***/ function(module, exports) {

	/**
	 * 跟中心转一定角度后的坐标
	 * @param point 点
	 * @param center 中心
	 * @param angle 角度
	 * @returns {THREE.Vector3} 结果
	 */
	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	exports.rotatePoint = rotatePoint;
	exports.getLocationPoint = getLocationPoint;
	exports.rotationAngleVector = rotationAngleVector;
	exports.getAngle = getAngle;
	exports.getVectorAngle = getVectorAngle;

	function rotatePoint(point, center, angle) {
	    var l = angle * Math.PI / 180;

	    //sin/cos value
	    var cosv = Math.cos(l);
	    var sinv = Math.sin(l);

	    // calc new point
	    var newX = (point.x - center.x) * cosv - (point.y - center.y) * sinv + center.x;
	    var newY = (point.x - center.x) * sinv + (point.y - center.y) * cosv + center.y;
	    return new THREE.Vector3(newX, newY, 0);
	}

	/**
	 *  从A到B的方向距离length的点
	 * @param pointA
	 * @param pointB
	 * @param length
	 * @returns {THREE.Vector3}
	 */

	function getLocationPoint(pointA, pointB, length) {
	    var vector = new THREE.Vector3(0, 0, 0);
	    vector.subVectors(pointB, pointA);
	    vector = vector.setLength(length);
	    vector.add(pointA);
	    return vector;
	}

	/**
	 * 向量旋转后的向量，返回旋转后的点和向量;
	 * @param movePoint 旋转角度
	 * @param fixedPoint 旋转轴点（固定的点）
	 * @param angle 旋转角度
	 * @param clockwise 旋转方向
	 */

	function rotationAngleVector(movePoint, fixedPoint, angle, clockwise) {

	    var tempVector = new THREE.Vector2(movePoint.x - fixedPoint.x, movePoint.y - fixedPoint.y);
	    var valueX = undefined,
	        valueY = undefined;
	    var radian = angle / 180 * Math.PI;

	    if (clockwise) {
	        valueX = tempVector.x * Math.cos(radian) + tempVector.y * Math.sin(radian) + fixedPoint.x;
	        valueY = tempVector.y * Math.cos(radian) - tempVector.x * Math.sin(radian) + fixedPoint.y;
	    } else {
	        valueX = tempVector.x * Math.cos(radian) - tempVector.y * Math.sin(radian) + fixedPoint.x;
	        valueY = tempVector.y * Math.cos(radian) + tempVector.x * Math.sin(radian) + fixedPoint.y;
	    }

	    var afterRotationPoint = new THREE.Vector2(valueX, valueY);
	    var afterRotationVector = new THREE.Vector2(valueX - fixedPoint.x, valueY - fixedPoint.y);

	    return {
	        point: afterRotationPoint,
	        vector: afterRotationVector
	    };
	}

	/*
	 first_p：起点坐标，center_p：端点坐标，second_p：末点
	 */

	function getAngle(first_p, center_p, second_p) {
	    var v_ao = new THREE.Vector2().subVectors(first_p, center_p);
	    var v_bo = new THREE.Vector2().subVectors(second_p, center_p);
	    return getVectorAngle(v_ao, v_bo);
	}

	function getVectorAngle(vector1, vector2) {
	    "use strict";
	    var dx1 = undefined,
	        dx2 = undefined,
	        dy1 = undefined,
	        dy2 = undefined,
	        angle = undefined,
	        abs = undefined;
	    dx1 = vector1.x;
	    dy1 = vector1.y;
	    dx2 = vector2.x;
	    dy2 = vector2.y;
	    var c = Math.sqrt(dx1 * dx1 + dy1 * dy1) * Math.sqrt(dx2 * dx2 + dy2 * dy2);
	    if (c == 0) return -1;
	    abs = (dx1 * dx2 + dy1 * dy2) / c;
	    if (abs < 0 && Math.abs(abs) > 1) {
	        //当abs>且是负数的时候，向量方向相反重合，为180°
	        return 180;
	    }
	    if (Math.abs(abs) > 1) {
	        //当abs>1且是正数数的时候，向量方向一致且重合，为0°
	        return 0;
	    }
	    angle = Math.acos((dx1 * dx2 + dy1 * dy2) / c) * 180 / Math.PI;

	    var isClockWise = vector1.x * vector2.y - vector1.y * vector2.x < 0;
	    isClockWise ? null : angle = -angle;
	    return {
	        //弧度
	        angle: angle * Math.PI / 180,

	        //second_p相对于first_p顺逆时针，true标示顺时针
	        clockWise: isClockWise,

	        //角度
	        angleValue: angle
	    };
	}

/***/ },
/* 23 */
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	exports['default'] = function (shape, startPoint, endPoint) {
	  var text = undefined,
	      unitLength = undefined,
	      unitMultiple = undefined,
	      min = undefined,
	      max = undefined,
	      start = undefined,
	      end = undefined;
	  unitLength = shape.parent.data.unitLength;
	  unitMultiple = shape.parent.data.unitMultiple;
	  start = shape.getObjectByName('startPoint') || shape.getObjectByName('intersectionStartPoint') || shape.getObjectByName('unionStartPoint');
	  end = shape.getObjectByName('endPoint') || shape.getObjectByName('intersectionEndPoint') || shape.getObjectByName('unionEndPoint');
	  if (startPoint.x <= endPoint.x) {
	    min = (startPoint.x / unitLength * unitMultiple).toFixed(1);
	    max = (endPoint.x / unitLength * unitMultiple).toFixed(1);
	    if (start.data.status && end.data.status) {
	      text = min + "≤n≤" + max;
	    } else if (start.data.status && !end.data.status) {
	      text = min + "≤n<" + max;
	    } else if (!start.data.status && end.data.status) {
	      text = min + "<n≤" + max;
	    } else {
	      text = min + "<n<" + max;
	    }
	  } else {
	    min = (endPoint.x / unitLength * unitMultiple).toFixed(1);
	    max = (startPoint.x / unitLength * unitMultiple).toFixed(1);
	    if (start.data.status && end.data.status) {
	      text = min + "≤n≤" + max;
	    } else if (start.data.status && !end.data.status) {
	      text = min + "<n≤" + max;
	    } else if (!start.data.status && end.data.status) {
	      text = min + "≤n<" + max;
	    } else {
	      text = min + "<n<" + max;
	    }
	  }
	  return text;
	};

	module.exports = exports['default'];

/***/ },
/* 24 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _ShapeUnion = __webpack_require__(25);

	var _ShapeUnion2 = _interopRequireDefault(_ShapeUnion);

	var _getSections = __webpack_require__(13);

	var _getSections2 = _interopRequireDefault(_getSections);

	var _toolbar = __webpack_require__(11);

	var _getIntersection = __webpack_require__(19);

	var _getIntersection2 = _interopRequireDefault(_getIntersection);

	var _updateVertices = __webpack_require__(21);

	var _updateVertices2 = _interopRequireDefault(_updateVertices);

	var _computeSection = __webpack_require__(23);

	var _computeSection2 = _interopRequireDefault(_computeSection);

	var _addText = __webpack_require__(17);

	var _addText2 = _interopRequireDefault(_addText);

	var _calculatMethod = __webpack_require__(20);

	exports['default'] = function (shape) {
	  var union = undefined,
	      unionObj = undefined,
	      unionObjs = undefined,
	      sections = undefined,
	      sectionObjs = [],
	      color = undefined,
	      height = undefined,
	      lineWidth = undefined,
	      unionStartSide = undefined,
	      unionEndSide = undefined,
	      unionLine = undefined,
	      unions = [],
	      unionStartPoint = undefined,
	      unionEndPoint = undefined,
	      text = undefined,
	      sectionText = undefined,
	      unionStartSideVector = undefined,
	      unionEndSideVector = undefined;

	  lineWidth = shape.data.lineWidth;
	  color = _toolbar.toolbarStatus.unionAttr.unionColor;
	  height = _toolbar.toolbarStatus.unionAttr.unionHeight;
	  sections = (0, _getSections2['default'])(shape).sections;
	  if (sections.length > 0) {
	    sectionObjs = (0, _getIntersection2['default'])(sections);
	    unionObjs = (0, _calculatMethod.unionSection)(sectionObjs);
	    // 获取已存在并集数量
	    for (var i = 0; i < shape.children.length; i++) {
	      var child = shape.children[i];
	      if (child.name == 'union') {
	        unions.push(child);
	      }
	    }
	    if (unionObjs) {
	      if (unions.length == 0) {
	        // 未创建并集时，创建并集
	        for (var i = 0; i < unionObjs.length; i++) {
	          unionObj = unionObjs[i];
	          union = (0, _ShapeUnion2['default'])(unionObj.leftPoint, unionObj.leftIsSolid, unionObj.rightPoint, unionObj.rightIsSolid, height, color, lineWidth);
	          shape.add(union);
	          // 创建交集文字
	          text = (0, _computeSection2['default'])(union, unionObj.leftPoint, unionObj.rightPoint);
	          sectionText = (0, _addText2['default'])(text, new THREE.Vector2((unionObj.leftPoint.x + unionObj.rightPoint.x) / 2, height - 10), 128, 16, '16px', color);
	          sectionText._dynamicTexture.clear().drawText(text, undefined, 16, color);
	          sectionText.name = "unionText";

	          union.add(sectionText);
	        }
	      } else {
	        // 已存在并集时，更新并集
	        if (unions.length < unionObjs.length) {
	          var count = unionObjs.length - unions.length;
	          for (var i = 0; i < count; i++) {
	            unionObj = unionObjs[unions.length + i];
	            union = (0, _ShapeUnion2['default'])(unionObj.leftPoint, unionObj.leftIsSolid, unionObj.rightPoint, unionObj.rightIsSolid, height, color, lineWidth);
	            shape.add(union);
	            // 创建交集文字
	            text = (0, _computeSection2['default'])(union, unionObj.leftPoint, unionObj.rightPoint);
	            sectionText = (0, _addText2['default'])(text, new THREE.Vector2((unionObj.leftPoint.x + unionObj.rightPoint.x) / 2, height - 10), 128, 16, '16px', color);
	            sectionText._dynamicTexture.clear().drawText(text, undefined, 16, color);
	            sectionText.name = "unionText";

	            union.add(sectionText);
	            unions.push(union);
	          }
	        }
	        if (unions.length >= unionObjs.length) {
	          for (var i = 0; i < unions.length; i++) {
	            union = unions[i];
	            if (i >= unionObjs.length) {
	              union.visible = false;
	            } else {
	              unionObj = unionObjs[i];
	              union.visible = true;
	              unionStartPoint = union.getObjectByName('unionStartPoint');
	              unionEndPoint = union.getObjectByName('unionEndPoint');
	              unionStartSide = union.getObjectByName('unionStartSide');
	              unionEndSide = union.getObjectByName('unionEndSide');
	              unionLine = union.getObjectByName('unionLine');
	              sectionText = union.getObjectByName('unionText');
	              // 修改端点状态及位置
	              unionStartPoint.position.x = unionObj.leftPoint.x;
	              unionEndPoint.position.x = unionObj.rightPoint.x;
	              if (unionObj.leftIsSolid) {
	                unionStartPoint.getObjectByName('inCircle').visible = false;
	                unionStartPoint.data.status = true;
	              } else {
	                unionStartPoint.getObjectByName('inCircle').visible = true;
	                unionStartPoint.data.status = false;
	              }
	              if (unionObj.rightIsSolid) {
	                unionEndPoint.getObjectByName('inCircle').visible = false;
	                unionEndPoint.data.status = true;
	              } else {
	                unionEndPoint.getObjectByName('inCircle').visible = true;
	                unionEndPoint.data.status = false;
	              }

	              // 更新三线
	              unionStartSideVector = new THREE.Vector3(unionObj.leftPoint.x, height, 0);
	              unionEndSideVector = new THREE.Vector3(unionObj.rightPoint.x, height, 0);
	              (0, _updateVertices2['default'])(unionStartSide, unionObj.leftPoint, unionStartSideVector, lineWidth);
	              (0, _updateVertices2['default'])(unionEndSide, unionObj.rightPoint, unionEndSideVector, lineWidth);
	              (0, _updateVertices2['default'])(unionLine, new THREE.Vector3(unionStartSideVector.x, unionStartSideVector.y + lineWidth / 2), new THREE.Vector3(unionEndSideVector.x, unionEndSideVector.y + lineWidth / 2), lineWidth);

	              // 计算应该显示的文字
	              text = (0, _computeSection2['default'])(union, unionObj.leftPoint, unionObj.rightPoint);
	              // 刷新文字
	              sectionText._dynamicTexture.clear().drawText(text, undefined, 16, color);
	              sectionText.position.x = (unionObj.leftPoint.x + unionObj.rightPoint.x) / 2;
	              sectionText.position.y = height - 10;
	            }
	          }
	        }
	      }
	    } else {
	      for (var i = 0; i < shape.children.length; i++) {
	        var child = shape.children[i];
	        if (child.name == 'union') {
	          child.visible = false;
	        }
	      }
	    }
	  } else {
	    for (var i = 0; i < shape.children.length; i++) {
	      var child = shape.children[i];
	      if (child.name == 'union') {
	        child.visible = false;
	      }
	    }
	  }
	};

	module.exports = exports['default'];

/***/ },
/* 25 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _ShapeSectionLine = __webpack_require__(16);

	var _ShapePoint = __webpack_require__(18);

	var _ShapePoint2 = _interopRequireDefault(_ShapePoint);

	exports['default'] = function (startPoint, startIsSolid, endPoint, endIsSolid, height, color, lineWidth) {
	  var union = new THREE.Object3D();
	  var startSide = undefined,
	      endSide = undefined,
	      line = undefined,
	      start = undefined,
	      end = undefined;
	  // 创建左端点
	  start = (0, _ShapePoint2['default'])(lineWidth, color);
	  start.position.x = startPoint.x;
	  start.position.z = 0.1;
	  start.name = 'unionStartPoint';
	  start.data = {};
	  start.data.status = false;
	  if (startIsSolid) {
	    start.getObjectByName('inCircle').visible = false;
	    start.data.status = true;
	  }
	  // 创建右端点
	  end = (0, _ShapePoint2['default'])(lineWidth, color);
	  end.position.x = endPoint.x;
	  end.position.z = 0.1;
	  end.name = 'unionEndPoint';
	  end.data = {};
	  end.data.status = false;
	  if (endIsSolid) {
	    end.getObjectByName('inCircle').visible = false;
	    end.data.status = true;
	  }
	  // 创建交集左边线
	  startSide = (0, _ShapeSectionLine.createSide)(startPoint, height, lineWidth, color);
	  startSide.side.name = 'unionStartSide';
	  // 创建交集右边线
	  endSide = (0, _ShapeSectionLine.createSide)(endPoint, height, lineWidth, color);
	  endSide.side.name = 'unionEndSide';
	  startSide.upVector.y = startSide.upVector.y + lineWidth / 2;
	  endSide.upVector.y = endSide.upVector.y + lineWidth / 2;
	  // 创建交集下边线
	  line = (0, _ShapeSectionLine.createLine)(startSide.upVector, endSide.upVector, lineWidth, color);
	  line.name = 'unionLine';

	  union.add(start);
	  union.add(end);
	  union.add(startSide.side);
	  union.add(endSide.side);
	  union.add(line);

	  union.name = 'union';
	  return union;
	};

	module.exports = exports['default'];

/***/ },
/* 26 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _updateIntersection = __webpack_require__(14);

	var _updateIntersection2 = _interopRequireDefault(_updateIntersection);

	var _updateUnion = __webpack_require__(24);

	var _updateUnion2 = _interopRequireDefault(_updateUnion);

	var _toolbar = __webpack_require__(11);

	exports['default'] = function (shape) {
	  var intersection = shape.getObjectByName('intersection');
	  var union = shape.getObjectByName('union');
	  if (intersection && _toolbar.toolbarStatus.isShowIntersection) {
	    (0, _updateIntersection2['default'])(shape);
	  }
	  if (union && _toolbar.toolbarStatus.isShowUnion) {
	    (0, _updateUnion2['default'])(shape);
	  }
	};

	module.exports = exports['default'];

/***/ },
/* 27 */
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	exports['default'] = function (shape, action) {
	  var unitController = shape.getObjectByName('unitController');
	  var select = shape.getObjectByName('unitSelect');
	  if (!action) {
	    if (shape.getObjectByName('section') || shape.getObjectByName('markPoint') || shape.getObjectByName('regulation')) {
	      unitController.visible = false;
	      select.visible = false;
	    } else {
	      unitController.visible = true;
	    }
	  } else {
	    if (action == 'interval' || action == 'regulation' || action == 'mark') {
	      unitController.visible = false;
	      select.visible = false;
	    } else {
	      if (shape.getObjectByName('section') || shape.getObjectByName('markPoint') || shape.getObjectByName('regulation')) {
	        unitController.visible = false;
	        select.visible = false;
	      } else {
	        unitController.visible = true;
	      }
	    }
	  }
	};

	module.exports = exports['default'];

/***/ },
/* 28 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by ｘｃｃ on 2015/12/23.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.AddMarkPoint = AddMarkPoint;
	exports.clearAll = clearAll;
	exports.clear = clear;
	exports.add = add;
	exports.getCharCollection = getCharCollection;
	exports.getPositionCollection = getPositionCollection;
	exports.resetCollection = resetCollection;
	exports.refreshPositionCollection = refreshPositionCollection;
	exports.setisOpenForMarkPoint = setisOpenForMarkPoint;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _UtilsMessages = __webpack_require__(29);

	var _UtilsMessages2 = _interopRequireDefault(_UtilsMessages);

	var _MarkPoint = __webpack_require__(30);

	var _MarkPoint2 = _interopRequireDefault(_MarkPoint);

	var _AxisView = __webpack_require__(34);

	var _UtilsMoveMarkPoint = __webpack_require__(53);

	var _threeManger = __webpack_require__(10);

	var _constants = __webpack_require__(4);

	var _UtilsEditeMarkPointText = __webpack_require__(56);

	var _decoData = __webpack_require__(57);

	var charCollection = []; //标识点标识收集器
	var positionCollection = [];exports.positionCollection = positionCollection;
	//标识点位置收集器
	var isOpenForMarkPoint = true;

	function AddMarkPoint(point, clsName) {

	    if (isOpenForMarkPoint) {
	        var radius = _AxisView.lineWidth * 1.5;
	        //如果打开了标识点，则关闭一切其他操作，在一定范围内点击屏幕生成标识点。
	        var size = charCollection.length;
	        if (size == _decoData.maxSize) {
	            //数轴题最多四个点
	            console.log('数轴题最多四个点');
	            console.log(charCollection);
	            return;
	        }
	        var char = _constants.CHARACTER[size];
	        //找出CHARACTER里有，而charCollection没有的第一个元素
	        for (var v = 0; v < size; v++) {
	            var isSame = false;
	            for (var vv = 0; vv < size; vv++) {
	                if (_constants.CHARACTER[v] == charCollection[vv]) {
	                    isSame = true;
	                    break;
	                }
	            }
	            if (!isSame) {
	                char = _constants.CHARACTER[v];
	                break;
	            }
	        }
	        console.log('char=' + char);
	        var posisitionX = point.x - _AxisView.numberLine.position.x;
	        for (var v = 0; v < positionCollection.length; v++) {
	            //console.log('positionCollection[v]=' + positionCollection[v])
	            var frist = positionCollection[v] - radius;
	            var end = positionCollection[v] + radius;
	            //console.log('frist=' + frist + '      end=' + end)
	            //if (frist < posisitionX && posisitionX < end) {
	            //    console.log('标识点重叠，请换个位置！')
	            //    return ;
	            //}//数轴题表示点不判断重合
	        }
	        var markPoint = new _MarkPoint2['default'](radius, _AxisView.numberLine, posisitionX, char).createMarkPoint(clsName);
	        charCollection.push(char);
	        positionCollection.push(posisitionX);
	        _AxisView.numberLine.add(markPoint);
	        return markPoint;
	    }
	}

	function clearAll() {
	    charCollection = [];
	}

	function clear(markPointText) {
	    //删除单个标识点的操作
	    var array = [];
	    for (var v = 0; v < charCollection.length; v++) {
	        //在已收集的容器里移除需要删除的标识
	        if (charCollection[v] != markPointText) array.push(charCollection[v]);
	    }
	    charCollection = array;
	    console.log('我在AddmarkMpoint的Clear里，当前字体容器里有');
	    console.log(charCollection);
	}

	function add(markPointText) {
	    //修改之后的标识点marktext还需要加入到已收集的容器，因为最大为十个，包括已修改的
	    charCollection.push(markPointText);
	    console.log('我在AddmarkMpoint的add里，当前容器里有');
	    console.log(charCollection);
	}

	function getCharCollection() {
	    return charCollection;
	}

	function getPositionCollection() {
	    return positionCollection;
	}

	function resetCollection() {
	    charCollection = [];
	    exports.positionCollection = positionCollection = [];
	    (0, _UtilsEditeMarkPointText.resetText)();
	    console.log('我在AddmarkMpoint的resetCollection清空重置');
	}

	function refreshPositionCollection(array) {
	    exports.positionCollection = positionCollection = array;
	    console.log('我在AddmarkMpoint的refreshPositionCollection里，当前位置容器里有');
	    console.log(positionCollection);
	}

	function setisOpenForMarkPoint(boolean) {
	    isOpenForMarkPoint = boolean;
	}

/***/ },
/* 29 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var messages = {
	    markNumError: '最多增加十个标识点'
	};

	exports['default'] = function (options) {
	    if (!options) {
	        return;
	    }
	    var $field = $(_presenter2['default'].view).find('.numberLine-tips');
	    $field.html(messages[options]);
	    $field.show(150).delay(2000).hide(200);
	};

	module.exports = exports['default'];

/***/ },
/* 30 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by xcc on 2015/12/22.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

	exports.getTheValue = getTheValue;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

	var _UtilsAddText = __webpack_require__(17);

	var _UtilsAddText2 = _interopRequireDefault(_UtilsAddText);

	var _UtilsUpdateUnit = __webpack_require__(31);

	/**
	 * 标识点创建模型
	 * @param lineWidth 连接旋转点，需要旋转到合并点的端点
	 * @param numberLine 位置相对于group
	 * @param offSetX 相对于group的X轴偏移量
	 * @param offSetY 相对于group的Y轴偏移量
	 * @param text 需要显示的字（ABC...）
	 */
	var markPositionCollection = [];

	var MarkPoint = (function () {
	    function MarkPoint(radius, lineGroup, offSetX, text) {
	        if (radius === undefined) radius = 6;
	        if (lineGroup === undefined) lineGroup = new THREE.Object3D();

	        _classCallCheck(this, MarkPoint);

	        this.radius = radius;
	        this.lineGroup = lineGroup;
	        this.offSetX = offSetX;
	        this.text = text.toString();
	    }

	    // 圆材质

	    _createClass(MarkPoint, [{
	        key: 'getCricleMaterial',
	        value: function getCricleMaterial() {
	            return new THREE.MeshBasicMaterial({
	                color: '#FF0000',
	                transparent: false,
	                opacity: 1
	            });
	        }

	        // 绘制刻度选择框
	    }, {
	        key: 'drawTextFrame',
	        value: function drawTextFrame() {
	            var frame = new THREE.Shape();
	            frame.moveTo(-20, 17);
	            frame.lineTo(20, 17);
	            frame.lineTo(20, 35);
	            frame.lineTo(-20, 35);
	            frame.lineTo(-20, 17);
	            var points = frame.createPointsGeometry();
	            var side = new THREE.Line(points, new THREE.LineBasicMaterial({
	                color: 0x333333,
	                opacity: 1
	            }));
	            //frame.position.copy(new THREE.Vector3(this.unitLength,-23,0));
	            return side;
	        }

	        // 字体材质
	    }, {
	        key: 'getTextMaterial',
	        value: function getTextMaterial() {
	            return new THREE.MeshBasicMaterial({
	                color: '#FF0000',
	                transparent: false,
	                opacity: 1
	            });
	        }

	        // 绘制标识点
	    }, {
	        key: 'createMarkPoint',
	        value: function createMarkPoint(group) {
	            var groupCricle = new THREE.Object3D();
	            var circleGeometry = new THREE.CircleGeometry(this.radius, 32);
	            var circle = new THREE.Mesh(circleGeometry, this.getCricleMaterial());
	            groupCricle.position.x = this.offSetX;
	            groupCricle.position.y = 0;

	            var position = new THREE.Vector2();
	            position.x = 0;
	            position.y = 0;
	            position.y += _UtilsUpdateUnit.unitHeightSend + 5;
	            var msgMarkLetter = (0, _UtilsAddText2['default'])(this.text, position, 32, 32, '15px', 'black'); //字母ABC

	            position.y = 0;
	            position.y -= _UtilsUpdateUnit.unitHeightSend + 15; //加2是为了与你刻度值的值等高
	            var value = this.offSetX / _UtilsUpdateUnit.unitLengthSend;
	            var valueText = this.getTheValue(value.toString());
	            console.log('value=' + value + '   valueText=' + valueText);
	            var msgMarkValue = (0, _UtilsAddText2['default'])(valueText, position, 64, 32, '15px', 'red'); //标识点具体的值

	            var drawTextFrame = this.drawTextFrame();
	            drawTextFrame.visible = false;

	            drawTextFrame.name = 'markPointFrame';
	            groupCricle.name = 'markPoint';
	            circle.name = 'markPointCircle';
	            msgMarkLetter.name = 'markPointText';
	            msgMarkValue.name = 'markPointValue';
	            groupCricle.userData.clsName = group;
	            groupCricle.userData.markText = this.text;
	            groupCricle.userData.valueText = valueText;
	            groupCricle.add(circle);
	            //groupCricle.add(msgMarkLetter);//数轴题注释标记点的符号
	            groupCricle.add(msgMarkValue);
	            groupCricle.add(drawTextFrame);
	            groupCricle.position.z += 1;
	            return groupCricle;
	        }
	    }, {
	        key: 'getTheValue',
	        value: function getTheValue(value) {
	            var result = value.indexOf('.');
	            if (result != -1) {
	                //存在小数点,截取
	                return value.substring(0, result + 2);
	            }
	            return '';
	        }
	    }]);

	    return MarkPoint;
	})();

	exports['default'] = MarkPoint;

	function getTheValue(offSetX) {
	    var value = offSetX / _UtilsUpdateUnit.unitLengthSend;
	    var result = value.toString().indexOf('.');
	    if (result != -1) {
	        //存在小数点,截取
	        //return value.toString().substring(0, result + 2);
	        console.log('get The value is ', value);
	        return parseInt(value);
	    }
	    return value;
	}

/***/ },
/* 31 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _ShapeUnit = __webpack_require__(32);

	var _ShapeUnit2 = _interopRequireDefault(_ShapeUnit);

	var _ShapeSmallUnit = __webpack_require__(33);

	var _ShapeSmallUnit2 = _interopRequireDefault(_ShapeSmallUnit);

	var _updateVertices = __webpack_require__(21);

	var _updateVertices2 = _interopRequireDefault(_updateVertices);

	var _addText = __webpack_require__(17);

	var _addText2 = _interopRequireDefault(_addText);

	/**
	 * shape数轴
	 * pointA数轴左端点
	 * pointB数轴右端点
	 * lineWidth数轴线宽
	 * unitHeight刻度高度
	 * unitLength数轴单个刻度的长度
	 */

	exports['default'] = function (shape, pointA, pointB) {
	  var unitMultiple = arguments.length <= 3 || arguments[3] === undefined ? 1 : arguments[3];
	  var unitLength = arguments.length <= 4 || arguments[4] === undefined ? 80 : arguments[4];
	  var lineWidth = arguments.length <= 5 || arguments[5] === undefined ? 6 : arguments[5];
	  var unitHeight = arguments.length <= 6 || arguments[6] === undefined ? 15 : arguments[6];

	  var unit = undefined,
	      unitNum = undefined,
	      unitContent = undefined,
	      unitCount = undefined,
	      unitCACount = undefined,
	      unitCBCount = undefined,
	      center = undefined,
	      vectorAB = undefined,
	      vectorCA = undefined,
	      vectorCB = undefined,
	      addCount = undefined,
	      unitPoint = undefined,
	      text = undefined,
	      samllUnitCount = undefined,
	      samllUnitCACount = undefined,
	      samllUnitCBCount = undefined,
	      smallUnits = undefined,
	      smallUnitPoint = undefined;
	  var line = shape.getObjectByName('line');
	  var circleCenter = shape.getObjectByName('center');
	  exports.unitLengthSend = unitLengthSend = unitLength; //传入标识点 xiongcc
	  exports.unitHeightSend = unitHeightSend = unitHeight; //传入标识点 xiongcc
	  exports.unitMultipleSend = unitMultipleSend = unitMultiple; //传入标识点 xiongcc
	  center = new THREE.Vector3(0, 0, 0);
	  vectorAB = new THREE.Vector2().subVectors(pointB, pointA);
	  vectorCA = new THREE.Vector2().subVectors(pointA, center);
	  vectorCB = new THREE.Vector2().subVectors(center, pointB);
	  // 数轴上应显示刻度个数
	  unitCount = parseInt(vectorAB.length() / unitLength);
	  samllUnitCount = parseInt(vectorAB.length() / (unitLength / 10));
	  unitCACount = parseInt(vectorCA.length() / unitLength);
	  samllUnitCACount = parseInt(vectorCA.length() / (unitLength / 10));
	  unitCBCount = parseInt(vectorCB.length() / unitLength);
	  samllUnitCBCount = parseInt(vectorCB.length() / (unitLength / 10));

	  if (unitCount == unitCACount + unitCBCount) {
	    unitCount += 1;
	  }

	  if (line.children.length == 0) {
	    for (var i = 0; i < unitCount; i++) {
	      var unitContainer = new THREE.Object3D();
	      unit = (0, _ShapeUnit2['default'])(lineWidth);
	      unitNum = (0, _addText2['default'])('', center, 64, 32, '16px', 'black');
	      if (i == 1) {
	        unitNum.name = 'showText';
	      } else {
	        unitNum.name = 'text';
	      }
	      unitNum.position.y = -30;
	      unitContainer.add(unit);
	      unitContainer.add(unitNum);
	      unitContainer.visible = false;
	      line.add(unitContainer);
	    }
	    for (var i = 0; i < (unitCount + 1) * 10; i++) {
	      var smallUnit = (0, _ShapeSmallUnit2['default'])();
	      smallUnit.visible = false;
	      circleCenter.add(smallUnit);
	    }
	  } else {
	    if (unitCount > line.children.length) {
	      addCount = unitCount - line.children.length;
	      for (var i = 0; i < addCount; i++) {
	        var unitContainer = new THREE.Object3D();
	        unit = (0, _ShapeUnit2['default'])(lineWidth);
	        unitNum = (0, _addText2['default'])('', center, 64, 32, '16px', 'black');
	        unitNum.name = 'text';
	        unitNum.position.y = -30;
	        unitContainer.add(unit);
	        unitContainer.add(unitNum);
	        unitContainer.visible = false;
	        line.add(unitContainer);
	      }
	      for (var i = 0; i < addCount * 10; i++) {
	        var smallUnit = (0, _ShapeSmallUnit2['default'])();
	        smallUnit.visible = false;
	        circleCenter.add(smallUnit);
	      }
	    }
	  }
	  for (var i = 0; i < line.children.length; i++) {
	    unitContent = line.children[i];
	    unit = unitContent.getObjectByName('unit');
	    unitNum = unitContent.getObjectByName('text') || unitContent.getObjectByName('showText');
	    if (i <= unitCBCount) {
	      unitPoint = new THREE.Vector3(unitLength * i, 0, 0);
	      text = parseInt(i * unitMultiple * 10) / 10;
	      unitContent.position.copy(unitPoint);
	      unitNum._dynamicTexture.clear().drawText(text.toString(), undefined, 16, '#000000');
	      if (text % 5 != 0) {
	        unitNum.visible = false; //数轴题刻度显示为5的倍数
	      }
	      unitContent.visible = true;
	      if (i == 0) {
	        unit.visible = false;
	      }
	    } else if (i > unitCBCount && i < unitCount) {
	      unitPoint = new THREE.Vector3(-unitLength * (i - unitCBCount), 0, 0);
	      text = parseInt(-(i - unitCBCount) * unitMultiple * 10) / 10;
	      line.children[i].position.copy(unitPoint);
	      unitNum._dynamicTexture.clear().drawText(text.toString(), undefined, 16, '#000000');
	      if (text % 5 != 0) {
	        unitNum.visible = false; //数轴题刻度显示为5的倍数
	      }
	      unitContent.visible = true;
	    } else {
	      unitContent.visible = false;
	    }
	  }
	  smallUnits = circleCenter.children;
	  if (unitLength < 80 || unitMultiple.toString().indexOf('.') != -1) {
	    for (var i = 0; i < smallUnits.length; i++) {
	      smallUnits[i].visible = false;
	    }
	    shape.data.smallUnitVisible = false;
	  } else {
	    for (var i = 0; i < smallUnits.length; i++) {
	      if (i <= samllUnitCBCount) {
	        smallUnitPoint = new THREE.Vector3(unitLength / 10 * i, 0, 0);
	        smallUnits[i].position.copy(smallUnitPoint);
	        smallUnits[i].visible = true;
	        if (i == 0 || i == samllUnitCBCount) {
	          smallUnits[i].visible = false;
	        }
	      } else if (i > samllUnitCBCount && i < samllUnitCount) {
	        smallUnitPoint = new THREE.Vector3(-(unitLength / 10) * (i - samllUnitCBCount), 0, 0);
	        smallUnits[i].position.copy(smallUnitPoint);
	        smallUnits[i].visible = true;
	      } else {
	        smallUnits[i].visible = false;
	      }
	    }
	    shape.data.smallUnitVisible = true;
	  }
	};

	var unitLengthSend, unitHeightSend, unitMultipleSend;
	exports.unitLengthSend = unitLengthSend;
	exports.unitHeightSend = unitHeightSend;
	exports.unitMultipleSend = unitMultipleSend;

/***/ },
/* 32 */
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	exports['default'] = function (lineWidth) {
		var point1 = arguments.length <= 1 || arguments[1] === undefined ? new THREE.Vector3(0, 0, 0) : arguments[1];
		var unitHeight = arguments.length <= 2 || arguments[2] === undefined ? 15 : arguments[2];

		var shape = new THREE.Shape();
		var point2 = new THREE.Vector3(point1.x, point1.y + unitHeight, 0);
		shape.moveTo(point1.x + lineWidth / 4, 0);
		shape.lineTo(point2.x + lineWidth / 4, unitHeight);
		shape.lineTo(point2.x - lineWidth / 4, unitHeight);
		shape.lineTo(point1.x - lineWidth / 4, 0);
		shape.lineTo(point1.x + lineWidth / 4, 0);
		var geometry = new THREE.ShapeGeometry(shape);
		var unit = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({
			color: 0x333333,
			transparent: false,
			opacity: 1
		}));
		unit.name = 'unit';
		unit.position.z = -1;
		return unit;
	};

	module.exports = exports['default'];

/***/ },
/* 33 */
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	exports['default'] = function () {
	  var unitHeight = arguments.length <= 0 || arguments[0] === undefined ? 15 : arguments[0];

	  var geometry = new THREE.Geometry();
	  geometry.vertices.push(new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, unitHeight / 1.7, 0));
	  var smallUnit = new THREE.Line(geometry, new THREE.LineBasicMaterial({
	    color: 0x333333,
	    transparent: false,
	    opacity: 1
	  }));
	  smallUnit.name = 'smallUnit';
	  smallUnit.position.z = -1;
	  return smallUnit;
	};

	module.exports = exports['default'];

/***/ },
/* 34 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by zhoujunzhou on 2016/1/4.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.init = init;
	exports.initEditorCanvas = initEditorCanvas;
	exports.updateNewValue = updateNewValue;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _NumberLine = __webpack_require__(35);

	var _NumberLine2 = _interopRequireDefault(_NumberLine);

	var _OperationMarkPoint = __webpack_require__(36);

	var _OperationMarkPoint2 = _interopRequireDefault(_OperationMarkPoint);

	var _MarkPoint = __webpack_require__(30);

	var _MarkPoint2 = _interopRequireDefault(_MarkPoint);

	var _UtilsUpdateUnit = __webpack_require__(31);

	var _UtilsUpdateUnit2 = _interopRequireDefault(_UtilsUpdateUnit);

	var _UtilsUpdateUnitNum = __webpack_require__(38);

	var _UtilsUpdateUnitNum2 = _interopRequireDefault(_UtilsUpdateUnitNum);

	var _constants = __webpack_require__(4);

	var _UtilsToolbar = __webpack_require__(11);

	var _ShapeAddMarkPoint = __webpack_require__(28);

	var _moduleControl = __webpack_require__(6);

	var _ShapeAxisView = __webpack_require__(34);

	var _threeManger = __webpack_require__(10);

	var _EventDocumentEvent = __webpack_require__(9);

	var _EventDocumentEvent2 = _interopRequireDefault(_EventDocumentEvent);

	var _ShapeConnectLine = __webpack_require__(39);

	var _ShapeConnectLine2 = _interopRequireDefault(_ShapeConnectLine);

	var _EditorCoordNoteModel = __webpack_require__(40);

	var _EditorCoordNoteModel2 = _interopRequireDefault(_EditorCoordNoteModel);

	var _EditorCoordNumberModel = __webpack_require__(45);

	var _EditorCoordNumberModel2 = _interopRequireDefault(_EditorCoordNumberModel);

	var _EditorCalcNoteModel = __webpack_require__(46);

	var _EditorCalcNoteModel2 = _interopRequireDefault(_EditorCalcNoteModel);

	var _EditorCalcNumberModel = __webpack_require__(48);

	var _EditorCalcNumberModel2 = _interopRequireDefault(_EditorCalcNumberModel);

	var _ShapePoint = __webpack_require__(18);

	var _ShapePoint2 = _interopRequireDefault(_ShapePoint);

	var _UtilsAddCurve = __webpack_require__(49);

	var _UtilsAddCurve2 = _interopRequireDefault(_UtilsAddCurve);

	var lineWidth = undefined,
	    numberLine = undefined;
	exports.lineWidth = lineWidth;
	exports.numberLine = numberLine;
	var offsetX = 500,
	    offsetY = 22,
	    offsetXY = 0;
	exports.offsetX = offsetX;
	exports.offsetY = offsetY;
	exports.offsetXY = offsetXY;
	var unitLength = 25;
	exports.unitLength = unitLength;

	function init(value) {
	    //threeStart();
	    if (_presenter2['default'].isTeacherMobile || _presenter2['default'].isStudentMobile) {
	        exports.offsetX = offsetX = 500;
	        var pointA = undefined,
	            pointB = undefined;
	        if (value) {
	            //整数
	            pointA = new THREE.Vector3(0, 0, 0);
	            pointB = new THREE.Vector3(1025, 0, 0);
	            _constants.REAL_ESTATE.endPosition = 1025;
	            //DocumentEvent()
	        } else {
	                //自然数
	                pointA = new THREE.Vector3(-500, 0, 0);
	                pointB = new THREE.Vector3(525, 0, 0);
	                _constants.REAL_ESTATE.endPosition = 525;
	                //DocumentEvent();//数轴题web端不可编辑,注释掉鼠标事件
	            }
	        initNumberLine(pointA, pointB, value);
	    } else {
	        console.log('axisView REAL_ESTATE.width ', _constants.REAL_ESTATE.width);
	        if (_constants.REAL_ESTATE.width > _constants.REAL_ESTATE.frontage) {
	            exports.offsetX = offsetX = 400;
	            var pointA = undefined,
	                pointB = undefined;
	            if (value) {
	                //整数
	                pointA = new THREE.Vector3(0, 0, 0);
	                pointB = new THREE.Vector3(820, 0, 0);
	                _constants.REAL_ESTATE.endPosition = 820;
	                //DocumentEvent()
	            } else {
	                    //自然数
	                    pointA = new THREE.Vector3(-400, 0, 0);
	                    pointB = new THREE.Vector3(420, 0, 0);
	                    _constants.REAL_ESTATE.endPosition = 420;
	                    //DocumentEvent();//数轴题web端不可编辑,注释掉鼠标事件
	                }
	            exports.unitLength = unitLength = 20;
	            initNumberLine(pointA, pointB, value);
	            console.log('init with width:', _constants.REAL_ESTATE.width, _threeManger.scene.getObjectByName("line"));
	        } else {

	            exports.offsetX = offsetX = 300;
	            var pointA = undefined,
	                pointB = undefined;
	            if (value) {
	                //整数
	                pointA = new THREE.Vector3(0, 0, 0);
	                pointB = new THREE.Vector3(620, 0, 0);
	                _constants.REAL_ESTATE.endPosition = 620;
	                //DocumentEvent()
	            } else {
	                    //自然数
	                    pointA = new THREE.Vector3(-300, 0, 0);
	                    pointB = new THREE.Vector3(320, 0, 0);
	                    _constants.REAL_ESTATE.endPosition = 320;
	                    //DocumentEvent();//数轴题web端不可编辑,注释掉鼠标事件
	                }
	            exports.unitLength = unitLength = 15;
	            initNumberLine(pointA, pointB, value);
	            console.log('init with width:', _constants.REAL_ESTATE.width, _threeManger.scene.getObjectByName("line"));
	        }
	    }

	    console.log(unitLength, 'unitLength');
	    _presenter2['default'].renderer();
	}

	function initNumberLine(pointA, pointB, value) {
	    exports.lineWidth = lineWidth = 6;
	    var arrowLength = 30;
	    var controllerDis = 20;
	    var unitHeight = 15;

	    var unitMultiple = 1;
	    var selectA = new THREE.Vector3(-15, 0, 0);
	    var selectB = new THREE.Vector3(15, 0, 0);
	    exports.numberLine = numberLine = new _NumberLine2['default'](pointA, pointB, lineWidth, arrowLength, controllerDis, unitHeight, unitLength, selectA, selectB).create();
	    (0, _UtilsUpdateUnit2['default'])(numberLine, pointA, pointB, unitMultiple, unitLength, lineWidth, unitHeight);
	    numberLine.data.pointA = pointA;
	    numberLine.data.pointB = pointB;
	    numberLine.data.lineWidth = lineWidth;
	    numberLine.data.arrowLength = arrowLength;
	    numberLine.data.controllerDis = controllerDis;
	    numberLine.data.unitHeight = unitHeight;
	    numberLine.data.unitLength = unitLength;
	    numberLine.data.unitMultiple = unitMultiple;
	    numberLine.data.selectA = selectA;
	    numberLine.data.selectB = selectB;
	    numberLine.data.mathAxis = 'mathAxis';
	    if (value) {
	        numberLine.position.x = -offsetX;
	    }
	    _threeManger.scene.add(numberLine);
	    var childrenLength = undefined;
	    if (value) {
	        childrenLength = _threeManger.scene.getObjectByName("line").children.length - 1;
	    } else {
	        childrenLength = Math.floor(_threeManger.scene.getObjectByName("line").children.length / 2);
	    }
	    _threeManger.scene.getObjectByName("line").children[childrenLength].visible = false;
	    var input = $('.numberline-input');
	    input.on('keyup', function () {
	        (0, _UtilsUpdateUnitNum2['default'])(numberLine, this);
	    });
	}

	function initEditorCanvas() {

	    console.log('initEditorCanvas');
	    var group = _threeManger.scene.getObjectByName("group");
	    var examModel = (0, _moduleControl.getAxisExamModel)();
	    var type = examModel.examType;
	    var numberArray = examModel.valueArray;
	    if (_presenter2['default'].isFirstTime) {
	        (0, _ShapeAxisView.init)(examModel.isInteger);
	        _presenter2['default'].isFirstTime = false;
	    } else {
	        if (typeof group !== 'undefined') {
	            group.parent.remove(group);
	        }
	        (0, _ShapeAxisView.init)(examModel.isInteger);
	    }

	    if (type == _constants.EXAM_TYPE.Coord_Point_Note) {
	        initCoordPointNote();
	    } else if (type == _constants.EXAM_TYPE.Coord_Point_Number) {
	        initCoordPointNumber();
	    } else if (type == _constants.EXAM_TYPE.Calculate_Note) {
	        initCalculateNote();
	    } else if (type == _constants.EXAM_TYPE.Calculate_Number) {
	        initCalculateNumber();
	    } else {
	        console.log('generate view of subject fail ');
	    }
	    _presenter2['default'].renderer();
	}

	function updateNewValue() {
	    var examModel = (0, _moduleControl.getAxisExamModel)();
	    if (examModel instanceof _EditorCoordNoteModel2['default']) {
	        initCoordPointNote();
	    } else if (examModel instanceof _EditorCoordNumberModel2['default']) {
	        initCoordPointNumber();
	    } else if (examModel instanceof _EditorCalcNoteModel2['default']) {
	        initCalculateNote();
	    } else if (examModel instanceof _EditorCalcNumberModel2['default']) {
	        initCalculateNumber();
	    } else {
	        console.log('generate view of subject fail ');
	    }
	    _presenter2['default'].renderer();
	}

	function initCoordPointNote() {
	    var numberArray = (0, _moduleControl.getAxisExamModel)().valueArray;
	    $.each(numberArray, function (i, item) {
	        var point = new THREE.Vector3();
	        point.x = item * unitLength;
	        point.y = 0;
	        point.z = 0;
	    });
	}
	function initCoordPointNumber() {
	    var numberArray = (0, _moduleControl.getAxisExamModel)().valueArray;
	    var value = (0, _moduleControl.getAxisExamModel)().isInteger;
	    $.each(numberArray, function (i, item) {
	        if (value) {
	            var point = new THREE.Vector3();
	            point.x = item * unitLength - offsetX;
	            point.y = 0;
	            point.z = 0;
	            (0, _ShapeAddMarkPoint.AddMarkPoint)(point);
	        } else {
	            var point = new THREE.Vector3();
	            point.x = item * unitLength;
	            point.y = 0;
	            point.z = 0;
	            (0, _ShapeAddMarkPoint.AddMarkPoint)(point);
	        }
	    });
	}
	function initCalculateNote() {
	    var examModel = (0, _moduleControl.getAxisExamModel)();
	    var parent = _threeManger.scene.getObjectByName("group");
	    var width = parent.data.lineWidth * 1.5;
	    var startPoint = examModel.valueArray[0];
	    if (examModel.valueArray.length == 2) {
	        _UtilsToolbar.toolbarStatus.lineColor = ['#03ACF6', '#00AE9D'];
	    } else if (examModel.valueArray.length == 3) {
	        _UtilsToolbar.toolbarStatus.lineColor = ['#03ACF6', '#00AE9D', '#0372D2'];
	    }
	    _UtilsToolbar.toolbarStatus.startPoint = (0, _ShapePoint2['default'])(width, _constants.baseColor, parent.data.smallUnitVisible ? pointText : undefined, new THREE.Vector2(0, -30));
	    _UtilsToolbar.toolbarStatus.startPoint.position.x = startPoint * unitLength;
	    _UtilsToolbar.toolbarStatus.startPoint.name = 'outset';
	    parent.add(_UtilsToolbar.toolbarStatus.startPoint);
	}
	function initCalculateNumber() {
	    var examModel = (0, _moduleControl.getAxisExamModel)();
	    var parent = _threeManger.scene.getObjectByName("group");
	    var value = examModel.valueArray;
	    var symbol = examModel.symbolArray;
	    console.log(value, 'value', symbol);
	    var width = undefined;
	    if (examModel.valueArray.length == 2) {
	        _UtilsToolbar.toolbarStatus.lineColor = ['#03ACF6', '#00AE9D'];
	    } else if (examModel.valueArray.length == 3) {
	        _UtilsToolbar.toolbarStatus.lineColor = ['#03ACF6', '#00AE9D', '#0372D2'];
	    }
	    var temp = undefined;
	    for (var i = 0; i < symbol.length; i++) {
	        if (i == 0) {
	            width = parent.data.lineWidth * 1.3;
	            _UtilsToolbar.toolbarStatus.startPoint = (0, _ShapePoint2['default'])(width, 'customize', parent.data.smallUnitVisible ? pointText : undefined, new THREE.Vector2(0, -30));
	            _UtilsToolbar.toolbarStatus.startPoint.position.x = value[i] * unitLength;
	        } else {
	            width = parent.data.lineWidth;
	            _UtilsToolbar.toolbarStatus.startPoint = _UtilsToolbar.toolbarStatus.endPoint;
	        }
	        _UtilsToolbar.toolbarStatus.endPoint = (0, _ShapePoint2['default'])(parent.data.lineWidth, _constants.baseColor, parent.data.smallUnitVisible ? pointText : undefined, new THREE.Vector2(0, -30));
	        if (symbol[i] > 0) {
	            if (temp === undefined) {
	                _UtilsToolbar.toolbarStatus.endPoint.position.x = (value[i] + value[i + 1]) * unitLength;
	                temp = value[i] + value[i + 1];
	            } else {
	                console.log('this is temp', temp);
	                _UtilsToolbar.toolbarStatus.endPoint.position.x = (temp + value[i + 1]) * unitLength;
	            }
	        } else if (symbol[i] < 0) {
	            if (temp === undefined) {
	                _UtilsToolbar.toolbarStatus.endPoint.position.x = (value[i] - value[i + 1]) * unitLength;
	                temp = value[i] - value[i + 1];
	            } else {
	                console.log('this is temp', temp);
	                _UtilsToolbar.toolbarStatus.endPoint.position.x = (temp - value[i + 1]) * unitLength;
	            }
	        }
	        var curve = new _UtilsAddCurve2['default'](_UtilsToolbar.toolbarStatus, parent.position, parent.data.unitLength / parent.data.unitMultiple);
	        curve.add(_UtilsToolbar.toolbarStatus.startPoint);
	        curve.add(_UtilsToolbar.toolbarStatus.endPoint);
	        parent.add(curve);
	    }
	}

/***/ },
/* 35 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

	var _UtilsUpdateVertices = __webpack_require__(21);

	var _UtilsUpdateVertices2 = _interopRequireDefault(_UtilsUpdateVertices);

	var _threeManger = __webpack_require__(10);

	var _UtilsRotateAngle = __webpack_require__(22);

	/**
	 * pointA数轴左端点
	 * pointB数轴右端点
	 * lineWidth数轴线宽
	 * arrowLength箭号长度
	 * controllerDis控制器距两端的距离
	 * unitHeight刻度高度
	 * unitLength数轴单个刻度的长度
	 */

	var NumberLine = (function () {
	    function NumberLine() {
	        var pointA = arguments.length <= 0 || arguments[0] === undefined ? new THREE.Vector3(-280, 0, 0) : arguments[0];
	        var pointB = arguments.length <= 1 || arguments[1] === undefined ? new THREE.Vector3(280, 0, 0) : arguments[1];
	        var lineWidth = arguments.length <= 2 || arguments[2] === undefined ? 6 : arguments[2];
	        var arrowLength = arguments.length <= 3 || arguments[3] === undefined ? 30 : arguments[3];
	        var controllerDis = arguments.length <= 4 || arguments[4] === undefined ? 20 : arguments[4];
	        var unitHeight = arguments.length <= 5 || arguments[5] === undefined ? 15 : arguments[5];
	        var unitLength = arguments.length <= 6 || arguments[6] === undefined ? 80 : arguments[6];
	        var selectA = arguments.length <= 7 || arguments[7] === undefined ? new THREE.Vector3(70, -20, 0) : arguments[7];
	        var selectB = arguments.length <= 8 || arguments[8] === undefined ? new THREE.Vector3(90, -20, 0) : arguments[8];

	        _classCallCheck(this, NumberLine);

	        this.pointA = pointA;
	        this.pointB = pointB;
	        this.lineWidth = lineWidth;
	        this.arrowLength = arrowLength;
	        this.controllerDis = controllerDis;
	        this.unitHeight = unitHeight;
	        this.unitLength = unitLength;
	        this.selectA = selectA;
	        this.selectB = selectB;
	    }

	    // 线材质

	    _createClass(NumberLine, [{
	        key: 'getMaterial',
	        value: function getMaterial() {
	            return new THREE.MeshBasicMaterial({
	                color: 0x333333,
	                transparent: false,
	                opacity: 1
	            });
	        }

	        // 容差材质
	    }, {
	        key: 'getGroupMaterial',
	        value: function getGroupMaterial() {
	            return new THREE.MeshBasicMaterial({
	                color: 0x333333,
	                transparent: true,
	                opacity: 0
	            });
	        }

	        // 控制器材质
	    }, {
	        key: 'getControllerMaterial',
	        value: function getControllerMaterial() {
	            return new THREE.MeshBasicMaterial({
	                color: 0x00ff00,
	                transparent: false,
	                opacity: 1
	            });
	        }

	        // 控制器中间材质
	    }, {
	        key: 'getControllerCenterMaterial',
	        value: function getControllerCenterMaterial() {
	            return new THREE.MeshBasicMaterial({
	                color: 0xffffff,
	                transparent: false,
	                opacity: 1
	            });
	        }

	        // 控制器材质
	    }, {
	        key: 'getMarkPointMaterial',
	        value: function getMarkPointMaterial() {
	            return new THREE.MeshBasicMaterial({
	                color: '#FF0000',
	                transparent: false,
	                opacity: 1
	            });
	        }

	        // 绘制线
	    }, {
	        key: 'createLine',
	        value: function createLine() {
	            var shape = new THREE.Shape();
	            shape.moveTo(this.pointA.x, -this.lineWidth / 2);
	            shape.lineTo(this.pointB.x, -this.lineWidth / 2);
	            shape.lineTo(this.pointB.x, this.lineWidth / 2);
	            shape.lineTo(this.pointA.x, this.lineWidth / 2);
	            shape.lineTo(this.pointA.x, -this.lineWidth / 2);
	            var geometry = new THREE.ShapeGeometry(shape);
	            var line = new THREE.Mesh(geometry, this.getMaterial());
	            line.name = 'line';
	            return line;
	        }

	        // 绘制圆心
	    }, {
	        key: 'createCenter',
	        value: function createCenter() {
	            var circleGeometry = new THREE.CircleGeometry(this.lineWidth * 1.2, 32);
	            var circle = new THREE.Mesh(circleGeometry, this.getMaterial());
	            circle.name = 'center';
	            return circle;
	        }

	        // 绘制刻度选择框
	    }, {
	        key: 'createUnitSelect',
	        value: function createUnitSelect() {
	            var us = new THREE.Shape();
	            us.moveTo(this.selectA.x, this.selectA.y - this.lineWidth * 1.6);
	            us.lineTo(this.selectB.x, this.selectB.y - this.lineWidth * 1.6);
	            us.lineTo(this.selectB.x, this.selectB.y + this.lineWidth * 1.6);
	            us.lineTo(this.selectA.x, this.selectB.y + this.lineWidth * 1.6);
	            us.lineTo(this.selectA.x, this.selectA.y - this.lineWidth * 1.6);
	            var points = us.createPointsGeometry();
	            var side = new THREE.Line(points, new THREE.LineBasicMaterial({
	                color: 0x333333,
	                opacity: 1
	            }));
	            side.name = 'unitSelect';
	            side.visible = false;
	            side.position.copy(new THREE.Vector3(this.unitLength, -23, 0));
	            return side;
	        }

	        // 绘制箭头
	    }, {
	        key: 'createArrow',
	        value: function createArrow() {
	            var arrow = new THREE.Object3D();
	            var arrowCenterGeometry = new THREE.CircleGeometry(this.lineWidth / 2, 32);
	            var arrowCenter = new THREE.Mesh(arrowCenterGeometry, this.getMaterial());
	            var center = new THREE.Vector3(1, 0, 0); //数轴题改变相机位置,需要改变角度显示箭头
	            // 转动角度
	            var arrorPoint = (0, _UtilsRotateAngle.getLocationPoint)(center, this.pointA, 20);
	            // 画图形  
	            var arrowPointA = (0, _UtilsRotateAngle.rotatePoint)(arrorPoint, center, 45);
	            var arrowPointB = (0, _UtilsRotateAngle.rotatePoint)(arrorPoint, center, -45);
	            // 绘制箭头上边
	            var sideA = new THREE.Shape();
	            sideA.moveTo(0, -this.lineWidth);
	            sideA.lineTo(arrowPointA.x, -this.lineWidth);
	            sideA.lineTo(arrowPointA.x, this.lineWidth);
	            sideA.lineTo(0, this.lineWidth);
	            sideA.lineTo(0, -this.lineWidth);
	            var sideAGeometry = new THREE.ShapeGeometry(sideA);
	            var arrowUp = new THREE.Mesh(sideAGeometry, this.getMaterial());
	            (0, _UtilsUpdateVertices2['default'])(arrowUp, center, arrowPointA, this.lineWidth);
	            // 绘制箭头下边
	            var sideB = new THREE.Shape();
	            sideB.moveTo(0, -this.lineWidth);
	            sideB.lineTo(arrowPointB.x, -this.lineWidth);
	            sideB.lineTo(arrowPointB.x, this.lineWidth);
	            sideB.lineTo(0, this.lineWidth);
	            sideB.lineTo(0, -this.lineWidth);
	            var sideBGeometry = new THREE.ShapeGeometry(sideB);
	            var arrowDown = new THREE.Mesh(sideBGeometry, this.getMaterial());
	            (0, _UtilsUpdateVertices2['default'])(arrowDown, center, arrowPointB, this.lineWidth);
	            arrow.add(arrowCenter);
	            arrow.add(arrowUp);
	            arrow.add(arrowDown);
	            arrow.position.copy(this.pointB);
	            arrow.name = 'arrow';
	            return arrow;
	        }

	        // 绘制左右控制器
	    }, {
	        key: 'createController',
	        value: function createController() {
	            var circleLeftGeometry = new THREE.CircleGeometry(this.lineWidth * 1.5, 64);
	            var controllerLeft = new THREE.Mesh(circleLeftGeometry, this.getControllerMaterial());
	            controllerLeft.position.copy(new THREE.Vector3(this.pointA.x - this.controllerDis, this.pointA.y, 0.1));
	            controllerLeft.name = 'controllerLeft';

	            var circleLeftCenterGeometry = new THREE.CircleGeometry(this.lineWidth * 1, 64);
	            var controllerLeftCenter = new THREE.Mesh(circleLeftCenterGeometry, this.getControllerCenterMaterial());
	            controllerLeftCenter.name = 'controllerLeftCenter';
	            controllerLeft.add(controllerLeftCenter);

	            var circleRigthGeometry = new THREE.CircleGeometry(this.lineWidth * 1.5, 64);
	            var controllerRight = new THREE.Mesh(circleRigthGeometry, this.getControllerMaterial());
	            controllerRight.position.copy(new THREE.Vector3(this.pointB.x + this.controllerDis, this.pointB.y, 0.1));
	            controllerRight.name = 'controllerRight';

	            var circleRightCenterGeometry = new THREE.CircleGeometry(this.lineWidth * 1, 64);
	            var controllerRightCenter = new THREE.Mesh(circleRightCenterGeometry, this.getControllerCenterMaterial());
	            controllerRightCenter.name = 'controllerRightCenter';
	            controllerRight.add(controllerRightCenter);
	            return {
	                controllerLeft: controllerLeft,
	                controllerRight: controllerRight
	            };
	        }

	        // 绘制刻度控制器
	    }, {
	        key: 'createUnitController',
	        value: function createUnitController() {
	            var unitGeometry = new THREE.CircleGeometry(this.lineWidth * 1.5, 64);
	            var unitController = new THREE.Mesh(unitGeometry, this.getControllerMaterial());
	            unitController.position.copy(new THREE.Vector3(this.unitLength, 0, 0.1));
	            unitController.name = 'unitController';

	            var unitCenterGeometry = new THREE.CircleGeometry(this.lineWidth * 1, 64);
	            var unitControllerCenter = new THREE.Mesh(unitCenterGeometry, this.getControllerCenterMaterial());
	            unitControllerCenter.name = 'unitControllerCenter';
	            unitController.add(unitControllerCenter);
	            return unitController;
	        }

	        // 绘制group
	    }, {
	        key: 'createLineGroup',
	        value: function createLineGroup() {
	            var groupShape = new THREE.Shape();
	            groupShape.moveTo(this.pointA.x, -this.lineWidth * 2.5);
	            groupShape.lineTo(this.pointB.x, -this.lineWidth * 2.5);
	            groupShape.lineTo(this.pointB.x, this.lineWidth * 2.5);
	            groupShape.lineTo(this.pointA.x, this.lineWidth * 2.5);
	            groupShape.lineTo(this.pointA.x, -this.lineWidth * 2.5);
	            var groupGeometry = new THREE.ShapeGeometry(groupShape);
	            var group = new THREE.Mesh(groupGeometry, this.getGroupMaterial());
	            group.name = 'group';
	            group.data = {};
	            return group;
	        }

	        // 开始创建数轴
	    }, {
	        key: 'create',
	        value: function create() {
	            var group = this.createLineGroup();
	            var line = this.createLine();
	            var circle = this.createCenter();
	            var arrow = this.createArrow();
	            //let controller = this.createController();//数轴题注释
	            //let unitController = this.createUnitController();
	            var unitSelect = this.createUnitSelect();
	            group.add(line);
	            group.add(circle);
	            group.add(arrow);
	            //group.add(controller.controllerLeft);
	            //group.add(controller.controllerRight);
	            //group.add(unitController);
	            group.add(unitSelect);
	            return group;
	        }
	    }]);

	    return NumberLine;
	})();

	exports['default'] = NumberLine;
	module.exports = exports['default'];

/***/ },
/* 36 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by xcc on 2015/12/22.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _constants = __webpack_require__(4);

	var _MarkPoint = __webpack_require__(30);

	var _MarkPoint2 = _interopRequireDefault(_MarkPoint);

	var _UtilsButtonUtls = __webpack_require__(37);

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _threeManger = __webpack_require__(10);

	var operationData = {
	    isMarkOpen: false,
	    isDelete: false,
	    isDeleteAll: false
	};
	var group;
	var removea = [];

	exports['default'] = function () {
	    "use strict";
	    $(_presenter2['default'].view).find('.mark').on("click", function () {
	        //    $(this).css({"background-color":'#FF0000'});
	        //hideAllBtn(this);
	        //operationData.isMarkOpen = !operationData.isMarkOpen;
	        //showOrHideMarkPointBtn(operationData.isMarkOpen);
	        //
	        //operationData.isDeleteAll = false;
	        //operationData.isDelete = false;
	        //showOrHideDeleteAllBtn(operationData.isDeleteAll);
	        //showOrHideDeleteBtn(operationData.isDelete);
	    });
	    $(_presenter2['default'].view).find('.clear_all').on("click", function () {
	        //operationData.isDeleteAll = !operationData.isDeleteAll;
	        //showOrHideDeleteAllBtn(operationData.isDeleteAll);

	        //operationData.isMarkOpen = false;
	        //operationData.isDelete = false;
	        //showOrHideMarkPointBtn(operationData.isMarkOpen);
	        //showOrHideDeleteBtn(operationData.isDelete);
	        // group = scene.getObjectByName('group');
	        ////let groupMark = group.getObjectByName('markPoint');
	        //removea = [];
	        //for (let i = 0;i < group.children.length; i++ ) {
	        //    //    group = scene.getObjectByName('group');
	        //    if (group.children[i].name == 'markPoint') {
	        //        removea.push(group.children[i]);
	        //    }
	        //}
	        //for(var i =0;i<removea.length;i++){
	        //    removea[i].parent.remove( removea[i]);
	        //}
	    });
	    $(_presenter2['default'].view).find('.clean').on("click", function () {
	        //operationData.isDelete = !operationData.isDelete;
	        //showOrHideDeleteBtn(operationData.isDelete);
	        //
	        //operationData.isMarkOpen = false;
	        //operationData.isDeleteAll = false;
	        //showOrHideMarkPointBtn(operationData.isMarkOpen);
	        //showOrHideDeleteAllBtn(operationData.isDeleteAll);
	    });
	};

	exports.operationData = operationData;

/***/ },
/* 37 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/12/24.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenterJs = __webpack_require__(1);

	var _presenterJs2 = _interopRequireDefault(_presenterJs);

	var _ShapeOperationMarkPoint = __webpack_require__(36);

	function showOrHideMarkPointBtn(isOpen) {
	    if (isOpen) {
	        $(_presenterJs2['default'].view).find('.mark').addClass('on');
	    } else {
	        $(_presenterJs2['default'].view).find('.mark').removeClass('on');
	    }
	}
	function showOrHideDeleteBtn(isOpen) {
	    if (isOpen) {
	        console.log('showOrHideDeleteBtn');
	        $(_presenterJs2['default'].view).find('.clean').addClass('on');
	    } else {
	        $(_presenterJs2['default'].view).find('.clean').removeClass('on');
	    }
	}

	function showOrHideDeleteAllBtn(isOpen) {
	    if (isOpen) {
	        $(_presenterJs2['default'].view).find('.clear_all').addClass('on');
	    } else {
	        $(_presenterJs2['default'].view).find('.clear_all').removeClass('on');
	    }
	}

	exports.showOrHideDeleteAllBtn = showOrHideDeleteAllBtn;
	exports.showOrHideDeleteBtn = showOrHideDeleteBtn;
	exports.showOrHideMarkPointBtn = showOrHideMarkPointBtn;

/***/ },
/* 38 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _updateUnit = __webpack_require__(31);

	var _updateUnit2 = _interopRequireDefault(_updateUnit);

	exports['default'] = function (shape, input) {
	  var showText = shape.getObjectByName('showText');
	  var unitMultiple = input.value;
	  if (unitMultiple == '') {
	    showText._dynamicTexture.clear().drawText(input.value.toString(), undefined, 16, '#000000');
	  } else {
	    unitMultiple = new Number(unitMultiple);
	    if (isNaN(unitMultiple)) {
	      showText._dynamicTexture.clear().drawText(shape.data.unitMultiple.toString(), undefined, 16, '#000000');
	      input.value = shape.data.unitMultiple;
	    } else {
	      if (unitMultiple.toString().indexOf('.') != -1) {
	        var i = unitMultiple.toString().split('.')[0];
	        var f = unitMultiple.toString().split('.')[1];
	        f = f.split('')[0];
	        if (f == 0) {
	          unitMultiple = i;
	        } else {
	          unitMultiple = i + '.' + f;
	        }
	        input.value = unitMultiple;
	      }
	      if (unitMultiple != 0 && (unitMultiple < 0.1 || unitMultiple > 1000)) {
	        unitMultiple = shape.data.unitMultiple;
	        input.value = unitMultiple;
	      }
	      showText._dynamicTexture.clear().drawText(unitMultiple.toString(), undefined, 16, '#000000');
	      shape.data.unitMultiple = unitMultiple;
	    }
	  }
	};

	module.exports = exports['default'];

/***/ },
/* 39 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by zhoujunzhou on 2016/1/6.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

	var _UtilsUpdateVertices = __webpack_require__(21);

	var _UtilsUpdateVertices2 = _interopRequireDefault(_UtilsUpdateVertices);

	var _UtilsRotateAngle = __webpack_require__(22);

	var _threeManger = __webpack_require__(10);

	var ConnectLine = (function () {
	    function ConnectLine(clsName) {
	        _classCallCheck(this, ConnectLine);

	        //this.pointA = pointA;
	        //this.pointB = pointB;
	        this.lineWidth = 6;
	        this.objectName = clsName + '_cLine';
	    }

	    // 线材质

	    _createClass(ConnectLine, [{
	        key: 'getMaterial',
	        value: function getMaterial() {
	            return new THREE.MeshBasicMaterial({
	                color: 0xDD4E42,
	                transparent: false,
	                opacity: 1
	            });
	        }

	        //updateLine(pointA, pointB) {
	        //    this.pointA = pointA;
	        //    this.pointB = pointB;
	        //    create();
	        //}

	    }, {
	        key: 'createLineGroup',
	        value: function createLineGroup() {

	            var lineWidth = 6;
	            var lineShape = new THREE.Shape();
	            lineShape.moveTo(0, 0);
	            lineShape.lineTo(10, -lineWidth);
	            lineShape.lineTo(10, lineWidth);
	            lineShape.lineTo(0, lineWidth);
	            lineShape.lineTo(0, 0);
	            var lineShapeGeometry = new THREE.ShapeGeometry(lineShape);
	            var cLineShape = new THREE.Mesh(lineShapeGeometry, this.getMaterial());

	            (0, _UtilsUpdateVertices2['default'])(cLineShape, this.pointA, this.pointB, lineWidth);

	            return cLineShape;
	        }

	        // 绘制箭头
	    }, {
	        key: 'createArrow',
	        value: function createArrow() {
	            var arrow = new THREE.Object3D();
	            //let arrowCenterGeometry = new THREE.CircleGeometry(this.lineWidth / 2, 32);
	            //let arrowCenter = new THREE.Mesh(arrowCenterGeometry, this.getMaterial());
	            ////let center = new THREE.Vector3(0, 0, 0);
	            var center = this.pointB;

	            // 转动角度
	            var arrorPoint = (0, _UtilsRotateAngle.getLocationPoint)(center, this.pointA, 20);
	            // 画图形
	            var arrowPointA = (0, _UtilsRotateAngle.rotatePoint)(arrorPoint, center, 45);
	            var arrowPointB = (0, _UtilsRotateAngle.rotatePoint)(arrorPoint, center, -45);

	            // 绘制箭头上边
	            var sideA = new THREE.Shape();
	            sideA.moveTo(0, -this.lineWidth);
	            sideA.lineTo(arrowPointA.x, -this.lineWidth);
	            sideA.lineTo(arrowPointA.x, this.lineWidth);
	            sideA.lineTo(0, this.lineWidth);
	            sideA.lineTo(0, -this.lineWidth);
	            var sideAGeometry = new THREE.ShapeGeometry(sideA);
	            var arrowUp = new THREE.Mesh(sideAGeometry, this.getMaterial());
	            (0, _UtilsUpdateVertices2['default'])(arrowUp, center, arrowPointA, this.lineWidth);
	            // 绘制箭头下边
	            var sideB = new THREE.Shape();
	            sideB.moveTo(0, -this.lineWidth);
	            sideB.lineTo(arrowPointB.x, -this.lineWidth);
	            sideB.lineTo(arrowPointB.x, this.lineWidth);
	            sideB.lineTo(0, this.lineWidth);
	            sideB.lineTo(0, -this.lineWidth);
	            var sideBGeometry = new THREE.ShapeGeometry(sideB);
	            var arrowDown = new THREE.Mesh(sideBGeometry, this.getMaterial());
	            (0, _UtilsUpdateVertices2['default'])(arrowDown, center, arrowPointB, this.lineWidth);

	            //arrow.add(arrowCenter);
	            arrow.add(arrowUp);
	            arrow.add(arrowDown);
	            //arrow.position.copy(this.pointB);
	            arrow.name = 'arrow';

	            return arrow;
	        }
	    }, {
	        key: 'getShape',
	        value: function getShape(waistLength, bottomLength) {
	            var shape = new THREE.Shape();

	            //底边上的高
	            var height = Math.sqrt(Math.pow(waistLength, 2) - Math.pow(bottomLength / 2, 2));
	            //重心
	            var centerX = bottomLength / 2;
	            var centerY = height / 3;

	            shape.moveTo(centerX, -centerY);
	            shape.lineTo(0, height - centerY);
	            shape.lineTo(-centerX, -centerY);
	            shape.lineTo(centerX, -centerY);

	            return shape;
	        }
	    }, {
	        key: 'createTriangle',
	        value: function createTriangle() {
	            var lineShape = new THREE.Shape();
	            lineShape.moveTo(0, -20);
	            lineShape.lineTo(-10, 10);
	            lineShape.lineTo(10, 10);
	            lineShape.lineTo(0, -20);
	            var lineShapeGeometry = new THREE.ShapeGeometry(lineShape);
	            var cLineShape = new THREE.Mesh(lineShapeGeometry, this.getMaterial());

	            var angle = (0, _UtilsRotateAngle.getVectorAngle)(this.pointA, this.pointB);
	            if (!angle.clockWise) {
	                cLineShape.rotation.z = angle.angle + Math.PI / 4;
	            } else {
	                cLineShape.rotation.z = angle.angle - Math.PI / 4;
	            }

	            cLineShape.position.copy(this.pointB);

	            return cLineShape;
	        }

	        // 开始创建数轴
	    }, {
	        key: 'create',
	        value: function create(pointA, pointB) {
	            this.pointA = pointA;
	            this.pointB = pointB;

	            if (this.group) {
	                //this.group.dispose();
	                _threeManger.scene.remove(this.group);
	            }

	            this.group = this.createLineGroup();
	            var arrow = this.createArrow();
	            //let arrow = this.createTriangle();

	            var arrowCenterGeometry = new THREE.CircleGeometry(this.lineWidth / 2, 32);
	            var arrowCenter = new THREE.Mesh(arrowCenterGeometry, this.getMaterial());
	            arrowCenter.position.copy(this.pointB);

	            this.group.add(arrow);
	            this.group.add(arrowCenter);
	            this.group.name = this.objectName;
	            _threeManger.scene.add(this.group);
	        }
	    }, {
	        key: 'remove',
	        value: function remove() {
	            if (this.group) {
	                this.group.dispose();
	                _threeManger.scene.remove(this.group);
	            }
	        }
	    }]);

	    return ConnectLine;
	})();

	exports['default'] = ConnectLine;
	module.exports = exports['default'];

/***/ },
/* 40 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by zhoujunzhou on 2016/1/5.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

	var _get = function get(_x, _x2, _x3) { var _again = true; _function: while (_again) { var object = _x, property = _x2, receiver = _x3; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x = parent; _x2 = property; _x3 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

	function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	var _BaseExamModel2 = __webpack_require__(41);

	var _BaseExamModel3 = _interopRequireDefault(_BaseExamModel2);

	var _DomViewCalcElementBuilder = __webpack_require__(42);

	var _NumberBuilder = __webpack_require__(43);

	var _constants = __webpack_require__(4);

	var _ConnectPointControl = __webpack_require__(44);

	var _ConnectPointControl2 = _interopRequireDefault(_ConnectPointControl);

	var _moduleControl = __webpack_require__(6);

	/**
	 * 坐标点类型：在坐标点标出已知数字
	 */

	var CoordNoteModel = (function (_BaseExamModel) {
	    _inherits(CoordNoteModel, _BaseExamModel);

	    function CoordNoteModel() {
	        _classCallCheck(this, CoordNoteModel);

	        _get(Object.getPrototypeOf(CoordNoteModel.prototype), 'constructor', this).call(this, _constants.EXAM_TYPE.Coord_Point_Note);
	        this.btnClassArray = [];
	        this.userResArray = [];
	    }

	    _createClass(CoordNoteModel, [{
	        key: 'create',
	        value: function create(value) {
	            if (!value) {
	                this.valueArray = (0, _NumberBuilder.generRanArray)(this);
	            } else {
	                this.valueArray = value;
	            }

	            (0, _DomViewCalcElementBuilder.buildTextView)(this);
	            if ((0, _moduleControl.isApp)()) {
	                this.createConnectPointControl();
	            }
	            return this;
	        }
	    }, {
	        key: 'createByModel',
	        value: function createByModel(examModel) {}
	    }, {
	        key: 'createConnectPointControl',
	        value: function createConnectPointControl() {
	            this.connectContorl = new _ConnectPointControl2['default'](); //conmark
	            this.connectContorl.bindButtonClick(this);
	        }
	    }, {
	        key: 'updateDomValue',
	        value: function updateDomValue() {
	            (0, _DomViewCalcElementBuilder.updateButtonValue)(this);
	        }
	    }, {
	        key: 'updateValueArray',
	        value: function updateValueArray() {
	            this.valueArray = (0, _NumberBuilder.generRanArray)(this);
	            this.updateDomValue();
	        }
	    }, {
	        key: 'setResValue',
	        value: function setResValue(i, resValue) {
	            console.log('will set index', i, 'value is', resValue);
	            this.userResArray[i] = resValue;
	            console.log('set down', this.userResArray);
	        }
	    }]);

	    return CoordNoteModel;
	})(_BaseExamModel3['default']);

	exports['default'] = CoordNoteModel;
	module.exports = exports['default'];

/***/ },
/* 41 */
/***/ function(module, exports) {

	/**
	 * Created by zhoujunzhou on 2016/1/5.
	 */

	/**
	 * 基本题型数据模型
	 */
	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});

	var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var BaseExamModel = (function () {
	    function BaseExamModel(type) {
	        _classCallCheck(this, BaseExamModel);

	        this.examType = type; //题型
	        this.isInteger = false; //是否是整数
	        this.valueArray = [];
	        this.userResArray = [];
	    }

	    _createClass(BaseExamModel, [{
	        key: "create",
	        value: function create(value) {}
	    }, {
	        key: "updateDomValue",
	        value: function updateDomValue() {}
	    }, {
	        key: "updateValueArray",
	        value: function updateValueArray() {}
	    }, {
	        key: "setInteger",
	        value: function setInteger(isInt) {
	            this.isInteger = isInt;
	            this.updateValueArray();
	        }
	    }, {
	        key: "setIntegerNotUpdate",
	        value: function setIntegerNotUpdate(isInt) {
	            this.isInteger = isInt;
	        }
	    }, {
	        key: "getCorrectRes",
	        value: function getCorrectRes() {
	            return this.valueArray.toString();
	        }
	    }, {
	        key: "getUserRes",
	        value: function getUserRes() {
	            return this.userResArray.toString();
	        }
	    }]);

	    return BaseExamModel;
	})();

	exports["default"] = BaseExamModel;
	module.exports = exports["default"];

/***/ },
/* 42 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by zhoujunzhou on 2016/1/5.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.updateCalcTextView = updateCalcTextView;
	exports.updateCaclResultText = updateCaclResultText;
	exports.buildCalcTextView = buildCalcTextView;
	exports.buildInputView = buildInputView;
	exports.buildTextView = buildTextView;
	exports.buildCalcInputView = buildCalcInputView;
	exports.updateInputValue = updateInputValue;
	exports.updateButtonValue = updateButtonValue;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _constants = __webpack_require__(4);

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	__webpack_require__(4);

	var _DomViewManager = __webpack_require__(7);

	var _moduleControl = __webpack_require__(6);

	var _ShapeAxisView = __webpack_require__(34);

	var PRE_INPUT_ELEMENT = 'axis_input_element_';
	exports.PRE_INPUT_ELEMENT = PRE_INPUT_ELEMENT;
	var PRE_SYMBOL_ELEMENT = 'axis_symbol_element_';
	exports.PRE_SYMBOL_ELEMENT = PRE_SYMBOL_ELEMENT;
	var INPUT_NUMBER_CLS = 'number_list_input';
	exports.INPUT_NUMBER_CLS = INPUT_NUMBER_CLS;
	var PRE_EXAM_TYPE_ELEMENT = 'pre_exam_type_element_';

	exports.PRE_EXAM_TYPE_ELEMENT = PRE_EXAM_TYPE_ELEMENT;
	var INPUT_MARGIN_HEIGHT = 100;

	exports.INPUT_MARGIN_HEIGHT = INPUT_MARGIN_HEIGHT;
	function appendInput(clsName) {

	    var outDom = $('<div style="position:absolute;" class="number_list_box ' + clsName + '" ></div>');

	    var inputEle = null;
	    if ((0, _moduleControl.isApp)()) {
	        if (_presenter2['default'].isTeacherMobile || _presenter2['default'].isStudentMobile) {
	            //默认type为number，pad端弹出软键盘
	            inputEle = $('<input class="number_list_input" type="number"/>');
	        } else {
	            inputEle = $('<input class="number_list_input" type="text"/>');
	        }

	        outDom.append(inputEle);
	    }

	    (0, _DomViewManager.getNumberBox)().append(outDom);

	    return inputEle;
	}

	function appendCalcInput(clsName) {

	    var outDom = $('<div  class="number_list_box ' + clsName + '" ></div>');
	    var inputEle = null;
	    if ((0, _moduleControl.isApp)()) {
	        if (_presenter2['default'].isTeacherMobile || _presenter2['default'].isStudentMobile) {
	            //默认type为number，pad端弹出软键盘
	            inputEle = $('<input class="number_list_input" type="number"/>');
	        } else {
	            inputEle = $('<input class="number_list_input" type="text"/>');
	        }
	        outDom.append(inputEle);
	    }

	    (0, _DomViewManager.getNumberBox)().append(outDom);
	    return inputEle;
	}

	function appendText(clsName) {
	    var btnText = '<div style="margin:0 15px" class=" number_list_box ' + clsName + '"></div>';
	    return (0, _DomViewManager.getNumberBox)().append(btnText);
	}

	function appendPlusText(clsName) {
	    var btnText = '<div class="symbol_box icon_plus ' + clsName + '"></div>';
	    return (0, _DomViewManager.getNumberBox)().append(btnText);
	}

	function appendMinusText(clsName) {
	    var btnText = '<div class="symbol_box icon_minus ' + clsName + '"></div>';
	    return (0, _DomViewManager.getNumberBox)().append(btnText);
	}

	function appendEqualText(clsName) {
	    var btnText = '<div class="symbol_box icon_equals ' + clsName + '"></div>';
	    return (0, _DomViewManager.getNumberBox)().append(btnText);
	}

	function clearInputDiv() {
	    //let marginTop = REAL_ESTATE.height / 2 - INPUT_MARGIN_HEIGHT;
	    (0, _DomViewManager.getNumberBox)().css({
	        //top: marginTop
	    });
	    (0, _DomViewManager.clearBuildDiv)();
	}

	function updateCalcTextView(examModel) {
	    if (!examModel || !examModel.valueArray || !examModel.symbolArray) {
	        return;
	    }
	    var calcText = '';
	    calcText += examModel.valueArray[0];

	    var len = examModel.valueArray.length;
	    var symbolLen = examModel.symbolArray.length;
	    for (var i = 1; i < len && i - 1 < symbolLen; i++) {
	        if (examModel.symbolArray[i - 1] > 0) {
	            calcText += ' + ';
	        } else {
	            calcText += ' - ';
	        }
	        calcText += examModel.valueArray[i] + '';
	    }
	    calcText += ' = ? ';
	    $(_presenter2['default'].view).find('.' + PRE_EXAM_TYPE_ELEMENT + examModel.examType).html(calcText);
	}

	function updateCaclResultText(examModel, resultValue) {
	    var htmlText = $(_presenter2['default'].view).find('.' + PRE_EXAM_TYPE_ELEMENT + examModel.examType).html();
	    var sIndex = htmlText.indexOf("=");
	    htmlText = htmlText.substring(0, sIndex + 1);
	    htmlText += ' ' + resultValue;
	    $(_presenter2['default'].view).find('.' + PRE_EXAM_TYPE_ELEMENT + examModel.examType).html(htmlText);
	}

	function buildCalcTextView(examModel) {
	    clearInputDiv();
	    appendText(PRE_EXAM_TYPE_ELEMENT + examModel.examType);
	}

	function buildInputView(examModel) {
	    if (!examModel) {
	        return;
	    }

	    clearInputDiv();
	    if (examModel.valueArray) {
	        var clsName = undefined;

	        var _loop = function (i, len) {
	            clsName = PRE_INPUT_ELEMENT + i;

	            var inputEle = appendInput(clsName);
	            if (inputEle) {
	                inputEle.keyup(function () {
	                    examModel.userResArray[i] = $(this).val();
	                    console.log('inputEle value:', $(this).val());
	                });

	                inputEle.focusin(function (event) {
	                    //console.log("event:", event);

	                    $(_presenter2['default'].view).find(".input-number-value").find('.on').removeClass('on');
	                    var target = event.target;
	                    $(target).parent().addClass('on');
	                    //console.log('inputEle clsName:', clsName);

	                    //console.log("target:", target);
	                });
	            }
	        };

	        for (var i = 0, len = examModel.valueArray.length; i < len; i++) {
	            _loop(i, len);
	        }
	    }
	    updateInputValue(examModel);
	}

	function buildTextView(examModel) {
	    if (!examModel) {
	        return;
	    }

	    clearInputDiv();

	    if (examModel.valueArray) {
	        var clsName = undefined;
	        for (var i = 0, len = examModel.valueArray.length; i < len; i++) {
	            clsName = PRE_INPUT_ELEMENT + i;
	            examModel.btnClassArray[i] = clsName;
	            appendText(clsName);
	        }
	    }
	    updateButtonValue(examModel);
	}

	function buildCalcInputView(examModel) {

	    if (!examModel || !examModel.valueArray || !examModel.symbolArray) {
	        return;
	    }

	    clearInputDiv();
	    var inputClsName = PRE_SYMBOL_ELEMENT + 0;

	    //calcText += examModel.valueArray[0];
	    var inputEle = null;
	    inputEle = appendCalcInput(inputClsName);
	    bindInputEle(inputEle, 0, examModel);

	    var len = examModel.valueArray.length;
	    var symbolLen = examModel.symbolArray.length;
	    for (var i = 1; i < len && i - 1 < symbolLen; i++) {
	        if (examModel.symbolArray[i - 1] > 0) {
	            //calcText += ' + ';
	            appendPlusText(PRE_SYMBOL_ELEMENT + (i - 1));
	        } else {
	            appendMinusText(PRE_SYMBOL_ELEMENT + (i - 1));
	        }
	        inputEle = appendCalcInput(PRE_SYMBOL_ELEMENT + i);
	        bindInputEle(inputEle, i, examModel);
	    }
	    appendEqualText(PRE_SYMBOL_ELEMENT + examModel.symbolArray.length);
	    inputEle = appendCalcInput(PRE_SYMBOL_ELEMENT + examModel.valueArray.length);
	    bindInputEle(inputEle, examModel.valueArray.length, examModel);
	}

	function bindInputEle(inputEle, index, examModel) {
	    if (inputEle) {
	        inputEle.keyup(function () {
	            examModel.userResArray[index] = $(this).val();
	            console.log('bindInputEle inputEle value:', $(this).val());
	            //inputEle.focus();
	        });

	        inputEle.focusin(function (event) {
	            //console.log("event:", event);

	            $(_presenter2['default'].view).find(".input-number-value").find('.on').removeClass('on');
	            var target = event.target;
	            $(target).parent().addClass('on');
	            //console.log('inputEle clsName:', clsName);

	            //console.log("target:", target);
	        });
	    }
	}

	function updateInputValue(examModel) {
	    var clsName = undefined;

	    var canvasEle = $(_presenter2['default'].view).find('.com_lay_board');
	    //let inputEle = $(presenter.view).find('.' + PRE_INPUT_ELEMENT + 0);
	    var inputEle = $(_presenter2['default'].view).find('.axis_input_element_' + 0);

	    var offsetLeft = canvasEle.width() / 2 - inputEle.outerWidth() / 2;

	    //console.log("offsetLeft:", offsetLeft);
	    //console.log("canvasEle.width():", canvasEle.width());
	    //console.log("inputEle.width() :", inputEle.width());
	    //console.log("inputEle.outerWidth() :", inputEle.outerWidth());
	    //console.log("inputEle.outerWidth(true) :", inputEle.outerWidth(true));

	    var lastIndex = 0;
	    var minValue = examModel.valueArray[0];
	    for (var i = 0, len = examModel.valueArray.length; i < len; i++) {
	        if (minValue > examModel.valueArray[i]) {
	            minValue = examModel.valueArray[i];
	            lastIndex = i;
	        }
	        clsName = PRE_INPUT_ELEMENT + i;
	        var leftPading = undefined;
	        if (!examModel.isInteger) {
	            leftPading = examModel.valueArray[i] * _ShapeAxisView.unitLength;
	            $(_presenter2['default'].view).find('.' + clsName).css('left', leftPading + offsetLeft);
	        } else {
	            leftPading = (0 + _constants.SCODE_COPE.NATURAL_SCOPE) * _ShapeAxisView.unitLength;
	            leftPading = offsetLeft - leftPading;
	            leftPading += examModel.valueArray[i] * _ShapeAxisView.unitLength;
	            $(_presenter2['default'].view).find('.' + clsName).css('left', leftPading);
	        }

	        //console.log("leftPading:", leftPading);
	        //console.log("unitLength:", unitLength);
	        //console.log("examModel.valueArray[i]:", examModel.valueArray[i]);

	        //$(presenter.view).find('.' + clsName).css('left', offsetLeft);

	        //if (presenter.isTeacherPc) {
	        //    $(presenter.view).find('.' + clsName).css('left', leftPading + offsetLeft + 45);//適用画布缩小后,输入框的位置偏移
	        //} else if (presenter.isStudentMobile || presenter.isTeacherMobile) {
	        //    $(presenter.view).find('.' + clsName).css('left', leftPading + 70);
	        //} else if (presenter.isWeb) {
	        //    $(presenter.view).find('.' + clsName).css('left', leftPading + 170);
	        //} else {
	        //    if (REAL_ESTATE.width > REAL_ESTATE.frontage) {
	        //        $(presenter.view).find('.' + clsName).css('left', leftPading + 120);
	        //    } else {
	        //        $(presenter.view).find('.' + clsName).css('left', leftPading + 75);
	        //    }
	        //
	        //}
	    }

	    if ((0, _moduleControl.isApp)()) {
	        $(_presenter2['default'].view).find('.' + PRE_INPUT_ELEMENT + lastIndex).addClass('on');
	    }
	}

	function updateButtonValue(examModel) {
	    var clsName = undefined;
	    for (var i = 0, len = examModel.valueArray.length; i < len; i++) {
	        clsName = PRE_INPUT_ELEMENT + i;
	        $(_presenter2['default'].view).find('.' + clsName).html(examModel.valueArray[i]);
	    }
	}

/***/ },
/* 43 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by zhoujunzhou on 2016/1/5.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.generRanArray = generRanArray;

	var _constants = __webpack_require__(4);

	var _moduleControl = __webpack_require__(6);

	function generRanArray(examModel) {

	    if (!examModel) {
	        return;
	    }
	    var data = [];
	    var value = undefined;
	    for (var i = 0; i < 4; i++) {

	        value = newNumber(examModel.isInteger);
	        while (isHaveThisNumber(data, value)) {
	            value = newNumber(examModel.isInteger);
	        }

	        data[i] = value;
	    }

	    console.log(data);
	    return data;
	}

	function randomSymbolCode() {
	    var symbolCode = 0.5 - Math.random();
	    if (symbolCode >= 0) {
	        symbolCode = 1;
	    } else {
	        symbolCode = -1;
	    }

	    return symbolCode;
	}

	function newNumber(isInteger) {
	    var scopeValue = undefined;
	    var symbolCode = 1;
	    if (isInteger) {
	        scopeValue = _constants.SCODE_COPE.INTEGER_SCOPE;
	    } else {
	        scopeValue = _constants.SCODE_COPE.NATURAL_SCOPE;
	    }

	    if (!isInteger) {
	        symbolCode = randomSymbolCode();
	    }

	    return Math.floor(Math.random() * scopeValue + 1) * symbolCode;
	}

	function isHaveThisNumber(para, num) {
	    if (typeof para == "object") {
	        if (para.length == 0) {
	            return false;
	        }
	    }
	    for (var i = 0; i < para.length; i++) {
	        var padding = Math.abs(para[i] - num);
	        if (padding <= 4) {
	            console.log('与目标数组有间距小于3:', num);
	            return true;
	        }
	    }
	    return false;
	}

/***/ },
/* 44 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by zhoujunzhou on 2016/1/6.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _constants = __webpack_require__(4);

	var _ShapeConnectLine = __webpack_require__(39);

	var _ShapeConnectLine2 = _interopRequireDefault(_ShapeConnectLine);

	var _threeManger = __webpack_require__(10);

	var _DomViewCalcElementBuilder = __webpack_require__(42);

	var ConnectPointControl = (function () {
	    function ConnectPointControl() {
	        _classCallCheck(this, ConnectPointControl);

	        this.selectClsName = 'axis_input_element_0';
	        this.lineMap = new Map();
	    }

	    _createClass(ConnectPointControl, [{
	        key: 'getSelectBtnClsName',
	        value: function getSelectBtnClsName() {
	            return this.selectClsName;
	        }

	        /**
	         * 添加按钮点击监听，点击后修改selectClsName的值为当前点击的值
	         */
	    }, {
	        key: 'bindButtonClick',
	        value: function bindButtonClick(coordNoteModel) {

	            var clsObject = this;
	            //默认第一个选择状态
	            $(_presenter2['default'].view).find('.' + coordNoteModel.btnClassArray[0] + '').addClass('on');

	            var _loop = function (i, len) {
	                $(_presenter2['default'].view).find('.' + coordNoteModel.btnClassArray[i] + '').off('click').on('click touchstart', function (e) {
	                    e.preventDefault();
	                    var clsName = $(e.target).attr('class');
	                    clsObject.selectClsName = 'axis_input_element_' + i;
	                    clsObject.removeAllSelect(coordNoteModel);
	                    $(e.target).addClass('on');
	                });
	            };

	            for (var i = 0, len = coordNoteModel.btnClassArray.length; i < len; i++) {
	                _loop(i, len);
	            }
	        }
	    }, {
	        key: 'removeAllSelect',
	        value: function removeAllSelect(coordNoteModel) {
	            for (var i = 0, len = coordNoteModel.btnClassArray.length; i < len; i++) {
	                $(_presenter2['default'].view).find('.' + coordNoteModel.btnClassArray[i] + '').removeClass('on');
	            }
	        }
	    }, {
	        key: 'drawConnectLine',
	        value: function drawConnectLine(btnClsName, vectorPoint) {
	            //当前选中的dom节点连接到canvas的点
	            var btnElement = $(_presenter2['default'].view).find('.' + btnClsName);
	            var canvasEle = $(_presenter2['default'].view).find('.numberline-canvas');

	            //console.log('canvasEle offset():', canvasEle.offset());
	            //console.log('canvasEle position():', canvasEle.position());
	            //console.log('canvasEle widget():', canvasEle.width());
	            //console.log('canvasEle height():', canvasEle.height());
	            //
	            //console.log('btnElement offset():', btnElement.offset());
	            //console.log('btnElement widget():', btnElement.width());
	            //console.log('btnElement height():', btnElement.height());
	            //console.log('btnElement position():', btnElement.position());

	            var left = btnElement.position().left;

	            var btnWidth = btnElement.width();
	            var btnHeight = btnElement.height();
	            if (_presenter2['default'].isTeacherPc && !_presenter2['default'].isFullPPT) {
	                left = left - _constants.REAL_ESTATE.width + btnWidth; //针对TeacherPC修改,原为REAL_ESTATE.width/2,偏移已在外部添加,
	            } else {
	                    left = left - _constants.REAL_ESTATE.width / 2 + btnWidth;
	                }

	            //let pointA = new THREE.Vector3(left+btnWidth/2, INPUT_MARGIN_HEIGHT*2.8  - btnHeight , 0);

	            var pointA = undefined;
	            //if (presenter.isTeacherPc) {
	            var lineTop = canvasEle.height() / 2 - (btnElement.offset().top - canvasEle.offset().top) - btnHeight;
	            console.log(' lineTop:', lineTop);
	            pointA = new THREE.Vector3(left + btnWidth / 2, lineTop, 0);

	            //} else {
	            //    pointA = new THREE.Vector3(left + btnWidth / 2, INPUT_MARGIN_HEIGHT * 2.8 - btnHeight, 0);
	            //}

	            var cLine = this.lineMap.get(btnClsName);
	            if (cLine) {
	                cLine.create(pointA, vectorPoint);
	            } else {
	                cLine = new _ShapeConnectLine2['default'](btnClsName);
	                this.lineMap.set(btnClsName, cLine);
	                cLine.create(pointA, vectorPoint);
	            }
	        }
	    }, {
	        key: 'doIntersectObjects',
	        value: function doIntersectObjects(pointer) {

	            var rect = $(_presenter2['default'].view).find('.numberline-canvas')[0].getBoundingClientRect();
	            var x = (pointer.left - rect.left) / rect.width;
	            var y = (pointer.top - rect.top) / rect.height;
	            var mouse = new THREE.Vector2(x * 2 - 1, -(y * 2) + 1);

	            //raycaster.setFromCamera(mouse, object.camera);
	            //let intersections = raycaster.intersectObjects(objects, true);
	            //
	            //return intersections[0] ? intersections[0] : false;
	        }
	    }]);

	    return ConnectPointControl;
	})();

	exports['default'] = ConnectPointControl;
	module.exports = exports['default'];

/***/ },
/* 45 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by zhoujunzhou on 2016/1/5.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

	var _get = function get(_x, _x2, _x3) { var _again = true; _function: while (_again) { var object = _x, property = _x2, receiver = _x3; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x = parent; _x2 = property; _x3 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

	function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	var _BaseExamModel2 = __webpack_require__(41);

	var _BaseExamModel3 = _interopRequireDefault(_BaseExamModel2);

	var _DomViewCalcElementBuilder = __webpack_require__(42);

	var _NumberBuilder = __webpack_require__(43);

	var _constants = __webpack_require__(4);

	var _moduleControl = __webpack_require__(6);

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	/**
	 * 坐标点类型：在已知坐标轴上的点填写数字
	 */

	var CoordNumberModel = (function (_BaseExamModel) {
	    _inherits(CoordNumberModel, _BaseExamModel);

	    function CoordNumberModel() {
	        _classCallCheck(this, CoordNumberModel);

	        _get(Object.getPrototypeOf(CoordNumberModel.prototype), 'constructor', this).call(this, _constants.EXAM_TYPE.Coord_Point_Number);
	    }

	    _createClass(CoordNumberModel, [{
	        key: 'create',
	        value: function create(value) {
	            if (!value) {
	                this.valueArray = (0, _NumberBuilder.generRanArray)(this);
	            } else {
	                this.valueArray = value;
	            }

	            (0, _DomViewCalcElementBuilder.buildInputView)(this);

	            if ((0, _moduleControl.isApp)()) {
	                this.bindInputKey();
	            }

	            var clsObj = this;
	            setTimeout(function () {
	                (0, _DomViewCalcElementBuilder.buildInputView)(clsObj);
	            }, 200);

	            return this;
	        }
	    }, {
	        key: 'bindInputKey',
	        value: function bindInputKey() {

	            var clsObject = this;

	            //$(presenter.view).find('.input-number-value').off('click').on('click touchstart', function (e) {
	            //    e.preventDefault();
	            //
	            //
	            //    let target = e.target;
	            //    //if (target.tagName == 'INPUT' && !$(target).parent().hasClass('on')) {
	            //    //    target.blur();
	            //    //    target.focus();
	            //    //    clsObject.clearOtherSelect();
	            //    //    $(target).parent().addClass('on');
	            //    //}
	            //
	            //    console.log("target:", target);
	            //
	            //
	            //});
	            //
	            //$(presenter.view).find('.input-number-value').off('mouseleave').on('mouseleave', function (e) {
	            //    $(presenter.view).find('input').blur();
	            //    console.log("mouseleave");
	            //});
	        }
	    }, {
	        key: 'clearOtherSelect',
	        value: function clearOtherSelect() {
	            for (var i = 0, len = this.valueArray.length; i <= len; i++) {
	                $(_presenter2['default'].view).find('.' + _DomViewCalcElementBuilder.PRE_INPUT_ELEMENT + i).removeClass('on');
	            }
	        }
	    }, {
	        key: 'updateDomValue',
	        value: function updateDomValue() {
	            (0, _DomViewCalcElementBuilder.updateInputValue)(this);
	        }
	    }, {
	        key: 'updateValueArray',
	        value: function updateValueArray() {
	            this.valueArray = (0, _NumberBuilder.generRanArray)(this);
	            this.updateDomValue();
	        }
	    }]);

	    return CoordNumberModel;
	})(_BaseExamModel3['default']);

	exports['default'] = CoordNumberModel;
	module.exports = exports['default'];

/***/ },
/* 46 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by zhoujunzhou on 2016/1/5.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

	var _get = function get(_x, _x2, _x3) { var _again = true; _function: while (_again) { var object = _x, property = _x2, receiver = _x3; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x = parent; _x2 = property; _x3 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

	function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	var _BaseExamModel2 = __webpack_require__(41);

	var _BaseExamModel3 = _interopRequireDefault(_BaseExamModel2);

	var _DomViewCalcElementBuilder = __webpack_require__(42);

	var _NumberBuilder = __webpack_require__(43);

	var _constants = __webpack_require__(4);

	var _RadomCalcBuilder = __webpack_require__(47);

	/**
	 * 加减运算类型：在坐标轴上标出已知计算式的结果
	 */

	var CalcNoteModel = (function (_BaseExamModel) {
	    _inherits(CalcNoteModel, _BaseExamModel);

	    function CalcNoteModel() {
	        _classCallCheck(this, CalcNoteModel);

	        _get(Object.getPrototypeOf(CalcNoteModel.prototype), 'constructor', this).call(this, _constants.EXAM_TYPE.Calculate_Note);
	        this.symbolArray = []; //随机生成的运算符号
	        this.userSymbolArray = [];
	        this.userResult;
	    }

	    _createClass(CalcNoteModel, [{
	        key: 'create',
	        value: function create(value, symbols) {

	            console.log('create CalcNoteModel');

	            if (!value) {
	                this.updateValueArray();
	            } else {
	                this.valueArray = value;
	            }

	            if (symbols) {
	                this.symbolArray = symbols;
	            }

	            (0, _DomViewCalcElementBuilder.buildCalcTextView)(this);
	            //if (!isWeb) {
	            //this.createConnectPointControl();
	            this.updateDomValue();
	            return this;
	        }
	    }, {
	        key: 'updateDomValue',
	        value: function updateDomValue() {
	            (0, _DomViewCalcElementBuilder.updateCalcTextView)(this);
	        }
	    }, {
	        key: 'updateValueArray',
	        value: function updateValueArray() {
	            var formuala = undefined;
	            if (this.isInteger) {
	                formuala = (0, _RadomCalcBuilder.generFromulaByScope)(2, 40);
	            } else {
	                formuala = (0, _RadomCalcBuilder.generFromulaByScope)(2, 15, true);
	            }

	            this.valueArray = formuala.number;
	            this.symbolArray = formuala.symboCodes;
	            this.updateDomValue();
	        }
	    }, {
	        key: 'getCorrectRes',
	        value: function getCorrectRes() {

	            return this.buildCalcString(this.valueArray, this.symbolArray);
	        }
	    }, {
	        key: 'getUserRes',
	        value: function getUserRes() {
	            //return this.userResValue;
	            return this.buildCalcString(this.userResValue, this.userSymbolArray);
	        }
	    }, {
	        key: 'setUserRes',
	        value: function setUserRes(userResArray, userSymbolArray) {
	            console.log('try to setUserRes');
	            try {
	                this.userResValue = userResArray;
	                this.userSymbolArray = userSymbolArray;
	            } catch (e) {
	                console.log('setUserRes Fail,error info is', e);
	            }

	            console.log('setUserRes done', this.userResValue, this.userSymbolArray);
	            if (this.userResValue.length > 1) {
	                (0, _DomViewCalcElementBuilder.updateCaclResultText)(this, this.updateResultText(this.userResValue, this.userSymbolArray));
	            }

	            //return this.buildCalcString(this.userResValue, this.userSymbolArray);
	        }
	    }, {
	        key: 'buildCalcString',
	        value: function buildCalcString(values, symbols) {

	            if (!values || !symbols) {
	                return;
	            }

	            var calcText = '';
	            calcText += values[0];

	            var len = values.length;
	            var symbolLen = symbols.length;
	            for (var i = 1; i < len && i - 1 < symbolLen; i++) {
	                if (symbols[i - 1] > 0) {
	                    calcText += ' + ';
	                } else {
	                    calcText += ' - ';
	                }
	                calcText += values[i] + '';
	            }

	            return calcText;
	        }
	    }, {
	        key: 'updateResultText',
	        value: function updateResultText(values, symbols) {
	            //计算结果
	            var resultValue = values[0];
	            for (var i = 0, len = values.length - 1; i < len; i++) {
	                resultValue = resultValue + values[i + 1] * symbols[i];
	            }

	            //let resultString = values.toString();
	            //resultString += ',' + resultValue;
	            return resultValue;
	        }
	    }]);

	    return CalcNoteModel;
	})(_BaseExamModel3['default']);

	exports['default'] = CalcNoteModel;
	module.exports = exports['default'];

/***/ },
/* 47 */
/***/ function(module, exports) {

	/**
	 * Created by zhoujunzhou on 2016/1/8.
	 */
	//import {SCODE_COPE} from '../constants'
	//import {setAxisExamModle} from '../moduleControl'

	//window.onload = function () {
	//    console.log('Javascript has start!!!');
	////   generFromula(3,10,1);
	//    generFromulaByScope(4,15,true);
	//};

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.generFromulaByScope = generFromulaByScope;
	function Formula() {
	    //     this.number = [] ;
	    //     this.symboCodes = [];
	    //     this.resultValue = undefined;
	    //     this.maxNum =undefined;
	    //     this.mixNum =undefined;
	    //     this.maxResult;   //结果值的最大值
	    //     this.mixResult;  // 结果的最小值
	}

	function generFromulaByScope(length, scopeValue, isNatural) {
	    if (!length || length < 2) {
	        return;
	    }
	    var formula = new Formula();

	    formula.lenght = length;

	    if (isNatural) {
	        formula.maxNum = scopeValue;
	        formula.mixNum = 1;
	        formula.maxResult = scopeValue;
	        formula.mixResult = -scopeValue;
	    } else {
	        formula.maxNum = scopeValue;
	        formula.mixNum = 1;
	        formula.maxResult = scopeValue;
	        formula.mixResult = 0;
	    }

	    generSymbolCode(formula, generRanArray(length, formula.maxNum, formula.mixNum));
	    console.log('formula:', formula);

	    return formula;
	}

	function generFromula(lenght, maxNum, mixNum) {
	    if (!lenght || lenght < 2) {
	        return;
	    }
	    var formula = new Formula();
	    // formula.number = generRanArray(lenght);
	    formula.maxNum = maxNum;
	    formula.mixNum = mixNum;
	    formula.maxResult = maxNum;
	    formula.mixResult = mixNum;
	    formula.lenght = lenght;
	    generSymbolCode(formula, generRanArray(lenght, maxNum, mixNum));

	    console.log('formula:', formula);
	}

	function generSymbolCode(formula, ranArray) {
	    var lastValue = ranArray[0];
	    var lastArray = [];
	    lastArray[0] = lastValue;
	    var valideSymbol = undefined;
	    var symbolArray = [];
	    for (var i = 1, len = ranArray.length; i < len; i++) {
	        valideSymbol = computeSymbol(lastValue, ranArray[i], formula.maxResult, formula.mixResult);

	        if (valideSymbol) {
	            lastValue = valideSymbol.resultValue;
	            if (valideSymbol.isChangeOrder) {
	                lastArray.splice(0, 0, ranArray[i]);
	                symbolArray.splice(0, 0, valideSymbol.symbolCode);
	            } else {
	                lastArray[lastArray.length] = ranArray[i];
	                symbolArray[symbolArray.length] = valideSymbol.symbolCode;
	            }
	        } else {
	            console.log('generSymbolCode has error--------');
	            generSymbolCode(formula, generRanArray(formula.lenght, formula.maxNum, formula.mixNum));
	            return;
	        }
	    }

	    if (checkCalc(lastArray, symbolArray, formula.maxResult, formula.mixResult)) {
	        console.log('验证是合法的计算式');
	        formula.number = lastArray;
	        formula.symboCodes = symbolArray;
	    } else {
	        console.log('验证是非合法的计算式');
	        // generSymbolCode(formula,lastArray);
	        generSymbolCode(formula, generRanArray(formula.lenght, formula.maxNum, formula.mixNum));
	    }
	}

	function checkCalc(numberArray, symbolArray, maxNum, mixNum) {
	    var resultValue = numberArray[0];
	    for (var i = 0, len = numberArray.length - 1; i < len; i++) {

	        resultValue = resultValue + numberArray[i + 1] * symbolArray[i];

	        if (!isValideCalc(resultValue, maxNum, mixNum)) {
	            console.log('checkCalc resultvalue:', resultValue);
	            return false;
	        }
	    }
	    console.log('checkCalc resultvalue:', resultValue);
	    return true;
	}

	function ValideSymbol() {
	    //     this._isChangeOrder=undefined;
	    //     this._symbolCode=undefined;
	    //     this._resultValue =undefined;
	}

	function isValideCalc(resultValue, maxNum, mixNum) {
	    return resultValue <= maxNum && resultValue >= mixNum;
	}

	function computeSymbol(a, b, maxResultNum, mixResultNum) {

	    var valideSymbol = new ValideSymbol();
	    var randomSymCode = randomSymbolCode();

	    var resultValue = a + b * randomSymCode;
	    if (isValideCalc(resultValue, maxResultNum, mixResultNum)) {
	        valideSymbol.symbolCode = randomSymCode;
	        valideSymbol.resultValue = resultValue;
	    } else {
	        resultValue = a + b * randomSymCode * -1;
	        if (isValideCalc(resultValue, maxResultNum, mixResultNum)) {
	            valideSymbol.symbolCode = -1 * randomSymCode;
	            valideSymbol.resultValue = resultValue;
	        } else {
	            resultValue = b - a;
	            if (isValideCalc(resultValue, maxResultNum, mixResultNum)) {
	                valideSymbol.isChangeOrder = true;
	                valideSymbol.symbolCode = -1;
	                valideSymbol.resultValue = resultValue;
	            } else {
	                console.log('cannot computeSymbol a，b', a, b);
	                return null;
	            }
	        }
	    }

	    return valideSymbol;
	}

	function generRanArray(lenght, maxNum, mixNum) {

	    var data = [];
	    var value = undefined;
	    for (var i = 0; i < lenght; i++) {

	        value = newNumber(maxNum, mixNum);
	        while (isHaveThisNumber(data, value)) {
	            value = newNumber(maxNum, mixNum);
	        }

	        data[i] = value;
	    }

	    console.log('generRanArray:', data);
	    return data;
	}

	function randomSymbolCode() {
	    var symbolCode = 0.5 - Math.random();
	    if (symbolCode >= 0) {
	        symbolCode = 1;
	    } else {
	        symbolCode = -1;
	    }

	    return symbolCode;
	}

	function newNumber(maxNum, mixNum) {
	    var scopeValue = maxNum - mixNum;
	    return mixNum + Math.floor(Math.random() * scopeValue);
	}

	function isHaveThisNumber(para, num) {
	    if (typeof para == "object") {
	        if (para.length === 0) {
	            return false;
	        }
	    }
	    for (var i = 0; i < para.length; i++) {
	        var padding = Math.abs(para[i] - num);
	        if (padding === 0) {
	            console.log('与目标数组相同:', num);
	            return true;
	        }
	    }
	    return false;
	}

/***/ },
/* 48 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by zhoujunzhou on 2016/1/5.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

	var _get = function get(_x, _x2, _x3) { var _again = true; _function: while (_again) { var object = _x, property = _x2, receiver = _x3; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x = parent; _x2 = property; _x3 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

	function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	var _BaseExamModel2 = __webpack_require__(41);

	var _BaseExamModel3 = _interopRequireDefault(_BaseExamModel2);

	var _DomViewCalcElementBuilder = __webpack_require__(42);

	var _NumberBuilder = __webpack_require__(43);

	var _constants = __webpack_require__(4);

	var _RadomCalcBuilder = __webpack_require__(47);

	var _moduleControl = __webpack_require__(6);

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	/**
	 * 加减运算类型：已知坐标轴图填写完整的计算式
	 */

	var CalcNumberModel = (function (_BaseExamModel) {
	    _inherits(CalcNumberModel, _BaseExamModel);

	    function CalcNumberModel() {
	        _classCallCheck(this, CalcNumberModel);

	        _get(Object.getPrototypeOf(CalcNumberModel.prototype), 'constructor', this).call(this, _constants.EXAM_TYPE.Calculate_Number);
	        this.symbolArray = []; //随机生成的运算符号
	        this.userSymbolArray = [];
	    }

	    _createClass(CalcNumberModel, [{
	        key: 'create',
	        value: function create(value, symbols) {
	            if (!value) {
	                this.updateValueArray();
	            } else {
	                this.valueArray = value;
	            }

	            if (symbols) {
	                this.symbolArray = symbols;
	            }

	            (0, _DomViewCalcElementBuilder.buildCalcInputView)(this);

	            if ((0, _moduleControl.isApp)()) {
	                this.bindInputKey();
	            }

	            return this;
	        }
	    }, {
	        key: 'bindInputKey',
	        value: function bindInputKey() {

	            var clsObject = this;
	            //
	            //for (let i = 0, len = this.valueArray.length; i <= len; i++) {
	            //
	            //
	            //    $(presenter.view).find('.' + PRE_SYMBOL_ELEMENT + i).off('click').on('click touchstart', function (e) {
	            //        e.preventDefault();
	            //        let target = e.target;
	            //        clsObject.clearOtherSelect();
	            //        $(target).parent().addClass('on');
	            //        $(target).blur();
	            //        $(target).focus()
	            //    });
	            //
	            //}
	            //
	            ////$(presenter.view).find('.' + PRE_SYMBOL_ELEMENT + 0).find(':input').focus();
	            //$(presenter.view).find('.' + PRE_SYMBOL_ELEMENT + 0).addClass('on');
	        }
	    }, {
	        key: 'clearOtherSelect',
	        value: function clearOtherSelect() {
	            for (var i = 0, len = this.valueArray.length; i <= len; i++) {
	                $(_presenter2['default'].view).find('.' + _DomViewCalcElementBuilder.PRE_SYMBOL_ELEMENT + i).removeClass('on');
	            }
	        }
	    }, {
	        key: 'updateDomValue',
	        value: function updateDomValue() {
	            (0, _DomViewCalcElementBuilder.buildCalcInputView)(this);
	        }
	    }, {
	        key: 'updateValueArray',
	        value: function updateValueArray() {
	            var formuala = undefined;
	            if (this.isInteger) {
	                formuala = (0, _RadomCalcBuilder.generFromulaByScope)(2, 40);
	            } else {
	                formuala = (0, _RadomCalcBuilder.generFromulaByScope)(3, 15, true);
	            }
	            this.valueArray = formuala.number;
	            this.symbolArray = formuala.symboCodes;

	            this.updateDomValue();
	        }
	    }, {
	        key: 'getCorrectRes',
	        value: function getCorrectRes() {
	            if (!this.valueArray || !this.symbolArray) {
	                return;
	            }

	            var resultValue = this.valueArray[0];
	            for (var i = 0, len = this.valueArray.length - 1; i < len; i++) {
	                resultValue = resultValue + this.valueArray[i + 1] * this.symbolArray[i];
	            }

	            var resultString = this.valueArray.toString();
	            resultString += ',' + resultValue;

	            return resultString;
	        }
	    }, {
	        key: 'getUserRes',
	        value: function getUserRes() {

	            if (!this.userResArray || !this.symbolArray) {
	                return;
	            }

	            //let userResultValue = parseInt(this.userResArray[0]);
	            //for (let i = 0, len = this.userResArray.length - 1; i < len; i++) {
	            //    userResultValue = (userResultValue + parseInt(this.userResArray[i + 1]) * parseInt(this.symbolArray[i]));
	            //}
	            var resultString = this.userResArray.toString();
	            //resultString += ',' + userResultValue;
	            return resultString;
	        }
	    }]);

	    return CalcNumberModel;
	})(_BaseExamModel3['default']);

	exports['default'] = CalcNumberModel;
	module.exports = exports['default'];

/***/ },
/* 49 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

	exports.setRegulationCount = setRegulationCount;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

	var _threeManger = __webpack_require__(10);

	var _addText = __webpack_require__(17);

	var _addText2 = _interopRequireDefault(_addText);

	var _rotateAngle = __webpack_require__(22);

	var _calculatMethodJs = __webpack_require__(20);

	var _addArrowJs = __webpack_require__(50);

	var _addArrowJs2 = _interopRequireDefault(_addArrowJs);

	var _addDotJs = __webpack_require__(51);

	var _addDotJs2 = _interopRequireDefault(_addDotJs);

	var _destroyThreeObjectJs = __webpack_require__(52);

	var _destroyThreeObjectJs2 = _interopRequireDefault(_destroyThreeObjectJs);

	var _ShapeAxisView = __webpack_require__(34);

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var regulationCount = 0;
	exports.regulationCount = regulationCount;

	var _default = (function () {
	    function _default(toolbar, originPoint, unitLength) {
	        var lineWidth = arguments.length <= 3 || arguments[3] === undefined ? 5 : arguments[3];

	        _classCallCheck(this, _default);

	        this.curve = new THREE.Object3D();
	        this.curve.outset = toolbar.startPoint;
	        this.curve.terminal = toolbar.endPoint;
	        this.curve.startPoint = toolbar.startPoint.position;
	        this.curve.endPoint = toolbar.endPoint.position;
	        this.curve.bottom = toolbar.startPoint.userData.radius + 5;
	        this.curve.color = toolbar.startPoint.userData.color;
	        this.curve.lineWidth = lineWidth;
	        this.curve.unitLength = unitLength;
	        this.curve.draw = !_presenter2['default'].isTeacherMobile && !_presenter2['default'].isStudentMobile ? this.draw : this.drawArc;
	        this.curve.update = !_presenter2['default'].isTeacherMobile && !_presenter2['default'].isStudentMobile ? this.update : this.updateArc;
	        this.curve.revertArrow = this.revertArrow;
	        this.curve.clear = this.clear;
	        this.curve.destroy = this.destroy;
	        this.curve.draw();
	        return this.curve;
	    }

	    _createClass(_default, [{
	        key: 'drawArc',
	        value: function drawArc(value) {
	            var crossArrow = this.getObjectByName('crossArrow'),
	                b = this.endPoint.x > this.startPoint.x,
	                centerPoint = Math.abs(this.endPoint.x - this.startPoint.x) >= 20 * _ShapeAxisView.unitLength ? new THREE.Vector2((this.endPoint.x + this.startPoint.x) / 2, (this.endPoint.x - this.startPoint.x) / 4) : new THREE.Vector2((this.endPoint.x + this.startPoint.x) / 2, (this.endPoint.x - this.startPoint.x) / 2),
	                radian = new THREE.QuadraticBezierCurve(this.startPoint, centerPoint, this.endPoint),
	                points = radian.getSpacedPoints(20),
	                limitPoint = radian.getPoint(.5),
	                count = (b ? '+' : '') + ((this.endPoint.x * 1000 - this.startPoint.x * 1000) / this.unitLength.toFixed(10) / 1000).toFixed(1);
	            //console.log(centerPoint)
	            if (crossArrow) {
	                //let distanceText = this.getObjectByName('distance'),
	                //	outsetText = this.getObjectByName('outset').getObjectByName('positionText'),
	                //	terminalText = this.getObjectByName('terminal').getObjectByName('positionText');
	                crossArrow.position.x = this.endPoint.x;
	                if (b != crossArrow.userData.up) {
	                    crossArrow.position.y *= -1;
	                    crossArrow.rotation.z == Math.PI ? crossArrow.rotation.set(0, 0, 0) : crossArrow.rotation.set(0, 0, Math.PI);
	                    crossArrow.userData.up = b;
	                }
	                //distanceText.position.x = limitPoint.x;
	                //distanceText.position.y = b ? limitPoint.y + 40 : limitPoint.y - 16;
	                //distanceText._dynamicTexture.clear().drawText(count, undefined, 32);
	                //if(outsetText){
	                //	outsetText._dynamicTexture.clear().drawText((this.startPoint.x/(this.unitLength.toFixed(10))).toFixed(1), undefined,16);
	                //	outsetText.visible = (this.startPoint.x/this.unitLength).toFixed(1)%1 !== 0;
	                //	terminalText._dynamicTexture.clear().drawText((this.endPoint.x/(this.unitLength.toFixed(10))).toFixed(1), undefined,16);
	                //	terminalText.visible = (this.endPoint.x/this.unitLength).toFixed(1)%1 !== 0;
	                //}
	            } else {
	                    if (b) {
	                        //增减线颜色不同
	                        this.color = '#FF0000';
	                    } else {
	                        this.color = '#00FF00';
	                    }
	                    var arrow = (0, _addArrowJs2['default'])(this.endPoint, this.lineWidth, this.color, b);
	                    arrow.position.y = b ? this.bottom : -this.bottom;
	                    this.add(arrow);
	                    var text = (0, _addText2['default'])(count, limitPoint, 64, 32, '16px');
	                    text.name = 'distance';
	                    b ? text.position.y += 24 : text.position.y -= 32;
	                    //this.add(text);
	                }
	            var path = new THREE.Path();
	            var geometry = path.createGeometry(points);
	            var material = new THREE.LineBasicMaterial({ color: this.color, linewidth: this.lineWidth });
	            var torus = new THREE.Line(geometry, material);
	            torus.name = 'torus';
	            // torus.position.x = centerPoint.x;
	            torus.position.y = b ? this.bottom : -this.bottom;
	            torus.position.z = 0;
	            // let angle = b ? (Math.PI-Math.abs(rotation.angle))/2 : Math.PI+(Math.PI-Math.abs(rotation.angle))/2
	            // torus.rotation.set(0,0, angle);

	            this.add(torus);
	            if (!value) {
	                this.name = 'regulation' + regulationCount;
	                exports.regulationCount = regulationCount += 1;
	            }

	            //console.log(torus)
	        }
	    }, {
	        key: 'draw',
	        value: function draw(value) {

	            var crossArrow = this.getObjectByName('crossArrow'),
	                b = this.endPoint.x > this.startPoint.x,
	                centerPoint = Math.abs(this.endPoint.x - this.startPoint.x) >= 20 * _ShapeAxisView.unitLength ? new THREE.Vector2((this.endPoint.x + this.startPoint.x) / 2, (this.endPoint.x - this.startPoint.x) / 4) : new THREE.Vector2((this.endPoint.x + this.startPoint.x) / 2, (this.endPoint.x - this.startPoint.x) / 2),
	                radian = new THREE.QuadraticBezierCurve(this.startPoint, centerPoint, this.endPoint),
	                limitPoint = radian.getPoint(.5),
	                x = limitPoint.x,
	                y = b ? -Math.abs(((limitPoint.x - this.startPoint.x) * (limitPoint.x - this.startPoint.x) - limitPoint.y * limitPoint.y) / (2 * limitPoint.y)) : Math.abs(((limitPoint.x - this.startPoint.x) * (limitPoint.x - this.startPoint.x) - limitPoint.y * limitPoint.y) / (2 * limitPoint.y)),
	                point = new THREE.Vector2(x, y),
	                radius = new THREE.Vector2().subVectors(point, limitPoint).length(),
	                count = (b ? '+' : '') + ((this.endPoint.x * 1000 - this.startPoint.x * 1000) / this.unitLength.toFixed(10) / 1000).toFixed(1);
	            if (b) {
	                //增减线颜色不同
	                this.color = '#FF0000';
	            } else {
	                this.color = '#00FF00';
	            }

	            if (crossArrow) {

	                var distanceText = this.getObjectByName('distance'),

	                //outsetText = this.getObjectByName('outset').getObjectByName('positionText'),
	                terminalText = this.getObjectByName('terminal').getObjectByName('positionText');
	                crossArrow.position.x = this.endPoint.x;
	                if (b != crossArrow.userData.up) {
	                    crossArrow.position.y *= -1;
	                    crossArrow.rotation.z == Math.PI ? crossArrow.rotation.set(0, 0, 0) : crossArrow.rotation.set(0, 0, Math.PI);
	                    crossArrow.userData.up = b;
	                }
	                distanceText.position.x = limitPoint.x;
	                distanceText.position.y = b ? limitPoint.y + 40 : limitPoint.y - 16;
	                distanceText._dynamicTexture.clear().drawText(count, undefined, 32);
	                if (outsetText) {
	                    //outsetText._dynamicTexture.clear().drawText((this.startPoint.x/(this.unitLength.toFixed(10))).toFixed(1), undefined,16);
	                    //outsetText.visible = (this.startPoint.x/this.unitLength).toFixed(1)%1 !== 0;
	                    terminalText._dynamicTexture.clear().drawText((this.endPoint.x / this.unitLength.toFixed(10)).toFixed(1), undefined, 16);
	                    terminalText.visible = (this.endPoint.x / this.unitLength).toFixed(1) % 1 !== 0;
	                }
	            } else {
	                var arrow = (0, _addArrowJs2['default'])(this.endPoint, this.lineWidth, this.color, b);
	                arrow.position.y = b ? this.bottom : -this.bottom;
	                this.add(arrow);
	                var text = (0, _addText2['default'])(count, limitPoint, 64, 32, '16px');
	                text.name = 'distance';
	                b ? text.position.y += 40 : text.position.y -= 32;
	                //this.add(text);
	            }

	            var rotation = (0, _rotateAngle.getAngle)(this.startPoint, point, this.endPoint);
	            var geometry = new THREE.TorusGeometry(radius, this.lineWidth / 2, 80, 50, rotation.angle);
	            var material = new THREE.MeshBasicMaterial({ color: this.color });
	            var torus = new THREE.Mesh(geometry, material);
	            torus.name = 'torus';
	            torus.position.x = point.x;
	            torus.position.y = b ? point.y += this.bottom : point.y -= this.bottom;
	            var angle = b ? (Math.PI - Math.abs(rotation.angle)) / 2 : Math.PI + (Math.PI - Math.abs(rotation.angle)) / 2;
	            torus.rotation.set(0, 0, angle);

	            this.add(torus);
	            if (!value) {
	                this.name = 'regulation' + regulationCount;
	                exports.regulationCount = regulationCount += 1;
	            }

	            //console.log(torus)
	        }
	    }, {
	        key: 'update',
	        value: function update() {
	            var torusObject = this.getObjectByName('torus');
	            var crossArrow = this.getObjectByName('crossArrow');
	            this.torusPosition = torusObject.position;
	            this.remove(torusObject);
	            this.remove(crossArrow);
	            (0, _destroyThreeObjectJs2['default'])(torusObject);
	            this.draw(true);
	        }
	    }, {
	        key: 'updateArc',
	        value: function updateArc() {
	            var torusObject = this.getObjectByName('torus');
	            var crossArrow = this.getObjectByName('crossArrow');
	            this.torusPosition = torusObject.position;
	            this.remove(torusObject);
	            this.remove(crossArrow);
	            (0, _destroyThreeObjectJs2['default'])(torusObject);
	            this.draw(true);
	        }
	    }, {
	        key: 'clear',
	        value: function clear(object) {
	            var length = object.children.length;

	            for (var i = 0; i < length; i++) {
	                object.remove(object.children[0]);
	                (0, _destroyThreeObjectJs2['default'])(object.children[0]);
	            }
	        }
	    }]);

	    return _default;
	})();

	exports['default'] = _default;

	function setRegulationCount(value) {
	    exports.regulationCount = regulationCount = value;
	}

/***/ },
/* 50 */
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	exports['default'] = function (point, lineWidth, color, up) {
		console.log(point);
		var arrow = new THREE.Object3D(),
		    verticalSide = new THREE.Shape(),
		    horizonalSide = new THREE.Shape(),
		    lineHeight = lineWidth * 3,
		    verticalGeometry = undefined,
		    horizonalGeometry = undefined,
		    material = new THREE.MeshBasicMaterial({
			color: color,
			transparent: false
		}),
		    verticalMesh = undefined,
		    horizonalMesh = undefined;

		if (up) {
			verticalSide.moveTo(-lineWidth / 2, 0);
			verticalSide.lineTo(-lineWidth / 2, lineHeight);
			verticalSide.lineTo(+lineWidth / 2, lineHeight);
			verticalSide.lineTo(+lineWidth / 2, 0);
			verticalSide.lineTo(-lineWidth / 2, 0);

			horizonalSide.moveTo(-lineHeight + lineWidth / 2, -lineWidth / 2);
			horizonalSide.lineTo(-lineHeight + lineWidth / 2, lineWidth / 2);
			horizonalSide.lineTo(+lineWidth / 2, lineWidth / 2);
			horizonalSide.lineTo(+lineWidth / 2, -lineWidth / 2);
			horizonalSide.lineTo(-lineHeight + lineWidth / 2, -lineWidth / 2);
		} else {
			verticalSide.moveTo(-lineWidth / 2, 0);
			verticalSide.lineTo(-lineWidth / 2, -lineHeight);
			verticalSide.lineTo(+lineWidth / 2, -lineHeight);
			verticalSide.lineTo(+lineWidth / 2, 0);
			verticalSide.lineTo(-lineWidth / 2, 0);

			horizonalSide.moveTo(+lineHeight - lineWidth / 2, -lineWidth / 2);
			horizonalSide.lineTo(+lineHeight - lineWidth / 2, lineWidth / 2);
			horizonalSide.lineTo(-lineWidth / 2, lineWidth / 2);
			horizonalSide.lineTo(-lineWidth / 2, -lineWidth / 2);
			horizonalSide.lineTo(+lineHeight - lineWidth / 2, -lineWidth / 2);
		}

		verticalGeometry = new THREE.ShapeGeometry(verticalSide);
		horizonalGeometry = new THREE.ShapeGeometry(horizonalSide);

		verticalMesh = new THREE.Mesh(verticalGeometry, material);
		horizonalMesh = new THREE.Mesh(horizonalGeometry, material);
		verticalMesh.name = 'tinyArrow';
		horizonalMesh.name = 'tinyArrow';
		arrow.add(verticalMesh);
		arrow.add(horizonalMesh);
		arrow.position.x = point.x;
		arrow.position.y = point.y;
		arrow.name = 'crossArrow';
		arrow.userData.up = up;
		return arrow;
	};

	module.exports = exports['default'];

/***/ },
/* 51 */
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	exports['default'] = function (point, lineWidth, color) {
		var radius = lineWidth * 2,
		    segments = 64,
		    material = new THREE.MeshBasicMaterial({
			color: color
		}),
		    geometry = new THREE.CircleGeometry(radius, segments),
		    circle = new THREE.Mesh(geometry, material);

		circle.position.x = point.x;
		circle.position.y = point.y;

		circle.name = 'outset';
		return circle;
	};

	module.exports = exports['default'];

/***/ },
/* 52 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports["default"] = destroyThreeObject;

	function destroyThreeObject(object) {
	  "use strict";
	  if (!object) return;
	  if (object.children && object.children.length > 0) {
	    for (var i = 0; i < object.children.length; i++) {
	      destroyThreeObject(object.children[i]);
	    }
	  }
	  if (object.geometry) object.geometry.dispose();
	  if (object.material) {
	    object.material.dispose();
	    if (object.material.map && object.material.map.dispose) object.material.map.dispose();
	  }
	  object = null;
	}

	module.exports = exports["default"];

/***/ },
/* 53 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by xcc on 2015/12/23.
	 */
	//let distance = new THREE.Vector3();
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.moveMarkPoint = moveMarkPoint;
	exports.refreshText = refreshText;
	exports.removeMeArray = removeMeArray;
	exports.initArray = initArray;
	exports.changeisFirst = changeisFirst;
	exports.refreshArray = refreshArray;
	exports.getMoveStatus = getMoveStatus;
	exports.setMoveStatus = setMoveStatus;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _addText = __webpack_require__(17);

	var _addText2 = _interopRequireDefault(_addText);

	var _updateUnit = __webpack_require__(31);

	var _ShapeAxisView = __webpack_require__(34);

	var _ShapeAddMarkPoint = __webpack_require__(28);

	var _upMarkPoint = __webpack_require__(54);

	var reMoveObjArray = [];
	var radius = undefined;
	var isFirst = false,
	    isMove = false;

	function moveMarkPoint(selectedObj, distance, shape) {
	    "use strict";
	    var objPosition = selectedObj.position.x;
	    if (!isFirst) {
	        //第一次进入跑，防止加载过多东西卡顿
	        removeMeArray(selectedObj);
	        isFirst = true;
	        isMove = true;
	    }
	    //for (let v = 0; v < reMoveObjArray.length; v++) {
	    //    if (reMoveObjArray[v] != objPosition) {
	    //        //console.log('reMoveObjArray[v]=' + reMoveObjArray[v] + 'radius=' + radius + '   selectedObj.position.x=' + selectedObj.position.x)
	    //        if (Math.abs(objPosition - reMoveObjArray[v]) <= radius * 2) {
	    //            //console.log('跳跳跳跳跳跳跳跳跳跳跳跳跳跳跳跳跳跳跳跳跳跳跳v=' + v)
	    //            selectedObj.position.y = radius * 2;
	    //            break;
	    //        } else {
	    //            //console.log('b不b不b不b不b不b不b不b不b不b不b不b不b不b不b不b不b不b不=' + v)
	    //            selectedObj.position.y = 0
	    //        }
	    //    }
	    //}

	    selectedObj.position.x += distance;

	    if (_presenter2['default'].isTeacherMobile || _presenter2['default'].isStudentMobile) {
	        if (selectedObj.position.x >= shape.data.pointB.x - 25) {
	            selectedObj.position.x = shape.data.pointB.x - 25;
	        } else if (selectedObj.position.x <= shape.data.pointA.x) {
	            selectedObj.position.x = shape.data.pointA.x;
	        }
	    } else {
	        if (selectedObj.position.x >= shape.data.pointB.x - 20) {
	            selectedObj.position.x = shape.data.pointB.x - 20;
	        } else if (selectedObj.position.x <= shape.data.pointA.x) {
	            selectedObj.position.x = shape.data.pointA.x;
	        }
	    }

	    //refreshText(selectedObj,unitLengthSend);
	}

	function refreshText(selectedObj, unitLengthSend) {
	    var markPointValue = selectedObj.getObjectByName('markPointValue');
	    var position = new THREE.Vector2();
	    position.x = markPointValue.position.x;
	    position.y -= unitHeight + 15;
	    var currentX = selectedObj.position.x;
	    if (markPointValue) markPointValue.parent.remove(markPointValue);
	    var value = currentX / unitLengthSend;
	    var round = Math.round(value * 10) / 10;
	    if (parseInt(round) == round) {
	        round = '';
	    }
	    var msgMarkValue = (0, _addText2['default'])(round, position, 32, 32, '15px', 'red'); //标识点具体的值
	    msgMarkValue.name = 'markPointValue';
	    selectedObj.add(msgMarkValue);
	}

	function removeMeArray(selectedObj) {
	    var reMoveObjArray = [];
	    var objPosition = selectedObj.position.x;
	    (0, _upMarkPoint.saveObjPosition)(objPosition);
	    var positionCollection = (0, _ShapeAddMarkPoint.getPositionCollection)();
	    if (positionCollection.length > 0) {
	        for (var v = 0; v < positionCollection.length; v++) {
	            if (positionCollection[v] != objPosition) {
	                reMoveObjArray.push(positionCollection[v]); //移除容器中当前位置的元素，因为移动过程中不需要与你比较
	            }
	        }
	    }
	    console.log('我在removeMeArray');
	    console.log('objPosition');
	    console.log(objPosition);
	    (0, _ShapeAddMarkPoint.refreshPositionCollection)(reMoveObjArray);
	}

	function initArray(selectedObj) {
	    //console.log('initArray');
	    reMoveObjArray = [];
	    if (selectedObj.name == 'markPoint') {
	        radius = _ShapeAxisView.lineWidth * 1.5;
	        var objPosition = selectedObj.position.x;
	        var positionCollection = (0, _ShapeAddMarkPoint.getPositionCollection)();
	        //console.log('positionCollection')
	        //console.log(positionCollection);
	        if (positionCollection.length > 0) {
	            for (var v = 0; v < positionCollection.length; v++) {
	                if (positionCollection[v] != objPosition) {
	                    reMoveObjArray.push(positionCollection[v]); //移除容器中当前位置的元素，因为移动过程中不需要与你比较
	                }
	            }
	        }
	        (0, _ShapeAddMarkPoint.refreshPositionCollection)(reMoveObjArray);
	        //console.log('reMoveObjArray')
	        //console.log(reMoveObjArray);
	    }
	}

	function changeisFirst() {
	    //每次移动抬起up的时候都得还原一些设置。
	    if (isFirst) isFirst = false;
	    reMoveObjArray = [];
	}

	function refreshArray(group) {
	    console.log('refreshArray');
	    //console.log(group)
	    //刷新容器，每次抬起都得刷新，如果以移动标识点，抬起的时候位置已经发生变化
	    var groupChileren = group.children;
	    var array = [];
	    for (var v = 0; v < groupChileren.length; v++) {
	        if (groupChileren[v].name == 'markPoint') {
	            array.push(groupChileren[v].position.x);
	        }
	    }
	    if (array.length > 0) {
	        (0, _ShapeAddMarkPoint.refreshPositionCollection)(array);
	    }
	}

	function getMoveStatus() {
	    return isMove;
	}

	function setMoveStatus(status) {
	    isMove = status;
	}

/***/ },
/* 54 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by xcc on 2016/1/5.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.upMarkPoint = upMarkPoint;
	exports.saveObjPosition = saveObjPosition;

	var _handleCallback = __webpack_require__(55);

	var _ShapeAddMarkPoint = __webpack_require__(28);

	var _moveMarkPoint = __webpack_require__(53);

	var _updateUnit = __webpack_require__(31);

	function upMarkPoint(selectedObj, positionCollection, parent) {
	    var status = (0, _moveMarkPoint.getMoveStatus)();
	    if (!status) {
	        console.log('你没有移动unitLengthSend=' + _updateUnit.unitLengthSend);

	        return;
	    }
	    var radius = _handleCallback.lineWidth * 1.5;
	    var positionX = selectedObj.parent.position.x;

	    for (var v = 0; v < positionCollection.length; v++) {
	        if (Math.abs(positionX - positionCollection[v]) < radius * 2) {
	            //如果位置小于两个圆心半径，说明重叠了
	            if (objPosition > positionX) {
	                //右到左
	                if (positionCollection[v] - radius * 2 <= parent.data.pointA.x) {
	                    //console.log('超过A点')
	                    //移动后的位置最终超过A点，则往回啦
	                    var distance = getTheDistance();
	                    selectedObj.parent.position.x = positionCollection[v] + distance;
	                    (0, _moveMarkPoint.refreshArray)(selectedObj.parent.parent);
	                    var refrsh = (0, _ShapeAddMarkPoint.getPositionCollection)();
	                    objPosition = positionCollection[v] - radius * 2; //只是为了前面比较，让程序知道是要从左到右
	                    var removeRelative = removePointToArray(refrsh, positionCollection[v]); //移除你相对于哪天参考点的标的标识点
	                    var removeOwn = removePointToArray(removeRelative, selectedObj.parent.position.x); //因为刷新了容器，你还要移除你自己的最新位置
	                    upMarkPoint(selectedObj, removeOwn, parent);
	                    (0, _moveMarkPoint.refreshText)(selectedObj.parent, _updateUnit.unitLengthSend); // 因为break了，所以得更新下放数值
	                    break;
	                } else {
	                    var distance = getTheDistance();
	                    selectedObj.parent.position.x = positionCollection[v] - distance;
	                }
	            } else {
	                //左到右
	                console.log('positionCollection[v] + radius * 2=' + (positionCollection[v] + radius * 2));
	                console.log('parent.data.pointB.x=' + parent.data.pointB.x);
	                if (positionCollection[v] + radius * 2 >= parent.data.pointB.x) {
	                    //console.log('超过B点')
	                    //console.log('selectedObj.parent.position.x=' + selectedObj.parent.position.x);
	                    //移动后的位置最终超过B点，则往回啦
	                    var distance = getTheDistance();
	                    selectedObj.parent.position.x = positionCollection[v] - distance;
	                    (0, _moveMarkPoint.refreshArray)(selectedObj.parent.parent);
	                    var refrsh = (0, _ShapeAddMarkPoint.getPositionCollection)();
	                    objPosition = parent.data.pointB.x; //只是为了前面比较，让程序知道是要从右到左
	                    var removeRelative = removePointToArray(refrsh, positionCollection[v]); //移除你相对于哪天参考点的标的标识点
	                    var removeOwn = removePointToArray(removeRelative, selectedObj.parent.position.x); //因为刷新了容器，你还要移除你自己的最新位置
	                    upMarkPoint(selectedObj, removeOwn, parent);
	                    (0, _moveMarkPoint.refreshText)(selectedObj.parent, _updateUnit.unitLengthSend); // 因为break了，所以得更新下放数值
	                    break;
	                } else {
	                    var distance = getTheDistance();
	                    selectedObj.parent.position.x = positionCollection[v] + distance;
	                }
	            }
	            var replace = removePointToArray(positionCollection, positionCollection[v]);
	            upMarkPoint(selectedObj, replace, parent);
	            (0, _moveMarkPoint.refreshText)(selectedObj.parent, _updateUnit.unitLengthSend);
	        }
	    }
	}

	var objPosition = undefined;
	function getTheDistance() {
	    //基于要显示在刻度上，得到的回弹距离
	    var distance = undefined;
	    var radius = _handleCallback.lineWidth * 1.5;
	    var smallUnit = _updateUnit.unitLengthSend / 10;
	    for (var v = 1; v < 5; v++) {
	        if (smallUnit * v >= radius * 2) {
	            distance = smallUnit * v;
	            break;
	        }
	    }
	    return distance;
	}

	function saveObjPosition(position) {
	    objPosition = position;
	}

	function removePointToArray(array, position) {
	    var remove = [];
	    var isOne = true;
	    for (var v = 0; v < array.length; v++) {
	        if (array[v] == position) {
	            //特殊情况会出现容器里有两个位置一样的，所以只要排除一个就行，别的都加入容器。
	            if (!isOne) remove.push(position);
	            isOne = false;
	        } else {
	            remove.push(array[v]);
	        }
	    }
	    return remove;
	}

/***/ },
/* 55 */
/***/ function(module, exports) {

	/* global $ */
	"use strict";

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	exports["default"] = function (eventData) {
	  "use strict";
	};

	module.exports = exports["default"];
	/**
	 接收到 native 端的消息并处理
	 * @param eventData {object} {item: 'click', value: 'FourEdges'}
	 */

/***/ },
/* 56 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 编辑标识点
	 * Created by xcc on 2015/12/29.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.editeMarkPointText = editeMarkPointText;
	exports.getAllowBoolean = getAllowBoolean;
	exports.writeMarkPointText = writeMarkPointText;
	exports.resetText = resetText;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _UtilsAddText = __webpack_require__(17);

	var _UtilsAddText2 = _interopRequireDefault(_UtilsAddText);

	var _ShapeAddMarkPoint = __webpack_require__(28);

	var _UtilsDialog = __webpack_require__(12);

	var _UtilsDialog2 = _interopRequireDefault(_UtilsDialog);

	var inputValue = undefined,
	    markPoint = undefined,
	    isWrited = undefined,
	    originalText = undefined,
	    nowText = undefined,
	    isAllowed = true;

	function editeMarkPointText(selectedObj, isOpen) {
	    //console.log('editeMarkPointText')
	    if (isOpen) {
	        markPoint = selectedObj.parent;
	        var markPointFrame = markPoint.getObjectByName('markPointFrame');
	        markPointFrame.visible = true;
	        $('.markpoint-input').attr('readonly', false).val('').focus();
	    } else {
	        if (markPoint) {
	            //如果按下了
	            if (isWrited) {
	                //如果你编辑了
	                (0, _ShapeAddMarkPoint.clear)(originalText); //移除你本身自带的text
	                var isExist = checkIsEsixt(nowText); //检测你编辑后的是否已经存在容器
	                if (isExist) {
	                    //存在相同标识点,停止一切标识点的其他操作
	                    _UtilsDialog2['default'].tips('发现存在相同标识点，禁止其他操作');
	                    $('.markpoint-input').attr('readonly', false).val('').focus();
	                    isAllowed = false;
	                    //dialog.msg('hahahaaha')
	                } else {
	                        //不存在相同标识点
	                        $('.markpoint-input').attr('readonly', true).val(''); //input失去焦点
	                        (0, _ShapeAddMarkPoint.add)(nowText);
	                        markPoint.userData.markText = nowText;
	                        setFrameDisEnable(selectedObj);
	                        isWrited = false;
	                        isAllowed = true;
	                    }
	            } else {
	                $('.markpoint-input').attr('readonly', true).val(''); //input失去焦点
	                setFrameDisEnable(selectedObj);
	                //console.log('没有编辑')
	            }
	            var CharCollection = (0, _ShapeAddMarkPoint.getCharCollection)();
	            //console.log('此时char容器有')
	            //console.log(CharCollection)
	        }
	    }
	}

	function getAllowBoolean() {
	    return isAllowed;
	}

	function checkIsEsixt(text) {
	    //检查某一个元素在char容器是否存在
	    var charCollect = (0, _ShapeAddMarkPoint.getCharCollection)();
	    for (var v = 0; v < charCollect.length; v++) {
	        if (charCollect[v] == text) return true;
	    }
	    return false;
	}
	function setFrameDisEnable(selectedObj) {
	    //以下为隐藏所有外框
	    var markPointArray = [];
	    var markPointF = selectedObj.children;
	    for (var v = 0; v < markPointF.length; v++) {
	        if (markPointF[v].name == 'markPoint') {
	            var frame = markPointF[v].getObjectByName('markPointFrame');
	            markPointArray.push(frame);
	        }
	    }
	    for (var i = 0; i < markPointArray.length; i++) {
	        var frame = markPointArray[i];
	        frame.visible = false;
	    }
	}

	function writeMarkPointText(input) {
	    inputValue = input.value.toString();
	    console.log('inputValue=' + inputValue);
	    if (inputValue.length > 3) {
	        console.log("请输入三位数以内的标识点");
	        inputValue = inputValue.substring(0, 3);
	        input.value = inputValue;
	        return;
	    }
	    isWrited = true;
	    var markPointText = markPoint.getObjectByName('markPointText'); //group里的text对象
	    var markText = markPoint.userData.markText; //携带的text值
	    originalText = markText;
	    nowText = inputValue;
	    var position = markPointText.position;
	    var msgMarkLetter = (0, _UtilsAddText2['default'])(inputValue, position, 32, 32, '15px', 'black'); //字母ABC
	    msgMarkLetter.name = 'markPointText';
	    markPointText.parent.add(msgMarkLetter);
	    markPointText.parent.remove(markPointText);
	}

	function resetText() {
	    originalText = null;
	}

/***/ },
/* 57 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/12/31.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.setMaxSize = setMaxSize;
	exports.decoData = decoData;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _constants = __webpack_require__(4);

	var _threeManger = __webpack_require__(10);

	var _UtilsToolbar = __webpack_require__(11);

	var _NumberLine = __webpack_require__(35);

	var _NumberLine2 = _interopRequireDefault(_NumberLine);

	var _OperationMarkPoint = __webpack_require__(36);

	var _OperationMarkPoint2 = _interopRequireDefault(_OperationMarkPoint);

	var _MarkPoint = __webpack_require__(30);

	var _MarkPoint2 = _interopRequireDefault(_MarkPoint);

	var _UtilsUpdateUnit = __webpack_require__(31);

	var _UtilsUpdateUnit2 = _interopRequireDefault(_UtilsUpdateUnit);

	var _UtilsAddCurve = __webpack_require__(49);

	var _UtilsAddCurve2 = _interopRequireDefault(_UtilsAddCurve);

	var _UtilsUpdateUnitNum = __webpack_require__(38);

	var _UtilsUpdateUnitNum2 = _interopRequireDefault(_UtilsUpdateUnitNum);

	var _EventDocumentEvent = __webpack_require__(9);

	var _EventDocumentEvent2 = _interopRequireDefault(_EventDocumentEvent);

	var _moduleControl = __webpack_require__(6);

	var _AxisView = __webpack_require__(34);

	var _ShapeAddMarkPoint = __webpack_require__(28);

	var _ShapePoint = __webpack_require__(18);

	var _ShapePoint2 = _interopRequireDefault(_ShapePoint);

	//import {buildTextView} from '../DomView/CalcElementBuilder'

	var _EditorCoordNoteModel = __webpack_require__(40);

	var _EditorCoordNoteModel2 = _interopRequireDefault(_EditorCoordNoteModel);

	var _EditorCoordNumberModel = __webpack_require__(45);

	var _EditorCoordNumberModel2 = _interopRequireDefault(_EditorCoordNumberModel);

	var _EditorCalcNoteModel = __webpack_require__(46);

	var _EditorCalcNoteModel2 = _interopRequireDefault(_EditorCalcNoteModel);

	var _EditorCalcNumberModel = __webpack_require__(48);

	var _EditorCalcNumberModel2 = _interopRequireDefault(_EditorCalcNumberModel);

	var maxSize = 4;
	exports.maxSize = maxSize;

	function setMaxSize(value) {
	    exports.maxSize = maxSize = value;
	}

	function decoData() {
	    $(_presenter2['default'].view).find('.com_u_boardtit').html(_presenter2['default'].model.question_url.title); //标题设置
	    //REAL_ESTATE.width = $(presenter.view).find('.com_lay_board').width();
	    //REAL_ESTATE.height = $(presenter.view).find('.com_lay_board').height();
	    var examModel = (0, _moduleControl.getAxisExamModel)();
	    var examType = examModel.examType;
	    if (!examModel) {
	        console.log('unexpect ExamModel');
	        return;
	    }
	    if (examType == _constants.EXAM_TYPE.Coord_Point_Note) {
	        //new CoordNoteModel().create(examModel.valueArray);
	        _UtilsToolbar.toolbarStatus._action = 'mark';
	        (0, _AxisView.init)(examModel.isInteger);
	        (0, _EventDocumentEvent2['default'])();
	    } else if (examType == _constants.EXAM_TYPE.Coord_Point_Number) {
	        _UtilsToolbar.toolbarStatus._action = 'mark';
	        (0, _AxisView.init)(examModel.isInteger);
	        $.each(examModel.valueArray, function (i, item) {
	            var point = new THREE.Vector3();
	            if (examModel.isInteger) {
	                point.x = item * _AxisView.unitLength - _AxisView.offsetX; //use new
	            } else {
	                    point.x = item * _AxisView.unitLength;
	                }
	            point.y = 0;
	            point.z = 0;
	            (0, _ShapeAddMarkPoint.AddMarkPoint)(point);
	        });
	        _presenter2['default'].renderer();
	        //DocumentEvent();
	    } else if (examType == _constants.EXAM_TYPE.Calculate_Note) {
	            _UtilsToolbar.toolbarStatus._action = 'regulation';
	            console.log('this is length ', examModel.valueArray);
	            if (examModel.valueArray.length == 2) {
	                _UtilsToolbar.toolbarStatus.lineColor = ['#03ACF6'];
	            } else if (examModel.valueArray.length == 3) {
	                _UtilsToolbar.toolbarStatus.lineColor = ['#03ACF6', '#00AE9D'];
	            }
	            (0, _AxisView.init)(examModel.isInteger);
	            var _parent = _threeManger.scene.getObjectByName("group");
	            var width = _parent.data.lineWidth * 1.5;
	            var startPoint = examModel.valueArray[0];
	            if (examModel.valueArray.length == 2) {
	                _UtilsToolbar.toolbarStatus.lineColor = ['#03ACF6', '#00AE9D'];
	            } else if (examModel.valueArray.length == 3) {
	                _UtilsToolbar.toolbarStatus.lineColor = ['#03ACF6', '#00AE9D', '#0372D2'];
	            }
	            _UtilsToolbar.toolbarStatus.startPoint = (0, _ShapePoint2['default'])(width, _constants.baseColor, _parent.data.smallUnitVisible ? pointText : undefined, new THREE.Vector2(0, -30));
	            _UtilsToolbar.toolbarStatus.startPoint.position.x = startPoint * _AxisView.unitLength;
	            examModel.setUserRes([startPoint]);
	            _UtilsToolbar.toolbarStatus.startPoint.name = 'outset';
	            _parent.add(_UtilsToolbar.toolbarStatus.startPoint);
	            _presenter2['default'].renderer();
	            (0, _EventDocumentEvent2['default'])();
	        } else if (examType == _constants.EXAM_TYPE.Calculate_Number) {
	            (0, _AxisView.init)(examModel.isInteger);
	            var _parent2 = _threeManger.scene.getObjectByName("group");
	            var value = examModel.valueArray;
	            var symbol = examModel.symbolArray;
	            console.log(value, 'value', symbol);
	            var width = undefined;
	            if (examModel.valueArray.length == 2) {
	                _UtilsToolbar.toolbarStatus.lineColor = ['#03ACF6', '#00AE9D'];
	            } else if (examModel.valueArray.length == 3) {
	                _UtilsToolbar.toolbarStatus.lineColor = ['#03ACF6', '#00AE9D', '#0372D2'];
	            }
	            var temp = undefined;
	            for (var i = 0; i < symbol.length; i++) {
	                if (i == 0) {
	                    width = _parent2.data.lineWidth * 1.3;
	                    _UtilsToolbar.toolbarStatus.startPoint = (0, _ShapePoint2['default'])(width, 'customize', _parent2.data.smallUnitVisible ? pointText : undefined, new THREE.Vector2(0, -30));
	                    _UtilsToolbar.toolbarStatus.startPoint.position.x = value[i] * _AxisView.unitLength;
	                } else {
	                    width = _parent2.data.lineWidth;
	                    _UtilsToolbar.toolbarStatus.startPoint = _UtilsToolbar.toolbarStatus.endPoint;
	                }
	                _UtilsToolbar.toolbarStatus.endPoint = (0, _ShapePoint2['default'])(_parent2.data.lineWidth, _constants.baseColor, _parent2.data.smallUnitVisible ? pointText : undefined, new THREE.Vector2(0, -30));
	                if (symbol[i] > 0) {
	                    if (temp === undefined) {
	                        _UtilsToolbar.toolbarStatus.endPoint.position.x = (value[i] + value[i + 1]) * _AxisView.unitLength;
	                        temp = value[i] + value[i + 1];
	                    } else {
	                        console.log('this is temp', temp);
	                        _UtilsToolbar.toolbarStatus.endPoint.position.x = (temp + value[i + 1]) * _AxisView.unitLength;
	                    }
	                } else if (symbol[i] < 0) {
	                    if (temp === undefined) {
	                        _UtilsToolbar.toolbarStatus.endPoint.position.x = (value[i] - value[i + 1]) * _AxisView.unitLength;
	                        temp = value[i] - value[i + 1];
	                    } else {
	                        console.log('this is temp', temp);
	                        _UtilsToolbar.toolbarStatus.endPoint.position.x = (temp - value[i + 1]) * _AxisView.unitLength;
	                    }
	                }
	                var curve = new _UtilsAddCurve2['default'](_UtilsToolbar.toolbarStatus, _parent2.position, _parent2.data.unitLength / _parent2.data.unitMultiple);
	                curve.add(_UtilsToolbar.toolbarStatus.startPoint);
	                curve.add(_UtilsToolbar.toolbarStatus.endPoint);
	                _parent2.add(curve);
	                _presenter2['default'].renderer();
	            }
	        } else {
	            console.log('error when decode data');
	            return;
	        }
	}

/***/ },
/* 58 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _updateVertices = __webpack_require__(21);

	var _updateVertices2 = _interopRequireDefault(_updateVertices);

	var _updateUnit = __webpack_require__(31);

	var _updateUnit2 = _interopRequireDefault(_updateUnit);

	exports['default'] = function (type, shape, touchShape) {
	  var controllerDis = undefined,
	      pointA = undefined,
	      pointB = undefined,
	      line = undefined,
	      unitMultiple = undefined,
	      unitLength = undefined,
	      lineWidth = undefined,
	      arrow = undefined;
	  line = shape.getObjectByName('line');
	  arrow = shape.getObjectByName('arrow');
	  pointA = shape.data.pointA;
	  pointB = shape.data.pointB;
	  controllerDis = shape.data.controllerDis;
	  unitMultiple = shape.data.unitMultiple;
	  unitLength = shape.data.unitLength;
	  lineWidth = shape.data.lineWidth;
	  if (type === 'controllerRight') {
	    pointB = new THREE.Vector3(touchShape.position.x - controllerDis, pointB.y, pointB.z);
	    shape.data.pointB = pointB;
	    arrow.position.copy(pointB);
	  } else if (type === 'controllerLeft') {
	    pointA = new THREE.Vector3(touchShape.position.x + controllerDis, pointA.y, pointA.z);
	    shape.data.pointA = pointA;
	  }

	  (0, _updateVertices2['default'])(line, pointA, pointB, lineWidth);
	  (0, _updateVertices2['default'])(shape, pointA, pointB, lineWidth * 5);
	  (0, _updateUnit2['default'])(shape, pointA, pointB, unitMultiple, unitLength, lineWidth);
	};

	module.exports = exports['default'];

/***/ },
/* 59 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _UtilsUpdateVertices = __webpack_require__(21);

	var _UtilsUpdateVertices2 = _interopRequireDefault(_UtilsUpdateVertices);

	var _UtilsUpdateUnit = __webpack_require__(31);

	var _UtilsUpdateUnit2 = _interopRequireDefault(_UtilsUpdateUnit);

	exports['default'] = function (shape, touchShape, intersectsDis) {
	    var line = shape.getObjectByName('line');
	    var controllerLeft = shape.getObjectByName('controllerLeft');
	    var controllerRight = shape.getObjectByName('controllerRight');
	    var arrow = shape.getObjectByName('arrow');
	    var circleCenter = shape.getObjectByName('center');
	    var center = new THREE.Vector3(0, 0, 0);
	    var vectorCB = new THREE.Vector2().subVectors(center, shape.data.pointB);
	    var vectorCA = new THREE.Vector2().subVectors(center, shape.data.pointA);
	    var unitCACount = parseInt(vectorCA.length() / shape.data.unitLength);
	    var unitCBCount = parseInt(vectorCB.length() / shape.data.unitLength);
	    var unitCARemain = vectorCA.length() % shape.data.unitLength / shape.data.unitLength;
	    var unitCBRemain = vectorCB.length() % shape.data.unitLength / shape.data.unitLength;
	    touchShape.position.x += intersectsDis;
	    if (touchShape.position.x <= 40) {
	        touchShape.position.x = 40;
	    } else if (touchShape.position.x >= 300) {
	        touchShape.position.x = 300;
	    }
	    shape.data.unitLength = touchShape.position.x;
	    shape.data.pointA.x = -(unitCACount + unitCARemain) * shape.data.unitLength;
	    shape.data.pointB.x = (unitCBCount + unitCBRemain) * shape.data.unitLength;
	    arrow.position.copy(shape.data.pointB);
	    controllerLeft.position.x = shape.data.pointA.x - shape.data.controllerDis;
	    controllerRight.position.x = shape.data.pointB.x + shape.data.controllerDis;
	    (0, _UtilsUpdateVertices2['default'])(line, shape.data.pointA, shape.data.pointB, shape.data.lineWidth);
	    (0, _UtilsUpdateVertices2['default'])(shape, shape.data.pointA, shape.data.pointB, shape.data.lineWidth * 5);
	    (0, _UtilsUpdateUnit2['default'])(shape, shape.data.pointA, shape.data.pointB, shape.data.unitMultiple, shape.data.unitLength, shape.data.lineWidth);
	};

	module.exports = exports['default'];

/***/ },
/* 60 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _UtilsUpdateUnit = __webpack_require__(31);

	var _UtilsUpdateUnit2 = _interopRequireDefault(_UtilsUpdateUnit);

	exports['default'] = function (shape, bool) {
	  var text = undefined,
	      select = undefined,
	      pointA = undefined,
	      pointB = undefined,
	      unitMultiple = undefined,
	      unitLength = undefined,
	      lineWidth = undefined;
	  text = shape.getObjectByName('showText');
	  select = shape.getObjectByName('unitSelect');
	  pointA = shape.data.pointA;
	  pointB = shape.data.pointB;
	  unitMultiple = shape.data.unitMultiple;
	  unitLength = shape.data.unitLength;
	  lineWidth = shape.data.lineWidth;

	  if (!bool) {
	    $('.numberline-input').attr('readonly', true);
	    select.visible = false;
	    (0, _UtilsUpdateUnit2['default'])(shape, pointA, pointB, unitMultiple, unitLength, lineWidth);
	  } else {
	    $('.numberline-input').attr('readonly', false).val(unitMultiple).focus();
	    select.visible = true;
	    select.position.x = unitLength;
	  }
	};

	module.exports = exports['default'];

/***/ },
/* 61 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _updateVertices = __webpack_require__(21);

	var _updateVertices2 = _interopRequireDefault(_updateVertices);

	var _computeSection = __webpack_require__(23);

	var _computeSection2 = _interopRequireDefault(_computeSection);

	var _toolbar = __webpack_require__(11);

	var _refreshSection = __webpack_require__(26);

	var _refreshSection2 = _interopRequireDefault(_refreshSection);

	exports['default'] = function (currShape, dis, mouseType) {
	  var shape = undefined,
	      intersection = undefined,
	      union = undefined;
	  shape = currShape.parent;
	  intersection = shape.parent.getObjectByName('intersection');
	  union = shape.parent.getObjectByName('union');
	  if (mouseType == 'up') {
	    sectionPile(shape, currShape);
	    (0, _refreshSection2['default'])(shape.parent);
	  } else {
	    sectionScope(shape, currShape, dis);
	    (0, _refreshSection2['default'])(shape.parent);
	  }
	};

	// 区间范围控制
	function sectionScope(shape, currShape, dis) {
	  var lineWidth = undefined,
	      startHeight = undefined,
	      endHeight = undefined,
	      startSide = undefined,
	      endSide = undefined,
	      startPoint = undefined,
	      endPoint = undefined,
	      sectionLine = undefined,
	      startSideVector = undefined,
	      endSideVector = undefined,
	      sectionText = undefined,
	      sectionColor = undefined,
	      text = undefined,
	      group = undefined,
	      startArr = [],
	      endArr = [];
	  group = shape.parent;
	  lineWidth = group.data.lineWidth;
	  startHeight = shape.data.startHeight;
	  endHeight = shape.data.endHeight;
	  startSideVector = shape.data.startSideVector;
	  endSideVector = shape.data.endSideVector;
	  sectionColor = shape.data.sectionColor;
	  startSide = shape.getObjectByName('startSide');
	  endSide = shape.getObjectByName('endSide');
	  startPoint = shape.getObjectByName('startPoint');
	  endPoint = shape.getObjectByName('endPoint');
	  sectionLine = shape.getObjectByName('sectionLine');
	  sectionText = shape.getObjectByName('sectionText');
	  switch (currShape.name) {
	    case 'startPoint':
	      startPoint.position.y = 0;
	      if (!_toolbar.toolbarStatus.refreshStartPoints) {
	        // 获取该端点上相同x坐标的点
	        startArr = getPile(startPoint, endPoint).startArr;
	        if (startArr.length > 0) {
	          // 更新该端点上相同x坐标的区间
	          updatePile(startArr, lineWidth);
	        }
	        _toolbar.toolbarStatus.refreshStartPoints = true;
	      }

	      if (startPoint.position.x + dis >= group.data.pointA.x && startPoint.position.x + dis <= group.data.pointB.x) {
	        startPoint.position.x += dis;
	        startSideVector.x = startPoint.position.x;
	      }
	      if (endPoint.position.y > startPoint.position.y) {
	        startHeight = startHeight + endPoint.position.y - startPoint.position.y; // 求出开始边应有高度  
	      }
	      startSideVector.y = startHeight - lineWidth / 2;
	      endSideVector.y = endHeight + endPoint.position.y - lineWidth / 2;
	      break;
	    case 'endPoint':
	      endPoint.position.y = 0;
	      if (!_toolbar.toolbarStatus.refreshEndPoints) {
	        // 获取该端点上相同x坐标的点
	        endArr = getPile(startPoint, endPoint).endArr;
	        if (endArr.length > 0) {
	          // 更新该端点上相同x坐标的区间
	          updatePile(endArr, lineWidth);
	        }
	        _toolbar.toolbarStatus.refreshEndPoints = true;
	      }
	      if (endPoint.position.x + dis >= group.data.pointA.x && endPoint.position.x + dis <= group.data.pointB.x) {
	        endPoint.position.x += dis;
	        endSideVector.x = endPoint.position.x;
	      }
	      if (endPoint.position.y < startPoint.position.y) {
	        endHeight = endHeight + startPoint.position.y - endPoint.position.y; // 求出结束边应有高度  
	      }
	      startSideVector.y = startHeight + startPoint.position.y - lineWidth / 2;
	      endSideVector.y = endHeight - lineWidth / 2;
	      break;
	    case 'startSide':
	    case 'endSide':
	    case 'sectionLine':
	    case 'sectionText':
	      startPoint.position.y = 0;
	      endPoint.position.y = 0;
	      if (!_toolbar.toolbarStatus.refreshStartPoints) {
	        // 获取该端点上相同x坐标的点
	        startArr = getPile(startPoint, endPoint).startArr;
	        if (startArr.length > 0) {
	          // 更新该端点上相同x坐标的区间
	          updatePile(startArr, lineWidth);
	        }
	        _toolbar.toolbarStatus.refreshStartPoints = true;
	      }
	      if (!_toolbar.toolbarStatus.refreshEndPoints) {
	        // 获取该端点上相同x坐标的点
	        endArr = getPile(startPoint, endPoint).endArr;
	        if (endArr.length > 0) {
	          // 更新该端点上相同x坐标的区间
	          updatePile(endArr, lineWidth);
	        }
	        _toolbar.toolbarStatus.refreshEndPoints = true;
	      }
	      if (startPoint.position.x <= endPoint.position.x) {
	        if (startPoint.position.x + dis >= group.data.pointA.x && endPoint.position.x + dis <= group.data.pointB.x) {
	          startPoint.position.x += dis;
	          endPoint.position.x += dis;
	        } else {
	          return true;
	        }
	      } else {
	        if (startPoint.position.x + dis <= group.data.pointB.x && endPoint.position.x + dis >= group.data.pointA.x) {
	          startPoint.position.x += dis;
	          endPoint.position.x += dis;
	        } else {
	          return true;
	        }
	      }
	      startSideVector.x = startPoint.position.x;
	      endSideVector.x = endPoint.position.x;
	      startSideVector.y = startHeight - lineWidth / 2;
	      endSideVector.y = endHeight - lineWidth / 2;
	      break;
	  }

	  // 更新区间三条线
	  (0, _updateVertices2['default'])(startSide, startPoint.position, new THREE.Vector3(startPoint.position.x, startPoint.position.y + startHeight, 0), lineWidth);
	  (0, _updateVertices2['default'])(endSide, endPoint.position, new THREE.Vector3(endPoint.position.x, endPoint.position.y + endHeight, 0), lineWidth);
	  (0, _updateVertices2['default'])(sectionLine, startSideVector, endSideVector, lineWidth);
	  // 计算应该显示的文字
	  text = (0, _computeSection2['default'])(shape, startSideVector, endSideVector);
	  // 刷新文字
	  sectionText._dynamicTexture.clear().drawText(text, undefined, 16, sectionColor);
	  sectionText.position.x = (startSideVector.x + endSideVector.x) / 2;
	  sectionText.position.y = startSideVector.y + 15;
	  shape.data.startSideVector = startSideVector;
	  shape.data.endSideVector = endSideVector;
	}

	// 同区间两点弹开
	function sectionFlick(shape, currShape) {
	  var lineWidth = undefined,
	      startHeight = undefined,
	      endHeight = undefined,
	      startSide = undefined,
	      endSide = undefined,
	      startPoint = undefined,
	      endPoint = undefined,
	      sectionLine = undefined,
	      startSideVector = undefined,
	      endSideVector = undefined,
	      sectionText = undefined,
	      sectionColor = undefined,
	      text = undefined,
	      group = undefined,
	      distanceX = undefined,
	      unitLength = undefined,
	      smallUnitVisible = undefined;
	  group = shape.parent;
	  smallUnitVisible = group.data.smallUnitVisible;
	  lineWidth = group.data.lineWidth;
	  unitLength = group.data.unitLength;
	  startHeight = shape.data.startHeight;
	  endHeight = shape.data.endHeight;
	  startSideVector = shape.data.startSideVector;
	  endSideVector = shape.data.endSideVector;
	  sectionColor = shape.data.sectionColor;
	  startSide = shape.getObjectByName('startSide');
	  endSide = shape.getObjectByName('endSide');
	  startPoint = shape.getObjectByName('startPoint');
	  endPoint = shape.getObjectByName('endPoint');
	  sectionLine = shape.getObjectByName('sectionLine');
	  sectionText = shape.getObjectByName('sectionText');

	  if (smallUnitVisible) {
	    distanceX = unitLength / 10;
	  } else {
	    distanceX = unitLength;
	  }
	  if (currShape.name == 'startPoint') {
	    if (distanceX >= 3 * lineWidth) {
	      if (startPoint.position.x >= endPoint.position.x - 3 * lineWidth && startPoint.position.x <= endPoint.position.x) {
	        if (endPoint.position.x - distanceX >= group.data.pointA.x) {
	          startPoint.position.x = endPoint.position.x - distanceX;
	        } else {
	          startPoint.position.x = endPoint.position.x + distanceX;
	        }
	      }
	      if (startPoint.position.x <= endPoint.position.x + 3 * lineWidth && startPoint.position.x > endPoint.position.x) {
	        if (endPoint.position.x + distanceX <= group.data.pointB.x) {
	          startPoint.position.x = endPoint.position.x + distanceX;
	        } else {
	          startPoint.position.x = endPoint.position.x - distanceX;
	        }
	      }
	    } else {
	      var count = Math.ceil(3 * lineWidth / distanceX);
	      if (startPoint.position.x >= endPoint.position.x - 3 * lineWidth && startPoint.position.x <= endPoint.position.x) {
	        if (endPoint.position.x - count * distanceX >= group.data.pointA.x) {
	          startPoint.position.x = endPoint.position.x - count * distanceX;
	        } else {
	          startPoint.position.x = endPoint.position.x + count * distanceX;
	        }
	      }
	      if (startPoint.position.x <= endPoint.position.x + 3 * lineWidth && startPoint.position.x > endPoint.position.x) {
	        if (endPoint.position.x + count * distanceX <= group.data.pointB.x) {
	          startPoint.position.x = endPoint.position.x + count * distanceX;
	        } else {
	          startPoint.position.x = endPoint.position.x - count * distanceX;
	        }
	      }
	    }
	  } else if (currShape.name == 'endPoint') {
	    if (distanceX >= 3 * lineWidth) {
	      if (endPoint.position.x >= startPoint.position.x - 3 * lineWidth && endPoint.position.x <= startPoint.position.x) {
	        if (startPoint.position.x - distanceX >= group.data.pointA.x) {
	          endPoint.position.x = startPoint.position.x - distanceX;
	        } else {
	          endPoint.position.x = startPoint.position.x + distanceX;
	        }
	      }
	      if (endPoint.position.x <= startPoint.position.x + 3 * lineWidth && endPoint.position.x > startPoint.position.x) {
	        if (startPoint.position.x + distanceX <= group.data.pointB.x) {
	          endPoint.position.x = startPoint.position.x + distanceX;
	        } else {
	          endPoint.position.x = startPoint.position.x - distanceX;
	        }
	      }
	    } else {
	      var count = Math.ceil(3 * lineWidth / distanceX);
	      if (endPoint.position.x >= startPoint.position.x - 3 * lineWidth && endPoint.position.x <= startPoint.position.x) {
	        if (startPoint.position.x - count * distanceX >= group.data.pointA.x) {
	          endPoint.position.x = startPoint.position.x - count * distanceX;
	        } else {
	          endPoint.position.x = startPoint.position.x + count * distanceX;
	        }
	      }
	      if (endPoint.position.x <= startPoint.position.x + 3 * lineWidth && endPoint.position.x > startPoint.position.x) {
	        if (startPoint.position.x + count * distanceX <= group.data.pointB.x) {
	          endPoint.position.x = startPoint.position.x + count * distanceX;
	        } else {
	          endPoint.position.x = startPoint.position.x - count * distanceX;
	        }
	      }
	    }
	  } else {
	    if (startPoint.position.x <= endPoint.position.x && startPoint.position.x + 3 * lineWidth > endPoint.position.x) {
	      if (distanceX >= 3 * lineWidth) {
	        if (endPoint.position.x - distanceX >= group.data.pointA.x) {
	          startPoint.position.x -= distanceX;
	        } else {
	          endPoint.position.x += distanceX;
	        }
	      } else {
	        var count = Math.ceil(3 * lineWidth / distanceX);
	        if (endPoint.position.x - count * distanceX >= group.data.pointA.x) {
	          startPoint.position.x = endPoint.position.x - count * distanceX;
	        } else {
	          endPoint.position.x = startPoint.position.x + count * distanceX;
	        }
	      }
	    } else if (startPoint.position.x > endPoint.position.x && startPoint.position.x - 3 * lineWidth < endPoint.position.x) {
	      if (distanceX >= 3 * lineWidth) {
	        if (startPoint.position.x - distanceX >= group.data.pointA.x) {
	          endPoint.position.x -= distanceX;
	        } else {
	          startPoint.position.x += distanceX;
	        }
	      } else {
	        var count = Math.ceil(3 * lineWidth / distanceX);
	        if (startPoint.position.x - count * distanceX >= group.data.pointA.x) {
	          endPoint.position.x = startPoint.position.x - count * distanceX;
	        } else {
	          startPoint.position.x = endPoint.position.x + count * distanceX;
	        }
	      }
	    }
	  }

	  startSideVector.x = startPoint.position.x;
	  endSideVector.x = endPoint.position.x;

	  // 更新区间三条线
	  (0, _updateVertices2['default'])(startSide, startPoint.position, new THREE.Vector3(startSideVector.x, startHeight, 0), lineWidth);
	  (0, _updateVertices2['default'])(endSide, endPoint.position, new THREE.Vector3(endSideVector.x, endHeight, 0), lineWidth);
	  (0, _updateVertices2['default'])(sectionLine, startSideVector, endSideVector, lineWidth);
	  // 计算应该显示的文字
	  text = (0, _computeSection2['default'])(shape, startSideVector, endSideVector);
	  // 刷新文字
	  sectionText._dynamicTexture.clear().drawText(text, undefined, 16, sectionColor);
	  sectionText.position.x = (startSideVector.x + endSideVector.x) / 2;
	  sectionText.position.y = startSideVector.y + 15;
	  shape.data.startSideVector = startSideVector;
	  shape.data.endSideVector = endSideVector;
	}

	// 向上堆叠区间端点
	function sectionPile(shape, currShape) {
	  var lineWidth = undefined,
	      startHeight = undefined,
	      endHeight = undefined,
	      startSide = undefined,
	      endSide = undefined,
	      startPoint = undefined,
	      endPoint = undefined,
	      sectionLine = undefined,
	      startSideVector = undefined,
	      endSideVector = undefined,
	      sectionText = undefined,
	      sectionColor = undefined,
	      text = undefined,
	      group = undefined,
	      distanceX = undefined,
	      startArr = [],
	      endArr = [];
	  group = shape.parent;
	  lineWidth = group.data.lineWidth;
	  startHeight = shape.data.startHeight;
	  endHeight = shape.data.endHeight;
	  startSideVector = shape.data.startSideVector;
	  endSideVector = shape.data.endSideVector;
	  sectionColor = shape.data.sectionColor;
	  startSide = shape.getObjectByName('startSide');
	  endSide = shape.getObjectByName('endSide');
	  startPoint = shape.getObjectByName('startPoint');
	  endPoint = shape.getObjectByName('endPoint');
	  sectionLine = shape.getObjectByName('sectionLine');
	  sectionText = shape.getObjectByName('sectionText');

	  var mixStartDis = undefined,
	      mixStartPoint = undefined,
	      mixEndDis = undefined,
	      mixEndPoint = undefined;
	  // 计算移动的区间的两个端点与其它端点最近的，以便进行位置堆叠
	  for (var i = 0; i < _toolbar.toolbarStatus.referInterval.length; i++) {
	    var referPoint = _toolbar.toolbarStatus.referInterval[i];
	    if (referPoint.id != startPoint.id && referPoint.id != endPoint.id) {
	      if (!mixStartDis) {
	        mixStartDis = Math.abs(startPoint.position.x - referPoint.position.x);
	        if (mixStartDis < 3 * lineWidth) {
	          mixStartPoint = referPoint;
	        }
	      } else {
	        if (Math.abs(startPoint.position.x - referPoint.position.x) < mixStartDis) {
	          mixStartDis = Math.abs(startPoint.position.x - referPoint.position.x);
	          if (mixStartDis < 3 * lineWidth) {
	            mixStartPoint = referPoint;
	          }
	        }
	      }

	      if (!mixEndDis) {
	        mixEndDis = Math.abs(endPoint.position.x - referPoint.position.x);
	        if (mixEndDis < 3 * lineWidth) {
	          mixEndPoint = referPoint;
	        }
	      } else {
	        if (Math.abs(endPoint.position.x - referPoint.position.x) < mixEndDis) {
	          mixEndDis = Math.abs(endPoint.position.x - referPoint.position.x);
	          if (mixEndDis < 3 * lineWidth) {
	            mixEndPoint = referPoint;
	          }
	        }
	      }
	    }
	  }
	  // 修改区间的x轴位置，方便计算弹开与堆叠
	  if (mixStartPoint) {
	    startPoint.position.x = mixStartPoint.position.x;
	  }
	  if (mixEndPoint) {
	    endPoint.position.x = mixEndPoint.position.x;
	  }
	  // 弹开同区间两个端点
	  sectionFlick(shape, currShape);

	  // 计算区间端点位置上堆叠的端点数量
	  for (var i = 0; i < _toolbar.toolbarStatus.referInterval.length; i++) {
	    var referPoint = _toolbar.toolbarStatus.referInterval[i];
	    if (referPoint.id != startPoint.id && referPoint.id != endPoint.id) {
	      if (startPoint.position.x - referPoint.position.x == 0) {
	        startArr.push(referPoint);
	      }
	      if (endPoint.position.x - referPoint.position.x == 0) {
	        endArr.push(referPoint);
	      }
	    }
	  }
	  if (currShape.name == 'startPoint') {
	    startPoint.position.y = startArr.length * 3 * lineWidth;
	  } else if (currShape.name == 'endPoint') {
	    endPoint.position.y = endArr.length * 3 * lineWidth;
	  } else {
	    startPoint.position.y = startArr.length * 3 * lineWidth;
	    endPoint.position.y = endArr.length * 3 * lineWidth;
	  }

	  if (startPoint.position.y >= endPoint.position.y) {
	    endHeight += startPoint.position.y - endPoint.position.y;
	  } else {
	    startHeight += endPoint.position.y - startPoint.position.y;
	  }

	  startSideVector.x = startPoint.position.x;
	  endSideVector.x = endPoint.position.x;
	  startSideVector.y = startPoint.position.y + startHeight - lineWidth / 2;
	  endSideVector.y = endPoint.position.y + endHeight - lineWidth / 2;

	  // 更新区间三条线
	  (0, _updateVertices2['default'])(startSide, startPoint.position, new THREE.Vector3(startPoint.position.x, startPoint.position.y + startHeight, 0), lineWidth);
	  (0, _updateVertices2['default'])(endSide, endPoint.position, new THREE.Vector3(endPoint.position.x, endPoint.position.y + endHeight, 0), lineWidth);
	  (0, _updateVertices2['default'])(sectionLine, startSideVector, endSideVector, lineWidth);
	  // 计算应该显示的文字
	  text = (0, _computeSection2['default'])(shape, startSideVector, endSideVector);
	  // 刷新文字
	  sectionText._dynamicTexture.clear().drawText(text, undefined, 16, sectionColor);
	  sectionText.position.x = (startSideVector.x + endSideVector.x) / 2;
	  sectionText.position.y = startSideVector.y + 15;
	  shape.data.startSideVector = startSideVector;
	  shape.data.endSideVector = endSideVector;

	  _toolbar.toolbarStatus.refreshStartPoints = false;
	  _toolbar.toolbarStatus.refreshEndPoints = false;
	}

	// 获取区间端点上堆叠的点
	function getPile(startPoint, endPoint) {
	  var startArr = [],
	      endArr = [];
	  for (var i = 0; i < _toolbar.toolbarStatus.referInterval.length; i++) {
	    var referPoint = _toolbar.toolbarStatus.referInterval[i];
	    if (referPoint.id != startPoint.id && referPoint.id != endPoint.id) {
	      if (startPoint.position.x == referPoint.position.x) {
	        startArr.push(referPoint);
	      }
	      if (endPoint.position.x == referPoint.position.x) {
	        endArr.push(referPoint);
	      }
	    }
	  }
	  return {
	    startArr: startArr,
	    endArr: endArr
	  };
	}

	// 更新堆叠上的区间
	function updatePile(arr, lineWidth) {
	  var point = undefined,
	      shape = undefined;
	  for (var i = 0; i < arr.length; i++) {
	    point = arr[i];
	    shape = point.parent;
	    point.position.y = i * 3 * lineWidth;
	    update(shape, point, lineWidth);
	  }
	}

	// 更新单个区间
	function update(shape, point, lineWidth) {
	  var startHeight = undefined,
	      endHeight = undefined,
	      startSideVector = undefined,
	      endSideVector = undefined,
	      sectionColor = undefined,
	      startPoint = undefined,
	      endPoint = undefined,
	      startSide = undefined,
	      endSide = undefined,
	      sectionLine = undefined,
	      sectionText = undefined,
	      text = undefined;

	  startHeight = shape.data.startHeight;
	  endHeight = shape.data.endHeight;
	  startSideVector = shape.data.startSideVector;
	  endSideVector = shape.data.endSideVector;
	  sectionColor = shape.data.sectionColor;
	  startSide = shape.getObjectByName('startSide');
	  endSide = shape.getObjectByName('endSide');
	  sectionLine = shape.getObjectByName('sectionLine');
	  sectionText = shape.getObjectByName('sectionText');
	  if (point.name == 'startPoint') {
	    startPoint = point;
	    endPoint = shape.getObjectByName('endPoint');
	  } else {
	    endPoint = point;
	    startPoint = shape.getObjectByName('startPoint');
	  }

	  if (startPoint.position.y >= endPoint.position.y) {
	    endHeight += startPoint.position.y - endPoint.position.y;
	  } else {
	    startHeight += endPoint.position.y - startPoint.position.y;
	  }
	  startSideVector.x = startPoint.position.x;
	  endSideVector.x = endPoint.position.x;
	  startSideVector.y = startPoint.position.y + startHeight - lineWidth / 2;
	  endSideVector.y = endPoint.position.y + endHeight - lineWidth / 2;

	  // 更新区间三条线
	  (0, _updateVertices2['default'])(startSide, startPoint.position, new THREE.Vector3(startPoint.position.x, startPoint.position.y + startHeight, 0), lineWidth);
	  (0, _updateVertices2['default'])(endSide, endPoint.position, new THREE.Vector3(endPoint.position.x, endPoint.position.y + endHeight, 0), lineWidth);
	  (0, _updateVertices2['default'])(sectionLine, startSideVector, endSideVector, lineWidth);
	  // 计算应该显示的文字
	  text = (0, _computeSection2['default'])(shape, startSideVector, endSideVector);
	  // 刷新文字
	  sectionText._dynamicTexture.clear().drawText(text, undefined, 16, sectionColor);
	  sectionText.position.x = (startSideVector.x + endSideVector.x) / 2;
	  sectionText.position.y = startSideVector.y + 15;
	  shape.data.startSideVector = startSideVector;
	  shape.data.endSideVector = endSideVector;
	}
	module.exports = exports['default'];

/***/ },
/* 62 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _updateSection = __webpack_require__(61);

	var _updateSection2 = _interopRequireDefault(_updateSection);

	var _refreshSection = __webpack_require__(26);

	var _refreshSection2 = _interopRequireDefault(_refreshSection);

	exports['default'] = function (currShape) {
	  var currCircle = currShape.getObjectByName('inCircle');
	  if (currCircle.visible) {
	    currCircle.visible = false;
	    currShape.data.status = true;
	  } else {
	    currCircle.visible = true;
	    currShape.data.status = false;
	  }
	  (0, _updateSection2['default'])(currShape);
	  (0, _refreshSection2['default'])(currShape.parent.parent);
	};

	module.exports = exports['default'];

/***/ },
/* 63 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

	var _UtilsAddText = __webpack_require__(17);

	var _UtilsAddText2 = _interopRequireDefault(_UtilsAddText);

	var _Point = __webpack_require__(18);

	var _Point2 = _interopRequireDefault(_Point);

	var Section = (function () {
	  function Section(lineWidth, color) {
	    _classCallCheck(this, Section);

	    this.lineWidth = lineWidth;
	    // this.color = this.getRandomColor();
	    this.color = color;
	  }

	  // 获取颜色

	  _createClass(Section, [{
	    key: 'getRandomColor',
	    value: function getRandomColor() {
	      return "#" + ("00000" + (Math.random() * 16777215 + 0.5 >> 0).toString(16)).slice(-6);
	    }

	    // 获取端点面材质
	  }, {
	    key: 'getPointMaterial',
	    value: function getPointMaterial() {
	      return new THREE.MeshBasicMaterial({
	        color: 0xffffff
	      });
	    }

	    // 获取端点线材质
	  }, {
	    key: 'getPointLineMaterial',
	    value: function getPointLineMaterial() {
	      return new THREE.MeshBasicMaterial({
	        color: this.color,
	        linewidth: 2
	      });
	    }

	    // 创建端点
	    // createPoint() {
	    //   let point = new THREE.Object3D();
	    //   let outCircleGeometry = new THREE.CircleGeometry(this.lineWidth*1.5, 32);
	    //   let outCircle = new THREE.Mesh( outCircleGeometry, new THREE.MeshBasicMaterial({
	    //     color:this.color,
	    //     transparent: false,
	    //     opacity: 1
	    //   }));
	    //   outCircle.position.z = 0.1;
	    //   outCircle.name = 'outCircle';
	    //   let inCircleGeometry = new THREE.CircleGeometry(this.lineWidth*1, 32);
	    //   let inCircle = new THREE.Mesh( inCircleGeometry, new THREE.MeshBasicMaterial({
	    //     color:0xffffff,
	    //     transparent: false,
	    //     opacity: 1
	    //   }));
	    //   inCircle.position.z = 0.1;
	    //   inCircle.name = 'inCircle';
	    //   point.add(inCircle);
	    //   point.add(outCircle);
	    //   return point;
	    // }

	    // 创建竖线
	  }, {
	    key: 'createSide',
	    value: function createSide(startVector, height) {
	      var shape = new THREE.Shape();
	      var endVector = new THREE.Vector3(startVector.x, startVector.y + height, 0);
	      shape.moveTo(startVector.x + this.lineWidth / 2, 0);
	      shape.lineTo(endVector.x + this.lineWidth / 2, height);
	      shape.lineTo(endVector.x - this.lineWidth / 2, height);
	      shape.lineTo(startVector.x - this.lineWidth / 2, 0);
	      shape.lineTo(startVector.x + this.lineWidth / 2, 0);
	      var geometry = new THREE.ShapeGeometry(shape);
	      var side = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({
	        color: this.color
	      }));
	      return {
	        side: side,
	        endVector: endVector
	      };
	    }

	    // 创建横线
	  }, {
	    key: 'createLine',
	    value: function createLine(startVector, endVector) {
	      var shape = new THREE.Shape();
	      shape.moveTo(startVector.x, startVector.y - this.lineWidth / 2);
	      shape.lineTo(endVector.x, endVector.y - this.lineWidth / 2);
	      shape.lineTo(endVector.x, endVector.y + this.lineWidth / 2);
	      shape.lineTo(startVector.x, startVector.y + this.lineWidth / 2);
	      shape.lineTo(startVector.x, startVector.y - this.lineWidth / 2);
	      var geometry = new THREE.ShapeGeometry(shape);
	      var line = new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({
	        color: this.color
	      }));
	      return line;
	    }

	    // 创建区间
	  }, {
	    key: 'createSection',
	    value: function createSection(startVector, endVector, startHeight, endHeight, text, parent) {
	      var start = undefined,
	          end = undefined,
	          startSide = undefined,
	          endSide = undefined,
	          line = undefined,
	          group = undefined,
	          sectionText = undefined,
	          sectionPosition = undefined;
	      group = new THREE.Object3D();
	      group.data = {};
	      group.name = 'section';
	      end = (0, _Point2['default'])(parent.data.lineWidth, this.color);
	      end.position.x = endVector.x - parent.position.x;
	      end.name = 'endPoint';
	      startSide = this.createSide(startVector, startHeight);
	      startSide.side.name = 'startSide';
	      endSide = this.createSide(endVector, endHeight);
	      endSide.side.name = 'endSide';

	      if (startHeight >= 0 || endHeight >= 0) {
	        startSide.endVector.y = startSide.endVector.y - this.lineWidth / 2;
	        endSide.endVector.y = endSide.endVector.y - this.lineWidth / 2;
	        sectionPosition = new THREE.Vector3((startVector.x + endVector.x) / 2, startHeight + 15, 0);
	      } else {
	        startSide.endVector.y = startSide.endVector.y + this.lineWidth / 2;
	        endSide.endVector.y = endSide.endVector.y + this.lineWidth / 2;
	        sectionPosition = new THREE.Vector3((startVector.x + endVector.x) / 2, -startHeight - 70, 0);
	      }

	      line = this.createLine(startSide.endVector, endSide.endVector);
	      line.name = 'sectionLine';
	      sectionText = (0, _UtilsAddText2['default'])(text, sectionPosition, 128, 16, '16px', this.color);
	      sectionText._dynamicTexture.clear().drawText(text, undefined, 16, this.color);
	      sectionText.name = "sectionText";
	      sectionText.position.z = -1;
	      group.add(end);
	      group.add(startSide.side);
	      group.add(endSide.side);
	      group.add(line);
	      group.add(sectionText);

	      group.data.startVector = startVector;
	      group.data.endVector = endVector;
	      group.data.startHeight = startHeight;
	      group.data.endHeight = endHeight;
	      group.data.startSideVector = startSide.endVector;
	      group.data.endSideVector = endSide.endVector;
	      group.data.sectionColor = this.color;
	      return group;
	    }
	  }]);

	  return Section;
	})();

	exports['default'] = Section;
	module.exports = exports['default'];

/***/ },
/* 64 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	exports["default"] = function (point, group) {
		var smallUnit = group.data.smallUnitVisible,
		    unit = group.data.unitMultiple,
		    radix = undefined,
		    remainder = undefined,
		    isNegative = point.x - group.position.x < 0,
		    multiple = undefined;

		radix = smallUnit ? group.data.unitLength / 10 : group.data.unitLength;
		console.log(radix);
		multiple = parseInt((point.x - group.position.x) / radix);
		remainder = (point.x - group.position.x) % radix;
		if (Math.abs(remainder) >= radix / 2) {
			isNegative ? multiple-- : multiple++;
		}
		point.x = multiple * radix + group.position.x;
		console.log(group.position.x);
	};

	module.exports = exports["default"];

/***/ },
/* 65 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	exports["default"] = function (mouseData, group) {
		var pointX = mouseData.movePoint.x - mouseData.startPoint.x;
		var smallUnit = group.data.smallUnitVisible,
		    unit = group.data.unitMultiple,
		    radix = undefined,
		    remainder = undefined,
		    isNegative = (mouseData.recordDistance += pointX) < 0,
		    multiple = undefined;
		// mouseData.recordDistance += pointX;
		// if(smallUnit){
		// 	radix = group.data.unitLength/10;

		// 	// pointX = isNegative ?  -multiple*radix :  multiple*radix;
		// }else{
		// 	radix = group.data.unitLength;
		// }
		radix = smallUnit ? group.data.unitLength / 10 : group.data.unitLength;
		multiple = parseInt(mouseData.recordDistance / radix);
		remainder = mouseData.recordDistance % radix;
		if (Math.abs(remainder) >= radix / 2) {
			isNegative ? multiple-- : multiple++;
		}
		pointX = multiple * radix;

		return pointX;
	};

	module.exports = exports["default"];

/***/ },
/* 66 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	exports['default'] = function (target, regulation, group, distanceX, secondRegulation) {
	    var b = undefined,
	        targetPositionX = undefined,
	        targetPositionSecond = undefined,
	        limitDistance = undefined;
	    if (!secondRegulation) {
	        b = target == 'outset', targetPositionX = b ? regulation.startPoint.x + distanceX : regulation.endPoint.x + distanceX, limitDistance = b ? Math.abs(targetPositionX - regulation.endPoint.x) : Math.abs(targetPositionX - regulation.startPoint.x);
	    } else {
	        b = target == 'outset', targetPositionX = b ? regulation.startPoint.x + distanceX : regulation.endPoint.x + distanceX, targetPositionSecond = b ? secondRegulation.startPoint.x : secondRegulation.endPoint.x + distanceX, limitDistance = b ? Math.abs(targetPositionX - regulation.endPoint.x) : Math.abs(targetPositionX - regulation.startPoint.x);
	    }
	    if (!secondRegulation) {
	        if (_presenter2['default'].isTeacherMobile || _presenter2['default'].isStudentMobile) {
	            if (limitDistance >= 40 || limitDistance >= group.data.unitLength / 2) {
	                if (targetPositionX <= group.data.pointB.x - 25 && targetPositionX >= group.data.pointA.x) {
	                    b ? regulation.startPoint.x = targetPositionX : regulation.endPoint.x = targetPositionX;
	                    regulation.update();
	                    //secondRegulation.update();
	                } else {
	                        return true;
	                    }
	            } else {
	                return true;
	            }
	        } else {
	            if (limitDistance >= 40 || limitDistance >= group.data.unitLength / 2) {
	                if (targetPositionX <= group.data.pointB.x - 20 && targetPositionX >= group.data.pointA.x) {
	                    b ? regulation.startPoint.x = targetPositionX : regulation.endPoint.x = targetPositionX;
	                    regulation.update();
	                    //secondRegulation.update();
	                } else {
	                        return true;
	                    }
	            } else {
	                return true;
	            }
	        }
	    } else {
	        if (limitDistance >= 40 || limitDistance >= group.data.unitLength / 2) {
	            if (targetPositionX <= group.data.pointB.x && targetPositionX >= group.data.pointA.x && targetPositionSecond <= group.data.pointB.x && targetPositionSecond >= group.data.pointA.x) {
	                b ? regulation.startPoint.x = targetPositionX : regulation.endPoint.x = targetPositionX;
	                regulation.update();
	                secondRegulation.update();
	            } else {
	                return true;
	            }
	        } else {
	            return true;
	        }
	    }
	};

	// if (selectedObj.group.name == 'outset') {
	//     if (Math.abs(regulation.startPoint.x + distanceX - regulation.endPoint.x) >= 40 || Math.abs(regulation.startPoint.x + distanceX - regulation.endPoint.x) >= group.data.unitLength / 2) {

	//         if (regulation.startPoint.x + distanceX <= group.data.pointB.x && regulation.startPoint.x + distanceX >= group.data.pointA.x) {
	//             regulation.startPoint.x += distanceX;
	//             regulation.update();
	//             mouseData.recordDistance -= distanceX;
	//         }
	//     }
	// }
	// if (selectedObj.group.name == 'terminal') {
	//     regulation = selectedObj.group.group;
	//     if (Math.abs(regulation.startPoint.x - distanceX - regulation.endPoint.x) >= 40 || Math.abs(regulation.startPoint.x - distanceX - regulation.endPoint.x) >= group.data.unitLength / 2) {

	//         if (regulation.endPoint.x + distanceX <= group.data.pointB.x && regulation.endPoint.x + distanceX >= group.data.pointA.x) {
	//             regulation.endPoint.x += distanceX;
	//             regulation.update();
	//             mouseData.recordDistance -= distanceX;
	//         }
	//     }
	// }
	module.exports = exports['default'];

/***/ },
/* 67 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _setZPosition = __webpack_require__(68);

	var _setZPosition2 = _interopRequireDefault(_setZPosition);

	exports['default'] = function (obj, color, group) {
	    if (!obj) {
	        return;
	    }
	    var originColor = obj.material.color.getHex();
	    obj.material.color.setHex(color);
	    var target = getTarget(obj, group);
	    console.log(target);
	    (0, _setZPosition2['default'])(target);
	    return {
	        obj: obj,
	        originColor: originColor
	    };
	};

	function getTarget(obj, group) {
	    while (obj.parent && obj.parent !== group) {
	        obj = obj.parent;
	        getTarget(obj, group);
	    }
	    return obj;
	}
	module.exports = exports['default'];

/***/ },
/* 68 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	var zPosition = 0;

	exports["default"] = function (shape) {
		if (!shape) return;
		zPosition += 2;
		shape.position.z = zPosition;
		console.log(shape.position.z);
	};

	module.exports = exports["default"];

/***/ },
/* 69 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by zhoujunzhou on 2016/1/4.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.bindButtonEvent = bindButtonEvent;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _constants = __webpack_require__(4);

	var _DomViewManager = __webpack_require__(7);

	var _moduleControl = __webpack_require__(6);

	var _threeManger = __webpack_require__(10);

	var _ShapeAddMarkPoint = __webpack_require__(28);

	var _ShapeAxisView = __webpack_require__(34);

	var _UtilsToolbar = __webpack_require__(11);

	var markPintArray = undefined;

	function bindButtonEvent() {

	    $(_presenter2['default'].view).find('.mathaxis-main-container').off('click').on('click touchstart', function (e) {
	        e.preventDefault();
	        var target = e.target;
	        console.log('target:', target);
	    });
	    $(_presenter2['default'].view).find('.btn_integer_num').off('click').on('click touchstart', function (e) {
	        e.preventDefault();
	        var target = e.target;

	        (0, _DomViewManager.selectTabDom)(false);

	        var examValue = (0, _moduleControl.getAxisExamModel)();
	        examValue.setInteger(false);
	        (0, _ShapeAddMarkPoint.resetCollection)();
	        (0, _ShapeAxisView.initEditorCanvas)(true);
	        reInitCanvas();
	        (0, _ShapeAxisView.updateNewValue)();
	    });

	    $(_presenter2['default'].view).find('.btn_natural_num').off('click').on('click touchstart', function (e) {
	        e.preventDefault();
	        var target = e.target;

	        (0, _DomViewManager.selectTabDom)(true);

	        var examValue = (0, _moduleControl.getAxisExamModel)();
	        examValue.setInteger(true);
	        (0, _ShapeAxisView.initEditorCanvas)(true);
	        reInitCanvas();
	        (0, _ShapeAxisView.updateNewValue)();
	    });

	    $(_presenter2['default'].view).find('.btn_exchange').off('click').on('click touchstart', function (e) {
	        e.preventDefault();
	        var target = e.target;
	        var examValue = (0, _moduleControl.getAxisExamModel)();
	        examValue.updateValueArray();

	        reInitCanvas();
	        (0, _ShapeAxisView.updateNewValue)();
	    });

	    $(_presenter2['default'].view).find('.btn_pre_step').off('click').on('click touchstart', function (e) {
	        e.preventDefault();
	        $(_presenter2['default'].view).find('.btn_integer_num').addClass('on');
	        $(_presenter2['default'].view).find('.btn_natural_num').removeClass('on');
	        (0, _moduleControl.setAxisExamModle)(null);
	        (0, _DomViewManager.clearBuildDiv)();
	        (0, _ShapeAddMarkPoint.resetCollection)();
	        (0, _DomViewManager.hideMainContainer)();
	        (0, _DomViewManager.showSelectTypeContainer)();
	        reInitCanvas();
	        _presenter2['default'].scope.$apply(function (scope) {
	            if (scope.model.title == '请在数轴上标出以下数字' || scope.model.title == '请根据数轴上的坐标点填空' || scope.model.title == '请在坐标轴上标出计算式的结果' || scope.model.title == '已知坐标轴图填写完整的计算式') {
	                scope.model.title = '';
	                console.log('title clear');
	            }
	        });
	    });
	    function reInitCanvas() {
	        var group = _threeManger.scene.getObjectByName("group");
	        markPintArray = [];
	        var group_markPoint = group.children;
	        for (var _i = 0; _i < group_markPoint.length; _i++) {
	            if (group_markPoint[_i].name == 'markPoint' || group_markPoint[_i].name == 'section' || group_markPoint[_i].name.toString().indexOf('regulation') != -1 || group_markPoint[_i].name == 'outset') {
	                markPintArray.push(group.children[_i]);
	            }
	            console.log(group_markPoint[_i].name);
	        }
	        for (var i = 0; i < markPintArray.length; i++) {
	            markPintArray[i].parent.remove(markPintArray[i]);
	        }
	        (0, _UtilsToolbar.setToolbarStatus)(null);
	        (0, _ShapeAddMarkPoint.resetCollection)();
	    }
	}

/***/ },
/* 70 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by zhangweiteng on 2016/1/12.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.parseModel = parseModel;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _constants = __webpack_require__(4);

	var _EditorCoordNoteModel = __webpack_require__(40);

	var _EditorCoordNoteModel2 = _interopRequireDefault(_EditorCoordNoteModel);

	var _EditorCoordNumberModel = __webpack_require__(45);

	var _EditorCoordNumberModel2 = _interopRequireDefault(_EditorCoordNumberModel);

	var _EditorCalcNoteModel = __webpack_require__(46);

	var _EditorCalcNoteModel2 = _interopRequireDefault(_EditorCalcNoteModel);

	var _EditorCalcNumberModel = __webpack_require__(48);

	var _EditorCalcNumberModel2 = _interopRequireDefault(_EditorCalcNumberModel);

	function parseModel(examModel) {
	    var isNoCreate = arguments.length <= 1 || arguments[1] === undefined ? false : arguments[1];

	    if (!examModel) {
	        return;
	    }
	    var examType = examModel.examType;
	    var model = null;
	    if (examType == _constants.EXAM_TYPE.Coord_Point_Note) {
	        model = new _EditorCoordNoteModel2['default']();
	        if (!isNoCreate) {
	            model.create(examModel.valueArray);
	        }
	    } else if (examType == _constants.EXAM_TYPE.Coord_Point_Number) {
	        model = new _EditorCoordNumberModel2['default']();
	        if (!isNoCreate) {
	            model.create(examModel.valueArray);
	        }
	    } else if (examType == _constants.EXAM_TYPE.Calculate_Note) {
	        model = new _EditorCalcNoteModel2['default']();
	        if (!isNoCreate) {
	            model.create(examModel.valueArray, examModel.symbolArray);
	        }
	    } else if (examType == _constants.EXAM_TYPE.Calculate_Number) {
	        model = new _EditorCalcNumberModel2['default']();
	        if (!isNoCreate) {
	            model.create(examModel.valueArray, examModel.symbolArray);
	        }
	    }
	    model.setIntegerNotUpdate(examModel.isInteger);

	    return model;
	}

/***/ },
/* 71 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 事件
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.unbindNativeListener = unbindNativeListener;
	exports.registerNativeListener = registerNativeListener;

	var _moduleControl = __webpack_require__(6);

	//事件监听销毁方法
	var callbacks = {};
	exports.callbacks = callbacks;

	function unbindNativeListener(key) {
	    if (_moduleControl.isApp && window.Bridge && window.Bridge.unRegisterListener) {
	        if (!key) {
	            $.each(callbacks, function (k, v) {
	                window.Bridge.unRegisterListener(k, callbacks[k]);
	            });
	            exports.callbacks = callbacks = {};
	        } else {
	            window.Bridge.unRegisterListener(key, callbacks[key]);
	        }
	    }
	}

	;

	//事件监听注册方法

	function registerNativeListener(key, _callback) {
	    if (_moduleControl.isApp && window.Bridge && window.Bridge.registerListener) {
	        callbacks[key] = window.Bridge.registerListener(key, _callback);
	    }
	}

	;

/***/ },
/* 72 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by zhoujunzhou on 2016/1/11.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.initSubmit = initSubmit;
	exports.getI18n = getI18n;
	exports.getAnswerContent = getAnswerContent;
	exports.getWrongPopup = getWrongPopup;
	exports.getResult = getResult;
	exports.showWebSubmit = showWebSubmit;
	exports.showMask = showMask;
	exports.showAlert = showAlert;
	exports.showPreViewPop = showPreViewPop;
	exports.showSimulateResult = showSimulateResult;
	exports.recordSubmitAnswer = recordSubmitAnswer;
	exports.recoverSubmitAnswer = recoverSubmitAnswer;
	exports.examCallBack = examCallBack;
	exports.showResult = showResult;
	exports.callSubmiterdo = callSubmiterdo;
	exports.stopAnswer = stopAnswer;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _moduleControl = __webpack_require__(6);

	var _sendEventToCalc = __webpack_require__(73);

	var _sendEventToCalc2 = _interopRequireDefault(_sendEventToCalc);

	var _mathaxisTimer = __webpack_require__(74);

	function initSubmit() {
	    //初始化国际化数据
	    if (!_presenter2['default'].i18nArr) {
	        _presenter2['default'].i18nArr = {
	            "answer_correct": "太棒啦, 您答对了!",
	            "answer_error": "这道题没有做对, 下次加油哦!",
	            "next_come_on": "答题结束，下次加油哦！",
	            "time_over": "时间到了，练习结束！",
	            "button_submit": "提交",
	            //'pic_or_text'     : '请将下方属于该分类的图/文拖到这里',
	            'options': '选项',
	            'people': '人'
	        };
	    }

	    //记录本题提交的时候的数据
	    _presenter2['default'].submitAnser = false;

	    _presenter2['default'].setUrlParams = function (url) {
	        console.log('Url:', url);
	    };
	}

	function getI18n() {
	    return {
	        "answer_correct": "太棒啦, 您答对了!",
	        "answer_error": "这道题没有做对, 下次加油哦!",
	        "next_come_on": "答题结束，下次加油哦！",
	        "time_over": "时间到了，练习结束！",
	        "button_submit": "提交",
	        //'pic_or_text'     : '请将下方属于该分类的图/文拖到这里',
	        'options': '选项',
	        'people': '人'
	    };
	}

	function getAnswerContent(answer) {
	    console.log('=====getAnswerContent:', answer);
	    if (!answer || answer.length == 0) {
	        //获取正确答案
	        //return presenter.classified.getCorrectHtml();
	    } else {
	            //根据选项ID获取内容
	            //return presenter.classified.getItemHtml(answer);
	        }
	}

	function getWrongPopup() {
	    console.log('=====getWrongPopup:');

	    //return '<button >   TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT </button>'
	}

	/**
	 * 学生端点击提交的时候调用改函数
	 */

	function getResult() {
	    console.log('=====getResult 提供给提交模块使用的方法:');
	    //var data = this.classified.getResult();
	    var correctRes;
	    var userRes;

	    if ((0, _moduleControl.getAxisExamModel)()) {
	        correctRes = (0, _moduleControl.getAxisExamModel)().getCorrectRes();
	        userRes = (0, _moduleControl.getAxisExamModel)().getUserRes();
	    }

	    console.log('getResult  correctRes:', correctRes);
	    console.log('getResult  userRes:', userRes);

	    var data = {
	        'status': 'complete',
	        'correct_response': correctRes,
	        'user_response': userRes
	    };

	    var res = {
	        "answer": JSON.stringify(data),
	        "questionId": _presenter2['default'].model.question_id
	    };

	    return res;
	}

	function showWebSubmit() {
	    new CommitBtn($(_presenter2['default'].view).find('div.com_lay_toptool'), 'time_id', function () {
	        //self.showSimulateResult();
	        submitWebTeacher();
	    });
	}

	//显示遮罩

	function showMask(isShow) {
	    var $mask = $(_presenter2['default'].view).find('.mask');
	    if ($mask.size() == 0 && isShow) {
	        $(_presenter2['default'].view).find('.number_lines_content').after('<div class="mask"></div>');
	        $(_presenter2['default'].view).find('.mask').css({
	            position: 'absolute',
	            top: 0,
	            left: 0,
	            width: '100%',
	            height: '100%',
	            'background-color': '#313131',
	            opacity: '0.1',
	            'z-index': 2
	        });
	    } else {
	        if (isShow) {
	            $mask.show();
	        } else {
	            $mask.hide();
	        }
	    }
	}

	;

	//显示弹窗内容

	function showAlert(type) {
	    var msg = '';

	    if (type == 'student') {
	        //学生端，根据是否提交进行提示
	        if (_presenter2['default'].submitStatus == 'doing' || _presenter2['default'].submitStatus == 'do') {
	            msg = getI18n['next_come_on'];
	        } else {
	            msg = getI18n['time_over'];
	        }
	    } else if (type == 'teacher') {
	        //教师端，根据正误提示
	        //var res = getAnsResult();
	        var res = {};

	        if (res.is_right) {
	            msg = getI18n['answer_correct'];
	        } else {
	            msg = getI18n['answer_error'];
	        }
	    }
	}

	function showPreViewPop(msg) {
	    var node = $(_presenter2['default'].view).find('.pop_result');
	    node.find('.text').html(msg);
	    node.show();

	    setTimeout(function () {
	        node.find('.text').html('');
	        node.hide();
	    }, 2000);
	}

	//教师端显示提示

	function showSimulateResult() {}
	//showAlert('teacher');
	//showResult(true);

	//记录已经提交的答案

	function recordSubmitAnswer() {
	    //获取底下的分类
	    var options = [];
	    var i = 0;
	    //$(this.container).find('.option_box .option_list').each(function(k, v){
	    //    var that = $(v);
	    //
	    //    //只保存显示的选项
	    //    if(!that.is(':hidden')) {
	    //        options[i] = {'type' : $(v).attr('type'), 'oid' : $(v).attr('oid'), 'content' : $(v).attr('content')};
	    //        i += 1;
	    //    }
	    //});
	    console.log('=====recordSubmitAnswer 记录已经提交的答案');

	    //将数据保存成json
	    //var tmpObj = JSON.parse(JSON.stringify(this.catesObj));
	    var tmpObj = JSON.parse(JSON.stringify('{test:testResult}'));
	    var value = { 'options': options, 'catesObj': tmpObj };

	    _presenter2['default'].submitAnser = value;
	}

	//恢复已经提交的答案

	function recoverSubmitAnswer() {
	    if (_presenter2['default'].submitAnser) {

	        //恢复数据
	        var options = _presenter2['default'].submitAnser.options;
	        var catesObj = _presenter2['default'].submitAnser.catesObj;
	        console.log('=====recoverSubmitAnswer 恢复已经提交的答案:', _presenter2['default'].submitAnser);
	    }
	}

	function examCallBack(data) {
	    console.log('examCallBack:', data);
	    var type = data.type;
	    var value = data.value ? data.value : false;

	    //公布随堂练习结果成功回调
	    //if (value && value.result && type == 'result') {
	    /**fix bug **/
	    if (value && type == 'result') {
	        //公布答案
	        console.log('tell me show result', data);
	        //如果是学生端就显示
	        var $resultTip = $(_presenter2['default'].view).find('.student_result');
	        var isCorrect = (0, _moduleControl.getAxisExamModel)().getCorrectRes() === (0, _moduleControl.getAxisExamModel)().getUserRes();
	        $resultTip.show();
	        if (isCorrect) {

	            $resultTip.addClass('correct');
	            $resultTip.text('太棒啦, 您答对了!');
	        } else {
	            $resultTip.addClass('error');
	            $resultTip.text('很遗憾,回答错误!');
	        }

	        //showResult(false);

	        //记录答题状态
	        _presenter2['default'].submitStatus = 'result';

	        //记录本地state
	        //saveLocalState();
	    }
	}

	/**
	 * 将答案显示出来
	 * type : alert = 弹窗提示 detail = 显示具体的正误
	 */

	function showResult(isRecover) {
	    console.log('=====recoverSubmitAnswer 恢复已经提交的答案:', _presenter2['default'].submitAnser);

	    var self = this;

	    //如果有提交过数据的话，就显示最后提交的内容
	    recoverSubmitAnswer();

	    //显示详细的错误、正确项
	    //$(this.container).find('.classify .grid').each(function(k, v) {
	    //    var that = this;
	    //
	    //    var cid = $(that).find('.list_box').attr('cid');
	    //    var tmpInfo = self.catesObj[cid];
	    //
	    //    $(that).find('.list').each(function(kk, vv){
	    //        var oid = $(vv).attr('oid');
	    //        var tmpThat = this;
	    //
	    //        //错误答案
	    //        if($.inArray(oid, tmpInfo.correct_ans) !== -1) {
	    //            $(tmpThat).addClass('click');
	    //        } else {
	    //            $(tmpThat).addClass('error');
	    //        }
	    //    });
	    //});

	    //移除正确和错误的判断
	    if (isRecover) {
	        //setTimeout(function(){
	        //    $(presenter.$view).find('.list_box .list').removeClass('error');
	        //    $(presenter.$view).find('.list_box .list').removeClass('click');
	        //}, 2000);
	    }
	}

	//自动提交

	function callSubmiterdo(time) {
	    console.log('===================== callSubmiterdo ');
	    if (_presenter2['default'].isStudentMobile) {
	        //发送结束考试
	        (0, _sendEventToCalc2['default'])('finish');

	        console.log('send event finish');

	        //这边因为不会回调，所以要自己添加
	        //this.showAlert('student');

	        //记录答题状态
	        _presenter2['default'].submitStatus = 'finished';

	        //记录答题时间
	        _presenter2['default'].submitTime = time;

	        console.log('callSubmiterdo submitTime:', _presenter2['default'].submitTime);

	        //清除事件
	        //this.destroy();
	        (0, _mathaxisTimer.destoryTimer)();
	        stopAnswer();
	    } else if (_presenter2['default'].isWeb || _presenter2['default'].isPPTShell) {

	        showPreViewPop('很遗憾,时间结束!');

	        submitWebTeacher();
	        showMask(true);
	        stopAnswer();
	        (0, _mathaxisTimer.destoryTimer)();
	        //showSimulateResult();
	    }
	}

	function submitWebTeacher() {
	    //教师端的预览提示
	    var isCorrect = (0, _moduleControl.getAxisExamModel)().getCorrectRes() === (0, _moduleControl.getAxisExamModel)().getUserRes();

	    console.log('getCorrectRes', (0, _moduleControl.getAxisExamModel)().getCorrectRes());
	    console.log('getUserRes', (0, _moduleControl.getAxisExamModel)().getUserRes());

	    //移除所以高亮状态
	    stopAnswer();

	    var $resultTip = $(_presenter2['default'].view).find('.tcresult').removeClass('correct error');
	    //let isCorrect = getAxisExamModel().getCorrectRes() === getAxisExamModel().getUserRes();

	    if (isCorrect) {

	        $resultTip.addClass('correct');
	        $resultTip.text('太棒啦, 您答对了!');
	    } else {
	        $resultTip.addClass('error');
	        $resultTip.text('很遗憾,回答错误!');
	    }
	}

	function stopAnswer() {
	    $(_presenter2['default'].view).find(".input-number-value").find('.on').removeClass('on');
	    $(_presenter2['default'].view).find('input').blur();
	}

/***/ },
/* 73 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by zhoujunzhou on 2016/1/11.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	exports['default'] = function (action) {
	    //是学生才能发送
	    if (!_presenter2['default'].isStudentMobile) {
	        return false;
	    }

	    console.log('sendEventToCalc:', action);

	    action = action || 'submit';
	    var timerId = window.setInterval(function () {
	        var answerSubmitter = player.getPlayerServices().getToolbarModule('AnswerSubmitter') || player.getPlayerServices().getModule('AnswerSubmitter');
	        if (answerSubmitter != null) {
	            window.clearInterval(timerId);
	            _presenter2['default'].eventBus.sendEvent('AnswerSubmitter', {
	                source: _presenter2['default'].model.ID,
	                action: action
	            });
	        }
	    });
	};

	module.exports = exports['default'];

/***/ },
/* 74 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by zhoujunzhou on 2016/1/19.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.initTimer = initTimer;
	exports.startTimer = startTimer;
	exports.lastTimer = lastTimer;
	exports.syncTime = syncTime;
	exports.registerTimer = registerTimer;
	exports.timeListem = timeListem;
	exports.destoryTimer = destoryTimer;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _callNative = __webpack_require__(75);

	var _callNative2 = _interopRequireDefault(_callNative);

	var _moduleControl = __webpack_require__(6);

	var _sendEventToDispatcher = __webpack_require__(76);

	var _submitControl = __webpack_require__(72);

	var AxisTimer = undefined;

	exports.AxisTimer = AxisTimer;

	function initTimer() {
	    //记录是不是已经同步过时间了
	    _presenter2['default'].isSyncTime = false;
	    //记录提交时间
	    _presenter2['default'].submitTime = 0;

	    if (!_presenter2['default'].model.question_url) {
	        console.log('data unreceived timer');
	        return;
	    }

	    //获取model传递过来的时间
	    var modelTimer = _presenter2['default'].model.question_url.timer;

	    console.log('=============== initTimer:', modelTimer);

	    //let modelTimer = {
	    //    "timer_type": "countdown",  //计时器类型: ["sequence", "countdown"]
	    //    "time_minute": "0",    //倒计时初始设置-分钟，timer_type="countdown"时有效
	    //    "time_second": "30"     //倒计时初始设置-秒，timer_type="countdown"时有效
	    //}

	    //计时组件
	    //计时器类型: "sequence",正计时
	    // "countdown" 倒计时
	    var mark = modelTimer.timer_type == 'sequence' ? true : false;
	    var time_limit = parseInt(modelTimer.time_minute) * 60 + parseInt(modelTimer.time_second);

	    var timer_type = modelTimer.timer_type;

	    exports.AxisTimer = AxisTimer = new Timer($(_presenter2['default'].view).find('div.com_u_timebox'), {
	        'sequence': mark,
	        'seconds': parseInt(time_limit)
	    });

	    console.log('=============== AxisTimer:', AxisTimer);

	    //如果是倒计时，设置回调函数
	    if (!mark) {
	        AxisTimer.onStop(function (time) {
	            (0, _submitControl.callSubmiterdo)(time);
	        });
	    }

	    if (_presenter2['default'].isWeb || _presenter2['default'].isPPTShell) {
	        startTimer(new Date().valueOf());
	    } else if (_presenter2['default'].isStudentMobile || _presenter2['default'].isWeb || _presenter2['default'].isPPTShell) {
	        var data = { item: 'exam', type: 'query' };
	        (0, _sendEventToDispatcher.sendEventToDispatcher)(data);
	    }
	}

	//开始计时

	function startTimer(startTime) {
	    console.log('=============== startTimer');
	    startTime = parseInt(startTime);
	    AxisTimer.sync(startTime);
	    AxisTimer.start();
	}

	//显示最后的时间

	function lastTimer(startTime) {
	    console.log('=============== lastTimer');
	    startTime = parseInt(startTime);
	    var timestamp = new Date().valueOf();
	    AxisTimer.sync(timestamp - startTime * 1000);
	}

	/**
	 * 请求时间同步
	 */

	function syncTime() {
	    //如果是学生才进行时间同步
	    if (_presenter2['default'].isWeb || _presenter2['default'].isStudentMobile || _presenter2['default'].isPPTShell) {
	        var param = { "eventName": "ExamInfo", "eventData": { item: "time" } };
	        (0, _callNative2['default'])('sendEvent', param);
	    }
	}

	/**
	 * 注册时间回调函数
	 */

	function registerTimer() {

	    registerNativeListener('ExamCallback', examCallBack);
	    registerNativeListener('ExamInfoCallback', timeListem);
	}

	function timeListem(data) {
	    console.log('===============> timeListem', data);
	    var item = data.item || '';
	    var value = data.value || {};

	    //如果已经同步过，就不再同步了
	    if (_presenter2['default'].isSyncTime == true) {
	        return false;
	    }

	    //如果是时间同步事件
	    if (item == 'time') {
	        var elapsedTime = value.data ? parseInt(value.data.elapsedTime) : 0;

	        //状态恢复使用
	        if (_presenter2['default'].submitStatus == 'finished' || _presenter2['default'].submitStatus == 'result') {
	            _presenter2['default'].isSyncTime = true;

	            //换pad的时候，答题时间数据丢失，就将教师端时间显示出来
	            if (_presenter2['default'].submitTime <= 0) {
	                lastTimer(elapsedTime);
	            }

	            //将时间停止
	            destoryTimer();
	        } else {
	            startTimer(elapsedTime);
	            _presenter2['default'].isSyncTime = true;
	        }
	    }
	}

	function destoryTimer() {
	    if (AxisTimer) {
	        AxisTimer.onDestory();
	    }
	}

/***/ },
/* 75 */
/***/ function(module, exports, __webpack_require__) {

	/* global isApp Bridge */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	var _constants = __webpack_require__(4);

	exports['default'] = function (eventName, data) {
	    if (isApp && window.Bridge && window.Bridge.callNative) {
	        return window.Bridge.callNative(_constants.callNativePath, eventName, data);
	    }
	    return false;
	};

	module.exports = exports['default'];

/***/ },
/* 76 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by zhoujunzhou on 2016/1/20.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.sendEventToDispatcher = sendEventToDispatcher;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	//发送事件给分发器

	function sendEventToDispatcher(data) {
	    //是学生才能发送
	    if (!_presenter2['default'].isStudentMobile) {
	        return false;
	    }

	    var timerId = window.setInterval(function () {
	        var dispatcher = player.getPlayerServices().getToolbarModule('classroomStudentDispatcher') || player.getPlayerServices().getModule('classroomStudentDispatcher');
	        if (dispatcher != null) {
	            window.clearInterval(timerId);
	            _presenter2['default'].eventBus.sendEvent('TaskInfo', data);
	        }
	    });
	}

	;

/***/ },
/* 77 */
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	exports['default'] = function (state) {

	    //设置当前习题结果的状态信息
	    console.log('===========设置当前习题结果的状态信息:', state);
	    var currentState;
	    if (state) {
	        currentState = JSON.parse(state);
	        // ToDo:处理Module的状态恢复
	    }
	};

	module.exports = exports['default'];

/***/ },
/* 78 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 获得当前Module的状态信息
	 * 可用于Module的状态恢复和保存
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	exports['default'] = function () {
	    // TODO: 添加符合Module需求的状态对象
	    //var moduleState = JSON.stringify({
	    //    module_id: presenter.model.ID
	    //})

	    var time = new Date().valueOf();
	    var state = {
	        module_id: _presenter2['default'].model.ID,
	        'submitStatus': _presenter2['default'].submitStatus,
	        'time': time,
	        'submitTime': _presenter2['default'].submitTime
	    };

	    return JSON.stringify(state);
	    //return moduleState;
	};

	module.exports = exports['default'];

/***/ },
/* 79 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	exports['default'] = function (path) {
	    _presenter2['default'].path = path;
	};

	module.exports = exports['default'];

/***/ },
/* 80 */
/***/ function(module, exports) {

	/* global $ */
	"use strict";

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	exports["default"] = function (eventData) {
	  "use strict";
	};

	module.exports = exports["default"];
	/**
	 接收到 native 端的消息并处理
	 * @param eventData {object} {item: 'click', value: 'FourEdges'}
	 */

/***/ },
/* 81 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	/**
	 * 该方法在翻页时会触发，执行机制为循环所有加载到页面的addon，
	 * 判断存在presenter.pageChange方法就会执行（即该工具未打开也会执行）
	 * 所以需做是否开启工具的判断，该方法所有学科工具必须实现
	 */

	exports['default'] = function () {
	    //隐藏
	    //let container = $(presenter.view).find('.three2D-canvas');
	    //if (container.css('display') != 'none') {
	    //    container.hide();
	    //    //删除所有图形
	    //    for (let index = scene.children.length - 1; index >= 0; index--) {
	    //        let sceneItem = scene.children[index];
	    //        if (sceneItem.name === 'tool') continue;
	    //        scene.remove(sceneItem);
	    //        sceneItem = null;
	    //    }
	    //
	    //    container.find("canvas").remove();
	    //    //通知投影端清除屏幕
	    //    //presenter.userInput("clear", {});
	    //
	    //    //隐藏helperTool和工具栏,删除撞击测试集合
	    //    helperTool.detach();
	    //    intersectObjs.splice(0, intersectObjs.length);
	    //    $(presenter.view).trigger('hide.quickToolbar');
	    //}
	};

	module.exports = exports['default'];

/***/ },
/* 82 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 运行环境下, 销毁Module时执行的方法
	 * @remark 该方法为Module生命周期方法, 仅在ICPlayer切换页面时执行
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _moduleControl = __webpack_require__(6);

	exports['default'] = function () {
	    //解除绑定的Module事件
	    // unBindEvent();
	    //ToDo:释放Module占用的内存对象
	    // 实例销毁
	    (0, _moduleControl.moduleClose)();
	    _presenter2['default'].callbacks = {};
	};

	module.exports = exports['default'];

/***/ },
/* 83 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/12/14.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	exports['default'] = function () {
	    var question_id = '',
	        question_url = '';
	    if (_presenter2['default'].model !== undefined) {
	        try {
	            question_id = _presenter2['default'].model.question_id;
	            question_url = JSON.stringify(_presenter2['default'].model.question_url);
	        } catch (e) {}
	    }

	    return {
	        id: question_id,
	        dispatchOnly: true,
	        type_code: 'nd_mathaxis',
	        type_name: '数轴题',
	        url: question_url
	    };
	};

	module.exports = exports['default'];
	//statistics_type: 'no_need', question_url

/***/ },
/* 84 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/12/15.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	exports['default'] = function (controller) {
	    _presenter2['default'].controller = controller;
	    _presenter2['default'].eventBus = controller.getEventBus();
	    _presenter2['default'].eventBus.addEventListener('SyncCallback', _presenter2['default']);
	    _presenter2['default'].eventBus.addEventListener('PageLoaded', _presenter2['default']);

	    //注册监听
	    //监听学生端提交
	    _presenter2['default'].eventBus.addEventListener('AnswerSubmitterEvent', _presenter2['default']);
	    //监听公布结果
	    _presenter2['default'].eventBus.addEventListener('ExamCallback', _presenter2['default']);
	    _presenter2['default'].eventBus.addEventListener('Exam', _presenter2['default']);

	    _presenter2['default'].eventBus.addEventListener('TaskInfoCallback', _presenter2['default']);
	};

	module.exports = exports['default'];

/***/ },
/* 85 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _submitControl = __webpack_require__(72);

	var _mathaxisTimer = __webpack_require__(74);

	exports['default'] = function (eventName, eventData) {
	    //测试将所有接收到的事件都打印出来
	    console.log('all listen event', eventName, eventData);
	    switch (eventName) {
	        case 'SyncCallback':
	            SyncCallback(eventData);
	            break;
	        case 'PageLoaded':
	            //console.log('PageLoaded');
	            break;
	        // //提交模块发送的事件
	        case 'AnswerSubmitterEvent':

	            if (eventData.event == 'finished' && eventData.source == _presenter2['default'].model.ID) {
	                //停止答题
	                console.log('停止答题');
	                console.log('归位');

	                var stopTime = _mathaxisTimer.AxisTimer.stop();
	                //停止答题
	                (0, _submitControl.stopAnswer)();

	                //在状态恢复的时候不进行提示，在正确情况下进行提示
	                if (_presenter2['default'].submitStatus != 'finished' && _presenter2['default'].submitStatus != 'result') {
	                    (0, _submitControl.showAlert)('student');
	                }

	                //如果提交了，就显示提交的时间
	                _presenter2['default'].submitTime = stopTime;
	                console.log('提交时间：', _presenter2['default'].submitTime);

	                //如果已经到公布答案了，就不设置为finished状态
	                if (_presenter2['default'].submitStatus != 'result') {
	                    _presenter2['default'].submitStatus = 'finished';
	                }
	            }

	            //提交过后，当前不可操作
	            if (eventData.event == 'undo' && eventData.source == _presenter2['default'].model.ID) {
	                if (_presenter2['default'].submitStatus != 'finished' && _presenter2['default'].submitStatus != 'result') {
	                    _presenter2['default'].submitStatus = 'undo';
	                }
	            }

	            //点击修改，当前可以操作
	            if (eventData.event == 'do' && eventData.source == _presenter2['default'].model.ID) {
	                //记录已经提交过
	                if (_presenter2['default'].submitStatus != 'finished' && _presenter2['default'].submitStatus != 'result') {
	                    _presenter2['default'].submitStatus = 'do';
	                }
	            }

	            //提交成功的时候，保存答题数据
	            if (eventData.event == 'success' && eventData.source == _presenter2['default'].model.ID) {
	                (0, _submitControl.recordSubmitAnswer)();
	            }

	            //记录本地state
	            //saveLocalState();

	            //console.log('PageLoaded');
	            break;

	        case 'ExamCallback':

	            //显示答案的模拟事件
	            if (eventData.type == 'result' && eventData.source == 'classroomStudentDispatcher') {
	                if (eventData.value && eventData.value.isRecover) {
	                    //显示答题反馈
	                    if (_presenter2['default'].isStudentMobile) {
	                        (0, _submitControl.examCallBack)(eventData);
	                    }

	                    _presenter2['default'].submitStatus = 'result';

	                    //记录本地state
	                    //saveLocalState();
	                }
	            }

	            break;
	        case 'TaskInfoCallback':
	            {
	                if (eventData.item == 'exam' && eventData.type == 'query') {
	                    //var elapsedTime = eventData.value.elapsedTime;
	                    //presenter.classified.startTimer(elapsedTime);

	                    console.log('开始时间同步');

	                    //服务器端开始的时间戳
	                    var startTimestamp = eventData.value.startTimestamp;
	                    startTimestamp = startTimestamp == 0 ? new Date().getTime() : startTimestamp;

	                    (0, _mathaxisTimer.startTimer)(startTimestamp);
	                }
	            }
	            break;
	        default:
	        // console.log nothing
	    }
	};

	function saveLocalState() {
	    if (_presenter2['default'].controller) {
	        _presenter2['default'].controller.getState().savePageState();
	    }
	}

	var SyncCallback = function SyncCallback(eventData) {
	    var type = eventData.type;
	    var value = eventData.value;

	    var $button = $(_presenter2['default'].view).find('.js-stop-sync-button');
	    switch (type) {
	        case 'request':
	            // 发送任务
	            _presenter2['default'].syncId = value.syncId;
	            if (value.result) {
	                // 成功
	                $button.show();
	            } else {
	                window.ClassroomUtils.showTipMessageBox('同步题目失败');
	            }
	            break;
	        case 'cancel':
	            // 结束同步
	            if (value.result) {
	                $button.hide();
	            } else {
	                window.ClassroomUtils.showMessageBox([{
	                    html: '关闭'
	                }, {
	                    html: '重试',
	                    target: 'h5',
	                    callback: {
	                        eventName: 'MathAxis',
	                        eventData: {
	                            source: _presenter2['default'].model.ID,
	                            item: 'retry'
	                        }
	                    }
	                }], '结束任务失败！');
	            }
	            break;
	    }
	};
	module.exports = exports['default'];

/***/ },
/* 86 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by zhoujunzhou on 2016/1/11.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	//发送事件给状态恢复

	exports['default'] = function (action) {
	    //是学生才能发送
	    if (!_presenter2['default'].isStudentMobile) {
	        return false;
	    }

	    action = action || 'undo';
	    var timerId = window.setInterval(function () {
	        var answerSubmitter = player.getPlayerServices().getToolbarModule('AnswerSubmitter') || player.getPlayerServices().getModule('AnswerSubmitter');
	        if (answerSubmitter != null) {
	            window.clearInterval(timerId);
	            _presenter2['default'].eventBus.sendEvent('AnswerSubmitterRecoverState', {
	                source: _presenter2['default'].model.ID,
	                action: action
	            });
	        }
	    });
	};

	module.exports = exports['default'];

/***/ },
/* 87 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by zhoujunzhou on 2016/1/12.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	exports['default'] = function (urlParams) {
	    if (urlParams.sys) {
	        isAnySystem(urlParams.sys);
	    }
	};

	function isAnySystem(systemMap) {
	    switch (systemMap) {
	        case 'homework':
	            _presenter2['default'].isHomeWork = true;
	            break;
	        case 'pptshell':
	            _presenter2['default'].isPPTShell = true;
	            break;
	        default:
	            _presenter2['default'].isHomeWork = false;
	    }
	};
	module.exports = exports['default'];

/***/ }
/******/ ]);