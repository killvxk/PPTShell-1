var nodeUuid = require("node-uuid");
var fileSys = require("fs");
var pathSys = require("path");
var util = require("./../common/util");
var json2Xml = require("./../common/json2XMLParser");
var utils = require('util');
var pathHelper = require('./question_tools/question_path_helper');

var p = new json2Xml.json2XMLParser.Parser();

//在此添加题型后，请相应地在app/prepare/edit.html的gametypes属性定义中添加(Line.60)
var interationList = [
    {"code": "$RE0401", "label": "连连看", "module_type": "linkup", "module_code": "linkup"},
    {"code": "$RE0402", "label": "排序题", "module_type": "nd_order", "module_code": "order"},
    {"code": "$RE0403", "label": "表格题", "module_type": "nd_table", "module_code": "table"},
    {"code": "$RE0406", "label": "字谜游戏", "module_type": "nd_wordpuzzle", "module_code": "word-puzzle"},
    {"code": "$RE0407", "label": "记忆卡片", "module_type": "nd_memorycard", "module_code": "memory-card"},
    {"code": "$RE0408", "label": "竖式计算", "module_type": "nd_arithmetic", "module_code": "arithmetic"},
    {"code": "$RE0409", "label": "比较大小", "module_type": "nd_compare", "module_code": "compare"},
    {"code": "$RE0410", "label": "猜词游戏", "module_type": "nd_guessword", "module_code": "guess-word"},
    {"code": "$RE0411", "label": "魔方盒游戏", "module_type": "nd_magicbox", "module_code": "magic-box"},
    {"code": "$RE0414", "label": "文本选择题", "module_type": "nd_textselect", "module_code": "text-select"},
    {"code": "$RE0415", "label": "分类题", "module_type": "nd_classified", "module_code": "classified"},
    {"code": "$RE0416", "label": "分式加减", "module_type": "nd_fraction", "module_code": "fraction"},
    {"code": "$RE0418", "label": "点排序", "module_type": "nd_pointsequencing", "module_code": "point-sequencing"},
    {"code": "$RE0421", "label": "选词填空题", "module_type": "nd_fillblank", "module_code": "fill-blank"},
    {"code": "$RE0423", "label": "连环填空", "module_type": "nd_sequencefill", "module_code": "sequence-fill"},
    {"code": "$RE0424", "label": "标签题", "module_type": "nd_imagemark", "module_code": "image-mark"},
    {"code": "$RE0425", "label": "划词标记", "module_type": "nd_highlightmark", "module_code": "highlight-mark"},
    {"code": "$RE0426", "label": "抽卡牌", "module_type": "nd_probabilitycard", "module_code": "probabilitycard"},
    {"code": "$RE0427", "label": "摸球", "module_type": "nd_catchball", "module_code": "catchball"},
    {"code": "$RE0429", "label": "天平", "module_type": "nd_balance", "module_code": "balance"},
    {"code": "$RE0430", "label": "植树", "module_type": "nd_planting", "module_code": "planting"},
    {"code": "$RE0431", "label": "模拟时钟", "module_type": "nd_clock", "module_code": "clock"},
    {"code": "$RE0432", "label": "方块塔", "module_type": "nd_lego", "module_code": "lego"},
    {"code": "$RE0442", "label": "拼图工具", "module_type": "nd_puzzle", "module_code": "puzzle"},
    {"code": "$RE0446", "label": "四格漫画", "module_type": "nd_comicdialogue", "module_code": "comicdialogue"},
    {"code": "$RE0447", "label": "数轴题", "module_type": "nd_mathaxis", "module_code": "mathaxis"},
	{"code": "$RE0451", "label": "连字拼诗", "module_type": "nd_spellpoem", "module_code": "spellpoem"},
    {"code": "$RE0452", "label": "区间题", "module_type": "nd_intervalproblem", "module_code": "intervalproblem"},
    {"code": "$RE0448", "label": "计数器", "module_type": "nd_counter", "module_code": "counter"},
    {"code": "$RE0434", "label": "英语句子发音评测", "module_type": "nd_sentence_evaluat", "module_code": "sentence_evaluat"},
    {"code": "$RE0443", "label": "英语句子发音评测", "module_type": "nd_section_evaluating", "module_code": "section_evaluating"},
    {"code": "$RE0444", "label": "算盘", "module_type": "nd_abacus", "module_code": "abacus"},
    {"code": "$RE0449", "label": "组词题", "module_type": "nd_makeword", "module_code": "makeword"}
    
];


exports.create = function (req, res, next) {
    var uuid = nodeUuid.v4();
    //var params = util.getOpenApiParam(req, createParam);
    var params = {
        module_type: req.params.module_type
    };
    var metaData = getMetadata(params.module_type, uuid, req.body);
    var result;
    var mCode = getModuleCode(params.module_type);

    //文本选择
    if (params.module_type == "nd_textselect") {
        result = {
            "id": uuid,
            "title": "",
            "skin": {"code": "", "css_url": "", "package_url": "", "name": ""},
            "timer": {"timer_type": "sequence", "time_minute": null, "time_second": null},
            "prompt": null
        };
    }
    //计数器
    else if (params.module_type == "nd_counter") {
        result = {
            "id": uuid,
            "title": "计数器",
            "skin": {"code": "wood", "css_url": "", "package_url": "", "name": ""},
            "timer": {"timer_type": "sequence", "time_minute": "0", "time_second": "0"},
            "content": {
                "shaftNum": 5,
                    "showNum": false,
                    "showNumText": true,
                    "showAudio": true,
                    "initNum": [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
            }
        };
    }
    //魔方盒
    else if (params.module_type == "nd_magicbox") {
        result = {
            "id": uuid,
            "title": "",
            "skin": {"code": "", "css_url": "", "package_url": "", "name": ""},
            "timer": {"timer_type": "sequence", "time_minute": null, "time_second": null},
            "chars": [],
            "border": {"width": 0, "height": 0},
            "words": []
        };
    }
    //字谜游戏
    else if (params.module_type == "nd_wordpuzzle") {
        result = {
            "id": uuid,
            "title": "",
            "skin": {"code": "", "css_url": "", "package_url": "", "name": ""},
            "timer": {"timer_type": "sequence", "time_minute": null, "time_second": null},
            "border": {"width": 7, "height": 7},
            "words": [],
            "chars": []
        };
    }
    //选词填空
    else if (params.module_type == "nd_fillblank") {
        result = {
            "id": uuid,
            "title": "",
            "skin": {"code": "", "css_url": "", "package_url": "", "name": ""},
            "timer": {"timer_type": "sequence", "time_minute": null, "time_second": null},
            "candidates": [],
            "article": ""
        };
    }
    //猜词游戏
    else if (params.module_type == "nd_guessword") {
        result = {
            "id": uuid,
            "title": "",
            "skin": {"code": "", "css_url": "", "package_url": "", "name": ""},
            "timer": {"timer_type": "sequence", "time_minute": null, "time_second": null},
            "items": null
        };
    }
    //比大小
    else if (params.module_type == "nd_compare") {
        result = {
            "id": uuid,
            "title": "",
            "skin": {"code": "", "css_url": "", "package_url": "", "name": ""},
            "items": null
        };
    }
    //竖式计算
    else if (params.module_type == "nd_arithmetic") {
        result = {
            "id": uuid,
            "title": "",
            "skin": {"code": "", "css_url": "", "package_url": "", "name": ""},
            "timer": {"timer_type": "sequence", "time_minute": null, "time_second": null},
            "prompt": null
        };
    }
    //点排序
    else if (params.module_type == "nd_pointsequencing") {
        result = {
            "id": uuid,
            "title": "",
            "skin": {"code": "", "css_url": "", "package_url": "", "name": ""},
            "timer": {"timer_type": "sequence", "time_minute": null, "time_second": null},
            "points": null,
            "background": null
        };
    }
    //分类题
    else if (params.module_type == "nd_classified") {
        result = {
            "id": uuid,
            "title": "",
            "skin": {"code": "", "css_url": "", "package_url": "", "name": ""},
            "timer": {"timer_type": "sequence", "time_minute": null, "time_second": null},
            "categories": [{"id": "", "name": "", "items": []}, {"id": "", "name": "", "items": []}],
            "classified_options": []
        };
    }
    //标签题
    else if(params.module_type == "nd_imagemark") {

        result = {
            "id": uuid,
            "title": "",
            "skin": {"code": "", "css_url": "", "package_url": "", "name": ""},
            "timer": {"timer_type": "sequence", "time_minute": null, "time_second": null},
            "background": "",
            "image_item": {"text": "", "asset_type": "", "asset": "", "other": {}},
            "mark_type": null,
            "tags": null
        };
    }
    //新排序题
    else if (params.module_type == "nd_order") {
        result = {
            "id": uuid,
            "title": "",
            "skin": {"code": "", "css_url": "", "package_url": "", "name": ""},
            "timer": {"timer_type": "sequence", "time_minute": null, "time_second": null},
            "items": [],
            "description": {
                "text": "",
                "asset_type": "",
                "asset": "",
                "image_extend": {
                    "asset": "",
                    "image_extend": {
                        "resize": ""
                    }
                }
            }
        };
    }
    //分类表格题
	else if (params.module_type == "nd_table") {
        result = {
            "id": uuid,
            "title": "",
            "skin": {"code": "", "css_url": "", "package_url": "", "name": ""},
            "timer": {"timer_type": "sequence", "time_minute": null, "time_second": null},
            "horizontal_items": [""],
            "vertical_items": ["", ""],
            "items": [],
            "description": {
                "text": "",
                "asset": "",
                "image_extend": {
                    "rotate": "",
                    "resize": ""
                }
            }
        };
    }
    //连连看、记忆卡片
    else if (params.module_type == "linkup" || params.module_type == "nd_memorycard") {
        result = {
            "id": uuid,
            "title": "",
            "skin": {"code": "", "css_url": "", "package_url": "", "name": ""},
            "timer": {"timer_type": "sequence", "time_minute": null, "time_second": null},
            "module_subtype": "",
            "items": []
        };
    }
    //分式加减
    else if (params.module_type == "nd_fraction") {
        result = {
            "id": uuid,
            "title": "",
            "skin": {"code": "", "css_url": "", "package_url": "", "name": ""},
            "timer": {"timer_type": "sequence", "time_minute": null, "time_second": null},
            "prompt": null
        };
    }
    //模拟时钟、方块塔
    else if (params.module_type == "nd_clock" || params.module_type == "nd_lego"
            || params.module_type == "nd_puzzle" || params.module_type == "nd_mathaxis"
            || params.module_type == "nd_intervalproblem") {
        result = {
            "id": uuid,
            "title": "",
            "skin": {"code": "", "css_url": "", "package_url": "", "name": ""},
            "timer": {"timer_type": "sequence", "time_minute": null, "time_second": null},
            "properties": [	//模块静态数据模型
                {
                    "name": "question_id",
                    "display_name": "题目ID",
                    "type": "string",
                    "value": "",
                    "is_localized": false
                },
                {
                    "name": "question_url",
                    "display_name": "题目内容",
                    "type": "jsonFile",
                    "value": "",
                    "is_localized": false
                }
            ],
            "content": {
            }
        };
    } 
    //四格漫画
    else if (params.module_type == "nd_comicdialogue") {
        result = {
            "id": uuid,
            "title": "",
            "skin": {"code": "", "css_url": "", "package_url": "", "name": ""},
            "timer": {"timer_type": "sequence", "time_minute": null, "time_second": null},
            "content":{
           	 "allow_addtip":false,
           	 "title":"",
           	 "desc":"",
           	 "background": {
                    "url": "",
                    "scale": 1
             },
			 "dialogues": []
           }         
        };
    }
    //连字拼诗
    else if (params.module_type == "nd_spellpoem") {
        result = {
            "id": uuid,
            "module_code": "nd_spellpoem", // 题目类型
            "title": "", //标题
            "skin": {"code": "", "css_url": "", "package_url": "", "name": ""},
            "timer": {"timer_type": "sequence", "time_minute": null, "time_second": null},
            "content": { //Editor数据模型正文
                "title": "",
                "author": "",
                "dynasty": "",
                "sentences": [
                    {
                        "words": ""
                    },
                    {
                        "words": ""
                    },
                    {
                        "words": ""
                    },
                    {
                        "words": ""
                    }
                ]
            }       
        };
    }
    else {
        result = {
            "id": uuid,
            "title": "",
            "skin": {"code": "", "css_url": "", "package_url": "", "name": ""},
            "timer": {"timer_type": "sequence", "time_minute": null, "time_second": null},
            "properties": [	//模块静态数据模型
                {
                    "name": "question_id",
                    "display_name": "题目ID",
                    "type": "string",
                    "value": "",
                    "is_localized": false
                },
                {
                    "name": "question_url",
                    "display_name": "题目内容",
                    "type": "jsonFile",
                    "value": "",
                    "is_localized": false
                }
            ],
            "content": {
            }
        };
    }

    if (mCode != "") {
        saveLocalFile(req, mCode, uuid, JSON.stringify(result), metaData);

        if (params.module_type == "linkup" || params.module_type == "nd_memorycard") { //连连看、记忆卡片 需要将精灵效果用的数据拷贝到习题包中
            copySpiritResource(params.module_type, uuid, req);
        }
    }
    return res.send(result);
};

//不支持离线重新编辑的在线备课系统创建的习题列表
var unReeditableModuleTypes = [
    "linkup",          //连连看
    "nd_memorycard",   //记忆卡片
    "nd_order",        //排序题
    "nd_table",        //分类表格题
    "nd_arithmetic",   //竖式计算
    "nd_compare"       //比大小
];
function isUnsupportedReedit(module_type) {
    for(var i = 0; i < unReeditableModuleTypes.length; i++) {
        if(module_type === unReeditableModuleTypes[i]) {
            return true;
        }
    }

    return false;
}
function isEditorDataFile(item) {
    if(item != 'hint.json' && item.indexOf('.json') > -1) {
        return true;
    }

    return false;
}

exports.get = function (req, res, next) {
    //var params = util.getOpenApiParam(req, createParam);
    var params = {
        module_type: req.params.module_type,
        module_instance_id: req.params.module_instance_id
    };
    var result = {};
    var resourcePath = getInteractionBase(params.module_instance_id, req) + "/resources";

    if (fileSys.existsSync(resourcePath)) {
        var editorJsonPath = resourcePath + "/editor.json";
        if(fileSys.existsSync(editorJsonPath)) {
            var editor = fileSys.readFileSync(editorJsonPath);
            if (editor) {
                result = JSON.parse(editor.toString());
            }
        } else {
            /**
             * 针对备课系统上编辑的互动习题(API-V02接口创建的习题)
             * 1. 根据pages/page.xml目录下的第一个name=question_url节点的 value属性获取 .json文件名
             * 2. 查找.json文件（hint.json除外）当做编辑端的输入数据模型
             * @type {{}}
             */
            if(!isUnsupportedReedit(params.module_type)) {
                var files = fileSys.readdirSync(resourcePath);
                files.forEach(function(item) {
                    if(isEditorDataFile(item)) {
                        editorJsonPath = resourcePath + "/" + item;
                        if(fileSys.existsSync(editorJsonPath)) {
                            var editor = fileSys.readFileSync(editorJsonPath);
                            if (editor) {
                                result = JSON.parse(editor.toString());
                            }
                        }
                    }
                });
            }
        }
    }

    result.physic_path =  pathSys.normalize(getInteractionBase(req.params.module_instance_id,req));
    return res.send(result);
};

exports.modify = function (req, res, next) {
    //var params = util.getOpenApiParam(req, createParam);
    var params = {
        module_type: req.params.module_type,
        module_instance_id: req.params.module_instance_id
    };
    var data = req.body;
    var mCode = getModuleCode(params.module_type);
    if (params.module_type == "nd_imagemark") {
        var tmpStr = "<img src='" + data.image_item.asset + "' ";
        for (var item in data.image_item.other) {
            tmpStr += item + "='" + data.image_item.other[item] + "' ";
        }
        tmpStr += "/>";
        data.background = tmpStr;
    }
    if (mCode != "") {
        saveLocalFile(req, mCode, params.module_instance_id, JSON.stringify(data));

        if (params.module_type == "linkup" || params.module_type == "nd_memorycard") { //连连看、记忆卡片 需要将精灵效果用的数据拷贝到习题包中
            copySpiritResource(params.module_type, params.module_instance_id, req);
        }
    }
    return res.send(data);
};

exports.upload = function (req, res, next) {
    var params = {
        module_instance_id: req.params.module_instance_id
    };

    var uuid = nodeUuid.v4();
    var file = req.files.file;

    var assetsPath = getInteractionBase(params.module_instance_id, req) + '/_ref/edu/esp/assets/';
    //var assetsPath = getInteractionBase(params.module_instance_id, req) + '/resources/assets/';
    mkdirsSync(assetsPath);

    var extend = file.name.split('.')[1];
    var targetFile = assetsPath + uuid + '.' + extend;
    var readStream = fileSys.createReadStream(file.path);
    var writeStream = fileSys.createWriteStream(targetFile);

    utils.pump(readStream, writeStream, function () {
        fileSys.unlinkSync(file.path);
    });

    return res.send('${ref-path}/edu/esp/assets/' + uuid + '.' + extend);
    //return res.send('${ref-base}/../resources/assets/' + uuid + '.' + extend);
};

var ARCHIVE_FILE_PATH = __dirname + "/../app/userdatas/edu/esp/archive_files/";
exports.saveFile = function(req, res, next) {
    try {
        var params = {
            file_name: req.params.file_name
        };

        var filePath = ARCHIVE_FILE_PATH + params.file_name;

        if (!fileSys.existsSync(ARCHIVE_FILE_PATH)) {
            fileSys.mkdirSync(ARCHIVE_FILE_PATH);
        }

        fileSys.writeFileSync(filePath, JSON.stringify(req.body));

        return res.send("success");
    } catch(err) {
        return res.send("fail");
    }
};

exports.loadFile = function(req, res, next) {
    var params = {
        file_name: req.params.file_name
    };
    var result;
    var filePath = ARCHIVE_FILE_PATH + params.file_name;

    if (fileSys.existsSync(ARCHIVE_FILE_PATH) && fileSys.existsSync(filePath)) {
        var fileContent = fileSys.readFileSync(filePath);

        if (fileContent) {
            result = fileContent.toString();
        } else {
            result = null;
        }
    } else {
        result = null;
    }

    return res.send(result);
};

exports.getRefAsset = function(req, res, next) {
    var fromRefBase = req.query.from_ref_base;
    var filepath = req.query.filepath;
    var module_instance_id = req.params.module_instance_id;
    if (!module_instance_id) {
        return res.status(400).send({code: "LS/MISSING_QUESTION_ID", message: "参数不正确，缺少习题ID。"});
    }
    if (filepath && filepath.indexOf("?") != -1) {
        filepath = filepath.substring(0, filepath.indexOf("?"));
    }
    if (filepath && filepath.indexOf("/") === 0) {
        filepath = filepath.substring(1);
    }

    var realPath = getInteractionBase(module_instance_id, req);
    if(fromRefBase == 'true') {
        realPath += filepath;
    } else {
        realPath +=  '_ref/' + filepath;
    }

    return res.sendFile(pathSys.resolve(realPath));
};

//习题根目录，存放main.xml
function getInteractionBase(id, req) {
    var base = req.param('question_base');
    if (!base) {
        //离线编辑器本地服务下的互动习题存放目录
        base = __dirname + "/../app/userdatas/edu/esp/interaction/" + getModulePackage(id) + "/";

        return base;
    } else {
        if (base.lastIndexOf("/") != base.length - 1) {
            base = base + "/";
        }

        ///**
        // * 1. 离线生成的习题包，包目录名为： id + ".pkg"
        // * 2. 线上生成的习题包，包目录名为： id + "_default"
        // */
        //var isOnline = fileSys.existsSync(base + getModulePackage(id, true));
        //return base + getModulePackage(id, isOnline) + "/";

        return base + getModulePackage(id) + "/";
    }
}

//针对连连看，记忆卡片需要拷贝精灵动画所需资源
function copySpiritResource(moduleType, uuid, req) {
    var spiritRoot = getInteractionBase(uuid, req) + '/_ref/spirit_root/';

    if(!fileSys.existsSync(spiritRoot)) {
        mkdirsSync(spiritRoot);

        if (moduleType == "linkup") { //连连看、记忆卡片 需要将精灵效果用的数据拷贝到习题包中
            //copyDirectory(spiritRoot, __dirname + "/../app/skins/linkup/wood/");

            copyFile(spiritRoot + "/default_img.jpg", __dirname + "/../app/skins/linkup/wood/default_img.jpg");
            copyFile(spiritRoot + "/game_canvas_bg.png", __dirname + "/../app/skins/linkup/wood/game_canvas_bg.png");
            copyFile(spiritRoot + "/skin.json", __dirname + "/../app/skins/linkup/wood/skin.json");

            copyDirectory(spiritRoot + "/effects", __dirname + "/../app/skins/linkup/wood/effects");
        } else if(moduleType == "nd_memorycard") {
            //copyDirectory(spiritRoot, __dirname + "/../app/skins/memorycard/wood/");

            copyFile(spiritRoot + "/default_img.jpg", __dirname + "/../app/skins/memorycard/wood/default_img.jpg");
            copyFile(spiritRoot + "/game_canvas_bg.png", __dirname + "/../app/skins/memorycard/wood/game_canvas_bg.png");
            copyFile(spiritRoot + "/game_canvas_ft.png", __dirname + "/../app/skins/memorycard/wood/game_canvas_ft.png");
            copyFile(spiritRoot + "/skin.json", __dirname + "/../app/skins/memorycard/wood/skin.json");

            copyDirectory(spiritRoot + "/effects", __dirname + "/../app/skins/memorycard/wood/effects");
        }
    }
}

//递归拷贝文件夹
function copyDirectory(dist, src) {
    mkdirsSync(dist);

    var files = fileSys.readdirSync(src);
    files.forEach(function(item) {
        var srcPath = src + "/" + item;
        if(fileSys.lstatSync(srcPath).isDirectory()) {
            copyDirectory(dist + "/" + item, srcPath);
        } else {
            copyFile(dist + "/" + item, srcPath);
        }
    });
}

//递归文件
function copyFile(dist, src) {
    var rs = fileSys.createReadStream(src);
    var ws = fileSys.createWriteStream(dist);

    rs.pipe(ws);
}

//同步创建多级目录
function mkdirsSync(fullDir, mode) {
    if (!fileSys.existsSync(fullDir)) {
        var parentDir;
        fullDir.split('/').forEach(function (subDir) {
            if (parentDir) {
                parentDir = parentDir + '/' + subDir;
            } else {
                parentDir = subDir;
            }

            if (!fileSys.existsSync(parentDir)) {
                if (!fileSys.mkdirSync(parentDir, mode)) {

                    return false;
                }
            }
        });
    }

    return true;
}

function getModulePackage(module_id, isOnline) {
    if(!!isOnline)
        return module_id + "_default";

    return module_id + ".pkg";
}

function getModuleCode(mType) {
    var interaction = getInteraction(mType);

    return !!interaction ? interaction.module_code : "";
}

function saveLocalFile(req, question_type, uuid, origin, metaData) {

    var fileContent = p.parser(question_type, origin);
    var rootPath = getInteractionBase(uuid, req);
    var resourcePath = rootPath + "/resources";
    var pagesPath = rootPath + "/pages";
    if (!fileSys.existsSync(rootPath)) {
        fileSys.mkdirSync(rootPath);
    }
    if (!fileSys.existsSync(pagesPath)) {
        fileSys.mkdirSync(pagesPath);
    }

    fileSys.writeFileSync(rootPath + "/main.xml", fileContent.main);
    fileSys.writeFileSync(pagesPath + "/page.xml", fileContent.page);
    fileSys.writeFileSync(rootPath + "/sdp-package.xml", fileContent.sdp_package);

    if(metaData != null) {
        fileSys.writeFileSync(rootPath + "/metadata.json", JSON.stringify(metaData));
    }

    if (fileContent.extend_files.length > 0) {
        if (!fileSys.existsSync(resourcePath)) {
            fileSys.mkdirSync(resourcePath);
        }
        for (var i = 0; i < fileContent.extend_files.length; i++) {
            fileSys.writeFileSync(resourcePath + "/" + fileContent.extend_files[i].name, fileContent.extend_files[i].content);
        }
    }
    fileSys.writeFileSync(rootPath + "/resources/editor.json", origin);
}

function getInteraction(mType) {
    for (var i = 0; i < interationList.length; i++) {
        if (interationList[i].module_type == mType) {
            return interationList[i];
        }
    }

    return null;
}

/**
 * 获取互动习题元数据
 * @param mType 题型类型 参照interationList的module_type
 * @param uuid  习题ID
 * @param metaInfo 基础元数据
 * @returns {*}
 */
function getMetadata(mType, uuid, metaInfo) {
    metaInfo = metaInfo || {};

    var interaction = getInteraction(mType);
    if(!!interaction) {
        var metaData = {
            "identifier": uuid,
            "title": interaction.label,
            "description": "<p>" + interaction.label + "</p>",
            "language": "zh_CN",
            "preview": {},
            "tags": [],
            "keywords": [],
			"question_type": interaction.module_type,
            "custom_properties": {
                "question_type": interaction.module_type
            },
            "categories": {
                "res_type": [
                    {
                        "identifier": uuid,
                        "taxonpath": null,
                        "taxonname": interaction.label,
                        "taxoncode": interaction.code
                    }
                ],
                "mediatype": [
                    {
                        "identifier": null,
                        "taxonpath": "",
                        "taxonname": "其他媒体类型",
                        "taxoncode": "$F990000"
                    }
                ]
            },
            "life_cycle": {
                "version": "v1.0",
                "status": "CREATED",
                "enable": true,
                "creator": metaInfo.creator,
                "publisher": null,
                "provider": null,
                "provider_source": null,
                "create_time": new Date().toUTCString(),
                "last_update": null
            },
            "education_info": {
                "interactivity": 0,
                "interactivity_level": 0,
                "end_user_type": null,
                "semantic_density": null,
                "context": null,
                "age_range": null,
                "difficulty": null,
                "learning_time": null,
                "description": null,
                "language": null
            },
            "relations": [
                {
                    "source": metaInfo.chapter_id,
                    "source_title": metaInfo.chapter_name,
                    "source_type": "chapters",
                    "relation_type": "ASSOCIATE"
                }
            ],
            "tech_info": {
                "href": {
                    "format": "xml",
                    "size": 0,
                    "location": "${ref-path}/edu/esp/interaction/" + getModulePackage(uuid) + "/main.xml",
                    "requirements": [],
                    "md5": null,
                    "entry": null
                }
            },
            "copyright": {
                "right": null,
                "description": null,
                "author": null
            }
        };

        return metaData;
    }

    return {};
}
