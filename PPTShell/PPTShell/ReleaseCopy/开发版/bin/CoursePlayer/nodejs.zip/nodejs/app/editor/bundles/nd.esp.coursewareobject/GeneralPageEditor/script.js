define(['angular'],function(angular){
	return function(){
		this.name = 'nd.esp.coursewareobject.GeneralPageEditor';
		this.supportTypes = ['^page'];
		this.render = function(editor,resource){
			angular.quickstart(editor.element,{
				templateUrl:'bundles/nd.esp.coursewareobject/GeneralPageEditor/template.html',
				controller:['$scope', function($scope){
					$scope.data = resource.data;

					editor.ctrl = this;
				}],
			});
		};
		this.save = function(editor,resource){
			console.log('saving...');
		};
		this.destroy = function(editor,resource){
			console.log('destroy editor...',editor);
		};
	};
});