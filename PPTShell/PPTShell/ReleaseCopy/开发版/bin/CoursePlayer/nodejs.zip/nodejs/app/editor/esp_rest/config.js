/**
 * Created by ChenST on 2016/1/18.
 */
var path = require('path');

module.exports.config = (function () {

    return {
        repository: {
            objectRootPath: function () {
                return path.join(__dirname, '..', '..', 'userdatas', 'edu', 'esp', 'interaction');
                //return "D:\\editor_repository"
            },

            templateRootPath: function () {
                return path.join(__dirname, '..', '..');
                //return "D:\\editor_repository"
            }
        }
    }

})();