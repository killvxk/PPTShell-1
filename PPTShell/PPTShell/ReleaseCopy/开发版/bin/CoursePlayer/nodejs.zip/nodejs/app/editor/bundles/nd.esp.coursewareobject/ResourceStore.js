define([
    'jquery',
    'espEnvironment',
    'espModel'
],function(
    $,
    espEnvironment,
    espModel
){
    function adjustData(metadata, type, repository){
        var item = {title: metadata.title};
        item.href = repository.getResourceUrl(metadata.tech_info && metadata.tech_info.href && metadata.tech_info.href.location || '');
        if(metadata.preview){
            for(var key in metadata.preview){
                item.thumbHref = repository.getResourceUrl(metadata.preview[key]);
                if(key === '120' || key === '240'){
                    break;
                }
            }
        }
        if(!item.thumbHref){
            if('$RA0101' == type){
                item.thumbHref = item.href;
            }else if('$RA0102' == type){
            }else if('$RA0103' == type){
            }else{
            }
        }
        if(metadata.tech_info && metadata.tech_info.href && metadata.tech_info.href.requirements && metadata.tech_info.href.requirements.length){
            for(var j=0;j<metadata.tech_info.href.requirements.length;j++){
                var x = metadata.tech_info.href.requirements[j];
                if(x.name == 'resolution'){
                    item.resolution = x.value;
                    var parts = item.resolution && item.resolution.split("*");
                    if(parts && parts.length == 2){
                        item.width = parseInt(parts[0]);
                        item.height = parseInt(parts[1]);
                    }
                }else if(x.name == 'duration'){
                    item.duration = x.value;
                }
            }
        }
        item.size = metadata.tech_info && metadata.tech_info.href && metadata.tech_info.href.size;
        return item;
    }

    return function () {
        return {
            name: 'coursewareobject',
            title: '颗粒库',
            order: 0,
            paging: false,
            uploadEnabled: true,
            processUploadResponse: function (response, type, params) {
                if(!params || !params.coursewareobjectId) throw '未发现颗粒ID';
                return adjustData(response, type, espModel.repository.coursewareobject(params.coursewareobjectId));
            },
            uploadOptions: function (params) {
                if(!params || !params.coursewareobjectId) throw '未发现颗粒ID';
                return {
                    url: espModel.repository.coursewareobject(params.coursewareobjectId).getAssetUploadUrl()
                };
            },
            getFileWriter: function (params) {
                if(!params || !params.coursewareobjectId) throw '未发现颗粒ID';
                return espModel.repository.coursewareobject(params.coursewareobjectId).getAssetFileWriter();
            },
            getDataList: function (params) {
                if(!params || !params.coursewareobjectId) return $.Deferred().reject('未发现颗粒ID');
                var repository = espModel.repository.coursewareobject(params.coursewareobjectId);
                return repository.listAssets(params).then(function (result) {
                    $.isArray(result) || (result = []);
                    var items = [];
                    for(var i=0;i<result.length;i++){
                        items.push(adjustData(result[i], params.type, repository));
                    }
                    return items;
                });
            }
        };
    };
});