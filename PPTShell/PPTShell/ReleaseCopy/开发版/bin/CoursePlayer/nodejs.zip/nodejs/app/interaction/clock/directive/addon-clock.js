var AddonClockThree_create =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _appPresenter = __webpack_require__(1);

	var _appPresenter2 = _interopRequireDefault(_appPresenter);

	exports['default'] = function () {
	  return _appPresenter2['default'];
	};

	module.exports = exports['default'];

/***/ },
/* 1 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenterRun = __webpack_require__(2);

	var _presenterRun2 = _interopRequireDefault(_presenterRun);

	var _presenterSetState = __webpack_require__(22);

	var _presenterSetState2 = _interopRequireDefault(_presenterSetState);

	var _presenterGetState = __webpack_require__(23);

	var _presenterGetState2 = _interopRequireDefault(_presenterGetState);

	var _presenterProjectionInitProjectionMobile = __webpack_require__(24);

	var _presenterProjectionInitProjectionMobile2 = _interopRequireDefault(_presenterProjectionInitProjectionMobile);

	var _presenterGetQuestionInfo = __webpack_require__(27);

	var _presenterGetQuestionInfo2 = _interopRequireDefault(_presenterGetQuestionInfo);

	var _presenterSetPlayerController = __webpack_require__(28);

	var _presenterSetPlayerController2 = _interopRequireDefault(_presenterSetPlayerController);

	var _presenterOnEventReceived = __webpack_require__(29);

	var _presenterOnEventReceived2 = _interopRequireDefault(_presenterOnEventReceived);

	var _presenterControllerDestroyJs = __webpack_require__(30);

	var _presenterControllerDestroyJs2 = _interopRequireDefault(_presenterControllerDestroyJs);

	var _presenterControllerPageShow = __webpack_require__(31);

	var _presenterControllerPageShow2 = _interopRequireDefault(_presenterControllerPageShow);

	var _presenterControllerPageLeave = __webpack_require__(33);

	var _presenterControllerPageLeave2 = _interopRequireDefault(_presenterControllerPageLeave);

	var _presenterClockConfigJs = __webpack_require__(10);

	var _presenterClockConfigJs2 = _interopRequireDefault(_presenterClockConfigJs);

	var _presenterUtilsGetRotationDegreesJs = __webpack_require__(15);

	var _presenterUtilsGetRotationDegreesJs2 = _interopRequireDefault(_presenterUtilsGetRotationDegreesJs);

	var _presenterUtilsGetDetailRotateDegreeJs = __webpack_require__(16);

	var _presenterUtilsGetDetailRotateDegreeJs2 = _interopRequireDefault(_presenterUtilsGetDetailRotateDegreeJs);

	var _presenterClockInitClockJs = __webpack_require__(32);

	var _presenterClockInitClockJs2 = _interopRequireDefault(_presenterClockInitClockJs);

	var _presenterClockTimeJs = __webpack_require__(11);

	var _presenterClockTimeJs2 = _interopRequireDefault(_presenterClockTimeJs);

	exports['default'] = {
	    run: _presenterRun2['default'],
	    setState: _presenterSetState2['default'],
	    getState: _presenterGetState2['default'],
	    initProjectionMobile: _presenterProjectionInitProjectionMobile2['default'],
	    getQuestionInfo: _presenterGetQuestionInfo2['default'],
	    setPlayerController: _presenterSetPlayerController2['default'],
	    onEventReceived: _presenterOnEventReceived2['default'],
	    pageShow: _presenterControllerPageShow2['default'],
	    pageLeave: _presenterControllerPageLeave2['default'],
	    destroy: _presenterControllerDestroyJs2['default'],
	    config: _presenterClockConfigJs2['default'],
	    getDegree: _presenterUtilsGetRotationDegreesJs2['default'],
	    getHourDegree: _presenterUtilsGetDetailRotateDegreeJs2['default'],
	    initClock: _presenterClockInitClockJs2['default'],
	    time: _presenterClockTimeJs2['default']
	};
	module.exports = exports['default'];

/***/ },
/* 2 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 运行环境下, 初始化Module的方法
	 * @param view 运行视图(DOM对象)
	 * @param model Module的模型, Key-Value结构
	 * @remark 该方法为Module生命周期方法,仅在Module初始化时执行一次
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenterLogic = __webpack_require__(3);

	var _presenterLogic2 = _interopRequireDefault(_presenterLogic);

	exports['default'] = function (view, model) {
	  (0, _presenterLogic2['default'])(view, model, false);
	};

	module.exports = exports['default'];

/***/ },
/* 3 */
/***/ function(module, exports, __webpack_require__) {

	/* global $ paper icCreatePlayer */
	/**
	 * Module的逻辑
	 * @param view 视图对象, 根据是否为预览状态传入不同的视图对象
	 * @param model 模型对象
	 * @param isPreview 是否为编辑环境, true=编辑环境, false=运行环境
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _runtime = __webpack_require__(4);

	var _runtime2 = _interopRequireDefault(_runtime);

	var _constants = __webpack_require__(5);

	var _clockClockElementJs = __webpack_require__(6);

	var _clockClockElementJs2 = _interopRequireDefault(_clockClockElementJs);

	var _ControllerBindEvent = __webpack_require__(7);

	var _ControllerBindEvent2 = _interopRequireDefault(_ControllerBindEvent);

	var _ControllerDragEvent = __webpack_require__(13);

	var _ControllerDragEvent2 = _interopRequireDefault(_ControllerDragEvent);

	exports['default'] = function (view, model, isPreview) {
	    var $ = window.$;
	    // 将 model 值赋给 this
	    _presenter2['default'].model = model;
	    // 将 view 值存入 presenter
	    _presenter2['default'].view = view;
	    var $view = $(view);
	    _clockClockElementJs2['default'].current = $view;

	    //事件绑定
	    (0, _ControllerBindEvent2['default'])();
	    (0, _ControllerDragEvent2['default'])();
	    /**
	     与 app 端通信
	     */
	    if (window.icCreatePlayer && _runtime2['default'] === window.icCreatePlayer.RUNTIME.TEACHER_MOBILE) {
	        window.bridgeListener = window.Bridge.registerListener(_constants.eventName, _presenter2['default'].handleCallBack);
	    }
	    // 初始化教师端发送按钮
	    var isTeacherMobile = window.icCreatePlayer && _runtime2['default'] === window.icCreatePlayer.RUNTIME.TEACHER_MOBILE;
	    if (isTeacherMobile) {
	        // 结束任务
	        $view.on('click', '.js-stop-sync-button', function (e) {
	            _presenter2['default'].eventBus.sendEvent('Sync', {
	                source: model.ID,
	                type: 'cancel',
	                value: {
	                    syncId: _presenter2['default'].syncId
	                }
	            });
	        });
	    }
	};

	module.exports = exports['default'];

/***/ },
/* 4 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	var runtime = null;
	if (window.icCreatePlayer) {
	    runtime = window.player.getPlayerServices().getRuntime();
	}
	exports["default"] = runtime;
	module.exports = exports["default"];

/***/ },
/* 5 */
/***/ function(module, exports) {

	
	// 定义画布尺寸
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	var REAL_ESTATE = {
	    width: 1158,
	    height: 710
	};

	exports.REAL_ESTATE = REAL_ESTATE;
	// TODO shapeConfiguration 要写个测试保证配置项
	//export const shapeConfiguration = $.extend({}, defaultToolStatus, customizeToolStatus)

	var callNativePath = 'com.nd.pad.icr.ui.IcrJsBridge';

	exports.callNativePath = callNativePath;
	// 与 native 通信的事件名
	var eventName = 'drawClockThree';

	exports.eventName = eventName;
	////定义发送到投影端的事件
	//export const PROJECTIONEVENT = {
	//    //关闭或者隐藏时钟
	//    init: "initClock.teacher",
	//    //显示或隐藏分刻度
	//    showHideMin: "showHideMinuteDivision.teacher",
	//    //显示或者隐藏秒针
	//    showHideSec: "showHideSecondPointer.teacher",
	//    //联动状态
	//    linkage: "linkAgeButtonSelected.teacher",
	//    //按住指针转动了6度
	//    dragPointer: "dragPointer.teacher",
	//    //联动时当秒针过12时分针加1或减1
	//    minuChange:"minuteAddOrSubtract.teacher",
	//    //时针顺或逆时针转动6度
	//    sMHour:"secondMinuteHour.teacher",
	//    //传递当前的时间
	//    time:"currentClockTime.teacher"
	//}

/***/ },
/* 6 */
/***/ function(module, exports) {

	/**
	 * Created by Administrator on 2015/12/8.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	var clock = {};
	exports['default'] = Object.defineProperties({}, {
	    current: {
	        get: function get() {
	            return clock;
	        },
	        set: function set(v) {
	            clock = {
	                hourPointer: v.find('.hour_hand'),
	                minutePointer: v.find('.minute_hand'),
	                secondPointer: v.find('.second_hand'),
	                btnOff: v.find('.btn_off'),
	                clock_1: v.find('.clock01'),
	                clock_2: v.find('.clock02'),
	                clock_3: v.find('.clock03'),
	                clock_4: v.find('.clock04'),
	                gear: v.find('.gear'),
	                clock: v.find('.clock'),
	                clock_num: v.find('.clock_num'),
	                circle: v.find('.circle')
	            };
	        },
	        configurable: true,
	        enumerable: true
	    },
	    clear: {
	        set: function set(v) {
	            clock = null;
	        },
	        configurable: true,
	        enumerable: true
	    }
	});
	module.exports = exports['default'];

/***/ },
/* 7 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Chends on 2015/11/23.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _clockClockElementJs = __webpack_require__(6);

	var _clockClockElementJs2 = _interopRequireDefault(_clockClockElementJs);

	var _actionsJs = __webpack_require__(8);

	/**
	 * 绑定基本的事件
	 */

	exports['default'] = function () {

	    //联动状态切换
	    _clockClockElementJs2['default'].current.btnOff.on('click touchstart', _actionsJs.linkageBtn);

	    //下方时钟样式的切换
	    _clockClockElementJs2['default'].current.clock_1.on('click touchstart', _actionsJs.clock_1);

	    _clockClockElementJs2['default'].current.clock_2.on('click touchstart', _actionsJs.clock_2);

	    _clockClockElementJs2['default'].current.clock_3.on('click touchstart', _actionsJs.clock_3);

	    _clockClockElementJs2['default'].current.clock_4.on('click touchstart', _actionsJs.clock_4);
	};

	module.exports = exports['default'];

/***/ },
/* 8 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Chends on 2015/12/9.
	 * dom上绑定的事件的集合
	 */
	//import userInput from '../projection/userInput'
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.linkageBtn = linkageBtn;
	exports.clock_1 = clock_1;
	exports.clock_2 = clock_2;
	exports.clock_3 = clock_3;
	exports.clock_4 = clock_4;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _clockStyleChangeJs = __webpack_require__(9);

	var _clockTimeJs = __webpack_require__(11);

	var _clockTimeJs2 = _interopRequireDefault(_clockTimeJs);

	var _clockLinkageJs = __webpack_require__(12);

	var _clockLinkageJs2 = _interopRequireDefault(_clockLinkageJs);

	var _clockClockElementJs = __webpack_require__(6);

	var _clockClockElementJs2 = _interopRequireDefault(_clockClockElementJs);

	var _clockConfigJs = __webpack_require__(10);

	var _clockConfigJs2 = _interopRequireDefault(_clockConfigJs);

	function linkageBtn(event) {
	    event.preventDefault();
	    (0, _clockStyleChangeJs.handleLinkageBtnClick)();
	    if (_clockClockElementJs2['default'].current.btnOff.hasClass('on')) {
	        _clockClockElementJs2['default'].current.gear.show();
	        _clockConfigJs2['default'].isLink = true;
	    } else {
	        _clockClockElementJs2['default'].current.gear.hide();
	        _clockConfigJs2['default'].isLink = false;
	    }
	}

	function clock_1(event) {
	    event.preventDefault();
	    if ($(this).hasClass('on')) return;
	    (0, _clockStyleChangeJs.showOrHideSecondPointer)(false);
	}

	function clock_2(event) {
	    event.preventDefault();
	    if ($(this).hasClass('on')) return;
	    (0, _clockStyleChangeJs.showOrHideSecondPointer)(true);
	}

	function clock_3(event) {
	    event.preventDefault();
	    if ($(this).hasClass('on')) return;
	    (0, _clockStyleChangeJs.showOrHideMinuteDivision)(false);
	}

	function clock_4(event) {
	    event.preventDefault();
	    if ($(this).hasClass('on')) return;
	    (0, _clockStyleChangeJs.showOrHideMinuteDivision)(true);
	}

/***/ },
/* 9 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Chends on 2015/11/27.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _clockClockElementJs = __webpack_require__(6);

	var _clockClockElementJs2 = _interopRequireDefault(_clockClockElementJs);

	var _clockConfigJs = __webpack_require__(10);

	var _clockConfigJs2 = _interopRequireDefault(_clockConfigJs);

	//显示或隐藏秒针
	function showOrHideSecondPointer(isShow) {
	    if (isShow) {
	        _clockClockElementJs2['default'].current.clock_2.addClass('on');
	        _clockClockElementJs2['default'].current.clock_1.removeClass('on');
	        _clockClockElementJs2['default'].current.secondPointer.show();
	        _clockConfigJs2['default'].showSeconds = true;
	    } else {
	        _clockClockElementJs2['default'].current.clock_1.addClass('on');
	        _clockClockElementJs2['default'].current.clock_2.removeClass('on');
	        _clockClockElementJs2['default'].current.secondPointer.hide();
	        _clockConfigJs2['default'].showSeconds = false;
	    }
	}

	//显示或隐藏分刻度
	function showOrHideMinuteDivision(isShow) {
	    if (isShow) {
	        _clockClockElementJs2['default'].current.clock_4.addClass('on');
	        _clockClockElementJs2['default'].current.clock_3.removeClass('on');
	        _clockClockElementJs2['default'].current.clock_num.show();
	        _clockConfigJs2['default'].showOuterDivision = true;
	    } else {
	        _clockClockElementJs2['default'].current.clock_3.addClass('on');
	        _clockClockElementJs2['default'].current.clock_4.removeClass('on');
	        _clockClockElementJs2['default'].current.clock_num.hide();
	        _clockConfigJs2['default'].showOuterDivision = false;
	    }
	}
	//联动按钮被按下
	function handleLinkageBtnClick() {
	    if (!_clockClockElementJs2['default'].current.btnOff.hasClass('on')) {
	        _clockClockElementJs2['default'].current.btnOff.addClass('on');
	    } else {
	        _clockClockElementJs2['default'].current.btnOff.removeClass('on');
	    }
	}

	exports.showOrHideSecondPointer = showOrHideSecondPointer;
	exports.showOrHideMinuteDivision = showOrHideMinuteDivision;
	exports.handleLinkageBtnClick = handleLinkageBtnClick;

/***/ },
/* 10 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/12/16.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _timeJs = __webpack_require__(11);

	var _timeJs2 = _interopRequireDefault(_timeJs);

	exports['default'] = {
	    'isLink': false,
	    'showOuterDivision': false,
	    'showSeconds': false,
	    'time': _timeJs2['default'].current
	};
	module.exports = exports['default'];

/***/ },
/* 11 */
/***/ function(module, exports) {

	/**
	 * Created by Chends on 2015/11/30.
	 * 时间的相关操作
	 */
	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	var currcentTime = new Date();
	currcentTime.setHours(3);
	currcentTime.setMinutes(0);
	currcentTime.setSeconds(45);

	exports["default"] = Object.defineProperties({}, {
	    current: {
	        get: function get() {
	            return currcentTime;
	        },
	        set: function set(v) {
	            currcentTime = v;
	        },
	        configurable: true,
	        enumerable: true
	    },
	    hour: {
	        get: function get() {
	            return currcentTime.getHours();
	        },
	        set: function set(hour) {
	            currcentTime.setHours(hour);
	        },
	        configurable: true,
	        enumerable: true
	    },
	    minute: {
	        get: function get() {
	            return currcentTime.getMinutes();
	        },
	        set: function set(minute) {
	            currcentTime.setMinutes(minute);
	        },
	        configurable: true,
	        enumerable: true
	    },
	    second: {
	        get: function get() {
	            return currcentTime.getSeconds();
	        },
	        set: function set(second) {
	            currcentTime.setSeconds(second);
	        },
	        configurable: true,
	        enumerable: true
	    }
	});
	module.exports = exports["default"];

/***/ },
/* 12 */
/***/ function(module, exports) {

	/**
	 * Created by Administrator on 2015/12/7.
	 * 全局的是否联动状态
	 */

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	var isLinkage = false;
	exports["default"] = Object.defineProperties({}, {
	    current: {
	        get: function get() {
	            return isLinkage;
	        },
	        set: function set(v) {
	            isLinkage = v;
	        },
	        configurable: true,
	        enumerable: true
	    }
	});
	module.exports = exports["default"];

/***/ },
/* 13 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/11/24.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.handleDraggableMouseDown = handleDraggableMouseDown;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _UtilsGetAngleJs = __webpack_require__(14);

	var _UtilsGetAngleJs2 = _interopRequireDefault(_UtilsGetAngleJs);

	var _UtilsGetRotationDegreesJs = __webpack_require__(15);

	var _UtilsGetRotationDegreesJs2 = _interopRequireDefault(_UtilsGetRotationDegreesJs);

	var _UtilsGetDetailRotateDegreeJs = __webpack_require__(16);

	var _UtilsGetDetailRotateDegreeJs2 = _interopRequireDefault(_UtilsGetDetailRotateDegreeJs);

	var _clockPointerRotateJs = __webpack_require__(17);

	var _clockPointerRotateJs2 = _interopRequireDefault(_clockPointerRotateJs);

	var _clockTimeJs = __webpack_require__(11);

	var _clockTimeJs2 = _interopRequireDefault(_clockTimeJs);

	var _clockAdjustClockJs = __webpack_require__(18);

	var _clockAdjustClockJs2 = _interopRequireDefault(_clockAdjustClockJs);

	var _clockGetCurrentHourJs = __webpack_require__(19);

	var _clockGetCurrentHourJs2 = _interopRequireDefault(_clockGetCurrentHourJs);

	var _clockGetCurrentMinuteJs = __webpack_require__(20);

	var _clockGetCurrentMinuteJs2 = _interopRequireDefault(_clockGetCurrentMinuteJs);

	var _clockGetCurrentSecondJs = __webpack_require__(21);

	var _clockGetCurrentSecondJs2 = _interopRequireDefault(_clockGetCurrentSecondJs);

	var _clockClockElementJs = __webpack_require__(6);

	var _clockClockElementJs2 = _interopRequireDefault(_clockClockElementJs);

	var _clockConfigJs = __webpack_require__(10);

	var _clockConfigJs2 = _interopRequireDefault(_clockConfigJs);

	var _clockLinkageJs = __webpack_require__(12);

	var _clockLinkageJs2 = _interopRequireDefault(_clockLinkageJs);

	var moveableObj = null;
	var dragging = false;
	var downAngle = null;
	var rotateAngle = null;
	//当前的指针
	var currentPointer = null;

	// 释放鼠标，清理
	var handleMouseup = function handleMouseup(e) {
	    dragging = false;
	    rotateAngle = null;
	    moveableObj = null;
	    downAngle = null;
	    _presenter2['default'].view.removeEventListener('touchend', handleMouseup);
	    _presenter2['default'].view.removeEventListener('mouseup', handleMouseup);
	    _presenter2['default'].view.removeEventListener('touchmove', handleMousemove);
	    _presenter2['default'].view.removeEventListener('mousemove', handleMousemove);
	    if (_clockConfigJs2['default'].isLink) {
	        _clockTimeJs2['default'].hour = (0, _clockGetCurrentHourJs2['default'])();
	        _clockTimeJs2['default'].minute = (0, _clockGetCurrentMinuteJs2['default'])();
	        _clockTimeJs2['default'].second = (0, _clockGetCurrentSecondJs2['default'])();
	        if (currentPointer !== 'hour') {
	            (0, _clockAdjustClockJs2['default'])(_clockTimeJs2['default'].hour, _clockTimeJs2['default'].minute, _clockTimeJs2['default'].second);
	        }
	    }
	    currentPointer = null;
	};

	// 移动鼠标
	var handleMousemove = function handleMousemove(e) {
	    if (!dragging || !moveableObj || !currentPointer) return;
	    e.preventDefault();
	    var ePoint = {
	        x: e.clientX || e.touches[0].clientX,
	        y: e.clientY || e.touches[0].clientY
	    };
	    //是否需要调整时针的位置
	    adjustPointer();

	    //拖动事件发生时位置的角度
	    var eAngle = (0, _UtilsGetAngleJs2['default'])(ePoint);
	    var angle = eAngle - downAngle;
	    if (Math.abs(angle) < 6) return;

	    //几个临界点的判断
	    if (downAngle === 354 && (eAngle > 358 || eAngle < 180)) {
	        downAngle = 0;
	        rotateAngle = (rotateAngle + 6) % 360;
	        (0, _clockPointerRotateJs2['default'])($(moveableObj), rotateAngle);
	        linkAgeHour(true);
	        if (_clockConfigJs2['default'].isLink && currentPointer === 'second') {
	            var mAngle = (0, _UtilsGetRotationDegreesJs2['default'])(_clockClockElementJs2['default'].current.minutePointer);
	            (0, _clockPointerRotateJs2['default'])(_clockClockElementJs2['default'].current.minutePointer, (mAngle + 6) % 360);
	            adjustHourPointer(true);
	        }
	        _clockTimeJs2['default'].hour = (0, _clockGetCurrentHourJs2['default'])();
	        _clockTimeJs2['default'].minute = (0, _clockGetCurrentMinuteJs2['default'])();
	        _clockTimeJs2['default'].second = (0, _clockGetCurrentSecondJs2['default'])();
	        return;
	    }

	    if (downAngle === 0) {
	        if (eAngle >= 6 && eAngle < 180) {
	            downAngle = 6;
	            rotateAngle = (rotateAngle + 6) % 360;
	            (0, _clockPointerRotateJs2['default'])($(moveableObj), rotateAngle);
	            linkAgeHour(true);
	        } else if (eAngle > 180 && eAngle <= 354) {
	            downAngle = 354;
	            rotateAngle = (rotateAngle - 6 + 360) % 360;
	            (0, _clockPointerRotateJs2['default'])($(moveableObj), rotateAngle);

	            linkAgeHour(false);
	            if (_clockConfigJs2['default'].isLink && currentPointer === 'second') {
	                var mAngle = (0, _UtilsGetRotationDegreesJs2['default'])(_clockClockElementJs2['default'].current.minutePointer);
	                (0, _clockPointerRotateJs2['default'])(_clockClockElementJs2['default'].current.minutePointer, (mAngle - 6) % 360);
	                adjustHourPointer(false);
	            }
	        }
	        _clockTimeJs2['default'].hour = (0, _clockGetCurrentHourJs2['default'])();
	        _clockTimeJs2['default'].minute = (0, _clockGetCurrentMinuteJs2['default'])();
	        _clockTimeJs2['default'].second = (0, _clockGetCurrentSecondJs2['default'])();
	        return;
	    }

	    if (Math.abs(angle) > 30 && Math.abs(angle) < 120) {
	        var div = 1;
	        if (angle > 0) {
	            div = Math.floor(angle / 6);
	        } else {
	            div = Math.ceil(angle / 6);
	        }
	        downAngle = (downAngle + 6 * div) % 360;
	        rotateAngle = (rotateAngle + 6 * div) % 360;
	        (0, _clockPointerRotateJs2['default'])($(moveableObj), rotateAngle);
	        fastAdjustHourPointer(div);
	        return;
	    }

	    if (angle >= 6 && angle <= 180 || angle < -180) {
	        downAngle = (downAngle + 6) % 360;
	        rotateAngle = (rotateAngle + 6) % 360;
	        (0, _clockPointerRotateJs2['default'])($(moveableObj), rotateAngle);
	        linkAgeHour(true);
	    }

	    //如果逆时针大于6度
	    if (angle <= -6 && angle > -180 || angle > 180) {
	        downAngle = (downAngle - 6 + 360) % 360;
	        rotateAngle = (rotateAngle - 6 + 360) % 360;
	        (0, _clockPointerRotateJs2['default'])($(moveableObj), rotateAngle);
	        linkAgeHour(false);
	    }
	    _clockTimeJs2['default'].hour = (0, _clockGetCurrentHourJs2['default'])();
	    _clockTimeJs2['default'].minute = (0, _clockGetCurrentMinuteJs2['default'])();
	    _clockTimeJs2['default'].second = (0, _clockGetCurrentSecondJs2['default'])();
	};
	//按下鼠标事件

	function handleDraggableMouseDown(e) {
	    e.preventDefault();
	    moveableObj = e.target;
	    dragging = true;
	    // mouseup 与 mousemove 事件由 view 监听
	    _presenter2['default'].view.addEventListener('mousemove', handleMousemove);
	    _presenter2['default'].view.addEventListener('touchmove', handleMousemove);
	    _presenter2['default'].view.addEventListener('touchend', handleMouseup);
	    _presenter2['default'].view.addEventListener('mouseup', handleMouseup);
	    //获得当前被按住的指针的旋转角度
	    rotateAngle = (0, _UtilsGetRotationDegreesJs2['default'])($(moveableObj));
	    //将旋转角度转化为360度体系下的值
	    if ($(moveableObj).hasClass('hour_hand')) {
	        //转为360度体系中时针的当前角度
	        downAngle = (rotateAngle + 90) % 360;
	        currentPointer = "hour";
	    } else if ($(moveableObj).hasClass('minute_hand')) {
	        downAngle = rotateAngle % 360;
	        currentPointer = "minute";
	    } else {
	        downAngle = (rotateAngle + 270) % 360;
	        currentPointer = "second";
	    }

	    if (_clockConfigJs2['default'].isLink && currentPointer !== 'hour') {
	        (0, _clockAdjustClockJs2['default'])(_clockTimeJs2['default'].hour, _clockTimeJs2['default'].minute, _clockTimeJs2['default'].second);
	    }
	}

	//联动状态下当分针变化一分钟时，时针也要相应的改变0.5度
	var linkAgeHour = function linkAgeHour(isclockwise) {
	    if (!_clockConfigJs2['default'].isLink || currentPointer !== 'minute') return;
	    adjustHourPointer(isclockwise);
	};

	//时针顺或逆时针加0.5度
	var adjustHourPointer = function adjustHourPointer(isclockwise) {
	    if (!_clockConfigJs2['default'].isLink) return;
	    var hAngle = (0, _UtilsGetDetailRotateDegreeJs2['default'])(_clockClockElementJs2['default'].current.hourPointer);
	    if (isclockwise) {
	        (0, _clockPointerRotateJs2['default'])(_clockClockElementJs2['default'].current.hourPointer, (hAngle + 0.5) % 360);
	    } else {
	        (0, _clockPointerRotateJs2['default'])(_clockClockElementJs2['default'].current.hourPointer, (hAngle - 0.5) % 360);
	    }
	};

	var fastAdjustHourPointer = function fastAdjustHourPointer(div) {
	    if (!_clockConfigJs2['default'].isLink || currentPointer !== 'minute') return;
	    var hAngle = (0, _UtilsGetDetailRotateDegreeJs2['default'])(_clockClockElementJs2['default'].current.hourPointer);
	    (0, _clockPointerRotateJs2['default'])(_clockClockElementJs2['default'].current.hourPointer, (hAngle + 0.5 * div) % 360);
	};

	//当不联动时，如果时针一开始不是在刻度上，那么第一次要调整到下一个最近的刻度上
	var adjustPointer = function adjustPointer() {
	    if (currentPointer !== 'hour' || downAngle % 6 === 0) return;
	    var temp = Math.floor(downAngle / 6);
	    var temp1 = downAngle % 6;
	    if (temp1 < 3) {
	        downAngle = temp * 6;
	    } else {
	        downAngle = (temp + 1) * 6 % 360;
	    }
	    rotateAngle = (downAngle - 90) % 360;
	};

	exports['default'] = function () {
	    //三个指针注册监听事件
	    $(_presenter2['default'].view).find('.clock').on('mousedown touchstart', '.draggable', handleDraggableMouseDown);
	};

/***/ },
/* 14 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Chends on 2015/11/24.
	 * 获取点在以表盘圆心为原点的坐标体系中，与x轴正方向之间角的角度
	 * 从12时开始顺时针为0到360度
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _clockClockElementJs = __webpack_require__(6);

	var _clockClockElementJs2 = _interopRequireDefault(_clockClockElementJs);

	exports['default'] = function (point) {
	    //整个表盘的中心点
	    var centerPoint = {
	        x: _clockClockElementJs2['default'].current.circle.offset().left + _clockClockElementJs2['default'].current.circle.width() / 2,
	        y: _clockClockElementJs2['default'].current.circle.offset().top + _clockClockElementJs2['default'].current.circle.height() / 2
	    };
	    var radious = Math.atan2(point.y - centerPoint.y, point.x - centerPoint.x);

	    radious = radious * (180 / Math.PI) + 90;
	    if (radious < 0) {
	        radious += 360;
	    }
	    radious = Math.round(radious);
	    radious %= 360;
	    return radious;
	};

	module.exports = exports['default'];

/***/ },
/* 15 */
/***/ function(module, exports) {

	/**
	 * Created by chends on 2015/11/25.
	 * 获取当前对象中transform属性的rotate值
	 * http://stackoverflow.com/questions/8270612/get-element-moz-transformrotate-value-in-jquery/11840120#11840120
	 */

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});

	exports["default"] = function (obj) {
	    var matrix = obj.css("-webkit-transform") || obj.css("transform");
	    if (matrix !== 'none') {
	        var values = matrix.split('(')[1].split(')')[0].split(',');
	        var a = values[0];
	        var b = values[1];
	        var angle = Math.round(Math.atan2(b, a) * (180 / Math.PI));
	    } else {
	        //如果该元素被隐藏，那么它的角度取一个不存在的值361
	        var angle = 361;
	    }
	    return angle < 0 ? angle + 360 : angle;
	};

	module.exports = exports["default"];

/***/ },
/* 16 */
/***/ function(module, exports) {

	/**
	 * Created by chends on 2015/12/7.
	 * 获取当前对象中transform属性的精确的rotate值
	 * http://stackoverflow.com/questions/8270612/get-element-moz-transformrotate-value-in-jquery/11840120#11840120
	 */

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});

	exports["default"] = function (obj) {
	    var matrix = obj.css("-webkit-transform") || obj.css("transform");
	    if (matrix !== 'none') {
	        var values = matrix.split('(')[1].split(')')[0].split(',');
	        var a = values[0];
	        var b = values[1];
	        var angle = Math.atan2(b, a) * (180 / Math.PI);
	        angle = verifyValue(angle);
	    } else {
	        //如果该元素被隐藏，那么它的角度取一个不存在的值361
	        var angle = 361;
	    }
	    return angle < 0 ? angle + 360 : angle;
	};

	var verifyValue = function verifyValue(value) {
	    var result = undefined;
	    value = value % 360;
	    if (value % 2 === 0) {
	        result = value;
	    } else {
	        var temp = Math.floor(value);
	        var temp1 = value - temp;
	        if (temp1 < 0.3) {
	            result = temp;
	        } else if (temp1 > 0.4 && temp1 < 0.7) {
	            result = temp + 0.5;
	        } else if (temp1 > 0.9) {
	            result = temp + 1;
	        }
	    }
	    result = result === 360 ? 0 : result;
	    return result;
	};
	module.exports = exports["default"];

/***/ },
/* 17 */
/***/ function(module, exports) {

	/**
	 * Created by Administrator on 2015/11/27.
	 */

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});

	exports["default"] = function (pointer, value) {
	    pointer.css({
	        webkitTransform: "rotate(" + value + "deg)",
	        transform: "rotate(" + value + "deg) translateZ(0)"
	    });
	};

	module.exports = exports["default"];

/***/ },
/* 18 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/11/30.
	 * 根据传入的时间来调整时钟的位置
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _pointerRotateJs = __webpack_require__(17);

	var _pointerRotateJs2 = _interopRequireDefault(_pointerRotateJs);

	var _clockElementJs = __webpack_require__(6);

	var _clockElementJs2 = _interopRequireDefault(_clockElementJs);

	exports['default'] = function (hour, minute, second) {
	    var sAngle = (second * 6 + 90) % 360;
	    //分针的角度为分钟数乘以6度
	    var mAngle = minute * 6;
	    //时针的角度为小时数乘以30度再加上分钟数,时针的位置不用对准刻度
	    var hAngle = ((hour % 12 + minute / 60) * 30 + 270) % 360;
	    (0, _pointerRotateJs2['default'])(_clockElementJs2['default'].current.secondPointer, sAngle);
	    (0, _pointerRotateJs2['default'])(_clockElementJs2['default'].current.minutePointer, mAngle);
	    (0, _pointerRotateJs2['default'])(_clockElementJs2['default'].current.hourPointer, hAngle);
	};

	module.exports = exports['default'];

/***/ },
/* 19 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/12/1.
	 * 获取时针所在的位置对应的小时数
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _UtilsGetDetailRotateDegreeJs = __webpack_require__(16);

	var _UtilsGetDetailRotateDegreeJs2 = _interopRequireDefault(_UtilsGetDetailRotateDegreeJs);

	var _clockElementJs = __webpack_require__(6);

	var _clockElementJs2 = _interopRequireDefault(_clockElementJs);

	exports['default'] = function () {
	    var currentHour = -1;
	    var rotateValue = (0, _UtilsGetDetailRotateDegreeJs2['default'])(_clockElementJs2['default'].current.hourPointer); //当前时钟的旋转角度
	    if (rotateValue >= 0 && rotateValue < 180) {
	        if (rotateValue >= 0 && rotateValue < 90) {
	            if (rotateValue < 30) {
	                currentHour = 3;
	            } else if (rotateValue >= 60) {
	                currentHour = 5;
	            } else {
	                currentHour = 4;
	            }
	        } else {
	            if (rotateValue < 120) {
	                currentHour = 6;
	            } else if (rotateValue >= 150) {
	                currentHour = 8;
	            } else {
	                currentHour = 7;
	            }
	        }
	    } else {
	        if (rotateValue < 270) {
	            if (rotateValue < 210) {
	                currentHour = 9;
	            } else if (rotateValue >= 240) {
	                currentHour = 11;
	            } else {
	                currentHour = 10;
	            }
	        } else {
	            if (rotateValue < 300) {
	                currentHour = 0;
	            } else if (rotateValue >= 330) {
	                currentHour = 2;
	            } else {
	                currentHour = 1;
	            }
	        }
	    }
	    return currentHour;
	};

	module.exports = exports['default'];

/***/ },
/* 20 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/12/2.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _UtilsGetRotationDegreesJs = __webpack_require__(15);

	var _UtilsGetRotationDegreesJs2 = _interopRequireDefault(_UtilsGetRotationDegreesJs);

	var _clockElementJs = __webpack_require__(6);

	var _clockElementJs2 = _interopRequireDefault(_clockElementJs);

	exports['default'] = function () {
	    var currentMinute = -1;
	    var rotateValue = (0, _UtilsGetRotationDegreesJs2['default'])(_clockElementJs2['default'].current.minutePointer);
	    currentMinute = Math.round(rotateValue / 6);
	    return currentMinute;
	};

	module.exports = exports['default'];

/***/ },
/* 21 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/12/2.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _UtilsGetRotationDegreesJs = __webpack_require__(15);

	var _UtilsGetRotationDegreesJs2 = _interopRequireDefault(_UtilsGetRotationDegreesJs);

	var _clockTimeJs = __webpack_require__(11);

	var _clockTimeJs2 = _interopRequireDefault(_clockTimeJs);

	var _clockElementJs = __webpack_require__(6);

	var _clockElementJs2 = _interopRequireDefault(_clockElementJs);

	exports['default'] = function () {
	    var currentSec = -10;
	    var rotateValue = (0, _UtilsGetRotationDegreesJs2['default'])(_clockElementJs2['default'].current.secondPointer);
	    if (rotateValue <= 90) {
	        currentSec = (rotateValue + 270) % 360 / 6;
	    } else if (rotateValue > 90 && rotateValue < 360) {
	        currentSec = (rotateValue - 90) / 6;
	    } else {
	        //如果秒针被隐藏
	        currentSec = _clockTimeJs2['default'].second;
	    }
	    return currentSec;
	};

	module.exports = exports['default'];

/***/ },
/* 22 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	exports["default"] = function (state) {
	  var currentState;
	  if (state) {
	    currentState = JSON.parse(state);
	    // ToDo:处理Module的状态恢复
	  }
	};

	module.exports = exports["default"];

/***/ },
/* 23 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 获得当前Module的状态信息
	 * 可用于Module的状态恢复和保存
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	exports['default'] = function () {
	  // TODO: 添加符合Module需求的状态对象
	  var moduleState = JSON.stringify({
	    module_id: _presenter2['default'].model.ID
	  });
	  return moduleState;
	};

	module.exports = exports['default'];

/***/ },
/* 24 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _runtimeJs = __webpack_require__(4);

	var _runtimeJs2 = _interopRequireDefault(_runtimeJs);

	var _registerNativeListener = __webpack_require__(25);

	var _registerNativeListener2 = _interopRequireDefault(_registerNativeListener);

	var _triggerUserInput = __webpack_require__(26);

	var _triggerUserInput2 = _interopRequireDefault(_triggerUserInput);

	/**
	 *  移动环境投影端
	 */

	exports['default'] = function () {
	  if (window.icCreatePlayer && _runtimeJs2['default'] === window.icCreatePlayer.RUNTIME.PROJECTION_MOBILE) {
	    (0, _registerNativeListener2['default'])('TriggerUserInput', _triggerUserInput2['default']);
	  }
	};

	module.exports = exports['default'];

/***/ },
/* 25 */
/***/ function(module, exports) {

	

	/**
	   * 投影端注册原生事件监听
	   * @param eventName
	   * @param callback
	   */
	"use strict";

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	exports["default"] = function (eventName, callback) {
	  if (window.isApp && window.Bridge && window.Bridge.registerListener) {
	    window.Bridge.registerListener(eventName, callback);
	  }
	};

	module.exports = exports["default"];

/***/ },
/* 26 */
/***/ function(module, exports, __webpack_require__) {

	/* global icCreatePlayer */
	//import presenter from '../../presenter'
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _runtime = __webpack_require__(4);

	var _runtime2 = _interopRequireDefault(_runtime);

	var _constantsJs = __webpack_require__(5);

	var _clockStyleChangeJs = __webpack_require__(9);

	var _clockPointerRotateJs = __webpack_require__(17);

	var _clockPointerRotateJs2 = _interopRequireDefault(_clockPointerRotateJs);

	var _clockAdjustClockJs = __webpack_require__(18);

	var _clockAdjustClockJs2 = _interopRequireDefault(_clockAdjustClockJs);

	var _clockClockElementJs = __webpack_require__(6);

	var _clockClockElementJs2 = _interopRequireDefault(_clockClockElementJs);

	/**
	 * 投影端接受指令操作
	 */

	exports['default'] = function (data) {
	    // 不为本模块指令不操作
	    if (window.icCreatePlayer && (data.source !== 'ClockThree' || _runtime2['default'] !== window.icCreatePlayer.RUNTIME.PROJECTION_MOBILE)) {
	        return;
	    }

	    switch (data.item) {
	        //case PROJECTIONEVENT.init:
	        //    $(presenter.view).find('.js-clock-view').toggleClass('is-hide');
	        //    break;
	        case _constantsJs.PROJECTIONEVENT.showHideMin:
	            (0, _clockStyleChangeJs.showOrHideMinuteDivision)(data.value.isShow);
	            break;
	        case _constantsJs.PROJECTIONEVENT.showHideSec:
	            (0, _clockStyleChangeJs.showOrHideSecondPointer)(data.value.isShow);
	            break;
	        case _constantsJs.PROJECTIONEVENT.linkage:
	            if (data.value.isLinkage) {
	                if (!_clockClockElementJs2['default'].current.btnOff.hasClass('on')) {
	                    _clockClockElementJs2['default'].current.btnOff.addClass('on');
	                }
	            } else {
	                _clockClockElementJs2['default'].current.btnOff.removeClass('on');
	            }
	            //clockElement.current.btnOff.toggleClass('on');
	            if (data.value.isLinkage) {
	                (0, _clockAdjustClockJs2['default'])(data.value.hour, data.value.minute, data.value.second);
	                _clockClockElementJs2['default'].current.gear.show();
	            } else {
	                _clockClockElementJs2['default'].current.gear.hide();
	            }
	            break;
	        case _constantsJs.PROJECTIONEVENT.dragPointer:
	            var temp = data.value.currPointer;
	            if (temp === 'hour') {
	                temp = _clockClockElementJs2['default'].current.hourPointer;
	            } else if (temp === 'minute') {
	                temp = _clockClockElementJs2['default'].current.minutePointer;
	            } else {
	                temp = _clockClockElementJs2['default'].current.secondPointer;
	            }
	            (0, _clockPointerRotateJs2['default'])(temp, data.value.angle);
	            break;
	        case _constantsJs.PROJECTIONEVENT.time:
	            (0, _clockAdjustClockJs2['default'])(data.value.hour, data.value.minute, data.value.second);
	            break;
	    }
	};

	module.exports = exports['default'];

/***/ },
/* 27 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	exports['default'] = function () {
	    var url = '',
	        question_id = '';
	    try {
	        var _presenter$model = _presenter2['default'].model;
	        var _question_id = _presenter$model.question_id;
	        var question_url = _presenter$model.question_url;

	        url = JSON.stringify(question_url);
	    } catch (e) {
	        //console.log('json stringify failed')
	    }
	    return {
	        id: question_id,
	        dispatchOnly: true,
	        type_code: 'nd_clock',
	        type_name: '模拟时钟',
	        statistics_type: 'no_need', url: url
	    };
	};

	module.exports = exports['default'];

/***/ },
/* 28 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	exports['default'] = function (controller) {
	  _presenter2['default'].controller = controller;
	  _presenter2['default'].eventBus = controller.getEventBus();
	  _presenter2['default'].eventBus.addEventListener('SyncCallback', _presenter2['default']);
	  _presenter2['default'].eventBus.addEventListener('PageLoaded', _presenter2['default']);
	};

	module.exports = exports['default'];

/***/ },
/* 29 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	exports['default'] = function (eventName, eventData) {
	    switch (eventName) {
	        case 'SyncCallback':
	            SyncCallback(eventData);
	            break;
	        case 'PageLoaded':
	            break;
	        default:

	    }
	};

	var SyncCallback = function SyncCallback(eventData) {
	    var type = eventData.type;
	    var value = eventData.value;

	    var $view = window.$(_presenter2['default'].view).find('#sendTask');
	    switch (type) {
	        case 'request':
	            // 发送任务
	            _presenter2['default'].syncId = value.syncId;
	            if (value.result) {
	                // 成功
	                $view.show();
	            } else {
	                window.ClassroomUtils.showTipMessageBox('同步题目失败');
	            }
	            break;
	        case 'cancel':
	            // 结束同步
	            if (value.result) {
	                $view.hide();
	            } else {
	                window.ClassroomUtils.showMessageBox([{
	                    html: '关闭'
	                }, {
	                    html: '重试',
	                    target: 'h5',
	                    callback: {
	                        eventName: 'ClockThree',
	                        eventData: {
	                            source: _presenter2['default'].model.ID,
	                            item: 'retry'
	                        }
	                    }
	                }], '结束任务失败！');
	            }
	            break;
	    }
	};
	module.exports = exports['default'];

/***/ },
/* 30 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Chends on 2015/11/23.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _clockClockElementJs = __webpack_require__(6);

	var _clockClockElementJs2 = _interopRequireDefault(_clockClockElementJs);

	var _ControllerActionsJs = __webpack_require__(8);

	var _ControllerDragEventJs = __webpack_require__(13);

	/**
	 * 销毁所有监听事件
	 */

	exports['default'] = function () {
	  _clockClockElementJs2['default'].current.btnOff.off('click touchstart', _ControllerActionsJs.linkageBtn);
	  _clockClockElementJs2['default'].current.clock_1.off('click touchstart', _ControllerActionsJs.clock_1);
	  _clockClockElementJs2['default'].current.clock_2.off('click touchstart', _ControllerActionsJs.clock_2);
	  _clockClockElementJs2['default'].current.clock_3.off('click touchstart', _ControllerActionsJs.clock_3);
	  _clockClockElementJs2['default'].current.clock_4.off('click touchstart', _ControllerActionsJs.clock_4);
	  _clockClockElementJs2['default'].current.clock.off('mousedown touchstart', '.draggable', _ControllerDragEventJs.handleDraggableMouseDown);
	};

	module.exports = exports['default'];

/***/ },
/* 31 */
/***/ function(module, exports, __webpack_require__) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

	var _clockInitClock = __webpack_require__(32);

	var _clockInitClock2 = _interopRequireDefault(_clockInitClock);

	exports["default"] = function (view, model) {
	    //初始化Clock
	    if (model && typeof model.question_url !== "undefined") {
	        var content = model.question_url.content;
	        (0, _clockInitClock2["default"])(content.isLink, content.showOuterDivision, content.showSeconds, content.hourDegree, content.minDegree, content.secondDegree);
	    }
	};

	module.exports = exports["default"];

/***/ },
/* 32 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/11/27.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports['default'] = initClock;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _styleChangeJs = __webpack_require__(9);

	var _pointerRotateJs = __webpack_require__(17);

	var _pointerRotateJs2 = _interopRequireDefault(_pointerRotateJs);

	var _clockTimeJs = __webpack_require__(11);

	var _clockTimeJs2 = _interopRequireDefault(_clockTimeJs);

	var _clockElementJs = __webpack_require__(6);

	var _clockElementJs2 = _interopRequireDefault(_clockElementJs);

	var _clockConfigJs = __webpack_require__(10);

	var _clockConfigJs2 = _interopRequireDefault(_clockConfigJs);

	function initClock(isLink, showDivisition, showSecond, hourDegree, minDegree, secondDegree) {

	    //是否联动
	    if (isLink) {
	        _clockElementJs2['default'].current.btnOff.addClass('on');
	        _clockElementJs2['default'].current.gear.show();
	        _clockConfigJs2['default'].isLink = true;
	    } else {
	        _clockElementJs2['default'].current.btnOff.removeClass('on');
	        _clockElementJs2['default'].current.gear.hide();
	        _clockConfigJs2['default'].isLink = false;
	    }

	    //是否显示分刻度
	    (0, _styleChangeJs.showOrHideMinuteDivision)(showDivisition);

	    //是否显示秒针
	    (0, _styleChangeJs.showOrHideSecondPointer)(showSecond);

	    //角度的初始化
	    if (typeof hourDegree !== 'undefined' && hourDegree !== null) {
	        (0, _pointerRotateJs2['default'])(_clockElementJs2['default'].current.hourPointer, hourDegree);
	        _clockTimeJs2['default'].hour = getHour(hourDegree);
	    }

	    if (typeof minDegree !== 'undefined' && minDegree !== null) {
	        (0, _pointerRotateJs2['default'])(_clockElementJs2['default'].current.minutePointer, minDegree);
	        _clockTimeJs2['default'].minute = Math.round(minDegree / 6);
	    }

	    if (typeof secondDegree !== 'undefined' && secondDegree !== null) {
	        (0, _pointerRotateJs2['default'])(_clockElementJs2['default'].current.secondPointer, secondDegree);
	        _clockTimeJs2['default'].second = getSecond(secondDegree);
	    }
	}

	//const verifyValue = (value) => {
	//    let result;
	//    value = value % 360;
	//    if(value % 6 === 0) {
	//        result = value;
	//    } else {
	//        let temp = Math.floor(value / 6);
	//        let temp1 = value % 6;
	//        if(temp1 < 3) {
	//            result = temp * 6;
	//        } else {
	//            result = (temp + 1) * 6;
	//        }
	//    }
	//    result = (result === 360) ? 0 :result;
	//    return result;
	//}

	//根据传入的时间来设置hour
	var getHour = function getHour(rotateValue) {
	    var currentHour = -1;
	    if (rotateValue >= 0 && rotateValue < 180) {
	        if (rotateValue >= 0 && rotateValue < 90) {
	            if (rotateValue < 30) {
	                currentHour = 3;
	            } else if (rotateValue >= 60) {
	                currentHour = 5;
	            } else {
	                currentHour = 4;
	            }
	        } else {
	            if (rotateValue < 120) {
	                currentHour = 6;
	            } else if (rotateValue >= 150) {
	                currentHour = 8;
	            } else {
	                currentHour = 7;
	            }
	        }
	    } else {
	        if (rotateValue < 270) {
	            if (rotateValue < 210) {
	                currentHour = 9;
	            } else if (rotateValue >= 240) {
	                currentHour = 11;
	            } else {
	                currentHour = 10;
	            }
	        } else {
	            if (rotateValue < 300) {
	                currentHour = 0;
	            } else if (rotateValue >= 330) {
	                currentHour = 2;
	            } else {
	                currentHour = 1;
	            }
	        }
	    }
	    return currentHour;
	};

	var getSecond = function getSecond(rotateValue) {
	    var currentSec = -1;
	    if (rotateValue <= 90) {
	        currentSec = (rotateValue + 270) % 360 / 6;
	    } else if (rotateValue > 90 && rotateValue < 360) {
	        currentSec = (rotateValue - 90) / 6;
	    }
	    return currentSec;
	};
	module.exports = exports['default'];

/***/ },
/* 33 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _destroy = __webpack_require__(30);

	var _destroy2 = _interopRequireDefault(_destroy);

	var _clockClockElementJs = __webpack_require__(6);

	var _clockClockElementJs2 = _interopRequireDefault(_clockClockElementJs);

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	exports['default'] = function () {
	    (0, _destroy2['default'])();
	    _presenter2['default'].model = null;
	    _presenter2['default'].view = null;
	};

	module.exports = exports['default'];

/***/ }
/******/ ]);