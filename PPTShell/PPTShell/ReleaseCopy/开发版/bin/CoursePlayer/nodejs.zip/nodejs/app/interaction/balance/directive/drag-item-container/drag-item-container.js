define(['angularAMD'], function(angularAMD) {
	angularAMD
		.directive('dragItemContainer', [

			function() {
				return {
					restrict: 'E',
					replace: true,
					scope: {
						options: '=options',
						dragItems: '=dragItems'
					},
					controller: ['$scope', function ($scope) {
					}]
				};
			}
		])
});