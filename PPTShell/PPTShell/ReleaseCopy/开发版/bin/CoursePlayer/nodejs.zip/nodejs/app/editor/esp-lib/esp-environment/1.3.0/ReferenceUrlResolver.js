/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
    'jquery',
    'espEnvironment/../UrlHelper'
],function(
    $,
    UrlHelper
){
    var SYMBOL_REF_PATH = '${ref-path}',
        SYMBOL_REF_RELATIVE = '${ref-relative}';
    function Resolver(rootPath, relativeRootPath, relativePath){
        this._rootPath = UrlHelper.cleanPathLimit(rootPath, false, true);
        this._relativeRootPath = UrlHelper.cleanPathLimit(relativeRootPath, false, true);
        this._relativePath = UrlHelper.cleanPathLimit(relativePath, true, true);
        this._relativeFullPath = this._relativeRootPath + '/' + this._relativePath;
        this._relativePathLevel = this._relativePath ? this._relativePath.split('/').length : 0;
    }
    Resolver.prototype.format = function (absoluteUrl) {
        if(!absoluteUrl || typeof absoluteUrl !== 'string') return absoluteUrl;
        var result;
        if(this._relativeFullPath && absoluteUrl.indexOf(this._relativeFullPath) === 0){
            result = SYMBOL_REF_RELATIVE + absoluteUrl.substring(this._relativeFullPath.length);
        }else if(this._relativeRootPath && absoluteUrl.indexOf(this._relativeRootPath) === 0){
            result = SYMBOL_REF_RELATIVE;
            for(var i=0;i<this._relativePathLevel;i++){
                result += '/..';
            }
            result += absoluteUrl.substring(this._relativeRootPath.length);
        }else if(this._rootPath && absoluteUrl.indexOf(this._rootPath) === 0){
            result = SYMBOL_REF_PATH + absoluteUrl.substring(this._rootPath.length);
        }else{
            result = absoluteUrl;
        }
        return result;
    };
    Resolver.prototype.parse = function (referenceUrl) {
        if(!referenceUrl ||  typeof referenceUrl !== 'string') return referenceUrl;
        var result;
        if(referenceUrl.indexOf(SYMBOL_REF_RELATIVE) === 0){
            result = UrlHelper.fixPath(this._relativeFullPath + referenceUrl.substring(SYMBOL_REF_RELATIVE.length));
        }else if(referenceUrl.indexOf(SYMBOL_REF_PATH) === 0){
            result = this._rootPath + referenceUrl.substring(SYMBOL_REF_PATH.length);
        }else{
            result = referenceUrl;
        }
        return result;
    };
    Resolver.prototype.test = function (url) {
        if(!url) return false;
        return (this._relativeFullPath && url.indexOf(this._relativeFullPath) === 0) ||
            (this._relativeRootPath && url.indexOf(this._relativeRootPath) === 0) ||
            (this._rootPath && url.indexOf(this._rootPath) === 0) ||
            (url.indexOf(SYMBOL_REF_RELATIVE) === 0) ||
            (url.indexOf(SYMBOL_REF_PATH) === 0);
    };

    return function(rootPath, relativeRootPath, relativePath){
        return new Resolver(rootPath, relativeRootPath, relativePath);
    };
});