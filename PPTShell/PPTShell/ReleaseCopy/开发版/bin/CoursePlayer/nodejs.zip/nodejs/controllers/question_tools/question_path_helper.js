var path = require('path');
var refbase = "${ref-base}";
var refpath = "${ref-path}";
var replacer = require("./refpath_replacer");
//习题根目录，存放main.xml
var getQuestionBase= function(id,req){ 
	var base = req.param('question_base');
	if(!base){
		base = __dirname + "/../../app/userdatas/edu/esp/questions/"; 
	}
	if(base.lastIndexOf("/")!=base.length-1){
		base = base+"/";
	} 
	return base + id + ".pkg";
}
exports.getQuestionBase = getQuestionBase;
//习题ref前缀，
exports.getQuestionRefBase = function(id){
	return refbase;
}
exports.getQuestionRefPath = function(id){
	return refpath+"/edu/esp/questions/" + id + ".pkg";
}
exports.getQuestionBaseNoRefPath=function(id){
	return "/edu/esp/questions/" + id + ".pkg";
}
//习题ref内容存放目录
exports.getQuestionRefPackagePath = function(id,req){
	var packagePath = getQuestionBase(id,req);
	return packagePath;
}
exports.getPlayerBase = function(id,req){
	var base = req.param('question_base');
	if(!base){
		base = __dirname + "/../../app/userdatas/edu/esp/questions/"; 
	}	
	return base+"/"+id+".pkg"; 
}
//将$(ref-path)转换成文件地址。 
exports.resolveFilePath = function(filepath,question_id,req){	
	filepath = replacer.toRefpath(filepath);
	if(filepath.indexOf(refbase)!=-1){
		filepath = filepath.substring(refbase.length);
	}	 
	var result = getQuestionBase(question_id,req)+filepath;	
	return result;
}

exports.getInteractionBase= function(id,req){
	var base = req.param('question_base');
	if(!base){
		base = __dirname + "/../../app/userdatas/edu/esp/interaction/"; 
	}
	if(base.lastIndexOf("/")!=base.length-1){
		base = base+"/";
	} 
	return base + id + ".pkg"; 
}
exports.getInteractionRefBase= function(id,req){
	return "${ref-path}/edu/esp/interaction/" + id + ".pkg";
}



