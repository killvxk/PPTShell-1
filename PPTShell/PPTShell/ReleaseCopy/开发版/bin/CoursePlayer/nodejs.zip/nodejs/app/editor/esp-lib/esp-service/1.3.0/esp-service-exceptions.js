/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
    'jquery',
    'exception'
],function(
    $,
    Exception
) {
    var Exceptions = {
        NOT_SUPPORT_OPERATION: new Exception('ESP-SERVICE-00001', '不支持的操作'),

        //颗粒相关异常
        GET_COURSEWAREOBJECT: new Exception('ESP-SERVICE-00001', '获取颗粒元数据失败: {0}'),
        CREATE_COURSEWAREOBJECT: new Exception('ESP-SERVICE-00001', '创建颗粒元数据失败'),
        COPY_COURSEWAREOBJECT: new Exception('ESP-SERVICE-00001', '复制颗粒失败: {0},{1}'),
        GET_COURSEWAREOBJECT_MAIN_XML: new Exception('ESP-SERVICE-00001', '获取颗粒 main.xml 失败: {0}'),
        UPDATE_COURSEWAREOBJECT_MAIN_XML: new Exception('ESP-SERVICE-00001', '更新颗粒 main.xml 失败: {0}'),
        GET_COURSEWAREOBJECT_PAGE_XML: new Exception('ESP-SERVICE-00001', '获取颗粒 page.xml 失败: {0}'),
        CREATE_COURSEWAREOBJECT_PAGE_XML: new Exception('ESP-SERVICE-00001', '创建颗粒 page.xml 失败: {0}'),
        UPDATE_COURSEWAREOBJECT_PAGE_XML: new Exception('ESP-SERVICE-00001', '创建颗粒 page.xml 失败: {0}'),
        LIST_COURSEWAREOBJECT_ASSETS: new Exception('ESP-SERVICE-00001', '获取颗粒资源列表失败: {0}'),

        GET_MODULE_DEFINITION: new Exception('ESP-SERVICE-00001', 'Module 定义不存在: {0}'),

        UPDATE_COURSEWAREOBJECT_PAGE: new Exception('ESP-SERVICE-00001', '保存颗粒页失败: {0}'),

        //素材相关异常
        LIST_ASSET: new Exception('ESP-SERVICE-00001', '获取素材列表败')
    };
    return Exceptions;
});