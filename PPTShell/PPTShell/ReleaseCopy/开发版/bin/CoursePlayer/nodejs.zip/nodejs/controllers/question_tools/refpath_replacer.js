var refbase = "${ref-base}";
var fs = require("fs");
var Q = require("q");
exports.toRefpath = function(data,questionId){
	data = data.replace(/\/v1\.3\/assets\/get\?(.*?)filepath=(.*?)['|"|\\|>]/gi,function(str){
		var prefix = "filepath=";
		var index = str.indexOf(prefix);
		str = str.substring(index+prefix.length);
		return refbase+str;
	});
	//handle last one 
	data = data.replace(/\/v1\.3\/assets\/get\?(.*?)filepath=(.*?)/gi,function(str){
		var prefix = "filepath=";
		var index = str.indexOf(prefix);
		str = str.substring(index+prefix.length);
		return refbase+str;
	});
    return data;
}
exports.fromRefpath = function(data,questionId,req){	
	var base = req.param('question_base');
	var baseparam = base ? '&question_base='+base:'';
	var newParam =data.replace(refbase,"/v1.3/assets/get?question_id="+questionId+baseparam+"&filepath=");
	while(newParam!=data){
		data = newParam;
		newParam = data.replace(refbase,"/v1.3/assets/get?question_id="+questionId+baseparam+"&filepath=");
	}
	return data;
}
exports.fromRefpath2 = function(pathManager,data){
	var baseparam = pathManager.toGetUrl();
	var newParam =data.replace(refbase,baseparam);
	while(newParam!=data){
		data = newParam;
		newParam = data.replace(refbase,baseparam);
	}
	return data;
}
var createMoveFile = function(filepath,namePrefix,waits){
	var prefix = "${ref-path}";
	var index = filepath.indexOf(prefix);
	var filename = filepath.substring(filepath.lastIndexOf("/")+1);
	str = filepath.substring(index+prefix.length);
	var lastchar = str.substring(str.length-1);
	if(lastchar == '"'||lastchar=="/"||lastchar=="'"||lastchar=="\\"||lastchar==">"||lastchar==")"){
		str = str.substring(0,str.length-1);
	}
	//避免同路径文件多次拷贝
	for(var i=0;i<waits.length;i++){
		if(waits[i].source == str){
			namePrefix = waits[i].prefix;
			var copy = {
				source :  waits[i].src,
				target: namePrefix!='' ? namePrefix+"_"+filename : filename,
				prefix: namePrefix+"_",
				nocopy: true
			};
			return copy;
		}
	}
	return {
		source: str,
		target: namePrefix!='' ? namePrefix+"_"+filename : filename,
		prefix:namePrefix,
	};
}

var formtFilePath = function(url){
	if(url.indexOf("?")!=-1){
		url = url.substring(0,url.indexOf("?"));
	}
	return url;
}

var moveOneFile = function(source,target,questionId,pathHelper,req){
	var defer = Q.defer();
	var base = pathHelper.getQuestionBase(questionId,req); 
	var sourcePath = base+"/_ref"+source;
	var lastchar = target.substring(target.length-1);	 
	if(lastchar == '"'||lastchar=="/"||lastchar=="'"||lastchar=="\\"||lastchar==">"||lastchar==")"){
		target = target.substring(0,target.length-1);
	}	
	var targetPath = base+"/resources/"+target;
	if(fs.existsSync(formtFilePath(sourcePath))){		
		var readStream = fs.createReadStream(formtFilePath(sourcePath))
		var writeStream = fs.createWriteStream(formtFilePath(targetPath));
		readStream.pipe(writeStream).on('finish', function(err) {		
			if(err){
				defer.reject("保存文件错误",err);
				return;
			}		
		    try{
		    	fs.unlinkSync(sourcePath);	    
		    }
		    catch(ex){console.log(ex);};
		    defer.resolve();
		});
		return defer.promise;
	}
	defer.resolve();
	return defer.promise;
}

var refPathToRefBaseRegexReplace = function(data,questionId,pathHelper,req,waits){
	var prefix = new Date().getTime();
	var count = 1;
	data = data.replace(/\$\{ref-path\}(.*?)['|"|\\|>|)]/gi,function(str){
		var localResourceFolder = questionId+".pkg/";
		var isBase = str.indexOf(localResourceFolder)!=-1;
		var item = createMoveFile(str,isBase? '': prefix+"_"+count,waits)
		waits.push(item);
		count++;
		return refbase+"/resources/"+item.target;
	});
	//handle last one
	data = data.replace(/\$\{ref-path\}(.*?)/gi,function(str){
		var localResourceFolder = questionId+".pkg/";
		var isBase = str.indexOf(localResourceFolder)!=-1;
		var item = createMoveFile(str,isBase? '': prefix+"_"+count,waits)
		waits.push(item);
		count++;
		return refbase+"/resources/"+item.target;
	});
	return data;
}
exports._refPathToRefBaseRegexReplace = refPathToRefBaseRegexReplace;

exports.refPathToRefBase = function(data,questionId,pathHelper,req){ 	
	var waitMove = [];
	data = refPathToRefBaseRegexReplace(data,questionId,pathHelper,req,waitMove);
	var all = [];
    for(var i=0;i<waitMove.length;i++){   
    	if(waitMove.nocopy) continue;
    	all.push(moveOneFile(waitMove[i].source,waitMove[i].target,questionId,pathHelper,req)); 
    }
    return Q.all(all).then(function(){
    	return data;
    });
}