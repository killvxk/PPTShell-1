/**
 * Created by px on 2015/6/11.
 */

define(['angularAMD'], function (angularAMD) {
    angularAMD.directive('timeSettingBtn', [function () {
        return {
            restrict: 'EA',
            template: '<a href="javascript:;" class="mainlink" poptipbox-placement-disabled="true" poptipbox-class="toolpop"  poptipbox-data="model.timer" poptipbox="<time-setting-box></time-setting-box>">时间设置</a>',
            scope: false,
            replace:true
        };
    }]).directive('timeSettingBox', ['$filter',function ($filter) {
        return {
            restrict: 'E',
            templateUrl: 'interaction/components/site-directive/time-setting-box/time-setting-box.html',
            scope: true,
            link: function ($scope) {
                var pageScope = $scope.$parent.originScope, old_time={};
                $scope.model = angular.extend({
                    timer_type:'sequence',//计时器类型: ["sequence", "countdown"]
                    time_minute:0,
                    time_second:10
                },pageScope.model.timer);

                //限制输入的时间数值大于0 小于60
                function limit_input(property){
                    old_time[property] = 0;
                    return function(val){
                        if(val){
                            var result = parseInt(val);
                            if(result.toString().length == val.toString().length && val.toString().length<=2 && result>=0 && result < 60){
                                old_time[property] = val;
                            }else{
                                $scope.model[property] = old_time[property];
                            }
                        }else{
                            old_time[property] = "";
                        }
                        console.log(property+':'+val);
                    }
                }

                $scope.$watch('model.time_minute',limit_input('time_minute'));
                $scope.$watch('model.time_second',limit_input('time_second'));

                $scope.close_popup = function(){
                    $scope.$parent.$parent.hide();
                }
                
                $scope.changgeType = function(type){
                	$scope.model.timer_type = type;
                	 if(type == 'countdown'){
                         if(angular.element(window.event.target).hasClass('time_second')){
                             return false ;
                         }
                		 if(!$scope.model.time_minute || ($scope.model.time_minute == 0 &&  $scope.model.time_second == 0)){
	                		 
	                		 $scope.model.time_minute = 1 ;
	                		 $scope.model.time_second = 0 ;
                		 }
                	 }else if($scope.model.timer_type == 'sequence'){
                		 $scope.model.time_minute = 0;
                     	 $scope.model.time_second = 0;
                	 }
                		 
                }

                $scope.cancel = function(){
                    $scope.close_popup();
                }

                $scope.ok = function(){
                    //TODO:保存时间数据
                    if($scope.model.timer_type == 'countdown'){
                        if(!$scope.model.time_minute || ($scope.model.time_minute == 0 &&  $scope.model.time_second == 0)){
                            $scope.model.time_minute = 1;
                        }
                        if(!$scope.model.time_second){
                            $scope.model.time_second = 0;
                        }
                    }else if($scope.model.timer_type == 'sequence'){
                    	$scope.model.time_minute = 0;
                    	$scope.model.time_second = 0;
                    }
                    angular.extend(pageScope.model.timer,$scope.model);
                    $scope.close_popup();
                    pageScope.model.timer.timer_type = $scope.model.timer_type;
                }
            }
        };
    }]);
});