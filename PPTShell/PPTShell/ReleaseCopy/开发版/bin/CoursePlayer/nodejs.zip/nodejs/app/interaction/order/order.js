/**
 *
 */
define(['app','order/directive/order.directive'
], function (app) {
    'use strict';
    app.controller('order_ctrl', [
        '$scope','skin_service','$stateParams','CustomEditorService','$rootScope','$filter',
        function ($scope,skin_service,$stateParams,CustomEditorService,$rootScope,$filter) {
        	$rootScope.moduleScope = $scope;
        	$scope.errorModel = {};
            $scope.model = {
                "description": {
                    "text": "",       //题干描述
                    "asset_type": "", //题干相关素材类型 ["image","video","audio"]
                    "asset": ""  ,           //题干相关素材
                    "image_extend":{       //旋转，放大缩小等属性，todo：具体属性唐焱鑫补充
                        "rotate":"",
                        "resize":""
                    }
                },
                "title": $filter('translate')('order.order_type'),         //标题
                "skin": {
                    code: "wood",
                    css_url: "${ref-path}/edu/esp/preparecustomeditor/order/wood/css/wood.css",
                    name: $filter('translate')('linkup.muwen'),
                    package_url: "${ref-path}/edu/esp/preparecustomeditor/order/wood"
                },
                "timer":{
                    "timer_type":"sequence",  //计时器类型: ["sequence", "countdown"]
                    "time_minute":"0",    //倒计时初始设置-分钟，timer_type="countdown"时有效
                    "time_second":"0"     //倒计时初始设置-秒，timer_type="countdown"时有效
                },
                items: [{},{},{},{}]
            };
            var loadingData = function(id){
                CustomEditorService.getQuestionInfoById(id)
                    .then(function(rtnData){
                        if(!rtnData){
                            $scope.errorModel.errorText =$filter('translate')('linkup.unvalidno');
                        }else{
                            if(rtnData.skin.code!=''){
                                angular.extend($scope.model,$scope.decodeData(rtnData));
                            }else{
                                $scope.model.id=rtnData.id;
                            }
                            $scope.errorModel.errorText = "";
                            skin_service.set_skin_by_code($scope.model.skin.code, "v1");
                        }
                    },function(){
                        $scope.errorModel.errorText = $filter('translate')('linkup.get_title_error');
                    })
            }

            //入口
            if(!$stateParams.id){
                $scope.showGuide = true;
                skin_service.set_skin_by_code($scope.model.skin.code, "v1");

            }else{
                $scope.showGuide = false;
                loadingData($stateParams.id);
            }
            
            $scope.$on('changgedSkin',function(){
                $rootScope.scaleHtml();
            });

            $scope.validPostData = function(){
                var modelData =$scope.model;
                if($.trim(modelData.description.text)==''){
                    $scope.errorModel.errorText = $filter('translate')('table.notnull.desc');
                } else {
                    var itemsCount = 0;
                    var newData = [];
                    angular.forEach(modelData.items,function(value,index){
                        if($.trim(value.text)!=='' ){
                            itemsCount++;
                            newData.push(value);
                        }
                    });
                    if(itemsCount<4){
                        $scope.errorModel.errorText = $filter('translate')('order.unvalid.count');
                    }else{
                        _.remove(modelData.items,function(item){
                           return $.trim(item.text)=='';
                        });
                        return true;
                    }
                }
            };
            
            //删除选项
            $scope.addItem = function($index) {
            	$scope.model.items.push({});
            };
            
            //删除选项
            $scope.removeItem = function($index) {
            	$scope.model.items.splice($index, 1);
            };
            
            $scope.encodeData = function(model){
                var newModel = angular.copy(model);
                newModel.description.text = window.customHtmlEncode(newModel.description.text);
                for(var i=0;i<newModel.items.length;i++){
                    newModel.items[i].text = window.customHtmlEncode(newModel.items[i].text);
                }
                return newModel;
            };
            
            $scope.decodeData = function(model){
                var newModel = angular.copy(model);
                newModel.description.text = window.customHtmlDecode(newModel.description.text);
                for(var i=0;i<newModel.items.length;i++){
                    newModel.items[i].text = window.customHtmlDecode(newModel.items[i].text);
                }
                return newModel;
            };
        }
    ]);

});