/**
 * The following features are still outstanding: animation as a
 * function, placement as a function, inside, support for more triggers than
 * just mouse enter/leave, html tooltips, and selector delegation.
 */

define(['angularAMD'], function(angularAMD) {


    angular.module('ui.bootstrap.bindHtml', [])

    .directive('bindHtmlUnsafe', ['$compile', function($compile) {
            return function(scope, element, attr) {
                element.addClass('ng-binding').data('$binding', attr.bindHtmlUnsafe);
                scope.$watch(attr.bindHtmlUnsafe, function bindHtmlUnsafeWatchAction(value) {
                    element.html($compile(value)(scope) || '');
                });
            };
        }])
        .directive('bindHtmlUnsafeTemplateid', ['$compile', function($compile) {
            return function(scope, element, attr) {
                element.addClass('ng-binding').data('$binding', attr.bindHtmlUnsafeTemplateid);
                scope.$watch(attr.bindHtmlUnsafeTemplateid, function bindHtmlUnsafeWatchAction(value) {
                    var html = angular.element('#' + value).html();
                    element.html($compile(html)(scope) || '');
                });
            };
        }]);

    angular.module('ui.bootstrap.position', [])

    /**
     * A set of utility methods that can be use to retrieve position of DOM elements.
     * It is meant to be used where we need to absolute-position DOM elements in
     * relation to other, existing elements (this is the case for tooltips, popovers,
     * typeahead suggestions etc.).
     */
    .factory('$position', ['$document', '$window', function($document, $window) {

        function getStyle(el, cssprop) {
            if (el.currentStyle) { //IE
                return el.currentStyle[cssprop];
            } else if ($window.getComputedStyle) {
                return $window.getComputedStyle(el)[cssprop];
            }
            // finally try and get inline style
            return el.style[cssprop];
        }

        /**
         * Checks if a given element is statically positioned
         * @param element - raw DOM element
         */
        function isStaticPositioned(element) {
            return (getStyle(element, 'position') || 'static') === 'static';
        }

        /**
         * returns the closest, non-statically positioned parentOffset of a given element
         * @param element
         */
        var parentOffsetEl = function(element) {
            var docDomEl = $document[0];
            var offsetParent = element.offsetParent || docDomEl;
            while (offsetParent && offsetParent !== docDomEl && isStaticPositioned(offsetParent)) {
                offsetParent = offsetParent.offsetParent;
            }
            return offsetParent || docDomEl;
        };

        return {
            /**
             * Provides read-only equivalent of jQuery's position function:
             * http://api.jquery.com/position/
             */
            position: function(element) {
                var elBCR = this.offset(element);
                var offsetParentBCR = {
                    top: 0,
                    left: 0
                };
                var offsetParentEl = parentOffsetEl(element[0]);
                if (offsetParentEl != $document[0]) {
                    offsetParentBCR = this.offset(angular.element(offsetParentEl));
                    offsetParentBCR.top += offsetParentEl.clientTop - offsetParentEl.scrollTop;
                    offsetParentBCR.left += offsetParentEl.clientLeft - offsetParentEl.scrollLeft;
                }

                var boundingClientRect = element[0].getBoundingClientRect();
                return {
                    width: boundingClientRect.width || element.prop('offsetWidth'),
                    height: boundingClientRect.height || element.prop('offsetHeight'),
                    top: elBCR.top - offsetParentBCR.top,
                    left: elBCR.left - offsetParentBCR.left
                };
            },

            /**
             * Provides read-only equivalent of jQuery's offset function:
             * http://api.jquery.com/offset/
             */
            offset: function(element) {
                var boundingClientRect = element[0].getBoundingClientRect();
                return {
                    width: boundingClientRect.width || element.prop('offsetWidth'),
                    height: boundingClientRect.height || element.prop('offsetHeight'),
                    top: boundingClientRect.top + ($window.pageYOffset || $document[0].documentElement.scrollTop),
                    left: boundingClientRect.left + ($window.pageXOffset || $document[0].documentElement.scrollLeft)
                };
            },

            /**
             * Provides coordinates for the targetEl in relation to hostEl
             */
            positionElements: function(hostEl, targetEl, positionStr, appendToBody) {

                var positionStrParts = positionStr.split('-');
                var pos0 = positionStrParts[0],
                    pos1 = positionStrParts[1] || 'center';

                var hostElPos,
                    targetElWidth,
                    targetElHeight,
                    targetElPos;

                hostElPos = appendToBody ? this.offset(hostEl) : this.position(hostEl);

                targetElWidth = targetEl.prop('offsetWidth');
                targetElHeight = targetEl.prop('offsetHeight');

                var shiftWidth = {
                    center: function() {
                        return hostElPos.left + hostElPos.width / 2 - targetElWidth / 2;
                    },
                    left: function() {
                        return hostElPos.left;
                    },
                    right: function() {
                        return hostElPos.left + hostElPos.width;
                    }
                };

                var shiftHeight = {
                    center: function() {
                        return hostElPos.top + hostElPos.height / 2 - targetElHeight / 2;
                    },
                    top: function() {
                        return hostElPos.top;
                    },
                    bottom: function() {
                        return hostElPos.top + hostElPos.height;
                    }
                };

                switch (pos0) {
                    case 'right':
                        targetElPos = {
                            top: shiftHeight[pos1](),
                            left: shiftWidth[pos0]()
                        };
                        break;
                    case 'left':
                        targetElPos = {
                            top: shiftHeight[pos1](),
                            left: hostElPos.left - targetElWidth
                        };
                        break;
                    case 'bottom':
                        targetElPos = {
                            top: shiftHeight[pos0](),
                            left: shiftWidth[pos1]()
                        };
                        break;
                    default:
                        targetElPos = {
                            top: hostElPos.top - targetElHeight,
                            left: shiftWidth[pos1]()
                        };
                        break;
                }

                return targetElPos;
            }
        };
    }]);

    function defaultHttpResponseTransform(data, headers) {
        if (isString(data)) {
            // strip json vulnerability protection prefix
            data = data.replace(JSON_PROTECTION_PREFIX, '');
            var contentType = headers('Content-Type');
            if ((contentType && contentType.indexOf(APPLICATION_JSON) === 0) ||
                (JSON_START.test(data) && JSON_END.test(data))) {
                data = fromJson(data);
            }
        }
        return data;
    }

    angular.module('ui.bootstrap.tooltip', [
            'template/poptipbox/poptipbox.html',
            'template/poptipbox/poptipbox-template.html',
            'template/tooltip/tooltip-template-popup.html',
            'template/tooltip/tooltip-popup.html',
            'template/tooltip/tooltip-html-unsafe-popup.html',
            'template/tooltip/tooltip-html-popup.html',
            'template/poptipbox/poptipbox-templateid.html',
            'ui.bootstrap.position', 'ui.bootstrap.bindHtml'
        ])
        .provider("$templateRequest", function() {
            this.$get = ['$templateCache', '$http', '$q', function($templateCache, $http, $q) {
                function handleRequestFn(tpl, ignoreRequestError) {
                    var self = handleRequestFn;
                    self.totalPendingRequests++;

                    var transformResponse = $http.defaults && $http.defaults.transformResponse;

                    if (angular.isArray(transformResponse)) {
                        var original = transformResponse;
                        transformResponse = [];
                        for (var i = 0; i < original.length; ++i) {
                            var transformer = original[i];
                            if (transformer !== defaultHttpResponseTransform) {
                                transformResponse.push(transformer);
                            }
                        }
                    } else if (transformResponse === defaultHttpResponseTransform) {
                        transformResponse = null;
                    }

                    var httpOptions = {
                        cache: $templateCache,
                        transformResponse: transformResponse
                    };

                    return $http.get(tpl, httpOptions)
                        .then(function(response) {
                            var html = response.data;
                            self.totalPendingRequests--;
                            $templateCache.put(tpl, html);
                            return html;
                        }, handleError);

                    function handleError() {
                        self.totalPendingRequests--;
                        if (!ignoreRequestError) {
                            throw $compileMinErr('tpload', 'Failed to load template: {0}', tpl);
                        }
                        return $q.reject();
                    }
                }

                handleRequestFn.totalPendingRequests = 0;

                return handleRequestFn;
            }];
        })

    /**
     * The $tooltip service creates tooltip- and popover-like directives as well as
     * houses global options for them.
     */
    .provider('$tooltip', function() {
        // The default options tooltip and popover.
        var defaultOptions = {
            placement: 'top',
            placementDisabled: false,
            animation: true,
            popupDelay: 0,
            useContentExp: false
        };

        // Default hide triggers for each show trigger
        var triggerMap = {
            'mouseenter': 'mouseleave',
            'click': 'click',
            'focus': 'blur'
        };

        // The options specified to the provider globally.
        var globalOptions = {};

        /**
         * `options({})` allows global configuration of all tooltips in the
         * application.
         *
         *   var app = angular.module( 'App', ['ui.bootstrap.tooltip'], function( $tooltipProvider ) {
         *     // place tooltips left instead of top by default
         *     $tooltipProvider.options( { placement: 'left' } );
         *   });
         */
        this.options = function(value) {
            angular.extend(globalOptions, value);
        };

        /**
         * This allows you to extend the set of trigger mappings available. E.g.:
         *
         *   $tooltipProvider.setTriggers( 'openTrigger': 'closeTrigger' );
         */
        this.setTriggers = function setTriggers(triggers) {
            angular.extend(triggerMap, triggers);
        };

        /**
         * This is a helper function for translating camel-case to snake-case.
         */
        function snake_case(name) {
            var regexp = /[A-Z]/g;
            var separator = '-';
            return name.replace(regexp, function(letter, pos) {
                return (pos ? separator : '') + letter.toLowerCase();
            });
        }

        /**
         * Returns the actual instance of the $tooltip service.
         * TODO support multiple triggers
         */
        this.$get = ['$window', '$compile', '$timeout', '$document', '$position', '$interpolate', function($window, $compile, $timeout, $document, $position, $interpolate) {
            return function $tooltip(type, prefix, defaultTriggerShow, options) {
                options = angular.extend({}, defaultOptions, globalOptions, options);

                /**
                 * Returns an object of show and hide triggers.
                 *
                 * If a trigger is supplied,
                 * it is used to show the tooltip; otherwise, it will use the `trigger`
                 * option passed to the `$tooltipProvider.options` method; else it will
                 * default to the trigger supplied to this directive factory.
                 *
                 * The hide trigger is based on the show trigger. If the `trigger` option
                 * was passed to the `$tooltipProvider.options` method, it will use the
                 * mapped trigger from `triggerMap` or the passed trigger if the map is
                 * undefined; otherwise, it uses the `triggerMap` value of the show
                 * trigger; else it will just use the show trigger.
                 */
                function getTriggers(trigger) {
                    var show = trigger || options.trigger || defaultTriggerShow;
                    var hide = triggerMap[show] || show;
                    return {
                        show: show,
                        hide: hide
                    };
                }

                var directiveName = snake_case(type);

                var startSym = $interpolate.startSymbol();
                var endSym = $interpolate.endSymbol();
                var template =
                    '<div ' + directiveName + '-popup ' +
                    'title="' + startSym + 'title' + endSym + '" ' +
                    (options.useContentExp ?
                        'content-exp="contentExp()" ' :
                        'content="' + startSym + 'content' + endSym + '" ') +
                    'placement="' + startSym + 'placement' + endSym + '" ' +
                    'popup-class="' + startSym + 'popupClass' + endSym + '" ' +
                    'animation="animation" ' +
                    'is-open="isOpen"' +
                    'origin-scope="origScope" ' +
                    '>' +
                    '</div>';

                return {
                    restrict: 'EA',
                    compile: function(tElem, tAttrs) {
                        var tooltipLinker = $compile(template);

                        return function link(scope, element, attrs, tooltipCtrl) {
                            var tooltip;
                            var tooltipLinkedScope;
                            var transitionTimeout;
                            var popupTimeout;
                            var appendToBody = angular.isDefined(options.appendToBody) ? options.appendToBody : false;
                            var triggers = getTriggers(undefined);
                            var hasEnableExp = angular.isDefined(attrs[prefix + 'Enable']);
                            var ttScope = scope.$new(true);

                            var positionTooltip = function() {
                                if (!tooltip || ttScope.placementDisabled) {
                                    return;
                                }

                                var ttPosition = $position.positionElements(element, tooltip, ttScope.placement, appendToBody);
                                ttPosition.top += 'px';
                                ttPosition.left += 'px';

                                // Now set the calculated positioning.
                                tooltip.css(ttPosition);
                            };

                            // Set up the correct scope to allow transclusion later
                            ttScope.origScope = scope;

                            // By default, the tooltip is not open.
                            // TODO add ability to start tooltip opened
                            ttScope.isOpen = false;

                            function toggleTooltipBind() {
                                if (!ttScope.isOpen) {
                                    showTooltipBind();
                                } else {
                                    hideTooltipBind();
                                }
                            }

                            // Show the tooltip with delay if specified, otherwise show it immediately
                            function showTooltipBind() {
                                if (hasEnableExp && !scope.$eval(attrs[prefix + 'Enable'])) {
                                    return;
                                }

                                prepareTooltip();

                                if (ttScope.popupDelay) {
                                    // Do nothing if the tooltip was already scheduled to pop-up.
                                    // This happens if show is triggered multiple times before any hide is triggered.
                                    if (!popupTimeout) {
                                        popupTimeout = $timeout(show, ttScope.popupDelay, false);
                                        popupTimeout.then(function(reposition) {
                                            reposition();
                                        });
                                    }
                                } else {
                                    show()();
                                }
                            }

                            function hideTooltipBind() {
                                scope.$apply(function() {
                                    hide();
                                });
                            }

                            // Show the tooltip popup element.
                            function show() {

                                popupTimeout = null;

                                // If there is a pending remove transition, we must cancel it, lest the
                                // tooltip be mysteriously removed.
                                if (transitionTimeout) {
                                    $timeout.cancel(transitionTimeout);
                                    transitionTimeout = null;
                                }

                                // Don't show empty tooltips.
                                if (!(options.useContentExp ? ttScope.contentExp() : ttScope.content)) {
                                    return angular.noop;
                                }

                                createTooltip();

                                if (!ttScope.placementDisabled) {
                                    // Set the initial positioning.
                                    tooltip.css({
                                        top: 0,
                                        left: 0,
                                        display: 'block'
                                    });
                                    ttScope.$digest();

                                    positionTooltip();
                                }


                                // And show the tooltip.
                                ttScope.isOpen = true;
                                ttScope.$apply(); // digest required as $apply is not called

                                // Return positioning function as promise callback for correct
                                // positioning after draw.
                                return ttScope.placementDisabled ? angular.noop : positionTooltip;
                            }

                            // Hide the tooltip popup element.
                            function hide() {
                            	if(ttScope){
                            		// First things first: we don't show it anymore.
                                    ttScope.isOpen = false;

                                    //if tooltip is going to be shown after delay, we must cancel this
                                    $timeout.cancel(popupTimeout);
                                    popupTimeout = null;

                                    // And now we remove it from the DOM. However, if we have animation, we
                                    // need to wait for it to expire beforehand.
                                    // FIXME: this is a placeholder for a port of the transitions library.
                                    if (ttScope.animation) {
                                        if (!transitionTimeout) {
                                            transitionTimeout = $timeout(removeTooltip, 500);
                                        }
                                    } else {
                                        removeTooltip();
                                    }
                            	}
                            }

                            function createTooltip() {
                                // There can only be one tooltip element per directive shown at once.
                                if (tooltip) {
                                    removeTooltip();
                                }
                                tooltipLinkedScope = ttScope.$new();
                                tooltipLinkedScope.hide = hide;
                                tooltipLinkedScope.origScope = scope;
                                tooltip = tooltipLinker(tooltipLinkedScope, function(tooltip) {
                                    if (appendToBody) {
                                        $document.find('body').append(tooltip);
                                    } else {
                                        element.after(tooltip);
                                    }
                                });

                                tooltipLinkedScope.$watch(function() {
                                    $timeout(positionTooltip, 0, false);
                                });

                                if (options.useContentExp) {
                                    tooltipLinkedScope.$watch('contentExp()', function(val) {
                                        if (!val && ttScope.isOpen) {
                                            hide();
                                        }
                                    });
                                }
                            }

                            function removeTooltip() {
                                transitionTimeout = null;
                                if (tooltip) {
                                    tooltip.remove();
                                    tooltip = null;
                                }
                                if (tooltipLinkedScope) {
                                    tooltipLinkedScope.$destroy();
                                    tooltipLinkedScope = null;
                                }
                            }

                            function prepareTooltip() {
                                prepPopupClass();
                                prepPlacement();
                                prepPopupDelay();
                            }

                            ttScope.contentExp = function() {
                                return scope.$eval(attrs[type]);
                            };

                            /**
                             * Observe the relevant attributes.
                             */
                            if (!options.useContentExp) {
                                attrs.$observe(type, function(val) {
                                    ttScope.content = val;

                                    if (!val && ttScope.isOpen) {
                                        hide();
                                    }
                                });
                            }

                            attrs.$observe('disabled', function(val) {
                                if (val && ttScope.isOpen) {
                                    hide();
                                }
                            });

                            attrs.$observe(prefix + 'Title', function(val) {
                                ttScope.title = val;
                            });

                            function prepPopupClass() {
                                ttScope.popupClass = attrs[prefix + 'Class'];
                            }

                            function prepPlacement() {
                                var val = attrs[prefix + 'Placement'];
                                ttScope.placement = angular.isDefined(val) ? val : options.placement;
                            }

                            function prepPopupDelay() {
                                var val = attrs[prefix + 'PopupDelay'];
                                var delay = parseInt(val, 10);
                                ttScope.popupDelay = !isNaN(delay) ? delay : options.popupDelay;
                            }

                            var unregisterTriggers = function() {
                                element.unbind(triggers.show, showTooltipBind);
                                element.unbind(triggers.hide, hideTooltipBind);
                            };

                            function prepTriggers() {
                                var val = attrs[prefix + 'Trigger'];
                                unregisterTriggers();

                                triggers = getTriggers(val);

                                if (triggers.show === triggers.hide) {
                                    element.bind(triggers.show, toggleTooltipBind);
                                } else {
                                    element.bind(triggers.show, showTooltipBind);
                                    element.bind(triggers.hide, hideTooltipBind);
                                }
                            }
                            prepTriggers();

                            var placementDisabled = scope.$eval(attrs[prefix + 'PlacementDisabled']);
                            ttScope.placementDisabled = angular.isDefined(placementDisabled) ? !!placementDisabled : options.placementDisabled;

                            var animation = scope.$eval(attrs[prefix + 'Animation']);
                            ttScope.animation = angular.isDefined(animation) ? !!animation : options.animation;

                            var appendToBodyVal = scope.$eval(attrs[prefix + 'AppendToBody']);
                            appendToBody = angular.isDefined(appendToBodyVal) ? appendToBodyVal : appendToBody;

                            // if a tooltip is attached to <body> we need to remove it on
                            // location change as its parent scope will probably not be destroyed
                            // by the change.
                            if (appendToBody) {
                                scope.$on('$locationChangeSuccess', function closeTooltipOnLocationChangeSuccess() {
                                    if (ttScope.isOpen) {
                                        hide();
                                    }
                                });
                            }
                            angular.element(document).bind("click",function(e){
                                if (e.target != element[0] && angular.element(e.target).parents('.poptipbox').length==0) {
                                    hide();
                                }
                            });
                            // Make sure tooltip is destroyed and removed.
                            scope.$on('$destroy', function onDestroyTooltip() {
                                $timeout.cancel(transitionTimeout);
                                $timeout.cancel(popupTimeout);
                                unregisterTriggers();
                                removeTooltip();
                                ttScope = null;
                            });
                        };
                    }
                };
            };
        }];
    })

    // This is mostly ngInclude code but with a custom scope
    .directive('tooltipTemplateTransclude', [
        '$animate', '$sce', '$compile', '$templateRequest',
        function($animate, $sce, $compile, $templateRequest) {
            return {
                link: function(scope, elem, attrs) {
                    var origScope = scope.$eval(attrs.tooltipTemplateTranscludeScope);

                    var changeCounter = 0,
                        currentScope,
                        previousElement,
                        currentElement;

                    var cleanupLastIncludeContent = function() {
                        if (previousElement) {
                            previousElement.remove();
                            previousElement = null;
                        }
                        if (currentScope) {
                            currentScope.$destroy();
                            currentScope = null;
                        }
                        if (currentElement) {
                            $animate.leave(currentElement).then(function() {
                                previousElement = null;
                            });
                            previousElement = currentElement;
                            currentElement = null;
                        }
                    };

                    scope.$watch($sce.parseAsResourceUrl(attrs.tooltipTemplateTransclude), function(src) {
                        var thisChangeId = ++changeCounter;

                        if (src) {
                            //set the 2nd param to true to ignore the template request error so that the inner
                            //contents and scope can be cleaned up.
                            $templateRequest(src, true).then(function(response) {
                                if (thisChangeId !== changeCounter) {
                                    return;
                                }
                                var newScope = origScope.$new();
                                var template = response;

                                var clone = $compile(template)(newScope, function(clone) {
                                    cleanupLastIncludeContent();
                                    $animate.enter(clone, elem);
                                });

                                currentScope = newScope;
                                currentElement = clone;

                                currentScope.$emit('$includeContentLoaded', src);
                            }, function() {
                                if (thisChangeId === changeCounter) {
                                    cleanupLastIncludeContent();
                                    scope.$emit('$includeContentError', src);
                                }
                            });
                            scope.$emit('$includeContentRequested', src);
                        } else {
                            cleanupLastIncludeContent();
                        }
                    });

                    scope.$on('$destroy', cleanupLastIncludeContent);
                }
            };
        }
    ])

    /**
     * Note that it's intentional that these classes are *not* applied through $animate.
     * They must not be animated as they're expected to be present on the tooltip on
     * initialization.
     */
    .directive('tooltipClasses', function() {
        return {
            restrict: 'A',
            link: function(scope, element, attrs) {
                if (scope.placement) {
                    element.addClass(scope.placement);
                }
                if (scope.popupClass) {
                    element.addClass(scope.popupClass);
                }
                if (scope.animation()) {
                    element.addClass(attrs.tooltipAnimationClass);
                }
            }
        };
    })

    .directive('tooltipPopup', ["$templateCache", function($templateCache) {
        return {
            restrict: 'EA',
            replace: true,
            scope: {
                content: '@',
                placement: '@',
                popupClass: '@',
                animation: '&',
                isOpen: '&'
            },
            template: $templateCache.get('template/tooltip/tooltip-popup.html')
        };
    }])

    .directive('tooltip', ['$tooltip', function($tooltip) {
        return $tooltip('tooltip', 'tooltip', 'mouseenter');
    }])

    .directive('tooltipTemplatePopup', ["$templateCache", function($templateCache) {
        return {
            restrict: 'EA',
            replace: true,
            scope: {
                contentExp: '&',
                placement: '@',
                popupClass: '@',
                animation: '&',
                isOpen: '&',
                originScope: '&'
            },
            template: $templateCache.get('template/tooltip/tooltip-template-popup.html')
        };
    }])

    .directive('tooltipTemplate', ['$tooltip', function($tooltip) {
        return $tooltip('tooltipTemplate', 'tooltip', 'mouseenter', {
            useContentExp: true
        });
    }])

    .directive('tooltipHtmlPopup', ["$templateCache", function($templateCache) {
        return {
            restrict: 'EA',
            replace: true,
            scope: {
                contentExp: '&',
                placement: '@',
                popupClass: '@',
                animation: '&',
                isOpen: '&'
            },
            template: $templateCache.get('template/tooltip/tooltip-html-popup.html')
        };
    }])

    .directive('tooltipHtml', ['$tooltip', function($tooltip) {
        return $tooltip('tooltipHtml', 'tooltip', 'mouseenter', {
            useContentExp: true
        });
    }])

    /*
     Deprecated
     */
    .directive('tooltipHtmlUnsafePopup', ["$templateCache", function($templateCache) {
        return {
            restrict: 'EA',
            replace: true,
            scope: {
                content: '@',
                placement: '@',
                popupClass: '@',
                animation: '&',
                isOpen: '&'
            },
            template: $templateCache.get('template/tooltip/tooltip-html-unsafe-popup.html')
        };
    }])

    .value('tooltipHtmlUnsafeSuppressDeprecated', false)
        .directive('tooltipHtmlUnsafe', [
            '$tooltip', 'tooltipHtmlUnsafeSuppressDeprecated', '$log',
            function($tooltip, tooltipHtmlUnsafeSuppressDeprecated, $log) {
                if (!tooltipHtmlUnsafeSuppressDeprecated) {
                    $log.warn('tooltip-html-unsafe is now deprecated. Use tooltip-html or tooltip-template instead.');
                }
                return $tooltip('tooltipHtmlUnsafe', 'tooltip', 'mouseenter');
            }
        ])


    .directive('poptipboxTemplatePopup', ["$templateCache", function($templateCache) {
        return {
            restrict: 'EA',
            replace: true,
            scope: {
                title: '@',
                contentExp: '&',
                placement: '@',
                popupClass: '@',
                animation: '&',
                isOpen: '&',
                originScope: '='
            },
            template: $templateCache.get('template/poptipbox/poptipbox-template.html')
        };
    }])

    .directive('poptipboxTemplate', ['$tooltip', function($tooltip) {
        return $tooltip('poptipboxTemplate', 'poptipbox', 'click', {
            useContentExp: true
        });
    }])

    .directive('poptipboxPopup', ["$templateCache", function($templateCache) {
        return {
            restrict: 'EA',
            replace: true,
            scope: {
                title: '@',
                content: '@',
                placement: '@',
                popupClass: '@',
                animation: '&',
                isOpen: '&',
                originScope: '='
            },
            template: $templateCache.get('template/poptipbox/poptipbox.html')
        };
    }])

    .directive('poptipbox', ['$tooltip', function($tooltip) {
        return $tooltip('poptipbox', 'poptipbox', 'click');
    }])

    .directive('poptipboxTemplateidPopup', ["$templateCache", function($templateCache) {
        return {
            restrict: 'EA',
            replace: true,
            scope: {
                title: '@',
                content: '@',
                placement: '@',
                popupClass: '@',
                animation: '&',
                isOpen: '&',
                originScope: '='
            },
            template: $templateCache.get('template/poptipbox/poptipbox-templateid.html')
        };
    }])

    .directive('poptipboxTemplateid', ['$tooltip', function($tooltip) {
        return $tooltip('poptipboxTemplateid', 'poptipbox', 'click');
    }])


    angular.module("template/tooltip/tooltip-html-popup.html", []).run(["$templateCache", function($templateCache) {
        $templateCache.put("template/tooltip/tooltip-html-popup.html",
            "<div class=\"tooltip\"\n" +
            "  tooltip-animation-class=\"fade\"\n" +
            "  tooltip-classes\n" +
            "  ng-class=\"{ in: isOpen() }\">\n" +
            "  <div class=\"tooltip-arrow\"></div>\n" +
            "  <div class=\"tooltip-inner\" ng-bind-html=\"contentExp()\"></div>\n" +
            "</div>\n" +
            "");
    }]);

    angular.module("template/tooltip/tooltip-html-unsafe-popup.html", []).run(["$templateCache", function($templateCache) {
        $templateCache.put("template/tooltip/tooltip-html-unsafe-popup.html",
            "<div class=\"tooltip\"\n" +
            "  tooltip-animation-class=\"fade\"\n" +
            "  tooltip-classes\n" +
            "  ng-class=\"{ in: isOpen() }\">\n" +
            "  <div class=\"tooltip-arrow\"></div>\n" +
            "  <div class=\"tooltip-inner\" bind-html-unsafe=\"content\"></div>\n" +
            "</div>\n" +
            "");
    }]);

    angular.module("template/tooltip/tooltip-popup.html", []).run(["$templateCache", function($templateCache) {
        $templateCache.put("template/tooltip/tooltip-popup.html",
            "<div class=\"tooltip\"\n" +
            "  tooltip-animation-class=\"fade\"\n" +
            "  tooltip-classes\n" +
            "  ng-class=\"{ in: isOpen() }\">\n" +
            "  <div class=\"tooltip-arrow\"></div>\n" +
            "  <div class=\"tooltip-inner\" ng-bind=\"content\"></div>\n" +
            "</div>\n" +
            "");
    }]);

    angular.module("template/tooltip/tooltip-template-popup.html", []).run(["$templateCache", function($templateCache) {
        $templateCache.put("template/tooltip/tooltip-template-popup.html",
            "<div class=\"tooltip\"\n" +
            "  tooltip-animation-class=\"fade\"\n" +
            "  tooltip-classes\n" +
            "  ng-class=\"{ in: isOpen() }\">\n" +
            "  <div class=\"tooltip-arrow\"></div>\n" +
            "  <div class=\"tooltip-inner\"\n" +
            "    tooltip-template-transclude=\"contentExp()\"\n" +
            "    tooltip-template-transclude-scope=\"originScope()\"></div>\n" +
            "</div>\n" +
            "");
    }]);

    angular.module("template/poptipbox/poptipbox-template.html", []).run(["$templateCache", function($templateCache) {
        $templateCache.put("template/poptipbox/poptipbox-template.html",
            "<div class=\"poptipbox\"\n" +
            "  tooltip-animation-class=\"fade\"\n" +
            "  tooltip-classes\n" +
            "  ng-class=\"{ in: isOpen() }\">\n" +
            "\n" +
            "  <div class=\"poptipbox-content\"\n" +
            "   tooltip-template-transclude=\"contentExp()\"\n" +
            "   tooltip-template-transclude-scope=\"originScope()\"></div>\n" +
            "</div>\n" +
            "");
    }]);


    angular.module("template/poptipbox/poptipbox.html", []).run(["$templateCache", function($templateCache) {
        $templateCache.put("template/poptipbox/poptipbox.html",
            "<div class=\"poptipbox\"\n" +
            "  tooltip-animation-class=\"fade\"\n" +
            "  tooltip-classes\n" +
            "  ng-class=\"{ in: isOpen() }\">\n" +
            "  <div class=\"poptipbox-content\" bind-html-unsafe=\"content\"></div>\n" +
            "</div>\n" +
            "");
    }]);

    angular.module("template/poptipbox/poptipbox-templateid.html", []).run(["$templateCache", function($templateCache) {
        $templateCache.put("template/poptipbox/poptipbox-templateid.html",
            "<div class=\"poptipbox\"\n" +
            "  tooltip-animation-class=\"fade\"\n" +
            "  tooltip-classes\n" +
            "  ng-class=\"{ in: isOpen() }\">\n" +
            "  <div class=\"poptipbox-content\" bind-html-unsafe-templateid=\"content\"></div>\n" +
            "</div>\n" +
            "");
    }]);

});
