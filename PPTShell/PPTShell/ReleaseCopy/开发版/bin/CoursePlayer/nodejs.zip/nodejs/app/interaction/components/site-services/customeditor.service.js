/**
 * Created by px on 2015/6/16.
 */
define(['angularAMD'], function(angularAMD) {
    'use strict';
    angularAMD
        .service('CustomEditorService', ['RestAngularCustomEditor', '$stateParams','$filter','diskpathService',
                                 function(RestAngularCustomEditor,$stateParams,$filter,diskpathService) {

        return {
            getSkins: function(area){
                var moduletype = $filter("filterGetAPIRouteByWebRouteV2")(area||$stateParams.area);
                return RestAngularCustomEditor("v0.1/interaction").one("skins").one(moduletype).getList();
            },
            getQuestionInfoById: function(id,area){
                var  moduletype = $filter("filterGetAPIRouteByWebRouteV2")(area||$stateParams.area);
                return RestAngularCustomEditor("v0.1/interaction").setRequestSuffix("?question_base=" + ($stateParams.question_base || '')).one(moduletype,id).get().then(function(data){
                    if(!!!data.id) {
                        data.skin = { code: 'wood' };
                        var messageWrapper = $('<div/>').css({
                            "position": "absolute",
                            "top": "0",
                            "left": "0",
                            "width": "100%",
                            "height": "100%",
                            "display": "flex",
                            "align-items": "center",
                            "justify-content": "center",
                            "z-index": "999"
                        }).css({
                            "display": "-webkit-flex",
                            "-webkit-align-items": "center",
                            "-webkit-justify-content": "center"
                        });

                        $('<p>当前习题暂不支持编辑</p>').css({
                            "padding": "20px",
                            "border-radius": "3px",
                            "font-size": "24px",
                            "color": "#fff",
                            "background-color": "rgba(0, 0, 0, 0.7)"
                        }).appendTo(messageWrapper);

                        messageWrapper.appendTo(document.body);
                    }

                	var filepath = data.physic_path;
                	delete data.physic_path;
                	diskpathService.setFilepath(filepath);
                	return data;
                });
            },
            getPreviewUrl: function() {
                return RestAngularCustomEditor("v1.3/questions").setRequestSuffix("?main_type=interaction&question_base=" + ($stateParams.question_base || '')).one($stateParams.id).one('qtiplayer').get();
            },
            addQuestion:function(postData,area){
                var  moduletype = $filter("filterGetAPIRouteByWebRouteV2")(area||$stateParams.area);
                return RestAngularCustomEditor("v0.1/interaction").setRequestSuffix("?question_base=" + ($stateParams.question_base || '')).one(moduletype).customPOST(postData);
            },
            updateQuestion:function(postData,area){
                var  moduletype = $filter("filterGetAPIRouteByWebRouteV2")(area||$stateParams.area);
                return RestAngularCustomEditor("v0.1/interaction").setRequestSuffix("?question_base=" + ($stateParams.question_base || '')).one(moduletype,postData.id).customPUT(postData);
            },
            readQuestionAccessRecord: function() {
                return RestAngularCustomEditor("v0.1/archives").one("questions_access_record").get();
            },
            saveQuestionAccessRecord: function(accessRecord) {
                var postData = JSON.stringify(accessRecord);
                return RestAngularCustomEditor("v0.1/archives").one("questions_access_record").customPOST(postData);
            }
        };
    }]);
});
