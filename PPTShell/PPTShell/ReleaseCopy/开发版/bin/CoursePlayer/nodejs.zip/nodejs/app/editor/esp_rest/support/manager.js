/**
 * Created by ChenST on 2016/1/18.
 */

var config = require('./../config').config;
var path = require('path');
var util = require('util');

var Manager = function (objectId) {
    this.resourceDir = path.join(config.repository.objectRootPath(), util.format('%s.pkg', objectId));
};

Manager.prototype.mainPath = function () {
    return path.join(this.resourceDir, 'main.xml');
};

Manager.prototype.pagePath = function (pageId) {
    return path.join(this.resourceDir, util.format('pages/%s.xml', pageId));
};

Manager.prototype.relativePagePath = function (pageId) {
    return util.format('pages/%s.xml', pageId);
};

Manager.prototype.sdpPackagePath = function () {
    return path.join(this.resourceDir, 'sdp-package.xml');
};

Manager.prototype.metadataJsonPath = function () {
    return path.join(this.resourceDir, 'metadata.json');
};

Manager.prototype.relativeResourceFilePath = function (_path) {
    return path.join('resources', _path);
};


Manager.prototype.resourceFilePath = function (_path) {
    return path.join(this.resourceDir, 'resources', _path);
};

Manager.prototype.resourcePath = function () {
    return path.join(this.resourceDir, 'resources');
};

module.exports.Manager = Manager;