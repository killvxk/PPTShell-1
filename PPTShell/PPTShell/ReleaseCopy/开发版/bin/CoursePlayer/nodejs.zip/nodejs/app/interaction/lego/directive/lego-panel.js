/**
 * Created by wuyukun on 2015/11/24.
 */
define(['angularAMD'
], function (angularAMD) {
    angularAMD.directive('legoPanel', [function () {
        return {
            restrict: 'E',
            templateUrl: 'interaction/lego/directive/lego-panel.html',
            link: function ($scope, element) {
                AddonLego_create().run($('.addon_Lego'));
            }
        };
    }]);
});