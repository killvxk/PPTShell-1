/**
 * Created by chenyoudong on 2015/12/30.
 */
define(['jquery'], function ($) {
    var reg = {
        protocol: /([^\/]+):\/\/(.*)/i,
        host: /(^[^\:\/]+)((?:\/|:|$)?.*)/,
        port: /\:?([^\/]*)(\/?.*)/,
        path: /([^\?#]+)(\??[^#]*)(#?.*)/
    };
    var dotPathReg = /\/[^\/]*\/\.\./g;
    function UrlRoot(baseUrl){
        return function(path, v1, v2, v3){
            return UrlHelper.build([baseUrl,path], v1, v2, v3)
        };
    };
    var UrlHelper = {
        cleanPathLimit: function(path, start, end){
            if(!path) return '';
            if(start === true){
                while(path.charAt(0) === '/'){
                    path = path.substring(1);
                }
            }
            if(end === true){
                while(path.charAt(path.length - 1) === '/'){
                    path = path.substring(0, path.length - 1);
                }
            }
            return path;
        },
        fixLimit:function(path){
            if(!path || path.indexOf('/')==0) return path;
            return '/'+path;
        },
        fixPath:function(path){
            if(!path) return path;
            while(dotPathReg.test(path)){
                path = path.replace(dotPathReg, '');
            }
            return path;
        },
        root: function(baseUrl){
            return UrlRoot(baseUrl);
        },
        merge:function(url){
            if(!$.isArray(url)) return url;
            var paths = [], parts = [], sIndex;
            $.each(url,function(i,path){
                if($.isArray(path)) path = UrlHelper.merge(path);
                if(path && (sIndex = path.indexOf('?')) !== -1){
                    parts.push(path.substring(sIndex + 1));
                    path = path.substring(0, sIndex);
                }
                paths.push(path);
            });
            var result = paths.join('/').replace(/(:)?(\/{2,})/g, function (match, $1, $2) {
                return $1 ? $1 + '//' : '/';
            });
            if(parts.length){
                result += '?' + parts.join('&');
            }
            return result;
        },
        build:function(url,v1,v2,v3){
            if(!url) return url;
            url = UrlHelper.merge(url);
            var variables,params,encode;
            if(v1===true||v1===false){
                variables=[];
                params={};
                encode=v1;
            }else if(typeof v1 === 'string' || $.isArray(v1) || !$.isPlainObject(v1)){
                if($.isArray(v1)){
                    variables=v1;
                }else{
                    variables=[v1];
                }
                if($.isPlainObject(v2)){
                    params=v2;
                    encode=v3!==false;
                }else{
                    params={};
                    encode=v2!==false;
                }
            }else{
                variables=[];
                params=v1;
                encode=v2!==false;
            }
            var noParams={};
            url = url.replace(/(\{.+?\})/g,function($1){
                var key=$1.substring(1,$1.length-1);
                var value;
                var index=parseInt(key);
                if(!isNaN(index)){
                    value=variables[index];
                }else{
                    value=params[key];
                }
                if(encode && value){
                    value=encodeURIComponent(value);
                }
                noParams[key]=true;
                return value||'';
            });
            var parts = [];
            for(var key in params){
                if(noParams[key]){
                    continue;
                }
                var value=params[key];
                if(value === null || typeof value === 'undefined'){
                    value='';
                }
                if(!$.isArray(value)){
                    value=[value];
                }
                for(var i=0;i<value.length;i++){
                    var v=value[i];
                    if($.isPlainObject(v)){
                        v=$.toJSON(v);
                    }
                    parts.push((encode?encodeURIComponent(key):key)+'='+(encode?encodeURIComponent(v):v));
                }
            }
            if(parts.length > 0){
                url += ((url.indexOf('?') == -1) ? '?' : '&') + parts.join('&');
            }
            return url;
        },
        analyse:function(url){
            if(!url || url=='/'){
                return {
                    host:window.location.hostname,
                    protocol:window.location.protocol,
                    port:window.location.port,
                    path:'/'
                };
            }else if(url.indexOf('/')==0){
                url=window.location.protoco+'://'+window.location.host+':'+window.location.port+url;
            }
            try{
                var tmp, res = {};
                res["href"] = url;
                for (var p in reg) {
                    tmp = reg[p].exec(url);
                    res[p] = tmp[1];
                    url = tmp[2];
                    if (url === "") {
                        url = "/";
                    }
                    if (p === "path") {
                        res["uri"]=tmp[1]+tmp[2];
                        res["path"] = tmp[1];
                        res["search"] = tmp[2];
                        res["hash"] = tmp[3];
                    }
                }
                return res;
            }catch(e){
                return null;
            }
        },
        populate:function(res){
            var url=res.protocol+'://'+host
                +(res.port?':'+res.port:'')
                +(res.path?'/'+res.path:'')
                +(res.hash?'#'+res.hash:'')
                +(res.search?'?'+res.search:'');
            return url;
        }
    };
    return UrlHelper;
});