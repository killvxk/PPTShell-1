define([
    'common',
    'moment',
    'sortable',
    'locale_zh_CN', 'locale_es',
    'angular-translate',
    'components/site-services/skin.service'
], function (angularAMD, moment) {
    'use strict';
    var app = angular.module('editorApp', [
        'restangular',
        'ui.router',
        'ui.sortable',
        'ui.bootstrap.tooltip',
        'pascalprecht.translate',
        'ngFileUpload'
    ])
        .constant('EnumsRouteQuestionType', {
            "linkup": {name: '连线题', api_route: 'linkups', question_type: 'linkup'},
            "order": {name: '排序题', api_route: 'nd_orders', question_type: 'nd_order'},
            "counter": {name: '计数器', api_route: 'nd_counter', question_type: 'nd_counter'},
            "table": {name: '表格题', api_route: 'nd_tables', question_type: 'nd_table'},
            "wordpuzzle": {name: '字谜游戏', api_route: 'nd_wordpuzzles', question_type: 'nd_wordpuzzle'},
            "memorycard": {name: '记忆卡片', api_route: 'nd_memorycards', question_type: 'nd_memorycard'},
            "arithmetic": {name: '竖式计算', api_route: 'nd_arithmetics', question_type: 'nd_arithmetic'},
            "compare": {name: '比较大小', api_route: 'nd_compares', question_type: 'nd_compare'},
            "guessword": {name: '猜词游戏', api_route: 'nd_guesswords', question_type: 'nd_guessword'},
            "magicbox": {name: '魔方盒游戏', api_route: 'nd_magicboxes', question_type: 'nd_magicbox'},
            "rationalnumbercalc": {
                name: '有理数乘法',
                api_route: 'nd_rationalnumbercalcs',
                question_type: 'nd_rationalnumbercalc'
            },
            "fillblank": {name: '选词填空题', api_route: 'nd_fillblanks', question_type: 'nd_fillblank'},
            "pointsequencing": {name: "点排序", api_route: 'nd_pointsequencings', question_type: 'nd_pointsequencing'},
            "classified": {name: '分类题型', api_route: 'nd_classifieds', question_type: 'nd_classified'},
            "textselect": {name: "文本选择题", api_route: 'nd_textselects', question_type: 'nd_textselect'},
            "fraction": {name: '分式加减型', api_route: 'nd_fractions', question_type: 'nd_fraction'},
            "imagemark": {name: "标签题型", api_route: 'nd_imagemarks', question_type: 'nd_imagemark'},
            "sequencefill": {name: "连环填空", api_route: 'nd_sequencefills', question_type: 'nd_sequencefill'},
            "highlightmark": {name: "划词标记", api_route: 'nd_highlightmarks', question_type: 'nd_highlightmark'},
            "probabilitycard": {name: "概率卡牌工具", api_route: 'nd_probabilitycards', question_type: 'nd_probabilitycard'},
            "catchball": {name: "摸球工具", api_route: 'nd_catchballs', question_type: 'nd_catchball'},
            "balance": {name: "天平工具", api_route: "nd_balances", question_type: "nd_balance"},
            "speechevaluating": {name: "语音测评", api_route: "nd_speechevaluatings", question_type: "nd_speechevaluating"},
            "sentence_evaluat": {
                name: "英语句子发音评测",
                api_route: "nd_sentence_evaluats",
                question_type: "nd_sentence_evaluat"
            },
            "section_evaluating": {
                name: "英语篇章发音评测",
                api_route: "nd_section_evaluatings",
                question_type: "nd_section_evaluating"
            },
            "wordcard_search": {name: "生字词卡", api_route: "nd_wordcard_searchs", question_type: "nd_wordcard_search"},
            "planting": {name: "植树", api_route: "nd_plantings", question_type: "nd_planting"},
            "clock": {name: "模拟时钟", api_route: "nd_clocks", question_type: "nd_clock"},
            "lego": {name: "方块塔", api_route: "nd_legos", question_type: "nd_lego"},
            "puzzle": {name: "拼图工具", api_route: "nd_puzzles", question_type: "nd_puzzle"},
            "comicdialogue": {name: "四格漫画", api_route: "nd_comicdialogue", question_type: "nd_comicdialogue"},
            "abacus": {name: "算盘", api_route: "nd_abacus", question_type: "nd_abacus"},
            "mathaxis": {name: "数轴题", api_route: "nd_mathaxiss", question_type: "nd_mathaxis"},
            "spellpoem": {name: "连字拼诗", api_route: "nd_spellpoem", question_type: "nd_spellpoem"},
            "intervalproblem": {name: "区间题", api_route: "nd_intervalproblems", question_type: "nd_intervalproblem"},
            "makeword": {name: "组词题", api_route: "nd_makewords", question_type: "nd_makeword"},
            "$template": {}
        })
        .config(['RestangularProvider', '$httpProvider', '$sceProvider', '$locationProvider', '$urlRouterProvider', '$stateProvider', '$translateProvider',
            function (RestangularProvider, $httpProvider, $sceProvider, $locationProvider, $urlRouterProvider, $stateProvider, $translateProvider) {
                var defaultLang = window.sessionStorage.getItem($translateProvider.storageKey());
                if (!defaultLang) {
                    defaultLang = (navigator.language || navigator.browserLanguage).substr(0, 2).toLowerCase() == 'es' ? 'es_EC' : 'zh_CN';
                    window.sessionStorage.setItem($translateProvider.storageKey(), defaultLang);
                }
                $translateProvider.translations('es_EC', angular_locale_es);
                $translateProvider.translations('zh_CN', angular_locale_zh_CN);
                $translateProvider.preferredLanguage(defaultLang);
                $translateProvider.useSanitizeValueStrategy('escaped');

                $urlRouterProvider
                    .otherwise('/home');
                //提供通用路由 可匹配/:area/:view/:params
                //如果要匹配定制的3级路由要写在 area.view.params 规则前面
                $stateProvider
                    .state('area', {
                        /**
                         * token_info : 授权信息
                         * space : 指明从教学资源管理系统的哪个库上选取多媒体资源[personal:个人库;public:ND库] - 2015-07-31
                         * chapter_id : 章节ID
                         * course_id : 课程ID - 2015-11-18
                         * english_card_type : 英文词卡操作类型：mark_tag=打标签[默认的], select_area=关联点选区 - 2015-11-18
                         *
                         * sys: 运行环境，主要是给预览时传给Module去识别，Module根据该参数呈现出不同的行为方式, 如：PPTshell环境(sys=pptshell)
                         */
                        url: '/:area?token_info&id&question_type&_lang_&space&chapter_id&chapter_name&coverage&english_card_type&grade&oper&sys&is_modify&question_base',
                        templateUrl: function ($stateParams) {
                            return '/interaction/' + $stateParams.area + '/' + $stateParams.area + '.html';
                        },
                        controllerProvider: function ($stateParams) {
                            return $stateParams.area + '_ctrl';
                        },
                        resolve: {
                            "__load": ['$q', '$rootScope', '$stateParams', 'UserDataService', '$translate', function ($q, $rootScope, $stateParams, UserDataService, $translate) {
                                var defer = $q.defer();
                                require([$stateParams.area + '/' + $stateParams.area], function () {
                                    defer.resolve();
                                    $rootScope.$apply();
                                }, function () {
                                    window.console && console.log("area的入口js不存在");
                                });
                                //if ($stateParams.token_info) {
                                //    UserDataService.setTokenInfo($stateParams.token_info);
                                //} else {
                                //    UserDataService.remove();
                                //}
                                $translate.use($stateParams['_lang_'] == 'es_EC' ? $stateParams['_lang_'] : 'zh_CN');

                                return defer.promise;
                            }]
                        }
                    });

                $sceProvider.enabled(false);
                var isIELower = CORSCustom.isIELower();

                //拦截所有ajax请求 根据需要添加请求授权或提供ie8、9的跨域请求支持。
                $httpProvider.interceptors.push(["$q", "$rootScope", "$location", "$timeout", function ($q, $rootScope, $location, $timeout) {
                    $rootScope.loadingData = true;
                    var setLoadingDataTimer = function (isloading) {
                        if ($rootScope.loadingDataTimer) $timeout.cancel($rootScope.loadingDataTimer);
                        //防止重复出现
                        $rootScope.loadingDataTimer = $timeout(function () {
                            $rootScope.loadingData = isloading;
                        }, 300);
                    };
                    return {
                        'request': function (config) {
                            setLoadingDataTimer(true);
                            var isAjax = config.url && config.url.indexOf("http") !== -1;
                            var host = [config.url.split('//')[0], "//", config.url.split('/')[2]].join('');
                            if (isAjax && $rootScope.token_info) {
                                var unAuth = config.params && config.params.unAuth;
                                if (!unAuth) {
                                    //添加授权header
                                    config.headers = angular.extend({
                                        "Content-Type": 'application/json',
                                        "Authorization": CryptoJS.HmacAuth($rootScope.token_info.access_token,
                                            $rootScope.token_info.mac_key,
                                            config.method, config.url.replace(host, ""),
                                            host.replace("http://", "").replace("https://", ""),
                                            moment($rootScope.token_info.server_time),
                                            moment($rootScope.token_info.local_time), config.params)
                                    }, config.headers);
                                }

                            } else {
                                //本地化项目无法获取token，但生字词卡需要访问在线资源 ，先注释掉。
                                // config.url = [config.url, '?', require.s.contexts._.config.urlArgs].join('');
                            }

                            //ie8\ie9 跨域封装数据
                            if (isAjax && isIELower && CORSCustom.isXDomain(config.url)) {
                                config.data = CORSCustom.encodeData(config.method, config.data, angular.extend({
                                    "Host": host.replace("http://", "").replace("https://", "")
                                }, config.headers));
                            }
                            if (config.params) {
                                //签名计算时根据参数的，需要删掉没用的参数
                                delete config.params.unAuth;
                            }
                            return config || $q.when(config);
                        },
                        'response': function (response) {
                            setLoadingDataTimer(false);
                            return response; // 或者 $q.when(config);
                        },
                        'requestError': function (rejection) {
                            setLoadingDataTimer(false);
                            return $q.reject(rejection);
                        },
                        'responseError': function (rejection) {
                            setLoadingDataTimer(false);
                            return $q.reject(rejection);
                        }
                    };
                }]);

            }
        ])
        .run(['$rootScope', '$timeout', '$location', '$state', 'skin_service', '$document', '$http',
            function ($rootScope, $timeout, $location, $state, skin_service, $document, $http) {

                //禁用浏览器后退
                $document.on('keydown', function ($event) {
                    if ($event.target == document.body && $event.keyCode == 8) {
                        $event.preventDefault();
                    }
                });

                //备课系统监听QuestionSaved消息，并刷新任务列表
                window.messageIframe = {
                    doMessage: function () {
                    }
                };
                function sys_mydomessage(msg) {
                    window.messageIframe.doMessage(msg);
                }

                window.messageIframe.messenger = new Messenger('message');
                window.messageIframe.messenger.listen(sys_mydomessage);
                window.messageIframe.messenger.addTarget(window.parent, 'parent');

                var timeout;
                $rootScope.scaleHtml = function (onCallback) {
                    clearTimeout(timeout);
                    timeout = setTimeout(function () {
                        var scalableLayout = angular.element('.scalable_layout')[0] || angular.element('.llkwrapper')[0];
                        if (scalableLayout) { //通过transform scale实现自适应
                            var style = document.createElement("div").style, supportCss3 = false;
                            angular.forEach(['transform', 'MozTransform', 'webkitTransform', 'OTransform', 'msTransform'], function (k, v) {
                                if (v in style) {
                                    supportCss3 = true;
                                    return false;
                                }
                            });
                            if (supportCss3) {
                                var $wrap = $(scalableLayout),
                                    llkwrapperHeight = $wrap.height(),
                                    llkwrapperWidth = $wrap.width(),
                                    scale = Math.min(angular.element(window).height() / llkwrapperHeight, angular.element(window).width() / llkwrapperWidth);
                                if (scale < 1) {
                                    $wrap.parent().removeClass('center_flex_layout');
                                    $wrap.css({
                                        transform: 'scale(' + scale + ')',
                                        transformOrigin: 'left top'
                                    }).addClass('transformed_layout');
                                    $wrap.parent().css({'margin': '0 auto'}).height(llkwrapperHeight * scale).width(llkwrapperWidth * scale);
                                } else {
                                    $wrap.parent().addClass('center_flex_layout');
                                    $wrap.css({transform: 'initial'}).removeClass('transformed_layout');
                                    $wrap.parent().css({'margin': '0 auto'}).css('height', '100%').css('width', 'auto');
                                }
                            } else {
                                //ie8下 滚动条的问题还没处理好
                                var $wrap = $(scalableLayout).css({zoom: 1}),
                                    llkwrapperHeight = $wrap.height(),
                                    llkwrapperWidth = $wrap.width(),
                                    scale = Math.min(angular.element(window).height() / llkwrapperHeight, angular.element(window).width() / llkwrapperWidth);
                                $wrap.css({zoom: scale});
                                $wrap.parent().css({'margin': '0 auto'}).height(llkwrapperHeight * scale).width(llkwrapperWidth * scale);
                            }

                            return;
                        }
                        //通过样式名实现自适应：com_layout_large, com_layout_mid, com_layout_small
                        var $wap = $('.com_layout');
                        var winHeight, winWidth;
                        var ratio = 10 / 7;
                        var maxWidth = 1300;
                        var maxHeight = maxWidth / ratio;
                        var minWidth = 1159;
                        var minHeight = minWidth / ratio;

                        function getWinSize() {
                            winHeight = $(window).height();
                            winWidth = $(window).width();
                        }

                        function setWapSize(s) {
                            $wap.removeClass('com_layout_small com_layout_mid com_layout_large');
                            $wap.addClass(s);
                        }

                        function wapRePosition() {
                            if (winWidth / winHeight > ratio) {
                                if (winHeight >= maxHeight) {
                                    setWapSize("com_layout_large");
                                } else if (winHeight <= minHeight) {
                                    setWapSize("com_layout_small");
                                } else {
                                    setWapSize("com_layout_mid");
                                }
                            } else {
                                if (winWidth >= maxWidth) {
                                    setWapSize("com_layout_large");
                                } else if (winWidth <= minWidth) {
                                    setWapSize("com_layout_small");
                                } else {
                                    setWapSize("com_layout_mid");
                                }
                            }
                        }

                        getWinSize();
                        wapRePosition();

                        angular.isFunction(onCallback) && onCallback(); //回调操作
                    }, 200);
                };
                angular.element(window).resize($rootScope.scaleHtml);
                /**
                 *这个本来是皮肤服务里面的，但是在延迟加载的js中监听事件无效，所以放到这里
                 **/
                    //切换页面的时候清空缓存数据、清理之前加的皮肤样式。否则数据和样式都会错乱
                $rootScope.$on('$stateChangeStart', function () {
                    skin_service.remove_all_skin();
                });
                //$stateChangeStar的时候area还没变过来 拼出的ajax url是错的
                $rootScope.$on('$stateChangeSuccess', function (evt, state, stateParams) {
                    if (stateParams.area != 'home') {
                        skin_service.get_skins();
                    }

                    $rootScope.scaleHtml();
                });
            }
        ]);

    return angularAMD.bootstrap(app);
});
