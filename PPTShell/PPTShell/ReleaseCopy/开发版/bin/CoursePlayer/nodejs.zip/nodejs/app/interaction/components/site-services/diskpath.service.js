define(['angularAMD'], function(angularAMD) {
    'use strict';
    angularAMD.service('diskpathService',[function(){
    	var filepath = '';
    	return {
	    	getFilepath:function(){
	    		return filepath;
	    	},
	    	setFilepath:function(path){
	    		return filepath = path;
	    	}	
    	}
    }]);
});