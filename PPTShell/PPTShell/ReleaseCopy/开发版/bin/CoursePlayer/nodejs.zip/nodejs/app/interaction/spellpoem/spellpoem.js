/**
 * spellpoem
 * 2016-01-15 10:31:17
 */
define(['app', 'spellpoem/directive/spellpoem.directive'], function (app) {
    'use strict';
    app.controller('spellpoem_ctrl', [
        '$scope', 'skin_service', '$stateParams', 'CustomEditorService', 'CharsetService', '$rootScope', '$filter', "$timeout",
        function ($scope, skin_service, $stateParams, CustomEditorService, CharsetService, $rootScope, $filter, $timeout) {
            $rootScope.moduleScope = $scope;
            $scope.errorModel = {};

            $scope.model = {
                "id": "",
                "module_code": "nd_spellpoem", // 题目类型
                "title": "", //标题
                "skin": {
                    code: "wood",
                    css_url: "${ref-path}/edu/esp/preparecustomeditor/spellpoem/wood/css/wood.css",
                    name: $filter('translate')('app.skin.wood'),
                    package_url: "${ref-path}/edu/esp/preparecustomeditor/spellpoem/wood"
                },
                "timer": {
                    "timer_type": "countdown",  //计时器类型: ["sequence", "countdown"]
                    "time_minute": "1",    //倒计时初始设置-分钟，timer_type="countdown"时有效
                    "time_second": "0"     //倒计时初始设置-秒，timer_type="countdown"时有效
                },
                "properties": [	//模块静态数据模型
                    {
                        "name": "question_id",
                        "display_name": "题目ID",
                        "type": "string",
                        "value": "",
                        "is_localized": false
                    },
                    {
                        "name": "question_url",
                        "display_name": "题目内容",
                        "type": "jsonFile",
                        "value": "",
                        "is_localized": false
                    }
                ],
                "content": { //Editor数据模型正文
                    "title": "登鹳雀楼",
                    "author": "王之涣",
                    "dynasty": "",
                    "sentences": [
                        {
                            "words": "白日依山尽"
                        },
                        {
                            "words": "黄河入海流"
                        },
                        {
                            "words": "欲穷千里目"
                        },
                        {
                            "words": "更上一层楼"
                        }
                    ]
                }
            };
            //数据加载
            var loadingData = function (id) {
                $scope.isloadingData = true;
                CustomEditorService.getQuestionInfoById(id)
                    .then(function (rtnData) {
                        if (!rtnData) {
                            $scope.errorModel.errorText = $filter('translate')('app.unvalidno');
                        } else {
                            if (rtnData.skin.code != '') {
                                $scope.model = $scope.decodeData(rtnData, true);
                            } else {
                                $scope.model.id = rtnData.id;
                                $scope.generatePoemBody();
                            }

                            skin_service.set_skin_by_code($scope.model.skin.code, "v1");
                            $scope.errorModel.errorText = "";
                            $scope.isloadingData = false;
                        }
                    }, function (error) {
                        $scope.errorModel.errorText = $filter('translate')('app.question.get.error');
                    })
            };

            //入口
            if (!$stateParams.id) { //新增
                skin_service.set_skin_by_code($scope.model.skin.code, "v1");
            } else { //修改
                loadingData($stateParams.id);
            }

            $scope.$on('changgedSkin', function () {
                $rootScope.scaleHtml();
            });

            //数据验证
            $scope.validPostData = function () {
                if (validStr($scope.model.title)) {
                    var tips = voidPoemInfos(false);
                    if (tips !== "") {
                        showErrorTips(tips, 0);
                        return false;
                    } else {
                        return true;
                    }
                } else {
                    showErrorTips($filter('translate')('spellpoem.no_title'), 0);
                    return false;
                }
            };

            //数据模型-编码
            $scope.encodeData = function (model) {

                return model;
            };

            //数据模型-解码
            $scope.decodeData = function (model, isInitLoad) {
                if (isInitLoad) {
                    try {
                        if (model && model.content) {
                            console.log(" decode data is initload = " + isInitLoad);
                            $scope.poemTitle = model.content.title;
                            $scope.poemAuthor = model.content.author;
                            $scope.poemDynasty = model.content.dynasty;

                            if (model.content.sentences) {
                                $scope.poemBody = getDisplaySentenceArray(model.content.sentences);
                            }
                            console.log("poem pody .");
                            console.log($scope.poemBody);
                        }
                    } catch (err) {

                    }
                }
                return model;
            };


            /**
             * *********************************************************
             * ***************** 连字拼诗 ** 开始 ***********************
             * *********************************************************
             */

            //右侧展示 古诗名
            $scope.poemTitle = "";
            //右侧展示 作者
            $scope.poemAuthor = "";
            //右侧展示 朝代
            $scope.poemDynasty = "";
            //右侧展示 古诗正文
            $scope.poemBody = {};
            //超过八个字显示小
            $scope.wordsMaxThan8 = false;
            //古诗名的最大字数
            $scope.poemTitleLength = 15;
            //作者的最大字数
            $scope.poemAuthorLength = 8;
            //古诗正文的最大字数
            $scope.poemSentenceLength = 10;
            //右侧显示超过八个时 添加 class word_small
            var WORDS8 = 8;
            //默认诗词是否编辑过
            var firstOnFocus = false;

            /**
             * 加句
             */
            $scope.addLine = function () {
                var currentLength = $scope.model.content.sentences.length;
                if (currentLength < 10) {
                    $scope.model.content.sentences[currentLength] = {
                        "words": ""
                    }
                }
                $('.poem_list2').animate({scrollTop: $('.btn_add').offset().top}, 2);
            };

            /**
             * 生成
             */
            $scope.generatePoemBody = function () {
                var tips = voidPoemInfos(true);
                if (tips !== "") {
                    showErrorTips(tips, 0);
                }
            };

            /**
             * 一键清除
             */
            $scope.cleanPoemBody = function () {
                $scope.model.content.title = "";
                $scope.model.content.author = "";
                $scope.poemTitle = "";
                $scope.poemAuthor = "";
                $scope.poemDynasty = "";
                $scope.poemBody = {};
                $scope.model.content.sentences = new Array();
                for (var i = 0; i < 4; i++) {
                    $scope.model.content.sentences[i] = {"words": ""};
                }
            };

            /**
             * 古诗名 中文
             */
            $scope.checkPoemTitle = function () {
                var text = $scope.model.content.title;
                $timeout(function () {
                    $scope.model.content.title = getChineseChars(text, $scope.poemTitleLength);
                }, 10);
            };

            /**
             * 作者 中文
             */
            $scope.checkPoemAuthor = function () {
                var text = $scope.model.content.author;
                $timeout(function () {
                    $scope.model.content.author = getChineseChars(text, $scope.poemAuthorLength);
                }, 10);
            };

            /**
             * 古诗正文 中文
             * @param index
             */
            $scope.checkPoemSentence = function (index) {
                var sentence = $scope.model.content.sentences[index];
                if (sentence) {
                    $timeout(function () {
                        sentence.words = getChineseChars(sentence.words, $scope.poemSentenceLength);
                    }, 10);
                }
            };

            /**
             * 默认古诗在编辑的时候消失
             */
            $scope.contentFocus = function(){
                if (!firstOnFocus){
                    firstOnFocus = true;
                    $scope.cleanPoemBody();
                }
            };

            /**
             * 获取中文字符
             * @param str
             * @returns {*}
             */
            function getChineseChars(str, length) {
                if (str && typeof str === 'string') {
                    var changeText = CharsetService.getChineses(str);
                    changeText = changeText.substring(0, length);
                    return changeText;
                } else {
                    return str;
                }
            }

            /**
             * 验证  古诗名  作者  古诗正文 输入
             * @param showGenerate
             * @returns {string}
             */
            function voidPoemInfos(showGenerate) {
                var hasTitle = validStr($scope.model.content.title);
                var hasAuthor = validStr($scope.model.content.author);
                var hasPoemtry = validPoemBody();

                var tips = "";

                if (hasTitle) {
                    if (hasAuthor) {
                        if (hasPoemtry) { // 有正文  有古诗名  有作者
                            if (showGenerate) {
                                $scope.poemTitle = $scope.model.content.title;
                                $scope.poemAuthor = $scope.model.content.author;
                                $scope.poemBody = getDisplaySentenceArray($scope.model.content.sentences);
                            }
                        } else { // 无正文  有古诗名  有作者
                            tips = $filter('translate')('spellpoem.please') + $filter('translate')('spellpoem.poem_body') + $filter('translate')('spellpoem.exclamation_mark');
                        }
                    } else {
                        if (hasPoemtry) {// 有正文  有古诗名  无作者
                            tips = $filter('translate')('spellpoem.please') + $filter('translate')('spellpoem.poem_author') + $filter('translate')('spellpoem.exclamation_mark');
                        } else { // 无正文  有古诗名  无作者
                            tips = $filter('translate')('spellpoem.please') + $filter('translate')('spellpoem.poem_author') + $filter('translate')('spellpoem.stop_mark') + $filter('translate')('spellpoem.poem_body') + $filter('translate')('spellpoem.exclamation_mark');
                        }
                    }
                } else {
                    if (hasAuthor) {
                        if (hasPoemtry) {// 有正文  无古诗名  有作者
                            tips = $filter('translate')('spellpoem.please') + $filter('translate')('spellpoem.poem_title') + $filter('translate')('spellpoem.exclamation_mark');
                        } else { // 无正文  无古诗名  有作者
                            tips = $filter('translate')('spellpoem.please') + $filter('translate')('spellpoem.poem_title') + $filter('translate')('spellpoem.stop_mark') + $filter('translate')('spellpoem.poem_body') + $filter('translate')('spellpoem.exclamation_mark');
                        }
                    } else {
                        if (hasPoemtry) { // 有正文  无古诗名  无作者
                            tips = $filter('translate')('spellpoem.please') + $filter('translate')('spellpoem.poem_title') + $filter('translate')('spellpoem.stop_mark') + $filter('translate')('spellpoem.poem_author') + $filter('translate')('spellpoem.exclamation_mark');
                        } else { // 无正文  无古诗名  无作者
                            tips = $filter('translate')('spellpoem.please') + $filter('translate')('spellpoem.poem_title') + $filter('translate')('spellpoem.stop_mark') + $filter('translate')('spellpoem.poem_author') + $filter('translate')('spellpoem.stop_mark') + $filter('translate')('spellpoem.poem_body') + $filter('translate')('spellpoem.exclamation_mark');
                        }
                    }
                }
                return tips;
            }

            /**
             * 检测字符串是否为空
             * @param str
             * @returns {boolean}
             */
            function validStr(str) {
                if (str && typeof str === 'string') {
                    var strTrim = str.trim();
                    if (strTrim !== "") {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }
            }

            /**
             * 验证 古诗正文
             * @returns {boolean}
             */
            function validPoemBody() {
                if ($scope.model.content.sentences === undefined) {
                    return false
                }
                var flag = false;
                var length = $scope.model.content.sentences.length;
                for (var i = 0; i < length; i++) {
                    var words = $scope.model.content.sentences[i].words.trim();
                    if (words !== "") {// 不空
                        flag = true;
                        break;
                    }
                }
                return flag;
            }

            /**
             * 错误提示
             * @param text 提示内容
             * @param delay 延时
             */
            function showErrorTips(text, delay) {
                if (delay === undefined || delay === 0) {
                    delay = 1000;
                }
                if (text !== null && text !== undefined && text !== "") {
                    try {
                        $scope.errorModel.errorText = text;
                        $scope.errorModel.dismissErrorTip(delay);
                    } catch (err) {
                    }
                }
            }

            /**
             * 获取显示的古诗正文数组
             * @param sens
             * @returns {*}
             */
            function getDisplaySentenceArray(sens) {
                if (sens) {
                    $scope.wordsMaxThan8 = false;
                    var array = Array();
                    var length = sens.length;
                    for (var i = 0; i < length; i++) {
                        var str = sens[i].words;
                        var strLength = str.length;
                        if (strLength === 0) {
                            continue;
                        } else if (strLength > WORDS8) {
                            $scope.wordsMaxThan8 = true;
                        }
                        var words = Array();
                        for (var j = 0; j < strLength; j++) {
                            words[j] = str.substr(j, 1);
                        }
                        array[i] = {
                            "words": words
                        };
                    }
                    return array;
                } else {
                    return null;
                }
            }
        }
    ]);
});
