/**
 * Created by oy on 2015/7/30.
 */

define(['app', 'fillblank/directive/fillblank.directive'
], function (app) {
    'use strict';
    app.controller('fillblank_ctrl', [
        '$scope', 'skin_service', '$stateParams', 'CustomEditorService', '$rootScope', '$filter', '$timeout',
        function ($scope, skin_service, $stateParams, CustomEditorService, $rootScope, $filter, $timeout) {

            $scope.errorModel = {};

            $scope.model = {
                'title': '',         //标题
                'skin': {
                    code: 'wood',
                    css_url: '${ref-path}/edu/esp/preparecustomeditor/fillblank/wood/css/wood.css',
                    name: $filter('translate')('fillblank.muwen'),
                    package_url: '${ref-path}/edu/esp/preparecustomeditor/fillblank/wood'
                },
                'timer': {
                    'timer_type': 'countdown',  //计时器类型: ['sequence', 'countdown']
                    'time_minute': 1,    //倒计时初始设置-分钟，timer_type = 'countdown'时有效
                    'time_second': 0     //倒计时初始设置-秒，timer_type = 'countdown'时有效
                },
                article: '',
                candidates: []
            };

            $scope.view = {
                left: 0,
                top: 0,
                interfereOptions: 0,
                options: 0,
                selection: null,
                showButton: false,
                buttonActive: false,
                content: getContent(),
                contentSize: 0,
                size:1,
                curLength:0,
                isFull:false
            };
            
            $scope.handle = {};

            var MAX_CONTENT_SIZE = 360;
            var MAX_OPTION_SIZE = 20;
            var MAX_CHARACTOR_NUM = 40;

            var loadingData = function (id) {
                CustomEditorService.getQuestionInfoById(id)
                    .then(function (rtnData) {
                        if (!rtnData) {
                            $scope.errorModel.errorText = $filter('translate')('fillblank.unvalidno');
                        } else {
                            if (rtnData.skin.code != '') {
                                $scope.model = $scope.decodeOrder(rtnData);
                                $scope.view.content = getContent();
                                $scope.view.options = countOptions();
                                $scope.view.interfereOptions = countOptions('interfere');
                                setTimeout(function(){
                                	 $scope.view.contentSize = countContent();
                                },0);
                            } else {
                                $scope.model.id = rtnData.id;
                            }

                            $scope.errorModel.errorText = '';
                            skin_service.set_skin_by_code($scope.model.skin.code,"v1");
                        }
                    }, function () {
                        $scope.errorModel.errorText = $filter('translate')('fillblank.get_title_error');
                    });
            };

            //入口
            if (!$stateParams.id) {
                skin_service.set_skin_by_code($scope.model.skin.code,"v1");
            } else {
                loadingData($stateParams.id);
            }

            $scope.$on('changgedSkin', function () {
                $rootScope.scaleHtml();
            });

            $('.side_titinp')[0].oncontextmenu = function () { return false; };
            $scope.handle.startSelect = function (e) {
                window.getSelection().removeAllRanges();
                $scope.view.showButton = false;
                $scope.view.selection = null;
            };

            $scope.handle.endSelect = function (e) {
                var selection = window.getSelection();
                
                $scope.view.showButton = false;
                if (selection.toString() == '') return;
                $scope.view.selection = selection;
                $scope.view.left = e.pageX;
                $scope.view.top = e.pageY - 30;
                $scope.view.showButton = true;
            };

            $scope.handle.cancel = function () {
                if (!$scope.view.buttonActive) hideAddButton();
            };

            // 添加选项操作
            // 借用下文本选择
            $scope.handle.addOption = function () {
            	if($scope.view.options < 10){
            		//var selection = $scope.view.selection;
                    var selection = window.getSelection();
                    var range = selection.getRangeAt(0);
                    var content = '';
                    var temp = '';

                    hideAddButton();

                    // 选项有重叠
                    if (!checkData(range)) {
                        $scope.errorModel.errorText = $filter('translate')('fillblank.body_error');
                        window.getSelection().removeAllRanges();
                        return;
                    }

                    //content = range.startContainer.textContent;
                    //var selected = content.substring(range.startOffset, range.endOffset);
                    var selected = range.toString();

                    // 选项字数超出
                    if (selected.length > MAX_OPTION_SIZE) {
                        $scope.errorModel.errorText = $filter('translate')('fillblank.maxlen_option');
                        window.getSelection().removeAllRanges();
                        return;
                    }

                    if (!selected.length) return;

                    //选中项临时的序号
                    var num = $('.side_titinp').find('ins.selected').length + 1;
                    var ins = document.createElement('ins');
                    ins.className = 'selected';
                    ins.setAttribute('data-num',num);
                    ins.setAttribute('contenteditable','false');

                    range.surroundContents(ins);
                    range.insertNode(ins);

                    var temp = resetOptionNum(getContentByHtml());
                    $scope.view.content = temp;
                    setCandidateFormContent(temp);
                    $timeout(function(){
                        var container = $('.side_titinp')[0];
                        //如果最后一个节点是ins，添加一个空格放置光标
                        if( container.lastChild.nodeName == 'INS'){
                            container.appendChild(document.createTextNode(' '));
                            var newRange = document.createRange();
                            newRange.setStart(container,container.childNodes.length - 1);
                            newRange.collapse(true);
                            selection = window.getSelection();
                            selection.removeAllRanges();
                            selection.addRange(newRange);
                        }

                    });

                    //var start = translateContent(content.substring(0, range.startOffset));
                    //var end = translateContent(content.substring(range.endOffset));
                    //selected = translateContent(selected);
                    //
                    //content = translateContent(content);
                    //temp = getContentByHtml().replace(content, function () {
                    //    return start + '<span id="mark"></span>' + end;
                    //});
                    //var num = getNum(temp);
                    //var str = start + '<ins class="selected" data-num="' + num + '" contenteditable="false">' + selected + '</ins>' + end;
                    //temp = resetOptionNum(getContentByHtml().replace(content, function () {
                    //    return str;
                    //}));
                    //$scope.view.content = temp;
                    //setCandidateFormContent(temp);
            	}else{
            		 $scope.errorModel.errorText = $filter('translate')('fillblank.maxcount_hint');
                     return false;
            	}
                
            };

            // 添加干扰数据
            $scope.handle.addInvalidOption = function () {
                addInvalidCandidate();
                $scope.view.curLength = 0;
            };

            // 结束编辑干扰项
            $scope.handle.endEdit = function (candidate,e) {
                $scope.view.curLength = 0;

                if (candidate.value === '') {
                    delCandidate(candidate);
                } else if (candidate.value.replace(/<(?:.|\s)*?>/g, '').length > MAX_OPTION_SIZE) {
                    $scope.errorModel.errorText = $filter('translate')('fillblank.maxlen_xoption');
                    delCandidate(candidate);
                } else {
                    candidate.readOnly = 1;
                }
            };
            
            //检查干扰项编辑时字数
            $scope.handle.checkInvalidLength = function (candidate,e){
            	var value = candidate.value;
            	var len = value.length;
            	var size = 0;
                $scope.view.curLength = len;
            	
            	size = getCharacterSize(value,false);         	
            	            	
            	if(len > MAX_OPTION_SIZE){
            		$scope.errorModel.errorText = $filter('translate')('fillblank.maxlen_xoption');
            	}
            	
        		if(size < 1){
        			candidate.size = 1;
        		}else if(size > MAX_CHARACTOR_NUM){
        			candidate.size = MAX_CHARACTOR_NUM;
        		}else{
        			candidate.size = size;
        		}
            	 /*
            	if(candidate.value.replace(/<(?:.|\s)*?>/g, '').length > MAX_OPTION_SIZE){
            		candidate.value = candidate.value.substring(0,MAX_OPTION_SIZE);                                		
            	}
            	*/
            };
            
            //正在输入状态改变size
            $scope.handle.changeSize = function (candidate,e){
                candidate.isFull = false;
            	if(candidate.value.length < MAX_OPTION_SIZE){
            		if(isEnabledCode(e.keyCode)){
            			candidate.size += 1;
            		}           		
            	}else{
                    if(e.keyCode != 8){
                        candidate.isFull = true;
                        $scope.errorModel.errorText = $filter('translate')('fillblank.maxlen_xoption'); 
                    }                     
            	}
            }
           
            // 删除选项操作
            $scope.handle.delOption = function (candidate) {
                delOption(candidate);
            };

            // 粘贴内容
            $scope.handle.pasteContent = function (e) {
                var oldContent = $.trim(getContentByHtml());
                setTimeout(function () {
                    var content = getContentByHtml();
                    var contentText = content.replace(/<(?:.|\s)*?>/g, '');

                    if (!checkSubLength(contentText)) {
                        $scope.errorModel.errorText = $filter('translate')('fillblank.maxlen_hint');
                    }

                    // 如果原来题干是空的，则粘贴入的文本全部移除标签
                    if (oldContent === '') {
                        content = contentText;
                    } else {
                        content = content.replace(/(<pre[^>]*>)(.*?)(<\/pre[^>]*>)/ig, function (match, n1, n2, n3) {
                            return n2 ? n1 + n2.replace(/<(?:.|\s)*?>/g, '') + n3 : match;
                        });
                        content = content.replace(/<(?!ins)(?!\/ins)[^>]*>/ig, '');
                        // 复制题干的内容做个处理
                        content = content.replace(/<ins class="selected" data-num="\d+" style=".*?">(.*?)<\/ins>/ig, '$1');
                    }
                    content = content.replace(/&nbsp;/g, ' ');

                    content = resetOptionNum(content).substring(0,360 + countOptions()*65);
                    setCandidateFormContent(content);
                    $('.side_titinp').html(content);
                    fixedCursor(e.target);
                    $scope.view.contentSize = countContent();
                }, 0);
            };

            // 编辑题目
            $scope.handle.editWithKeyboard = function (e) {
                hideAddButton ();
                var range,
                    selection,
                    startNode,
                    oldRange,
                    cursorPosition,
                    offset;
                var container = $('.side_titinp')[0];
                var text = container.textContent;

                var startContainer = window.getSelection().getRangeAt(0).startContainer;

                if (e.keyCode === 8 || e.keyCode === 46 || (e.ctrlKey && e.keyCode === 88)) {
                    var childLen = container.childNodes.length;
                    var content = getContentByHtml();
                    //content = resetOptionNum(content);
                    setCandidateFormContent(content);
                    $timeout(function(){
                        if( container.lastChild.nodeName == 'INS'){
                            container.appendChild(document.createTextNode(' '));
                            //range = document.createRange();
                            //range.setStart(container,childLen);
                            //range.collapse(true);
                            //selection = window.getSelection();
                            //selection.removeAllRanges();
                            //selection.addRange(range);//
                        }
                        //如果有两个连续的文本节点，则合并为一个
                        var len = container.childNodes.length;
                        for(var i = 0;i < len;i++){
                            var curNode = container.childNodes[i]
                            var curLen = curNode.textContent.length;
                            if(curNode.nodeType == 3 && curNode.nextSibling && curNode.nextSibling.nodeType == 3){
                                curNode.textContent += curNode.nextSibling.textContent;
                                container.removeChild(curNode.nextSibling);
                                range = document.createRange();
                                range.setStart(curNode,curLen);
                                range.collapse(true);
                                selection = window.getSelection();
                                selection.removeAllRanges();
                                selection.addRange(range);
                                break;
                            }
                        }
                    });

                    //$scope.view.content = content;
                    //$('.side_titinp')[0].innerHTML = content;
                    //光标位置
                    //$timeout(function(){
                    //    console.log('keyup',window.getSelection().getRangeAt(0));
                    //    oldRange = window.getSelection().getRangeAt(0);
                    //    startNode = $('.side_titinp')[0].childNodes[oldRange.startOffset];
                    //    cursorPosition = startNode.textContent.length - $scope.view.textOffset;
                    //    range = document.createRange();
                    //    range.setStart(startNode,cursorPosition);
                    //    range.setEnd(startNode,cursorPosition);
                    //    selection = window.getSelection();
                    //    selection.removeAllRanges();
                    //    selection.addRange(range);
                    //})

                } else if (e.keyCode === 13) {         // 空格+回车 会产生 &nbsp;
                    //var content = getContentByHtml();
                    //content = content.replace(/&nbsp;/g, ' ');
                    //$scope.view.content = content;
                    //enter键换行处理
                    //if(startContainer.tagName == 'DIV' && !startContainer.isSameNode($('.side_titinp')[0])){
                    //    $('.side_titinp')[0].replaceChild(document.createElement('br'),startContainer);
                    //    var offset = window.getSelection().getRangeAt(0).startOffset;
                    //    if(offset == 1){
                    //        offset = 2;
                    //    }
                    //
                    //    range = document.createRange();
                    //    range.setStart($('.side_titinp')[0],offset);
                    //    range.collapse(true);
                    //    selection = window.getSelection();
                    //    selection.removeAllRanges();
                    //    selection.addRange(range);
                    //}
                }

                //如果字数超过限制
                if(countContent() >= MAX_CONTENT_SIZE){
                    //var content = getContentByHtml();
                    //content = resetOptionNum(content).substring(0,360 + countOptions()*65);
                    //setCandidateFormContent(content);
                    //console.log(content);
                    ////$('.side_titinp').html(content);
                    //fixedCursor(e.target);

                    //对中文字符的判断和处理
                    range = window.getSelection().getRangeAt(0);
                    startNode = range.startContainer;
                    var str = startNode.textContent;
                    var overNum = countContent() - 360;
                    offset = range.startOffset;
                    if(/[\u4E00-\u9FFF]/.test(str.charAt(offset - 1))){
                        str = str.substring(0,offset - overNum) + str.substring(offset,str.length);
                        startNode.textContent = str;
                        range = document.createRange();
                        range.setStart(startNode,offset - overNum);
                        range.collapse(true);
                        selection = window.getSelection();
                        selection.removeAllRanges();
                        selection.addRange(range);
                    }

                    $scope.view.contentSize = countContent();
                    $scope.view.isFull = true;
                    //$scope.errorModel.errorText = $filter('translate')('fillblank.maxlen_hint');
                }
                
                $scope.view.contentSize = countContent();
            };

            // 检查题干
            $scope.handle.editCheck = function (e) {
            	$scope.view.isFull = false;

                if (isEnabledCode(e.keyCode)) {
                    var len = $(".side_titinp").text().length;
                    if (len >= MAX_CONTENT_SIZE) {
                        e.preventDefault();
                        $scope.view.isFull = true;
                        $scope.errorModel.errorText = $filter('translate')('fillblank.maxlen_hint');

                        return false;
                    }
                }

                var range,selection;
                selection = window.getSelection();
                range = selection.getRangeAt(0);
                $scope.view.textOffset = range.startContainer.textContent.length - range.startOffset;

            };

            $scope.handle.activeButton = function () {
                $scope.view.buttonActive = true;
            };

            $scope.handle.inactiveButton = function () {
                $scope.view.buttonActive = false;
            };
            
            //计算字符数
            function getCharacterSize(text,flag){
            	var size = 0;
            	var len = text.length;
            	
            	 for (var i = 0; i < len; i++) {
                     var a = text.charAt(i);
                     
                     if(a.match(/[^\x00-\xff]/ig) != null){
                     	size += 2;
                     }else{
                        size += 1;
                     } 
                }
            	 
            	return size;
            }
            
            //判断键值是否为可输入的键位
            function isEnabledCode (code){
            	var isEnabled = false;
            	if(code > 64 && code <91){
            		isEnabled = true;
            	}else if(code > 47 && code < 58){
            		isEnabled = true;
            	}else if(code > 95 && code < 108){
            		isEnabled = true;
            	}else if(code > 108 && code < 112){
            		isEnabled = true;
            	}else if(code > 185 && code < 223){
            		isEnabled = true;
            	}else if(code == 229){
            		isEnabled = true;
            	}else if(code == 32){
                    isEnabled = true;
                }
                else{
            		isEnabled = false;
            	}
            	
            	return isEnabled;
            }
            
            // 计算题干字数
            function countContent () {
                return $('.side_titinp').text().length;
            }

            function translateContent (content) {
                content = content.replace(/&/g, '&amp;');
                content = content.replace(/</g, '&lt;');
                content = content.replace(/>/g, '&gt;');
                return content;
            }

            function getContentByHtml (text) {
                var index = 0;
                //设置选项序号
                $('.side_titinp').find('ins.selected').each(function(){
                    $(this).attr('data-num',index++);
                });

                return text ? $('.side_titinp').text() : $('.side_titinp').html();
            }

            function checkData (range) {
                if (range.startContainer == range.endContainer && (range.startContainer.parentElement.tagName == 'PRE' || range.startContainer.parentElement.tagName == 'DIV')) {
                    return true;
                }
                return false;
            }

            // 转换题干
            function getContent () {
                var article = $scope.model.article;
                var candidates = $scope.model.candidates;
                for (var idx in candidates) {
                    article = article.replace('{' + candidates[idx].num + '}', function () {
                        return '<ins class="selected" data-num="' + candidates[idx].num + '" contenteditable="false">' + candidates[idx].value + '</ins>';
                    });
                }
                return article;
            }

            // 按题干取得答案序号
            function getNum (html) {
                var num = 0;
                var temp = $('<div>' + html + '</div>');
                var mark = temp.find('#mark');
                var prevOption = mark.prev('ins.selected');

                if (prevOption.length) {
                    num = prevOption.data('num') + 1;
                }
                return num;
            }

            // 题干重设序号
            function resetOptionNum (content) {
                var count = 0;
                content = content.replace(/data-num="\d+"/g, function () {
                    return 'data-num="' + (count++) + '"';
                });
                return content;
            }

            // 从题干生成选项
            function setCandidateFormContent(s) {
                var options = $('.side_titinp ins.selected');
                var newCandidates = [];
                var candidates = $scope.model.candidates;
                var count = 0;
                

                if (typeof s === 'string') {
                    options = $('<div>' + s + '</div>').find('ins.selected');
                }

                options.each(function () {
                	var size = 0;

                	size = getCharacterSize($(this).text(),true);
                   
                    newCandidates.push({
                        num: $(this).data('num'),
                        value: $(this).text(),
                        size:size,
                        readOnly:1
                    });
                    count++;
                });

                angular.forEach(candidates, function (candidate, key) {
                    if (candidate.num === -1) {
                        newCandidates.push(candidate);
                    }
                });

                $scope.model.candidates = newCandidates;
                $scope.view.options = count;
            }

            // 统计选项数
            function countOptions (interfere) {
                var count = 0;
                var interfereCount = 0;

                angular.forEach($scope.model.candidates, function (candidate, key) {
                    if (candidate.num !== -1) {
                        count++;
                    } else {
                        interfereCount++;
                    }
                });
                return interfere ? interfereCount : count;
            }

            function getTrueCandidateNum () {
                var candidates = $scope.model.candidates;
                var num = -1;
                for (var idx in candidates) {
                    candidates[idx].num > num ? num = candidates[idx].num : num;
                }
                return num;
            }

            function delOption (candidate) {
                if (candidate.num !== -1) {
                    var value = translateContent(candidate.value);
                    var target = '<ins class="selected" data-num="' + candidate.num + '" contenteditable="false">' + value + '</ins>';
                    var content = getContentByHtml().replace(target, function () {
                        return value;
                    });
                    content = resetOptionNum(content);
                    setCandidateFormContent(content);
                    $scope.view.content = content;
                } else {
                    delCandidate(candidate);
                }
            }

            function hideAddButton () {
                $scope.view.left = 0;
                $scope.view.top = 0;
                $scope.view.showButton = false;
            };

            // 左侧内容变化
            function contentChanged() {
                var candidates = $scope.model.candidates;
                var newCandidates = [];
                var content = getContentByHtml();
                var options = 0;
                var reg;

                angular.forEach(candidates, function (candidate, key) {
                    if (candidate.num !== -1) {
                        reg = new RegExp('<ins class="selected" data-num="' + candidate.num + '" contenteditable="false">' + candidate.value + '</ins>');
                        if (reg.test(content)) {
                            newCandidates.push(candidate);
                            options++;
                        }
                    } else {
                        newCandidates.push(candidate);
                    }
                });
                $scope.model.candidates = newCandidates;
                $scope.view.options = options;
            }

            // 添加选项数据
            function addCandidate (selected, num) {
                var candidate = {
                    num: num,
                    value: selected
                };

                $scope.model.candidates.push(candidate);
                $scope.view.options++;
            }

            // 添加干扰数据
            function addInvalidCandidate () {
                var candidate = {
                    num: -1,
                    value: '',
                    size:1,
                    readOnly:0,
                    isFull:false
                };

                $scope.model.candidates.push(candidate);
                $scope.view.interfereOptions++;
            }

            // 删除选项数据
            function delCandidate (candidate) {
                var candidates = $scope.model.candidates;

                candidates.splice(candidates.indexOf(candidate), 1);
                if (candidate.num === -1) {
                    $scope.view.interfereOptions--;
                } else {
                    $scope.view.options--;
                }
            }

            // 检查题干长度
            function checkSubLength (s) {
                var text = s || $('.side_titinp').text();
                return text.length <= MAX_CONTENT_SIZE;
            }

            //光标所在位置
            function getCharacterOffsetWithin(range, node) {
                var treeWalker = document.createTreeWalker(
                    node,
                    NodeFilter.SHOW_TEXT,
                    function(node) {
                        var nodeRange = document.createRange();
                        nodeRange.selectNode(node);
                        return nodeRange.compareBoundaryPoints(Range.END_TO_END, range) < 1 ?
                            NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
                    },
                    false
                );

                var charCount = 0;
                while (treeWalker.nextNode()) {
                    charCount += treeWalker.currentNode.length;
                }
                if (range.startContainer.nodeType == 3) {
                    charCount += range.startOffset;
                }
                return charCount;
            }
            
            //光标停在选项最后
            function fixedCursor(obj){
                var chdLen = obj.childNodes.length;
                var lastNode = obj.childNodes[chdLen-1];
                
                var range = document.createRange();
                
                obj.focus();
                
                if (chdLen == 0) {
                    range.setStart(obj, 0);
                    range.setEnd(obj, 0);
                } else {
                    if (lastNode.nodeType == 3) {
                        range.setStart(lastNode, lastNode.length);
                        range.setEnd(lastNode, lastNode.length);
                    } else {
                        range.setStart(obj, chdLen);
                        range.setEnd(obj, chdLen);
                    }
                }      
                
                var sel = window.getSelection();
                sel.removeAllRanges();
                sel.addRange(range);
            }

            $scope.validPostData = function () {
                var modelData = $scope.model;

                // 标题为空
                if ($.trim(modelData.title) == '') {
                    $scope.errorModel.errorText = $filter('translate')('fillblank.no_title');
                    return false;
                }

                // 题干为空
                if ($.trim(getContentByHtml()) == '') {
                    $scope.errorModel.errorText = $filter('translate')('fillblank.no_words');
                    return false;
                }

                // 正确选项
                if ($scope.view.options < 3) {
                    $scope.errorModel.errorText = $filter('translate')('fillblank.mincount_hint');
                    return false;
                }
                if ($scope.view.options > 10) {
                    $scope.errorModel.errorText = $filter('translate')('fillblank.maxcount_hint');
                    return false;
                }

                // 检查题干长度
                if (!checkSubLength()) {
                    $scope.errorModel.errorText = $filter('translate')('fillblank.maxlen_hint');
                    return false;
                }

                return true;
            };

            $scope.encodeOrder = function (model) {
                var model = angular.copy(model),
                    content = getContentByHtml(),
                    reg = /<ins class="selected" data-num="(\d+)" contenteditable="false">.*?<\/ins>/g;

                model.article = content.replace(reg, '{$1}');
               
                for(var i in model.candidates){
                	delete model.candidates[i].size;
                    delete model.candidates[i].readOnly;
                    delete model.candidates[i].curLength;
                    delete model.candidates[i].isFull;
                }

                return model;
            };

            $scope.decodeOrder = function (data) {
                var model = angular.copy(data);
                
                for(var i in model.candidates){
                    model.candidates[i].readOnly = 1;
                }
                
                return model;
            };
    }]);
});
