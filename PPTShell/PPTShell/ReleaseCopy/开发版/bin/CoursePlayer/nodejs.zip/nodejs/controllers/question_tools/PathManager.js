var REF_BASE = "${ref-base}";
var REF_PATH = "${ref-path}";
var Path  = require('path');
var uuid = require('node-uuid');
var root = Path.join(__dirname , "/../../app/userdatas/edu/esp");
var BaseQuestionDefaultPath =  Path.join(root,"questions");
var InteractQuestionDefaultPath = Path.join(root,"interaction");
var PathManager = function(id,basepath,type){
    this.type = type;
    this.id = id;
    this.basepath = basepath  ? basepath :  this.isBasicQuestion() ? BaseQuestionDefaultPath :InteractQuestionDefaultPath ;
    this.default = !basepath;
}
PathManager.prototype.toUrl = function(){

}
PathManager.prototype.isBasicQuestion = function(){
    return this.type != 'interaction';
}
PathManager.prototype.isDefault = function(){
    return this.default;
}
PathManager.prototype.getFilePath=function(relative){
    return relative ? Path.join(this.basepath,this.id+".pkg",relative) :Path.join(this.basepath,this.id+".pkg") ;
}
PathManager.prototype.getRefPath=function(relative){
    var url =  relative ? Path.join(REF_BASE,relative) : Path.join(REF_BASE);
    url = url.replace(/\\/g, '/');
    return url;
}
PathManager.prototype.getRefFullPath=function(relative){
    var pathOnServer = this.isBasicQuestion() ? "questions":"interaction";
    var url =  relative ? Path.join(REF_PATH,"edu/esp/",pathOnServer,this.id+".pkg",relative) : Path.join(REF_PATH,"edu/esp/",pathOnServer,this.id+".pkg");
    url = url.replace(/\\/g, '/');
    return url;
}
PathManager.prototype.extraInfoUrl = function(){
    var result = "";
    if(!this.isDefault()){
        result = result +"&question_base="+encodeURIComponent(this.basepath);
    }
    result = result +"&main_type="+(this.type||"")
    return result;
}
PathManager.prototype.toProxy = function(filepath,href,assettype){
    var questionBase = this.extraInfoUrl();
    return  '/v1.3/assets/proxy?'+questionBase+'&question_id='+this.id+'&filepath='+encodeURIComponent(filepath)+"&url="+encodeURIComponent(href)+"&assetType="+assettype+"&end=true";
}
PathManager.prototype.toGetUrl = function(filepath,href,assettype){
    var questionBase = this.extraInfoUrl();
    return  "/v1.3/assets/get?question_id="+this.id+questionBase+"&filepath=";
}


PathManager.prototype.urlJoin=function(path1,path2){
    return Path.join(path1,path2).replace(/\\/g, '/');
}

exports.create=function(req,type,question_id){
    var id = question_id;
    if(!id){
        id= req.param("identifier");
    }
    if(!id){
        id = req.params.id;
    }
    if(!id){
        id = uuid.v4();
    }
    if(!type){
        type = req.param("main_type");
        if(!type){
            type = 'basic';
        }
    }
    var base = req.param('question_base');
    if(base&&base.lastIndexOf("/")!=base.length-1){
        base = base+"/";
    }
    return new PathManager(id,base,type);
}
exports.PathManager = PathManager;




