var PathManagerCreator = require('./question_tools/PathManager');
var DEFAULT_BACKGROUND = {"url":"", "type":1, "left":0, "top":0, "right":0, "bottom":0};
var parsePage = function(pagexml){
    var text = pagexml.toString();
    var data = {
        content: "",
        object: ""
    };
    var index = text.indexOf("<property name='text' type='html'>");
    index = text.indexOf("<![CDATA[",index||0);
    if(index!=-1){
        var next = text.indexOf("]]>",index);
        data.content  =text.substring(index+'<![CDATA['.length,next);
    }
    index = text.indexOf("<property name=\"writer_background\" type=\"json\">");
    index = text.indexOf("<![CDATA[",index);
    if(index!=-1){
        var next = text.indexOf("]]>",index);
        var objectcontent  =text.substring(index+'<![CDATA['.length,next);
        if(objectcontent){
            data.background = JSON.parse(objectcontent);
        }
    }
    return data;
}
exports._parsePage = parsePage;
exports.getHandwrite = function(req, res, next) {
    var pathManager = PathManagerCreator.create(req,'interaction');
    var id = pathManager.id;
    var pagepath = pathManager.getFilePath("pages/"+id+".xml");
    var mainRefPath = pathHelper.getRefpath("main.xml");
    var refpath = "";
    fs.readFile(pagepath,function(err,data){
        if(err){
            return res.status(500).send({code:"LS/QUESTION_NOT_FOUND",message:"习题不存在。"});
        }
        data = parsePage(data);
        data.location = mainRefPath;
        data.physic_path =  path.normalize(pathManager.getFilePath(""));
        return res.send(data);
    });
}


exports.saveHandwrite = function(req, res, next) {
    var pathManager = PathManagerCreator.create(req,'interaction');
    var id = pathManager.id;
    var content = req.body.content;
    var background = req.body.background;
    if(!background){
        background = DEFAULT_BACKGROUND;
    }
    var handwriteparams ={
        question_id:id,
        question_prompt: content,
        background_content: JSON.stringify(background)
    };
    var pagepath = pathManager.getFilePath("pages/"+id+".xml");
    return saveToFile(pagepath,replaceByParams(loadTemplate("handwrite/page.xml"),handwriteparams)).then(function(){
        return res.send({content:content});
    });
}
function createHandwrite(req){
    var pathManager = PathManagerCreator.create(req,'interaction');
    var identifier = pathManager.id;
    var questionInfo = req.body;
    var templatemetadata = loadTemplate("handwrite/metadata.json");
    var mainurl = pathManager.getRefPath("main.xml")
    var params = {
        chapter_id: questionInfo.chapter_id,
        creator: questionInfo.creator,
        create_time: formatDate(new Date()),//20151216135748,
        identifier : identifier,
        page_id : identifier,
        question_type:'nd_handwritequestion',
        mainurl:mainurl
    };
    templatemetadata = replaceByParams(templatemetadata,params);
    var metadata = JSON.parse(templatemetadata);
    if(!questionInfo.chapter_id){
        metadata.relations = [];
    };
    metadata.page_id = identifier;
    var path = pathManager.getFilePath()
    return saveToFile(path+"/metadata.json",JSON.stringify(metadata)).then(function(){
        //save main.xml
        return saveToFile(path+"/main.xml",replaceByParams(loadTemplate("courseware/main.xml"),params)).then(function(){
            //save main-student.xml
            return saveToFile(path+"/sdp-package.xml",replaceByParams(loadTemplate("courseware/sdp-package.xml"),metadata)).then(function(){
                //save page.xml
                var handwriteparams ={
                    question_id:identifier,
                    question_prompt: '',
                    background_content: JSON.stringify(DEFAULT_BACKGROUND)
                };
                return saveToFile(path+"/pages/"+identifier+".xml",replaceByParams(loadTemplate("handwrite/page.xml"),handwriteparams)).then(function(){
                    return saveToFile(path+"/sdp-package.xml",loadTemplate("courseware/sdp-package.xml")).then(function(){
                        return metadata;
                    });
                });
            });
        });
    });
}