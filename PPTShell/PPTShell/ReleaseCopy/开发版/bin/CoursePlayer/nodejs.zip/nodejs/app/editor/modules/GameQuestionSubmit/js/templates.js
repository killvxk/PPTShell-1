define([], function () {
var templates = {};

templates["template.html"] = "<div class=\"GameQuestionSubmit_container\">\n" +
   "	  \n" +
   "</div> \n" +
   "\n" +
   "";
return templates;});