/**
 *
 */
define(['app'], function (app) {
    'use strict';
    app.controller('home_ctrl', ['$scope', '$location', '$stateParams', '$filter',
        function ($scope, $location, $stateParams, $filter) {
            var qtype = $filter("filterGetWebRouteByQuestionType")($stateParams.question_type);

            if (!$stateParams.question_type) {
                $scope.errorInfo = "question_type不能为空";
            } else if (!qtype) {
                $scope.errorInfo = "无效的自定义题型";
            } else {
                var url = "/" + qtype + "?rnd=" + new Date().getTime();
                for (var key in $stateParams) {
                    url += ("&" + key + "=" + (!$stateParams[key] ? "" : $stateParams[key]));
                }

                $location.url(url);
            }
        }
    ]);
});
