/**
 * Created by Administrator on 2015/12/3.
 */
define(['angularAMD'
], function (angularAMD) {
    angularAMD.directive('mathaxisDiv', [function () {
        return {
            restrict: 'E',
            templateUrl: 'interaction/mathaxis/directive/mathaxis-div.html',
            link: function (scope, element) {
                AddonMathAxis().run($('.com_lay_mboard'),scope.model,false,scope);

            }
        };
    }]);
});
