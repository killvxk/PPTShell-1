/**
 *
 */
define(['app', 'linkup/directive/linkup.directive'
], function (app) {
    'use strict';
    app.controller('linkup_ctrl', [
        '$scope','skin_service','$stateParams','CustomEditorService','$rootScope',"$filter",
        function ($scope,skin_service,$stateParams,CustomEditorService, $rootScope,$filter) {
        	$rootScope.moduleScope = $scope;
            $scope.errorModel = {};
            $scope.delData = {data:{}};
            $scope.model = {
                "title":"",         //标题
                "skin": {
                    code: "wood",
                    css_url: "${ref-path}/edu/esp/preparecustomeditor/linkup/wood/css/wood.css",
                    name:  $filter('translate')('linkup.muwen'),
                    package_url: "${ref-path}/edu/esp/preparecustomeditor/linkup/wood"
                },
                "timer":{
                    "timer_type":"sequence",  //计时器类型: ["sequence", "countdown"]
                    "time_minute":"0",    //倒计时初始设置-分钟，timer_type="countdown"时有效
                    "time_second":"0"     //倒计时初始设置-秒，timer_type="countdown"时有效
                }
            };
            var initModel = {
                "module_subtype":"image2text",//子类型:["image2image","image2text","text2text"]
                "title":"",         //标题
                "skin": {
                    code: "wood",
                    css_url: "${ref-path}/edu/esp/preparecustomeditor/linkup/wood/css/wood.css",
                    name: $filter('translate')('linkup.muwen'),
                    package_url: "${ref-path}/edu/esp/preparecustomeditor/linkup/wood"
                },
                "timer":{
                    "timer_type":"sequence",  //计时器类型: ["sequence", "countdown"]
                    "time_minute":"0",    //倒计时初始设置-分钟，timer_type="countdown"时有效
                    "time_second":"0"     //倒计时初始设置-秒，timer_type="countdown"时有效
                },
                items: [{},{},{}]
            };
            var loadingData = function(id){
                $scope.isloadingData=true;
                CustomEditorService.getQuestionInfoById(id)
                    .then(function(rtnData){
                        if(!rtnData){
                            $scope.errorModel.errorText = $filter('translate')('linkup.unvalidno');
                        }else{
                            if(rtnData.skin.code!=''){
                                $scope.model=$scope.decodeOrder(rtnData);
                                skin_service.set_skin_by_code($scope.model.skin.code, "v1");
                            }else{

                                $scope.showGuide = true;
                                initModel.id=rtnData.id;
                                skin_service.set_skin_by_code($scope.model.skin.code, "v1");
                            }
                            $scope.errorModel.errorText = "";
                            $scope.isloadingData=false;
                        }
                    },function(error){
                        $scope.errorModel.errorText = $filter('translate')('linkup.get_title_error');
                    })
            }

            //入口
            if(!$stateParams.id){
                //新增
                $scope.showGuide = true;
                skin_service.set_skin_by_code(initModel.skin.code, "v1");

            }else{
                //修改
                $scope.showGuide = false;

                loadingData($stateParams.id);
            }
            $scope.setModuleSubtype = function(module_subtype){
                $scope.showGuide = false;
                initModel.module_subtype = module_subtype;
                $scope.model.items = [{},{},{}];
                $scope.model.module_subtype = module_subtype;
                $scope.model.id = initModel.id;
                //$scope.model = initModel;
                
                //根据子类型设置默认标题
                switch($scope.model.module_subtype){
                case "image2image":
                	//$scope.model.title = $filter('translate')('linkup.title.image2image');
                	break;
                case "image2text":
                	//$scope.model.title = $filter('translate')('linkup.title.image2text');
                	break;
                case "text2text":
                	//$scope.model.title = $filter('translate')('linkup.title.text2text');
                	break;
                default:
                }
                
                
                $rootScope.scaleHtml();
            }
            $scope.$on('changgedSkin',function(){
                $rootScope.scaleHtml();
            })
            $scope.addLinkup = function(){
                $scope.model.items.push(angular.copy($scope.delData.data));
                $scope.delData = {data:{}};
            }
            $scope.validPostData = function(){
                var modelData =$scope.model;
                if($.trim(modelData.title)==''){
                    $scope.errorModel.errorText =  $filter('translate')('linkup.no_title');
                }else{
                    var itemsCount = 0;
                    for(var i=0;i<modelData.items.length;i++){
                        if(!(!modelData.items[i].source.href && !modelData.items[i].source.text) && !(!modelData.items[i].target.href && !modelData.items[i].target.text) ){
                            itemsCount++;
                        }else{
                            $scope.errorModel.errorText =  $filter('translate')('linkup.no_content');
                            return ;
                        }
                    };
                    if(itemsCount<3){
                        $scope.errorModel.errorText =  $filter('translate')('linkup.content_min');
                    }else{
                        return true;
                    }
                }
            }

            $scope.encodeOrder = function(model){
                var newModel = angular.copy(model);
                newModel.title = window.customHtmlEncode(newModel.title);
                for(var i=0;i<newModel.items.length;i++) {
                    if (newModel.items[i].source.item_type == 'text') {
                        newModel.items[i].source.text = window.customHtmlEncode(newModel.items[i].source.text);
                    }
                    if (newModel.items[i].target.item_type == 'text') {
                        newModel.items[i].target.text = window.customHtmlEncode(newModel.items[i].target.text);
                    }
                }
                return newModel;
            }
            $scope.encodeData = function(model){
                var newModel = angular.copy(model);
                newModel.title = window.customHtmlEncode(newModel.title);
                for(var i=0;i<newModel.items.length;i++) {
                    if (newModel.items[i].source.item_type == 'text') {
                        newModel.items[i].source.text = window.customHtmlEncode(newModel.items[i].source.text);
                    }
                    if (newModel.items[i].target.item_type == 'text') {
                        newModel.items[i].target.text = window.customHtmlEncode(newModel.items[i].target.text);
                    }
                }
                return newModel;
            }
            $scope.decodeOrder = function(model){
                var newModel = angular.copy(model);
                newModel.title = window.customHtmlDecode(newModel.title);
                for(var i=0;i<newModel.items.length;i++) {
                    if (newModel.items[i].source.item_type == 'text') {
                        newModel.items[i].source.text = window.customHtmlDecode(newModel.items[i].source.text);
                    }
                    if (newModel.items[i].target.item_type == 'text') {
                        newModel.items[i].target.text = window.customHtmlDecode(newModel.items[i].target.text);
                    }
                }
                return newModel;
            };
            $scope.decodeData = function(model){
                var newModel = angular.copy(model);
                newModel.title = window.customHtmlDecode(newModel.title);
                for(var i=0;i<newModel.items.length;i++) {
                    if (newModel.items[i].source.item_type == 'text') {
                        newModel.items[i].source.text = window.customHtmlDecode(newModel.items[i].source.text);
                    }
                    if (newModel.items[i].target.item_type == 'text') {
                        newModel.items[i].target.text = window.customHtmlDecode(newModel.items[i].target.text);
                    }
                }
                return newModel;
            };
            
            //题型说明视频点击后，弹出放大播放
            $scope.playFAQVideo = function() {
            	var box = angular.element('.llk_toolbar .desprtion'); 
            	$scope.faqVideoOffset = {left: box.offset().left + "px", top: Math.max(box.offset().top - 600, 0) + "px"};
            	$scope.isFAQVideoVisible = true;
            };
            $scope.closeFAQVideo = function() {
            	$scope.isFAQVideoVisible = false;
            };
            $scope.closeImagePreview = function() {
            	$scope.isImagePreview = false;
            };
        }
    ]);

});
