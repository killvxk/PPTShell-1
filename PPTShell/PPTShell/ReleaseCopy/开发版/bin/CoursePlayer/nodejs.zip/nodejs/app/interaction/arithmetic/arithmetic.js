define(['app', 'arithmetic/directive/arithmetic.directive'
], function (app) {
    'use strict';
    app.controller('arithmetic_ctrl', [
        '$scope', 'skin_service', '$stateParams', 'CustomEditorService', '$rootScope', '$filter', "$timeout",
        function ($scope, skin_service, $stateParams, CustomEditorService, $rootScope, $filter, $timeout) {
            $scope.errorModel = {};
            $scope.count = {
                placeholder: {title: "请输入标题"},
                inputValue: '',
                flag: true,
                calError: false

            };
            $scope.model = {
                "id": "",
                "title": "",         //标题
                "skin": {
                    code: "wood",
                    css_url: "${ref-path}/edu/esp/preparecustomeditor/arithmetic/wood/css/wood.css",
                    name: $filter('translate')('linkup.muwen'),
                    package_url: "${ref-path}/edu/esp/preparecustomeditor/arithmetic/wood"
                },
                "timer": {
                    "timer_type": "sequence",  //计时器类型: ["sequence", "countdown"]
                    "time_minute": "0",    //倒计时初始设置-分钟，timer_type="countdown"时有效
                    "time_second": "0"     //倒计时初始设置-秒，timer_type="countdown"时有效
                },
                "prompt": {
                    "number_first": {		// 计算数
                        "number": 23,		// 完整计算数字
                        "symbol": {"symbol": "-", "hide": false},	//正负
                        "items": [{
                            "num": 2,		// 位数数字
                            "hide": true | false,	// 是否隐藏设置为填空项
                            "index": 1 			//序号
                        }, {
                            "num": 3,
                            "hide": true | false,
                            "index": 1
                        }]
                    },
                    "number_second": {		// 计算数

                        "number": 23,
                        "symbol": {"symbol": "-", "hide": false},
                        "items": [{
                            "num": 2,
                            "hide": true | false,
                            "index": 1
                        }, {
                            "num": 3,
                            "hide": true | false,
                            "index": 1
                        }]
                    },
                    "number_result": {  		// 结果

                        "number": 23,
                        "symbol": {"symbol": "-", "hide": false},
                        "items": [{
                            "num": 2,
                            "hide": true | false,
                            "index": 1
                        }, {
                            "num": 3,
                            "hide": true | false,
                            "index": 1
                        }]
                    },
                    "operator": {"operator": "+", "hide": true | false},		//计算符
                    "procedure": [{			// 计算过程
                        "offset": 2,
                        "number": [
                            {"num": 2, "hide": false, "index": 1},
                            {"num": 3, "hide": false, "index": 1},
                        ]
                    }],
                    "remainder": [			//余数
                        {"num": 2, "hide": false, "index": 1},
                        {"num": 3, "hide": false, "index": 1},
                    ]
                }
            };

            $scope.calNum = {
                originNum: ""
            };


            var loadingData = function (id) {
                CustomEditorService.getQuestionInfoById(id)
                    .then(function (rtnData) {
                        if (!rtnData) {
                            $scope.errorModel.errorText = $filter('translate')('count.unvalidno');
                        } else {
                            if (rtnData.skin.code != '') {
                                angular.extend($scope.model,$scope.decodeOrder(rtnData));
                                $scope.calNum =  $scope.model.prompt ;
                                $scope.calNum.screen = "";

                                $scope.calNum.screen += tempF($scope.calNum.number_first.items ) ;
                                $scope.calNum.screen +=  $scope.calNum.operator.operator ;
                                $scope.calNum.screen += tempF($scope.calNum.number_second.items ) ;
                                $scope.count.inputValue  =   $scope.calNum.screen;

                                $scope.calNum.originNum = $scope.calNum.screen;
                            } else {
                                $scope.model.id = rtnData.id;
                            }
                            $scope.errorModel.errorText = "";
                            skin_service.set_skin_by_code($scope.model.skin.code, "v1");
                        }
                    }, function () {
                        $scope.errorModel.errorText = $filter('translate')('count.get_title_error');
                    })
            };
            //入口 ,初始化数据 ， 皮肤
            if (!$stateParams.id) {
                skin_service.set_skin_by_code($scope.model.skin.code, "v1");
            } else {
                loadingData($stateParams.id);
            }
            $scope.$on('changgedSkin', function () {
                $rootScope.scaleHtml();
            });

            //下一步
            $scope.nextStep = function (input) {
                //
                var reg = /[+×÷-]/;
                var n = input.search(reg);
                //竖式验证start
                if (n === -1 || input.length - 1 <= n) {
                    //	$scope.count.calError = true;
                    $scope.errorModel.errorText = "输入的算式不正确哦，正确格式如：21+24 ，最多支持五位数的加减乘除运算";
                    return;
                }
                var firstNum, secondNum, resultNum;
                //第一个数字
                firstNum = input.substring(0, n);
                //第二个数字
                secondNum = input.substring(n + 1, input.length);
                if (firstNum.length > 5 || secondNum.length > 5) {

                    //$scope.count.calError = true;
                    $scope.errorModel.errorText = "输入的算式不正确哦，正确格式如：21+24 ，最多支持五位数的加减乘除运算";
                    return;
                }
                //计算符号
                var operator = input.substring(n, n + 1);
                //计算结果
                resultNum = getResult(firstNum, secondNum, operator).toString();
                if (resultNum < 0) {

                    $scope.errorModel.errorText = "计算结果为负数，小学数学题无负数";
                    return;
                    $scope.calNum.number_result.symbol.symbol = "-";
                    resultNum = -resultNum;
                }
                if (operator === "÷" && parseInt(resultNum) === 0) {
                    $scope.errorModel.errorText = '被除数必须大于除数了';
                    return false;
                }
                //竖式验证end
                if (input && $scope.calNum.originNum === input) {

                } else {
                    $scope.calNum = {
                        "number_first": {		// 计算数
                            "number": "",		// 完整计算数字
                            "symbol": {"symbol": "+", "hide": false},	//正负
                            "items": []
                        },
                        "number_second": {		// 计算数

                            "number": "",
                            "symbol": {"symbol": "+", "hide": false},
                            "items": []
                        },
                        "number_result": {  		// 结果

                            "number": "",
                            "symbol": {"symbol": "+", "hide": false},
                            "items": []
                        },

                        operator: {"operator": "", "hide": false},
                        procedure: []

                    };
                    //计算符号
                    $scope.calNum.operator.operator = operator;
                    var numUtil = function (strNum, numArr) {
                        for (var i = 0, l = strNum.length; i < l; i++) {
                            var tempNum = {index: l - 1 - i, num: strNum.charAt(i), "hide": false};
                            numArr.push(tempNum);
                        }
                    };

                    //如果乘法 如 8*1001 要转化成 1001*8
                    if (operator === "×" && firstNum.length < secondNum.length) {
                        var temp = firstNum;
                        firstNum = secondNum;
                        secondNum = temp;
                    }
                    //第一个数字处理
                    $scope.calNum.number_first.number = firstNum;
                    numUtil(firstNum, $scope.calNum.number_first.items);

                    //第二个数字处理
                    $scope.calNum.number_second.number = secondNum;
                    numUtil(secondNum, $scope.calNum.number_second.items);


                    $scope.calNum.number_result.number = resultNum;

                    numUtil(resultNum + "", $scope.calNum.number_result.items);

//	                var panelWidth =  resultNum.length*50 + 150 ;
//	                $scope.count.countTranslate.panelWidth = panelWidth>550? 550:panelWidth ; 
//        			

                    $scope.calNum.originNum = input;  //
                    if (operator !== "÷") {
                        var n1 = firstNum.length - secondNum.length;
                        var n2 = resultNum.length - secondNum.length;
                        if (n1 < n2) {
                            n1 = n2;
                        }
                        if (n1 > 0) {
                            $scope.calNum.number_second.offset = n1;
                        }
                    }
                    var tempn;
                    //如果是乘除法 要显示过程，
                    if (operator === "×") {
                        for (var i = secondNum.length - 1, j = 0; i >= 0; i--) {
                            tempn = parseInt(secondNum[i]) * parseInt(firstNum);
                            if (tempn === 0) {
                                continue;
                            }
                            $scope.calNum.procedure[j] = {}
                            $scope.calNum.procedure[j].items = [];
                            numUtil(tempn + '', $scope.calNum.procedure[j].items);
                            $scope.calNum.procedure[j].number = tempn;
                            $scope.calNum.procedure[j].offset = secondNum.length - i - 1;
                            j++;
                        }
                        if ($scope.calNum.procedure.length == 1) {
                            delete $scope.calNum.procedure;
                            $scope.calNum.procedure = [];
                        }
                        //console.table($scope.calNum.procedure);
                    } else if (operator === "÷") {
                        var tempr = parseInt(firstNum);
                        var fl = firstNum.toString().length;
                        var powArr = [];
                        var mark = 0;
                        for (var i = 0; i < 10; i++) {
                            powArr.push(Math.pow(10, i));
                        }
                        if (resultNum.length > 0) {
                            for (var i = 0, j = 0, l = resultNum.length; i < l; i++) {
                                tempn = parseInt(resultNum[i]) * parseInt(secondNum);
                                var tempOffset = l - i - 1;
                                if (tempn === 0) {
                                    continue;
                                }
                                mark = i;
                                if (i == 0) {

                                } else {

                                    var temps = tempr.toString();
                                    $scope.calNum.procedure[j] = {}
                                    $scope.calNum.procedure[j].items = [];
                                    $scope.calNum.procedure[j].number = parseInt(temps.substring(0, temps.length - (tempOffset)));

                                    numUtil($scope.calNum.procedure[j].number + '', $scope.calNum.procedure[j].items);
                                    $scope.calNum.procedure[j].offset = fl - tempOffset - $scope.calNum.procedure[j].items.length;
                                    $scope.calNum.procedure[j].tempOffset = tempOffset;
                                    j++;
                                }

                                tempr = tempr - tempn * powArr[tempOffset];
                                $scope.calNum.procedure[j] = {}
                                $scope.calNum.procedure[j].items = [];
                                numUtil(tempn + '', $scope.calNum.procedure[j].items);
                                $scope.calNum.procedure[j].number = tempn;
                                $scope.calNum.procedure[j].offset = fl - tempOffset - $scope.calNum.procedure[j].items.length;
                                $scope.calNum.procedure[j].tempOffset = tempOffset;
                                j++;

                            }
                        }
                        var remainder = parseInt(firstNum) % parseInt(secondNum);
                        var tempo = {};
                        tempo.items = [];
                        numUtil(remainder + '', tempo.items);
                        tempo.number = remainder;
                        if (remainder == 0) {
                            tempo.offset = fl - (resultNum.length - mark + 1 - tempo.items.length );
                        } else {
                            tempo.offset = fl - tempo.items.length;
                        }
                        //$scope.calNum.procedure.push(tempo) ;
                        $scope.calNum.remainder = tempo;

                    }

                    //console.log( $scope.calNum ) ;

                }


                $scope.count.flag = false;

            };

//            $scope.$watch('e.calError',function(newValue,oldValue){
//            	console.log('e.calError',newValue,oldValue);
//            },true);

            $scope.previousStep = function (input) {

                $scope.count.flag = true;

            }
            $scope.validPostData = function () {
                var modelData = $scope.model;

                if ($.trim(modelData.title) == '') {
                    $scope.errorModel.errorText = $filter('translate')('count.notnull.title');
                    return false;
                }
                if ($scope.count.flag === true) {
                    $scope.errorModel.errorText = $filter('translate')('count.next.step');
                    return false;
                }

                var allItems = [].concat($scope.calNum.number_first.items).concat($scope.calNum.number_second.items).concat($scope.calNum.number_result.items);
                for (var i = 0, l = $scope.calNum.procedure.length; i < l; i++) {
                    allItems = allItems.concat($scope.calNum.procedure[i].items);
                }
                if ($scope.calNum.operator.operator === '÷') {
                    allItems = allItems.concat($scope.calNum.remainder.items);
                }
                var flag = false;
                for (var i = 0, l = allItems.length; i < l; i++) {
                    if (allItems[i].hide === true) {
                        flag = true;
                        break;
                    }
                }
                if (flag === false) {
                    $scope.errorModel.errorText = $filter('translate')('count.no_content');
                    return false;
                }


                return true;
            }
            $scope.encodeOrder = function (model) {
                var newModel = angular.copy(model);
                //newModel.title = window.customHtmlEncode(newModel.title );
                newModel.prompt = $scope.calNum;
                newModel.originNum = '';
//                newModel.prompt = {
//        		   "number_first" : $scope.calNum.firstItems,
//        		   "number_second": $scope.calNum.secondItems,
//        		   "number_result": $scope.calNum.resultItems,
//        		   "operator" :  	{hide:false,operator:$scope.calNum.operator.operator}
//                }
                if (newModel.prompt.operator.operator === '×') {
                    newModel.prompt.operator.operator = '*';
                } else if (newModel.prompt.operator.operator === '÷') {
                    newModel.prompt.operator.operator = '/';
                }

                return newModel;
            }
            $scope.decodeOrder = function (model) {

                var newModel = angular.copy(model);
                //newModel.title = window.customHtmlDecode(newModel.title );

                if (newModel.prompt.operator.operator === '*') {
                    newModel.prompt.operator.operator = '×';
                } else if (newModel.prompt.operator.operator === '/') {
                    newModel.prompt.operator.operator = '÷';
                }
                $scope.calNum = newModel.prompt;
                var procedure = $scope.calNum.procedure;
                var fl = $scope.calNum.number_first.number.toString().length;
                for (var i = 0, l = procedure.length; i < l; i++) {
                    procedure[i].tempOffset = fl - procedure[i].items.length - procedure[i].offset;
                }
                return newModel;
            };
            function tempF(items) {
                var arr = [];
                for (var i = 0, l = items.length; i < l; i++) {
                    arr[i] = items[i].num;
                }
                return arr.join('');
            }
            var getResult = function (n1, n2, oper) {
                n1 = parseInt(n1);
                n2 = parseInt(n2);
                if (oper === '+') {
                    return n1 + n2;
                } else if (oper === '-') {
                    return n1 - n2;
                } else if (oper === '×') {
                    return n1 * n2;
                } else if (oper === '÷') {
                    return Math.floor(n1 / n2);
                }
            }


        }
    ]);

});
