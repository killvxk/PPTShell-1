/**
 *
 */
define(['app'  , 'fraction/directive/fraction.directive'
], function (app) {
    'use strict';
    app.controller('fraction_ctrl', [
        '$scope','skin_service','$stateParams','CustomEditorService','UserDataService','$rootScope','$filter',"$timeout",
        function ($scope,skin_service,$stateParams,CustomEditorService,UserDataService,$rootScope,$filter,$timeout) {
            
        	$scope.fractions ={
            		placeholder:{title : "请输入标题"},
            		inputValue:'',
            		flag:true,
            		calError : false

            }

            $scope.model = {
            	"id":"",
                "title":"",         //标题
                "skin": {
                    code: "wood",
                    css_url: "",
                    name: $filter('translate')('linkup.muwen'),
                    package_url: ""
                },
                "timer":{
                    "timer_type":"sequence",  //计时器类型: ["sequence", "countdown"]
                    "time_minute":"0",    //倒计时初始设置-分钟，timer_type="countdown"时有效
                    "time_second":"0"     //倒计时初始设置-秒，timer_type="countdown"时有效
                },
            	"prompt":{
            		first:{},
            		second:{},
            		operator:{},
            		procedure:[],
            		result:{denominator:{hide:false},numerator:{hide:false}},
            		allow_lcm:true
            	}
            };
        
 
            
            
            var loadingData = function(id){
                CustomEditorService.getQuestionInfoById(id)
                    .then(function(rtnData){
                        if(!rtnData){
                            $scope.errorModel.errorText = $filter('translate')('fraction.unvalidno');
                        }else{
                            if(rtnData.skin.code!=''){


                                angular.extend($scope.model,$scope.decodeOrder(rtnData));
                              
                                $scope.model.prompt.screen = "";
                                
                                $scope.model.prompt.screen += $scope.model.prompt.first.numerator +"\/"+$scope.model.prompt.first.denominator; 
                                $scope.model.prompt.screen += $scope.model.prompt.operator ; 
                                $scope.model.prompt.screen += $scope.model.prompt.second.numerator +"\/"+$scope.model.prompt.second.denominator;
                                $scope.fractions.inputValue  =   $scope.model.prompt.screen 
                                $scope.fractions.originNum = $scope.model.prompt.screen;
                                
                            }else{
                                $scope.model.id=rtnData.id;
                            }

                            skin_service.set_skin_by_code($scope.model.skin.code,"v1");
                        }
                    },function(){
                        $scope.errorModel.errorText = $filter('translate')('fraction.get_title_error');
                    })
            }
            //入口 ,初始化数据 ， 皮肤
            if(!$stateParams.id){
                skin_service.set_skin_by_code($scope.model.skin.code,"v1");
            }else{
                loadingData($stateParams.id);
            }



            $scope.$on('changgedSkin',function(){
                $rootScope.scaleHtml();
            })
            
            $scope.prompt  = $scope.model.prompt ; 
            //下一步
            $scope.nextStep = function(input){
            	
            	var prompt  = $scope.model.prompt ;
            	if( /^\d{1,6}\/[1-9]\d{0,5}[+-]\d{1,6}\/[1-9]\d{0,5}$/.test(input) ===false ){
                	$scope.errorModel.errorText  = "输入的分式加减不正确哦，正确格式如：1/2+1/3，最多支持六位数字的分数计算。";
                	return; 
                }
            	//
            	if( input &&  $scope.fractions.originNum === input ){
            		$scope.fractions.flag=false; 
            		return ; 
            	}
                var n = input.search(/[+-]/) ; 
                //计算符号
                var operator = input.substring(n,n+1);
                
                var num1 = input.substring(0,n);
                var num2 = input.substring(n+1);
                //根据分式 "1/2" 构造对象{numerator:1,denominator:2}
                function getFractions(num){
                	var index = num.search(/\//) ; 
                    var n1 = parseInt(num.substring(0,index));
                    var n2 = parseInt(num.substring(index+1));  
                    var gcdNum = gcd(n1,n2) ; 
                    return  {
                    		numerator:n1/gcdNum,
                    		denominator:n2/gcdNum
                    } ; 
                }
                //第一个分式
                prompt.first = getFractions(num1) ; 
                //第二个分式
                prompt.second = getFractions(num2) ; 
                //操作符
                prompt.operator = operator ; 

                //计算结果
                if( operator === "+" ){
                	 prompt.result.numerator.num =  prompt.first.numerator*prompt.second.denominator+prompt.second.numerator*prompt.first.denominator;
                }else {
                	 prompt.result.numerator.num =  prompt.first.numerator*prompt.second.denominator - prompt.second.numerator*prompt.first.denominator;
                }
                if(prompt.result.numerator.num<0){
                	prompt.result.numerator.num = -prompt.result.numerator.num ; 
                	prompt.result.symbol = '-';
                }else if( prompt.result.numerator.num === 0 ){
                	$scope.errorModel.errorText = '请输入两个值不相等的分式';
                	return ; 
                }
                
                prompt.result.denominator.num = prompt.first.denominator*prompt.second.denominator ; 
                
                //最简分数的计算结构		
                prompt.result = getResultByLcm( prompt.result) ; 
                
//                if( prompt.result.denominator.num > 999999 ){
//                	$scope.errorModel.errorText  = "输入的分式计算结果分母超过六位数，最多支持六位数字的分数计算，正确格式如：1/2+1/3。";
//                	return; 
//                }
                //只允许最小公倍数
                prompt.allow_lcm = true ; 
          
                //最小公倍数
                var lcmNum =  prompt.first.denominator*prompt.second.denominator / gcd( prompt.first.denominator, prompt.second.denominator ) ; 
                prompt.lcm = lcmNum ;
                //计算过程的数据结构
                prompt.procedure = [
                   {
                       numerator : { // 分子
                           first    : {num: prompt.first.numerator,hide : false},      
                           second   : {num: lcmNum / prompt.first.denominator,hide: false},    
                       },
                       denominator:{ // 分母
                           first    : {num: prompt.first.denominator,hide : false},
                           second   : {num: lcmNum / prompt.first.denominator,hide : false},
                       }
                   },                 
                   {
                       numerator : { // 分子
                           first    : {num: prompt.second.numerator,hide : false},    
                           second   : {num: lcmNum / prompt.second.denominator,hide: false},   
                         
                       },
                       denominator:{ // 分母
                           first    : {num: prompt.second.denominator,hide : false},
                           second   : {num: lcmNum / prompt.second.denominator,hide : false},
                       }
                   }
                ] ; 
                
                //console.log(prompt);
                //最简分数by最小公倍数
                function getResultByLcm(result){
                	var gNum = gcd(result.numerator.num,result.denominator.num) ; 
                	result.numerator.num = result.numerator.num/gNum ; 
                	result.denominator.num =result.denominator.num/gNum ; 
                	return result ; 
                
                }
                $scope.fractions.originNum = input ; 
                $scope.fractions.flag=false;

            };
            
//            $scope.$watch('e.calError',function(newValue,oldValue){
//            	console.log('e.calError',newValue,oldValue);
//            },true);
            $scope.allowLcm = function(){
            	var prompt = $scope.model.prompt ; 

            	if(prompt.allow_lcm === true){
            		prompt.procedure[0].numerator.second.num =  prompt.second.denominator ; 
            		prompt.procedure[0].denominator.second.num = prompt.second.denominator ; 
            		prompt.procedure[1].numerator.second.num =  prompt.first.denominator ; 
            		prompt.procedure[1].denominator.second.num = prompt.first.denominator ;
            	}else{
            		prompt.procedure[0].numerator.second.num =  prompt.lcm / prompt.first.denominator ; 
            		prompt.procedure[0].denominator.second.num = prompt.lcm / prompt.first.denominator ; 
            		prompt.procedure[1].numerator.second.num =  prompt.lcm / prompt.second.denominator; 
            		prompt.procedure[1].denominator.second.num = prompt.lcm / prompt.second.denominator;  

            	}
                prompt.allow_lcm = !prompt.allow_lcm;
                window.event.preventDefault();

            }
            
            $scope.previousStep = function(){

                $scope.fractions.flag=true;

            }
            $scope.validPostData = function(){

                var modelData = $scope.model;
                if($.trim(modelData.title)==''){
                  $scope.errorModel.errorText = $filter('translate')('fraction.notnull.title');
                  return false ; 
                }
            	if( $scope.fractions.flag===true ){
           		 $scope.errorModel.errorText = '提交前请先进入下一步' ; 
           		 return false; 
            	}
                var  allItems = [];
                var i = 2 ; 
                while(i--){
                	allItems = allItems.concat( modelData.prompt.procedure[i].numerator.first) ; 
                	allItems = allItems.concat( modelData.prompt.procedure[i].numerator.second) ;
                	allItems = allItems.concat( modelData.prompt.procedure[i].denominator.first) ; 
                	allItems = allItems.concat( modelData.prompt.procedure[i].denominator.second) ;
                }
               
                allItems = allItems.concat( modelData.prompt.result.numerator) ; 
                allItems = allItems.concat( modelData.prompt.result.denominator) ;
                


                var flag = false  ; 
                for(var i = 0 ,l =  allItems.length ; i<l ; i++ ){
                    if( allItems[i].hide === true ){
                    	flag  = true ; 
                    	break ; 
                    }
                }
                if( flag === false ){
                    $scope.errorModel.errorText = $filter('translate')('fraction.no_content');
                    return false ; 
                }

                
                return true  ;
            }
            $scope.encodeOrder = function(model){
                var newModel = angular.copy(model);
               // newModel.title = window.customHtmlEncode(newModel.title )
                return newModel;
            }
            $scope.decodeOrder = function(model){
            	
                var newModel = angular.copy(model);
               // newModel.title = window.customHtmlDecode(newModel.title );
                return newModel;
                
            }
            
            //求最大公约数
            function gcd( a, b ){
            	if( a<b ) {
            		var temp = a ; a = b ; b = temp ; 
            	}
            	while( a-b > 0 ){
            		a = a - b ; 
                	if( a<b ) {
                		var temp = a ; a = b ; b = temp ; 
                	}
            	}
            	return a ; 
            }

        }
    ]);

});
