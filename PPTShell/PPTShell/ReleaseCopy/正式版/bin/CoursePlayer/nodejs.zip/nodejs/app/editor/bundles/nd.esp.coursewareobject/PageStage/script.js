/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
    'jlang',
    'jquery',
    'prompter',
    'espService',
    'espModel',
    './ModuleEditorFactory',
    'css!./style.css',
],function(
    jlang,
    $,
    prompter,
    espService,
    espModel,
    ModuleEditorFactory
){
    var templates = {
        page: '<div class="slides-coursewareobject-page-stage"></div>',
        moduleWrap: '<div class="_module-wrap" tabindex="0"></div>',
        moduleEditor: '<div class="_module-editor"></div>'
    };

    function PageStage(coursewareobjectId, pageId, wrapEl, config){
        var eventManager = jlang.EventManager(['beforeSave']);

        var apiProxy = $.extend({
            selectResource: function (options) {
                return $.Deferred().reject('不支持资源选择');
            }
        }, config && config.apiProxy)
        config = $.extend({}, config);

        var page,
            pageEl = $(templates.page).appendTo(wrapEl),
            moduleWraps = [];

        var coursewareobjectRepository = espModel.repository.coursewareobject(coursewareobjectId);
        coursewareobjectRepository.getPage(pageId).then(function (p) {
            page = p;
            var modules = page.modules;
            for(var i=0;i<modules.length;i++){
                var module = modules[i];
                renderModule(module);
            }
        },prompter.errorIf()).always(prompter.wait('正在加载页面内容'));

        function renderModule(module){
            var moduleWrap = new ModuleWrap(module);
            moduleWraps.push(moduleWrap);
        }

        function removeSelectedModule(){

        }

        function getModuleWraps(filter){
            var results = [];
            for(var i=0;i<moduleWraps.length;i++){
                var moduleWrap = moduleWraps[i];
                if($.isFunction(filter) && filter(moduleWrap) === false){
                    continue;
                }
                results.push(moduleWrap);
            }
            return results;
        }
        var moduleWrapFilters = {
            id: function(id){
                return function (moduleWrap) {
                    return moduleWrap.module.id == id;
                };
            },
            moduleId: function(moduleId){
                return function (moduleWrap) {
                    return moduleWrap.module.moduleId == moduleId;
                };
            }
        };
        function getModuleWrapById(id){
            return getModuleWraps(moduleWrapFilters.id(id))[0];
        }
        function getModuleInterfaces(name){
            var interfaces = [];
            var filter = $.noop;
            if(name.charAt(0) == '.'){
                filter = moduleWrapFilters.moduleId(name.substring(1));
                name = '.';
            }else if(name.charAt(0) == '#'){
                filter = moduleWrapFilters.id(name.substring(1));
                name = '.';
            }
            var mws = getModuleWraps(filter);
            for(var i=0;i<mws.length;i++){
                var editor = mws[i].editor;
                interface = editor.getInterface().as(name);
                interface && interfaces.push(interface);
            }
            return ModuleEditorFactory.compositeInterface(name, interfaces);
        }

        this.save = function(){
            if(!page) return $.Deferred().reject('页面尚未加载完成');
            var results = [];
            for(var i=0;i<moduleWraps.length;i++){
                var editor = moduleWraps[i].editor;
                editor && results.push(editor.save());
            }
            var promises = [];
            for(var i=0;i<results.length;i++){
                var result = results[i];
                if(result === false || typeof result === 'string'){
                    promises.push($.Deferred().reject(result));
                }else if(result && $.isFunction(result.then)){
                    promises.push(result);
                }
            }
            return $.when.apply(null,promises).then(function(){
                return coursewareobjectRepository.updatePage(page);
            });
        };

        var coursewareobjecRepositorytDecorator = {
            getResourceUrl: $.proxy(coursewareobjectRepository, 'getResourceUrl'),
            getResourceUploadUrl: $.proxy(coursewareobjectRepository, 'getResourceUploadUrl'),
        };
        /***************************** Api *************************************/
        this.on = $.proxy(eventManager, 'on');
        this.off = $.proxy(eventManager, 'off');
        this.getModuleWrapById = getModuleWrapById;
        this.getModuleInterfaces = getModuleInterfaces;
        Object.defineProperties(this, {
            'repository': {
                get: function () {
                    return coursewareobjecRepositorytDecorator;
                }
            },
            'coursewareobjectId': {
                get: function () {
                    return coursewareobjectId;
                }
            },
            'pageId': {
                get: function () {
                    return pageId;
                }
            }
        });

        var matrixReg = /matrix\((\d+(\.\d+)?), (\d+(\.\d+)?), (\d+(\.\d+)?), (\d+(\.\d+)?), (\d+(\.\d+)?), (\d+(\.\d+)?)\)/;
        this.transformScale = function (value, xy) {
            if(!value || !(value = parseFloat(value))) return 0;
            var scale = 1;
            pageEl.parents().each(function (i) {
                var transform = $(this).css('transform');
                var match = transform && transform !== 'none' && transform.match(matrixReg);
                if(match){
                    var scaleX = parseFloat(match[1]) || 1, scaleY = parseFloat(match[7]) || 1;
                    scale *= xy ? scaleX : scaleY;
                }
            });
            return value / scale;
        };
        this.transformScaleX = function (value) {
            return this.transformScale(value, 1);
        };
        this.transformScaleY = function (value) {
            return this.transformScale(value, 0);
        };

        this.selectResource = function (options) {
            return apiProxy.selectResource.apply(config, [options]);
        };

        var stageCtrl = this;
        /***************************** ModuleWrap *************************************/
        function ModuleWrap(module, isNewly){
            this._module = module;
            this._moduleDecorator = new ModuleDecorator(module);
            this._wrapEl = $(templates.moduleWrap).appendTo(pageEl);
            var className = 'slides-module-' + (module.editorId && module.editorId.toLowerCase() || '$none$');
            this._editorEl = $(templates.moduleEditor).appendTo(this._wrapEl).addClass(className);
            jlang.asEventManager(this, ['resize','move','rotate','show','hide','invalid','valid']);
            this._invalid = false;

            this._resetLayout = function () {
                var position = this._module.position,
                    size = this._module.size;
                this._wrapEl.css({
                    top: asCssSize(position.top),
                    left: asCssSize(position.left),
                    width: asCssSize(size.width),
                    height: asCssSize(size.height)
                });
                this._wrapEl.css(this._module.style);
                this._wrapEl.toggle(this._module.visible);
            };
            this._resetLayout();

            this._switchPresenter = function(){
                if(this._editor){
                    this._editor.__presenterId && this._editorEl.removeClass(className + '-' + this._editor.__presenterId.toLowerCase());
                    this._editor.clean();
                }
                this._module.presenterId && this._editorEl.addClass(className + '-' + this._module.presenterId.toLowerCase());
                $(this._editorEl).empty();
                this._module.editorId && ModuleEditorFactory.create(this._module.editorId).then($.proxy(function(presenterId, editor){
                    try{
                        editor.init(this._moduleDecorator,stageCtrl);
                        if(isNewly === true){
                            isNewly = false;
                            editor.initDefault(this);
                        }
                        var templatePromise = editor.getTemplate() ?
                            $.when(editor.getTemplate()) :
                            (editor.getTemplateUrl() ? this._module.editorRepository.getResource(editor.getTemplateUrl()) : $.when(''));
                        templatePromise.done($.proxy(function (template) {
                            if(template){
                                this._editorEl.html(template);
                            }
                        }, this)).fail($.proxy(function () {
                            console.info('未发现模板文件：' + this._module.editorRepository.getResourceUrl(editor.getTemplateUrl()));
                        }, this)).always($.proxy(function () {
                            try{
                                editor.render(this);
                            }catch(e){
                                var errorMessage = '渲染 Editor[' + this._module.editorId + '] 发生异常';
                                console.error(errorMessage, e);
                                console.log(this);
                                this.setInvalid(errorMessage, e);
                            }
                        }, this));
                    }catch(e){
                        var errorMessage = '初始化 Editor[' + this._module.editorId + '] 发生异常';
                        console.error(errorMessage, e);
                        this.setInvalid(errorMessage, e);
                    }
                    editor.__presenterId = this._module.presenterId;
                    this._editor = editor;
                },this,this._module.presenterId));
            };
            this._switchPresenter();

            this._wrapEl.on('focusin', $.proxy(function(){
                this.trigger('startEdit');
            },this));
            this._wrapEl.on('focusout', $.proxy(function(){
                this.trigger('endEdit');
            },this));
        }
        Object.defineProperties(ModuleWrap.prototype, {
            'presenterId': {
                get: function () {
                    return this._module.presenterId;
                },
                set: function (val) {
                    if(val === this._module.presenterId){
                        return;
                    }
                    this._module.presenterId = val;
                    this._switchPresenter();
                }
            },
            'position': {
                get: function () {
                    return this._module.position;
                },
                set: function (val) {
                    this._module.position = val;
                    val = this._module.position;
                    this._wrapEl.css({
                        top: asCssSize(val.top),
                        left: asCssSize(val.left)
                    });
                    this.trigger('move', val.top, val.left);
                }
            },
            'size': {
                get: function () {
                    return this._module.size;
                },
                set: function (val) {
                    this._module.size = val;
                    val = this._module.size;
                    this._wrapEl.css({
                        width: asCssSize(val.width),
                        height: asCssSize(val.height)
                    });
                    this.trigger('resize', val.width, val.height);
                }
            },
            'rotate': {
                get: function () {
                    return this._module.rotate;
                },
                set: function (val) {
                    this._module.rotate = val;
                    val = this._module.rotate;
                    this._wrapEl.css({
                        transform: 'rotate(' + val + ')'
                    });
                    this.trigger('rotate', val);
                }
            },
            'visible': {
                get: function () {
                    return this._module.visible;
                },
                set: function (val) {
                    this._module.visible = val;
                    val = this._module.visible;
                    this._wrapEl.toggle(val);
                    this.trigger(val ? 'show' : 'hide');
                }
            },
            'locked': {
                get: function () {
                    return this._module.locked;
                },
                set: function (val) {
                    this._module.locked = val;
                }
            },
            'style': {
                get: function () {
                    return this._module.style;
                },
                set: function (val) {
                    this._module.style = val;
                }
            },
            'element': {
                get: function () {
                    return this._editorEl[0];
                }
            },
            'editor': {
                get: function () {
                    return this._editor;
                }
            },
            'module': {
                get: function () {
                    return this._moduleDecorator;
                }
            },
            'invalid': {
                get: function () {
                    return this._invalid;
                }
            },
        });
        ModuleWrap.prototype.getElement = function () {
            return this._editorEl[0];
        };
        ModuleWrap.prototype.setInvalid = function (message, cause) {
            this._invalid = true;
            this._invalidMessage = message;
            this._invalidCause = cause;
            $(this._editorEl).text(message);
            this.trigger('invalid', message, cause);
        };
        ModuleWrap.prototype.cleanInvalid = function () {
            this._invalid = false;
            delete this._invalidMessage;
            delete this._invalidCause;
            this.trigger('valid');
        };
        /***************************** ModuleDecorator *************************************/
        function ModuleDecorator(module){
            this._module = module;
            $.each(this._module.properties, $.proxy(function (i, prop) {
                Object.defineProperty(this, '$' + prop.name, {
                    get: function () {
                        return prop.value;
                    },
                    set: function (val) {
                        prop.value = val;
                    }
                });
            }, this));
        }
        Object.defineProperties(ModuleDecorator.prototype, {
            'id': {
                get: function () {
                    return this._module.id;
                }
            },
            'moduleId': {
                get: function () {
                    return this._module.moduleId;
                }
            },
            'editorId': {
                get: function () {
                    return this._module.editorId;
                }
            },
            'editorRepository': {
                get: function () {
                    return this._module.editorRepository;
                }
            }
        });
        ModuleDecorator.prototype.getProperty = function (name) {
            return this._module.getProperty(name);
        };
        ModuleDecorator.prototype.getPropertyValue = function (name) {
            return this._module.getPropertyValue(name);
        };
        ModuleDecorator.prototype.setPropertyValue = function (name, value) {
            this._module.setPropertyValue(name, value);
        };

        function asCssSize(value){
            if(value && (value=value+'') && value.indexOf('px')==-1 && value.indexOf('%')==-1){
                return value + 'px';
            }
            return value;
        }
        function convterToCssLayout(layout){
            var result = {};
            for(var key in layout){
                var cssSize = layout[key];
                if(cssSize){
                    if(cssSize.indexOf('px')==-1 && cssSize.indexOf('%')==-1){
                        cssSize += 'px';
                    }
                    result[key] = cssSize;
                }
            }
            return result;
        }
    }
    return PageStage;
});