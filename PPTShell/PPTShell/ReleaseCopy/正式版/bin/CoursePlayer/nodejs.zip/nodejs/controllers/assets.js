var http = require('http');
var util = require('util');
var uuid = require('node-uuid');
var fs = require('fs');
var Path = require('path');
var sizeOf = require('image-size');
var pathHelper = require('./question_tools/question_path_helper');
var Q = require("q");
var PathManagerCreator = require('./question_tools/PathManager');
var getQuestionBase = function(identifier){
	return "edu/esp/questions";
}
function getQuestionPackagePath(identifier,req){
	return pathHelper.getQuestionRefPackagePath(identifier,req);
}

var QuestionUtils = require("./question_tools/QuestionUtils");
var checkDir = function(filepath, callback){
    return QuestionUtils.checkDir(filepath,callback);
}
var mkdir = function(filepath, callback){
    return QuestionUtils.mkdir(filepath,callback);
}

var convertBaiduImageToLocalImage = function(pathManager,baiduItems){
    var items = [];
    var baseid ="bd_"+new Date().getTime();
    for(var i=0;i<baiduItems.length;i++){
        var id = baseid+""+i;
        var item = baiduItems[i];        
        var filepath = "/resources/"+id+"."+item.Pictype;
        var url = pathManager.toProxy(filepath,item.ObjUrl,'');
        items.push({
            identifier:id,
            title:item.Desc,
            tech_info:{
                href:{
                    format:'',
                    location:url,
                    requirements:[{
                        type:'QUOTA',
                        name:'resolution',
                        value:item.Width+'*'+item.Height
                    }]
                }
            },
            preview:{
                 '240':"/v1.3/assets/proxy2?url="+encodeURIComponent(item.ObjUrl)
            },
            type:'$RA0101'
        });
    };
    return items;
};


var getLocalFileList = function(pathManager,assettype){
    var folder = pathManager.getFilePath("resources");
    var assetBasePath = pathManager.getRefPath("resources");
    var types = {
        jpg:{code:'$RA0101',minetype:''},
        jpeg:{code:'$RA0101',minetype:''},
        gif:{code:'$RA0101',minetype:''},
        png:{code:'$RA0101',minetype:''},
        bmp:{code:'$RA0101',minetype:''},
        mp4:{code:'$RA0103',minetype:''},
        mp3:{code:'$RA0102',minetype:''}
    };
    var defer = Q.defer();
    mkdir(folder,function(){
        var items = [];
        var files = fs.readdirSync(folder);
        for(var i=0;i<files.length;i++){
            if(files[i].indexOf(".")==-1){
                continue;
            }
            var href = pathManager.getRefPath("resources/"+files[i]);
            var assetId = files[i].substring(0,files[i].lastIndexOf(".")-1);
            var suffix = files[i].substring(files[i].lastIndexOf(".")+1);
            var type = types[suffix.toLowerCase()];
            if(['audio.png','background.jpg','default_audio.png','default_video.png','image.png','papertype_1.png'
                    ,'papertype_2.png','papertype_3.png','papertype_4.png','papertype_5.png','video.png'].indexOf(files[i])!=-1){
                continue;
            }
            if(files[i].indexOf("sf-")==0){
                continue;
            }
            if(type&&type.code==assettype){
                var data = {
                    identifier: assetId,
                    title: assetId+"."+suffix,
                    tech_info : {
                        href : {
                            "format" : type.mimetype,
                            "location":href,
                            requirements:[{
                                type:"QUOTA",
                                name:"resolution"
                            }]
                        }
                    },
                    type:type.code
                };
                if(type.code == '$RA0101'){
                    var dimensions =  sizeOf(pathManager.getFilePath("resources/"+files[i]));
                    data.tech_info.href.requirements[0].value =dimensions.width+"*"+dimensions.height;
                }
                items.push(data);
            }
        }
        defer.resolve(items);
    });
    return defer.promise;
}
exports._getLocalFileList = getLocalFileList;

exports.search = function(req, res, next) {
    var id = req.query.question_id;
    var pathManager = PathManagerCreator.create(req,'',id);
	var questionBase = pathManager.extraInfoUrl();
	var coverage = req.query.coverage;
    var assettype = req.query.type;

    //个人库
	if(coverage.indexOf("User")!=-1){
        //互动习题
        if(req.query.is_interaction === QUESTION_TYPE_INTERACTION) {
            InteractionAssetsManager.searchLocalAssets(req, res, next);

            return;
        }
        getLocalFileList(pathManager,assettype).then(function(items){
            res.send({
                items:items
            });
        });
	}
    //公共库
	else if(coverage.indexOf("Org/nd")!=-1){
        var server = req.query.slideServer;
        var csserver = req.query.csserver;
        if(server&&server.indexOf("//")!=-1){
            server = server.substring(server.indexOf("//")+2);
        }
        if(server&&server.lastIndexOf("/")!=-1){
            server = server.substring(0,server.lastIndexOf("/"));
        }
        var url = "/v1.3/assets?type="+req.query.type+"&coverage=Org/nd/OWNER"
            +"&page="+(req.query.page||1)
            +"&size="+(req.query.size||24)
            +"&chapter_id="+(req.query.chapter_id||'')
            +"&words="+encodeURIComponent(req.query.words||'');
        http.get({
                host:server,
                path:url,
                headers: {                   
                }                
            },function(result){             
                var body = "";
                result.on("data", function(chunk) {
                    body = body +chunk;
                });
                result.on("end",function(){
                    try{                        
                        var response = JSON.parse(body);
                        if(response.code){                           
                            return res.status(500).send({code:response.code,message:response.message});
                        }
                        var items = response.items;
                        var baseid ="nd_"+new Date().getTime();
                        for(var i=0;i<items.length;i++){
                            var item = items[i];                            
                            var href = item.tech_info.href.location;
                            href = href.replace("${ref-path}",csserver);
                            var previews = item.preview;
                            var assetid = baseid+""+i;
                            var suffix = href.substring(href.lastIndexOf(".")+1);
                            var filepath = "/resources/"+assetid+"."+suffix;
                            if(!previews || previews.length == 0 ){
                                item.preview = {
                                    "240":href,
                                    "media":href
                                }
                            }
                            else{
                                for(var key in previews){
                                    previews[key]= previews[key].replace("${ref-path}",csserver);
                                }
                                //previews['media']=href
                            }                           
                            item.tech_info.href.location = pathManager.toProxy(filepath,href,'$RA0101');

                        }
                        return res.send(response);
                        //handle items ....
                    }
                    catch(ex){                        
                        res.status(500).send({code:'LS/JSON_PARSE_FAIL',message:'请求返回的数据格式错误。'});
                    }     
                });           
            });            
    }
    //百度图库
    else if(coverage.indexOf("Baidu/bd/")!=-1&&assettype=="$RA0101"){
        if(req.query.words==''){
            return res.send({items:[]});	
        }
        var pageNumber = (req.query.page||1) -1;
        var baiduurl = "/image_search/search/search?word="+encodeURIComponent(req.query.words||'')+"&pn="+pageNumber+"&rn="+(req.query.size||24)+"&assetType=$RA0101&ie=utf-8";        
        http.get({
                host:'apis.baidu.com',
                path:baiduurl,
                headers: {
                    apikey:'de4eb4b4a1ae4e1c529b0774f931d1f8'
                }              
            },function(result){ 
                var body = "";
                result.on("data", function(chunk) {
                    body = body +chunk;
                });
                result.on("end",function(){                   
                    var response = JSON.parse(body);
                    var code = response.status.code;
                    if(code!='0'){
                        return res.status(500).send({code:code,message:response.status.msg});                        
                    }
                    var itemCount = response.data.ReturnNumber;
                    var total = response.data.TotalNumber;
                    var items = convertBaiduImageToLocalImage(pathManager,response.data.ResultArray);
                    return res.send({
                        item_count:itemCount,
                        total_count:total,
                        items:items
                    });
                });
            });
    }
    else{
        return res.send({items:[]});	
    }
};

exports.get=function(req,res,next){
    //互动习题
    if(req.query.is_interaction === QUESTION_TYPE_INTERACTION) {
        InteractionAssetsManager.getAsset(req, res, next);
        return;
    }
    var question_id = req.query.question_id;
    var pathManager = PathManagerCreator.create(req,null,question_id);
    var filepath = req.query.filepath;
    if(filepath&&filepath.indexOf("?")!=-1){
        filepath = filepath.substring(0,filepath.indexOf("?"));
    }
	var realPath = pathManager.getFilePath(filepath);
	return res.sendFile(Path.resolve(realPath));
}
exports.check_proxy= function(pathManager,filepath,url,assetType,callback){
    handleProxyFile(pathManager,filepath,url,assetType,callback);
}
exports.proxy2=function(req,res,next){ 	
    var url = req.query.url;
    var request = http.get(url, function(response) {
        response.pipe(res); 
    }).end();
}

exports.proxy3=function(req,res,next){ 	
    var url = req.params[0];
    var base = req.params.base;
    console.log("before decode ",base);
    base = new Buffer(base, 'base64').toString('ascii')
    if(base.indexOf('?')!=-1){
    	base = base.substring(0,base.indexOf("?"));
    }
    console.log("real url ",base,url);
    res.sendFile(Path.resolve(base,url));
}



exports.proxy=function(req,res,next){
    //互动习题
    if(req.query.is_interaction === QUESTION_TYPE_INTERACTION) {
        InteractionAssetsManager.downloadAssets(req, res, next);

        return;
    }
    var questionId = req.query.question_id;
    var pathManager = PathManagerCreator.create(req,null,questionId);
	var filepath = req.query.filepath;
    var url = req.query.url;
    var assetType = req.query.assetType;
    handleProxyFile(pathManager,filepath,url,assetType,function(realPath){
         return res.sendFile(Path.resolve(realPath));
    });
}
var handleProxyFile = function(pathManager,filepath,url,assetType,callback){
    if(filepath&&filepath.indexOf("?")!=-1){
        filepath = filepath.substring(0,filepath.indexOf("?"));
    }
    var filename = filepath.substring(filepath.lastIndexOf("/")+1);
    var assetId = filename.substring(0,filename.lastIndexOf("."));
	var realPath = pathManager.getFilePath(filepath);
    if(!fs.existsSync(realPath)){
        //download file to location     
        var file = fs.createWriteStream(realPath);
        var request = http.get(url, function(response) {
            var mimetype = response.headers['content-type'];
            if(mimetype){
                mimetype = mimetype.trim();
            }            
            response.pipe(file);            
            file.on('finish', function() {            	 
                file.close(function(){                    
                    return callback(realPath);
                });
            });
        });
        request.on('error',function(err){        	
        });
        request.end();
    }
    else{
        return callback(realPath);
    }
}

function saveMetadata(pathManager,assetId,filename,mimetype,asset_type){
    var assetBasePath = pathManager.getRefPath();
    var localPath = pathManager.getFilePath();
	var folder = Path.join(localPath,"resources");
    var suffix = filename.substring(filename.lastIndexOf("."));
	var path = "/resources/"+assetId+suffix;	   
    var href = pathManager.urlJoin(assetBasePath,path);
    var data = {
        identifier: assetId,
        title: filename,
        tech_info : {
            href : {
                "format" : mimetype,
                "location":href,
                requirements:[{
                    type:"QUOTA",
                    name:"resolution"
                }]
            }
        },
        type:asset_type
    };	
    if(asset_type == '$RA0101'){
        //var dimensions =  sizeOf(file.path);
        var dimensions =  sizeOf(pathManager.getFilePath("resources/"+assetId+suffix));
        data.tech_info.href.requirements[0].value =dimensions.width+"*"+dimensions.height; 
    }   
    return data;
}

var renameFile = function(source,target){
	var defer = Q.defer();
	var readStream = fs.createReadStream(source)
	var writeStream = fs.createWriteStream(target);
	readStream.pipe(writeStream).on('finish', function(err) {		
		if(err){
			defer.reject("保存文件错误",err);
			return;
		}		
	    fs.unlinkSync(source);	    
	    defer.resolve();
	});
	return defer.promise;
}

exports.upload = function(req, res, next) {
    //互动习题
    if(req.query.is_interaction === QUESTION_TYPE_INTERACTION) {
        InteractionAssetsManager.uploadAssets(req, res, next);

        return;
    }
    var question_id = req.query.question_id;
	var file = req.file;
    var pathManager = PathManagerCreator.create(req,null,question_id);

	var type = req.query.asset_type;
	var tempId = new Date().getTime()+""+Math.floor(Math.random()*100);
	var assetBasePath = pathManager.getRefFullPath();
	var suffix = file.originalname.substring(file.originalname.lastIndexOf("."));
	var prefix = file.originalname.substring(0,file.originalname.lastIndexOf("."));	
	
	var folder = pathManager.getFilePath("resources");


	mkdir(folder,function(){
        var realpath = pathManager.getFilePath("resources/"+tempId+suffix);
        renameFile(file.path,realpath).then(function(){
			var data = saveMetadata(pathManager,tempId,file.originalname,file.mimetype,req.query.asset_type);
			res.send(data);			
		});        	
	});
	return;
}; 

/* ========================================  互动习题资源相关操作 begin... ========================================*/
var QUESTION_TYPE_INTERACTION = 'true';
var InteractionAssetsManager = {
    $ref_base: "${ref-base}",
    $ref_path: "${ref-path}",
    $interaction_base: "edu/esp/interaction",
    $ref_assets_path: "/_ref/edu/esp/assets/",
    $assets_path: "/edu/esp/assets/",

    getInteractionPackagePath: function (id, req) {
        var base = req.param('question_base');

        if (!base) {
            base = __dirname + "/../app/userdatas/edu/esp/interaction/";
        }
        if (base.lastIndexOf("/") != base.length - 1) {
            base = base + "/";
        }

        return base + id + ".pkg";
    },
    resolveFilePath: function (filepath, question_id, req) {
        var _self = this;

        filepath = replacer.toRefpath(filepath);
        if (filepath.indexOf(refbase) != -1) {
            filepath = filepath.substring(refbase.length);
        }
        var result = _self.$interaction_base + filepath;
        return result;
    },
    mkdirsSync: function (fullDir, mode) {
        if (!fs.existsSync(fullDir)) {
            var parentDir;
            fullDir.split('/').forEach(function (subDir) {
                if (parentDir) {
                    parentDir = parentDir + '/' + subDir;
                } else {
                    parentDir = subDir;
                }

                if (!fs.existsSync(parentDir)) {
                    if (!fs.mkdirSync(parentDir, mode)) {

                        return false;
                    }
                }
            });
        }

        return true;
    },
    saveMetadata: function (assetId, questionId, filename, mimetype, asset_type, req) {
        var _self = this;

        var localPath = _self.getInteractionPackagePath(questionId, req);
        var folder = localPath + _self.$ref_assets_path;
        var suffix = filename.substring(filename.lastIndexOf("."));
        var path = _self.$ref_assets_path + assetId + suffix;
        var href = _self.$ref_base + _self.$ref_assets_path + assetId + suffix;
        var data = {
            identifier: assetId,
            title: filename,
            tech_info: {
                href: {
                    "format": mimetype,
                    "location": href,
                    requirements: [{
                        type: "QUOTA",
                        name: "resolution"
                    }]
                }
            },
            type: asset_type
        };

        if (asset_type == '$RA0101') {
            //var dimensions =  sizeOf(file.path);
            var dimensions = sizeOf(localPath + path);
            data.tech_info.href.requirements[0].value = dimensions.width + "*" + dimensions.height;
        }

        return data;
    },
    searchLocalAssets: function(req, res, next) {
        var _self = this;

        var assettype = req.query.type;
        var id = req.query.question_id;

        var localPath = _self.getInteractionPackagePath(id, req);
        var folder = localPath + _self.$ref_assets_path;
        var assetBasePath = _self.$ref_base + _self.$ref_assets_path;
        var types = {
            jpg: {code: '$RA0101', minetype: ''},
            jpeg: {code: '$RA0101', minetype: ''},
            gif: {code: '$RA0101', minetype: ''},
            png: {code: '$RA0101', minetype: ''},
            bmp: {code: '$RA0101', minetype: ''},
            mp4: {code: '$RA0103', minetype: ''},
            mp3: {code: '$RA0102', minetype: ''}
        };
        mkdir(folder, function () {
            var items = [];
            var files = fs.readdirSync(folder);
            for (var i = 0; i < files.length; i++) {
                if (files[i].indexOf(".") == -1) {
                    continue;
                }
                var href = assetBasePath + files[i];
                var assetId = files[i].substring(0, files[i].lastIndexOf(".") - 1);
                var suffix = files[i].substring(files[i].lastIndexOf(".") + 1);
                var type = types[suffix.toLowerCase()];
                if (['audio.png', 'background.jpg', 'default_audio.png', 'default_video.png', 'image.png', 'papertype_1.png'
                        , 'papertype_2.png', 'papertype_3.png', 'papertype_4.png', 'papertype_5.png', 'video.png'].indexOf(files[i]) != -1) {
                    continue;
                }
                if (files[i].indexOf("sf-") == 0) {
                    continue;
                }
                if (type && type.code == assettype) {
                    var data = {
                        identifier: assetId,
                        title: assetId + "." + suffix,
                        tech_info: {
                            href: {
                                "format": type.mimetype,
                                "location": href,
                                requirements: [{
                                    type: "QUOTA",
                                    name: "resolution"
                                }]
                            }
                        },
                        type: type.code
                    };
                    if (type.code == '$RA0101') {
                        //var dimensions =  sizeOf(file.path);
                        var dimensions = sizeOf(folder + files[i]);
                        data.tech_info.href.requirements[0].value = dimensions.width + "*" + dimensions.height;
                    }
                    items.push(data);
                }
            }
            res.send({
                items: items
            });
        });
    },
    getAsset: function (req, res, next) {
        var _self = this;

        var fromRefBase = req.query.from_ref_base;
        var filepath = req.query.filepath;
        var question_id = req.query.question_id;
        if (!question_id) {
            return res.status(400).send({code: "LS/MISSING_QUESTION_ID", message: "参数不正确，缺少习题ID。"});
        }
        if (filepath && filepath.indexOf("?") != -1) {
            filepath = filepath.substring(0, filepath.indexOf("?"));
        }
        if (filepath && filepath.indexOf("/") === 0) {
            filepath = filepath.substring(1);
        }

        var realPath = _self.getInteractionPackagePath(question_id, req);
        if (fromRefBase == 'true') {
            realPath += '/' + filepath;
        } else {
            realPath += '/_ref/' + filepath;
        }

        return res.sendFile(Path.resolve(realPath));
    },
    uploadAssets: function (req, res, next) {
        var _self = this;

        var file = req.file;
        var id = req.query.question_id;
        var type = req.query.asset_type;
        var tempId = new Date().getTime() + "" + Math.floor(Math.random() * 100);
        var assetBasePath = "${ref-path}/" + _self.$interaction_base + "/" + id + ".pkg";
        var suffix = file.originalname.substring(file.originalname.lastIndexOf("."));
        var prefix = file.originalname.substring(0, file.originalname.lastIndexOf("."));

        var localPath = _self.getInteractionPackagePath(id, req);
        var folder = localPath + _self.$ref_assets_path;
        var path = _self.$ref_assets_path + tempId + suffix;

        mkdir(folder, function () {
            renameFile(file.path, localPath + path).then(function () {
                var data = _self.saveMetadata(tempId, id, file.originalname, file.mimetype, req.query.asset_type, req);

                res.send(data);
            });
        });

        return;
    },
    downloadAssets: function (req, res, next) {
        var _self = this;

        var questionId = req.query.question_id;
        var filepath = req.query.filepath;
        var url = req.query.url;
        var assetType = req.query.assetType;

        _self.handleProxyFile(questionId, filepath, url, assetType, req, function (refPath) {
            return res.send(refPath);
        });
    },
    handleProxyFile: function (question_id, filepath, url, assetType, req, callback) {
        var _self = this;

        var filename = filepath.substring(filepath.lastIndexOf("/") + 1);
        var ref_assets_path = _self.getInteractionPackagePath(question_id, req) + _self.$ref_assets_path;
        var realPath = ref_assets_path + filename;

        _self.mkdirsSync(ref_assets_path);
        if (!fs.existsSync(realPath)) {
            //download file to location
            var file = fs.createWriteStream(realPath);
            var request = http.get(url, function (response) {
                response.pipe(file);
                file.on('finish', function () {
                    file.close(function () {
                        return callback(_self.$ref_path + _self.$assets_path + filename);
                    });
                });
            });
            request.on('error', function (err) {
            });
            request.end();
        }
        else {
            return callback(_self.$ref_path + _self.$assets_path + filename);
        }
    }
};

/* ========================================  互动习题资源相关操作 end      ========================================*/