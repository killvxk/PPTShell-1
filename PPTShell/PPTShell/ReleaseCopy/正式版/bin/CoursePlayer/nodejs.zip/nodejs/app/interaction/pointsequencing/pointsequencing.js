/**
 *
 */
define(['app', './directive/pointsequencing.directive','jqueryui'
], function (app) {
    'use strict';
    app.controller('pointsequencing_ctrl', [
        '$scope', 'skin_service', '$stateParams', 'CustomEditorService', '$rootScope', "$filter", '$timeout','$http','$compile',
        function ($scope, skin_service, $stateParams, CustomEditorService, $rootScope, $filter, $timeout,$http,$compile) {
        	$rootScope.moduleScope = $scope;
        	$scope.errorModel = {};
            $scope.delData = {data: {}};
            $scope.model = {
                "skin": {
                    code: "wood",
                    css_url: "${ref-path}/edu/esp/preparecustomeditor/pointsequencing/wood/css/wood.css",
                    name: $filter('translate')('linkup.muwen'),
                    package_url: "${ref-path}/edu/esp/preparecustomeditor/pointsequencing/wood"
                },
                "timer": {
                    "timer_type": "sequence",  //计时器类型: ["sequence", "countdown"]
                    "time_minute": "0",    //倒计时初始设置-分钟，timer_type="countdown"时有效
                    "time_second": "0"     //倒计时初始设置-秒，timer_type="countdown"时有效
                }
            };
            var reEdit = false;//是否再次进入编辑
            var loadingData = function (id) {
                $scope.isloadingData = true;
                //console.log('ssssssss == ' + $filter('filterRefPath'));
                CustomEditorService.getQuestionInfoById(id)
                    .then(function (rtnData) {
                        
                        if (!rtnData) {
                            $scope.errorModel.errorText = $filter('translate')('pointsequencing.unvalidno');
                            $scope.errorModel.dismissErrorTip(1000);
                        } else {
                            if (rtnData.skin.code != '') {
                                $scope.model = $scope.decodeOrder(rtnData);
                                skin_service.set_skin_by_code($scope.model.skin.code,"v1");
                            } else {
                                $scope.showGuide = true;
                                $scope.model.id = rtnData.id;
                                skin_service.set_skin_by_code($scope.model.skin.code,"v1");
                            }
                            $scope.errorModel.errorText = "";
                            $scope.isloadingData = false;

                            if (rtnData.background !== null) {//再次进入编辑
                                $scope.info.isNew = false;
                                $scope.info.background = rtnData.background;
                                $scope.info.background.scale = rtnData.background.scale;
                                if(rtnData.points != null){
                                    $scope.info.points = rtnData.points;
                                    $scope.event.updateShowValue();
                                }

                                /**
                                 * 因为背景图片的自适应依赖外围div的宽高，然而外围div的宽高又依赖于app.js中scaleHtml的样式计算（延迟200ms）
                                 * 所以由Line.86  $rootScope.scaleHtml进行回调处理
                                 */
                                //updateInfo($scope.info.background.url,false);
                            } else {
                                $scope.info.isNew = true;
                                $scope.info.background.url = '';//新增
                                $scope.info.background.scale = 1;
                            }
                        }
                    }, function (error) {
                        $scope.errorModel.errorText = $filter('translate')('pointsequencing.get_title_error');
                        $scope.errorModel.dismissErrorTip(1000);
                    })
            }

            //入口
            if (!$stateParams.id) {
                //新增
                $scope.showGuide = true;
                skin_service.set_skin_by_code($scope.model.skin.code,"v1");

            } else {
                //修改
                $scope.showGuide = false;

                loadingData($stateParams.id);
            }

            $scope.$on('changgedSkin', function () {
                $rootScope.scaleHtml(function() {
                    if(!!$scope.info.background.url) {
                        updateInfo($scope.info.background.url,false);
                    }
                });
            });

            $scope.validPostData = function () {
                var modelData = $scope.model;
                if ($.trim(modelData.title) == '') {
                    $scope.errorModel.errorText = $filter('translate')('pointsequencing.no_title');
                    $scope.errorModel.dismissErrorTip(1000);
                }else if( $scope.info.points.length <=2 ){
                    $scope.errorModel.errorText = $filter('translate')('pointsequencing.pointnum_noenough');
                    $scope.errorModel.dismissErrorTip(1000);
                }else if($scope.event.checkPointLegal() === false){
                    //$scope.errorModel.dismissErrorTip(1000);
                } else {
                    modelData.background = $scope.info.background;
                    modelData.points = $scope.info.points;
                    return true;
                }
            };

            $scope.errorModel.dismissErrorTip = function (delay){
                $timeout(function(){
                    $scope.errorModel.errorText = '';
                },delay);
            }

            $scope.encodeOrder = function (model) {
                return model;
            };

            $scope.decodeOrder = function (model) {
                return model;
            };

            $scope.addAssets = function(asset_type){
                if(asset_type){
                    $scope.info.background.scale = 0;
                    $scope.info.currentScalePosition = -1;
                    updateInfo($scope.info.description.asset);
                }
            };

            var ScrollBar = {
                value: 0,
                maxValue: 100,
                scrollWidth:0,
                step: 1,
                currentX: 0,
                Initialize: function() {
                    /*if (this.value > this.maxValue) {
                        alert("给定当前值大于了最大值");
                        return;
                    }*/
                    this.getValue();
                    this.scrollWidth = $(".progress_bar").width();
                    this.Value();
                    $(".scroll_Thumb").draggable($scope.info.background.url===''?'disable':'enable');

                },
                Value: function() {
                    var valite = false;
                    var currentValue;
                    $(".scroll_Thumb").draggable({
                        containment: ".progress",
                        start:function(event,ui){
                            valite = true;
                        },
                        drag:function(event,ui){
                           /* $(event.target).css({'top':'-3px','background-color':'#138ECB'});*/
                            if (valite == false) return;
                            currentValue = ui.position.left /*+ $("#scroll_Thumb").width()*/;
                            ScrollBar.currentX = currentValue;
                            ScrollBar.value = Math.round(ScrollBar.maxValue * ((currentValue) / ScrollBar.scrollWidth));
                            $scope.$apply(function(){
                                $scope.event.scaleTo(ScrollBar.value);
                            });
                        },
                        stop:function(event,ui){
                            $(".scroll_Thumb").css({'left':ScrollBar.currentX+'px'});
                            ScrollBar.value = Math.round(ScrollBar.maxValue * ((currentValue) / ScrollBar.scrollWidth));
                            $scope.$apply(function(){
                                $scope.event.scaleTo(ScrollBar.value);
                                ScrollBar.setValue(ScrollBar.value);
                            });
                            valite = false;
                        }
                    });
                },
                setValue:function(v){
                    ScrollBar.currentX = Math.floor(ScrollBar.scrollWidth * (v / ScrollBar.maxValue));
                    $(".scroll_Thumb").css({'left':(ScrollBar.currentX)+'px'});
                },
                setposition:function(left){
                    $(".scroll_Thumb").css({'left':left+'px'});
                },
                getValue: function() {
                    this.currentX = $(".progress_bar").width() * (this.value / this.maxValue);
                }
            };


            var $img = $('#pointsequencing-img');
            var $replaceFocus = $('#replaceFocus');
            var $showPoint = $('#showPoint');
            $showPoint.unbind('click');

            /**判断两线段是否相交**/
            function segmentsIntr(a, b, c, d) {
                // 三角形abc 面积的2倍
                var area_abc = (a.x - c.x) * (b.y - c.y) - (a.y - c.y) * (b.x - c.x);
                // 三角形abd 面积的2倍
                var area_abd = (a.x - d.x) * (b.y - d.y) - (a.y - d.y) * (b.x - d.x);
                // 面积符号相同则两点在线段同侧,不相交 (对点在线段上的情况,本例当作不相交处理);
                if (area_abc * area_abd >= 0) {
                    return false;
                }
                // 三角形cda 面积的2倍
                var area_cda = (c.x - a.x) * (d.y - a.y) - (c.y - a.y) * (d.x - a.x);
                // 三角形cdb 面积的2倍
                // 注意: 这里有一个小优化.不需要再用公式计算面积,而是通过已知的三个面积加减得出.
                var area_cdb = area_cda + area_abc - area_abd;
                if (area_cda * area_cdb >= 0) {
                    return false;
                }
                //计算交点坐标
                var t = area_cda / (area_abd - area_abc);
                var dx = t * (b.x - a.x),
                    dy = t * (b.y - a.y);
                return {
                    x: a.x + dx,
                    y: a.y + dy
                };
            };

            function updateInfo(url,clearPoints){
                function filter(input) {
                    if (input) {
                    	// return encodeURIComponent(input).replace(encodeURIComponent('${ref-path}'), (config.ref_path)).replace(/%2F/g,'/');
                    	return $filter('filterRefPath')(input);
                    } else {
                        return "";
                    }
                }

                function setScaleSizes(sizeBeyond){
                    $scope.info.scaleSize = [];
                    var width = 0;
                    var height = 0;
                    var i,len;
                    var imgWh,currentWh,adjustWh;

                    var containterWidth = $("#pointsequencing-containter").width() - 20;
            		var containterHeight = $("#pointsequencing-containter").height() - 20;
 
            		$scope.info.adjustSize.width = containterWidth * 5 / 7;
            		$scope.info.adjustSize.height = containterHeight * 5 / 7;
                    
            		$scope.info.maxWidth = containterWidth;
            		$scope.info.maxHeight = containterHeight;
                    
                    imgWh = $scope.info.oriWidth/$scope.info.oriHeight;//原始图片大小的宽高比
                    adjustWh = $scope.info.adjustSize.width/$scope.info.adjustSize.height;
                    if(imgWh > adjustWh){//图片比较宽
                        width = $scope.info.adjustSize.width;
                        height = $scope.info.oriHeight*width/$scope.info.oriWidth;
                        $scope.info.scaleSize.push({width:width,height:height});//先放入自适应尺寸

                        for(i=0; i<2; i++){
                            width = width+35;
                            height = $scope.info.oriHeight*width/$scope.info.oriWidth;
                            $scope.info.scaleSize.push({width:width,height:height});//放入自适应后面的尺寸
                        }

                        width = $scope.info.adjustSize.width;
                        var size;
                        for(i=0; i<$scope.info.firstScalePosition; i++){
                            width = width-35;
                            height = $scope.info.oriHeight*width/$scope.info.oriWidth;
                            size = {width:width,height:height};
                            $scope.info.scaleSize.splice(0,0,size);//放入自适应前面的尺寸
                        }
                    }else{//图片比较高
                        height = $scope.info.adjustSize.height;
                        width = $scope.info.oriWidth*height/$scope.info.oriHeight;

                        $scope.info.scaleSize.push({width:width,height:height});//先放入自适应尺寸

                        for(i=0; i<2; i++){
                            height = height+25;
                            width = $scope.info.oriWidth*height/$scope.info.oriHeight;
                            $scope.info.scaleSize.push({width:width,height:height});//先放入自适应尺寸
                        }

                        height = $scope.info.adjustSize.height;
                        var size;
                        for(i=0; i<$scope.info.firstScalePosition; i++){
                            height = height-25;
                            width = $scope.info.oriWidth*height/$scope.info.oriHeight;
                            size = {width:width,height:height};
                            $scope.info.scaleSize.splice(0,0,size);//放入自适应前面的尺寸
                        }
                    }

                    $scope.info.currentScalePosition = $scope.info.firstScalePosition;

                    ScrollBar.maxValue=$scope.info.scaleSize.length-1;
                    //初始化
                    ScrollBar.Initialize();


                }

                /**获取图片的uuid**/
                function getImgUuid(url){
                    if(url){
                        var headTag = '/assets/';
                        var footTag = '.pkg';
                        var headIndex = url.indexOf(headTag) + headTag.length;
                        var footIndex = url.indexOf(footTag);
                        var uuid = url.substring(headIndex,footIndex);
                        return uuid;
                    }
                }

                function reset(){
                    $scope.info.background.url = url;
                    $scope.info.imgSrc = $scope.info.background.url;
                    
                    var sizeBeyond = false;
                    if(img.width > $scope.info.maxWidth || img.height > $scope.info.maxHeight){//超过最大尺寸
                        sizeBeyond = true;
                    }else{
                        sizeBeyond = false;
                    }

                    $scope.info.ratio = img.width/img.height;
                    setScaleSizes(sizeBeyond);

                    if(clearPoints !== false){
                        $scope.info.points = [];//点清除
                        $scope.info.value = 1;
                    }

                    if($scope.info.isNew == false){
                        var i;
                        for(i=0; i<$scope.info.scaleSize.length; i++){
                            if(Math.abs($scope.info.oriHeight*$scope.info.background.scale - $scope.info.scaleSize[i].height) < 0.01 &&
                                Math.abs($scope.info.oriWidth*$scope.info.background.scale - $scope.info.scaleSize[i].width) < 0.01){
                                $scope.info.currentScalePosition = i;
                                break;
                            }
                        }
                    }

                    calImagePosition();

                    $img.width($scope.info.scaleSize[$scope.info.currentScalePosition].width);
                    $img.height($scope.info.scaleSize[$scope.info.currentScalePosition].height);
                    $scope.info.currentImageSize.width = $scope.info.scaleSize[$scope.info.currentScalePosition].width;
                    $scope.info.currentImageSize.height = $scope.info.scaleSize[$scope.info.currentScalePosition].height;
                    ScrollBar.setValue($scope.info.currentScalePosition);
                    $scope.info.isNew = true;
                };

                var img = new Image();
                img.src = filter(url);
                if(url){
                    $scope.errorModel.errorText = $filter('translate')('pointsequencing.loading');
                }


                img.onload = function(){
                    $scope.info.oriWidth = img.width;
                    $scope.info.oriHeight = img.height;

                    //获取图片大小
                    var preHost = window.config.lifecycle_host;
                    var uuid = getImgUuid(url);
                    var address = preHost + '/v0.6/assets/' + uuid + '?include=TI,LC,EDU,CG,CR';

                    $http({
                        method: 'GET',
                        url: address
                    }).success(function (data, status, headers, config) {
                        if (status === 200) {

                            $timeout(function(){
                                var imgSize = data.tech_info.href.size;
                                $scope.errorModel.dismissErrorTip(100);
                                if(imgSize/1024/1024 > 10){
                                    $scope.info.background.url = '';
                                    $scope.errorModel.errorText = $filter('translate')('pointsequencing.imagesize');
                                    $scope.errorModel.dismissErrorTip(1000);
                                }else{
                                    reset();
                                }
                            });
                        }
                    }).error(function (data, status, headers, config) {
                        $scope.errorModel.dismissErrorTip(100);
                        reset();
                    });
                };

            };

            //$scope.$watch('model.skin.code',function(n,o){
            //    $timeout(function(){
            //        updateInfo($scope.info.background.url,false);
            //    },300);
            //});

            function getStrLeng(str){
                var realLength = 0;
                if(str === undefined){
                    return realLength;
                }
                var len = str.length;
                var el = 0 ,cl = 0;

                var charCode = -1;
                for(var i = 0; i < len; i++){
                    charCode = str.charCodeAt(i);
                    if (charCode >= 0 && charCode <= 128) {
                        realLength += 1;
                        el++ ;
                    }else{
                        // 如果是中文则长度加3
                        realLength+=2;
                        cl++ ;
                    }
                }
                return {
                    l:realLength,
                    enLength:el,
                    chLength:cl
                };
            }

            var pointInfo = {
                num: 0,
                x: 0,
                y: 0,
                value: '',
                contentEditable:false,
                isSelected:false,
                isErrorPoint:false
            };

            $scope.info = {
                "description": {
                    "text": "",       //题干描述
                        "asset_type": "", //题干相关素材类型 ["image","video","audio"]
                        "asset": ""  ,           //题干相关素材
                        "image_extend":{       //旋转，放大缩小等属性，todo：具体属性唐焱鑫补充
                        "rotate":"",
                            "resize":""
                    }
                },
                title:$scope.model.title,//提干信息
                titleLength:0,
                timer:{
                    timer_type:$scope.model.timer.timer_type, //计时器类型: ["sequence", "countdown"]
                    time_minute:$scope.model.timer.time_minute, //倒计时初始设置-分钟，timer_type="countdown"时有效
                    time_second:$scope.model.timer.time_second //倒计时初始设置-秒，timer_type="countdown"时有效
                },
                background:{
                    url:'',
                    scale:0
                },
                adjustSize:{//自适应尺寸
                    width:465,
                    height:320
                },
                imgSrc:'',//绑定到html的图片地址
                value:1,
                editingPoing:null,
                enterPoint:false,
                bestAdjustScale:1,
                inAdjustModel:false,
                points: [],
                scaleSize:[],
                isNew:true,
                oriWidth:0,
                oriHeight:0,
                maxWidth:465,
                maxHeight:320,
                ratio:1,
                step:0.1,
                selectedPoint:null,
                currentScalePosition:-1,
                firstScalePosition:5,
                currentImageSize:{
                    width:0,
                    height:0
                },
                finish:false,
                mousePosition:{
                    x:0,
                    y:0
                },
                hoverOpacity:0,
                display:'none',
                pointSize:{
                    width:30,
                    height:30
                },
                pointSizeDefault:30,
                position:{left:0,top:0}
            };
            $scope.event = {};

            $scope.event.titleChange = function(){
                var title = $('textarea.tit').val();
                $scope.info.titleLength = title.length;
            };
            
            /**检查点是否重叠**/
            $scope.event.checkPointOverlay = function(point){
                var i,len;
                for(i=0,len=$scope.info.points.length; i<len; i++){
                    if($scope.info.points[i] != point){
                        var distance = (point.x-$scope.info.points[i].x)*(point.x-$scope.info.points[i].x) + (point.y-$scope.info.points[i].y)*(point.y-$scope.info.points[i].y);
                        if(distance < $scope.info.pointSize.width*$scope.info.pointSize.width){
                            $scope.errorModel.errorText = $filter('translate')('pointsequencing.point_overlay');
                            $scope.errorModel.dismissErrorTip(1000);
                            return true;
                        }
                    }
                }
                return false;
            };

            /**检查设置的点是否合法**/
            $scope.event.checkPointLegal = function(){
                var points = $scope.info.points;
                var i, j, len, a, b, c, d, intr;
                if(points.length > 2){
                    for(i=0,len=points.length; i<len-2; i++){
                        a = points[i];
                        b = points[i+1];
                        for(j=i+1;j<len-1;j++){
                            c = points[j];
                            d = points[j+1];
                            intr = segmentsIntr(a,b,c,d);
                            if(intr !== false){
                                a.isErrorPoint = true;
                                b.isErrorPoint = true;
                                c.isErrorPoint = true;
                                d.isErrorPoint = true;
                                $scope.errorModel.errorText = $filter('translate')('pointsequencing.segmentsIntr');
                                return false;
                            }
                        }
                    }
                }
                for(i=0,len=points.length; i<len; i++){
                    points[i].isErrorPoint = false;
                }
                $scope.errorModel.dismissErrorTip(100);
                return true;
            };

            /**选择点**/
            $scope.event.selectPoint = function(point){
                if($scope.info.selectedPoint != null){
                    $scope.info.selectedPoint.isSelected = false;
                }
                if(point === null){
                    return;
                }
                $replaceFocus.focus();
                point.isSelected = true;
                $scope.info.selectedPoint = point;
            };

            /**绑定快捷键，用于删除点**/
            $replaceFocus.bind('keyup',function(event){
                var currKey = 0,e = e || event;
                currKey = e.keyCode || e.which || e.charCode;
                if(currKey === 46 && $scope.info.selectedPoint !== null){//删除
                    var i,len,index=-1;
                    for(i=0,len=$scope.info.points.length; i<len; i++){
                        if($scope.info.points[i] === $scope.info.selectedPoint){
                            index = i;
                            $scope.info.points.splice(index,1);

                            $scope.$apply(function() {
                                afterDeletePoint(index);
                            });

                            break;
                        }
                    }
                    if(index > -1){
                        $scope.$apply(function(){
                            for(i=index,len=$scope.info.points.length; i<len; i++){
                                var num = $scope.info.points[i].num;
                                $scope.info.points[i].num = num - 1;
                            }
                            $scope.event.checkPointLegal();
                        });
                    }
                }
            });

            function afterDeletePoint(index) {
                $scope.info.value > 1 && $scope.info.value--; //修复bug-37392
                $scope.info.enterPoint = false;  //修复bug-37386

                if(index < $scope.info.points.length) {
                    for(var i = index; i < $scope.info.points.length; i++) {
                        $scope.info.points[i].value = i + 1;
                    }
                }
            }

            $scope.event.onMouseMove = function(event){
                $scope.info.mousePosition.x = event.offsetX;
                $scope.info.mousePosition.y = event.offsetY;
                $scope.info.hoverOpacity = 0.5;
                //$scope.info.display = 'inline-block';
            };
            $scope.event.onMouseEnter = function(){
                $scope.info.hoverOpacity = 0.5;
                $scope.info.display = 'inline-block';
            };
            $scope.event.onMouseLeave = function(event){
                var pointOffsetX = $scope.info.pointSize.width/2,pointOffsetY = $scope.info.pointSize.height/2;
                if(event.offsetX <= pointOffsetX || event.offsetX >= ($scope.info.currentImageSize.width-pointOffsetX) ||
                    event.offsetY <= pointOffsetY || event.offsetY >= ($scope.info.currentImageSize.height-pointOffsetY)){//超出图片边界，隐藏
                    $scope.info.display = 'none';
                }
            }

            /**更新点的显示文本**/
            $scope.event.updateShowValue = function(){
                getNewPointValue();
            };

            /**编辑点**/
            $scope.event.startEditPoint = function(point){
                if($scope.info.editingPoing === null || $scope.info.editingPoing === undefined){
                    $scope.info.editingPoing = point;
                    $scope.info.editingPoing.contentEditable = true;
                    return;
                }else if($scope.info.editingPoing != point){
                    $scope.info.editingPoing.stopEdit();
                    point.contentEditable = true;
                    $scope.info.editingPoing = point;
                }else if($scope.info.editingPoing == point){
                    $scope.info.editingPoing.contentEditable = true;
                }
            };

            /**
             * 获取新的点值
             */
            function getNewPointValue(){
                //取出最大值
                var maxValue = 1,i= 0,len = 0,curValue = 0;
                var isExist = false;
                /*for(i= 1,len=$scope.info.points.length; i<len; i++){
                    if($.isNumeric($scope.info.points[i].value)){
                        curValue = Number($scope.info.points[i].value);
                        maxValue = curValue > maxValue?curValue:maxValue;
                    }
                }*/
                //修复bug#41868
                for(i= 0,len=$scope.info.points.length; i<len; i++){
                    if($.isNumeric($scope.info.points[i].value)){
                        curValue = Number($scope.info.points[i].value);
                        maxValue = curValue > maxValue?curValue:maxValue;
                    }
                }
                if(maxValue >= 999){
                    for(i=1; i<999; i++){
                        for(var j=0;j<len;j++){
                            if($.isNumeric($scope.info.points[j].value)){
                                curValue = Number($scope.info.points[j].value);
                                if(curValue === i){
                                    isExist = true;
                                    break;
                                }
                            }
                        }
                        if(isExist){
                            isExist = false;
                        }else{
                            $scope.info.value = i;
                            break;
                        }
                    }
                }else{
                    $scope.info.value = maxValue+1;
                }
            }

            /**检查点边缘，若有超出，则收回**/
            $scope.event.checkPointEdge = function(point){
                if(point){
                    if(point.x < 0){
                        point.x = 0;
                    }
                    if(point.x > $scope.info.currentImageSize.width-$scope.info.pointSize.width){
                        point.x = $scope.info.currentImageSize.width-$scope.info.pointSize.width;
                    }
                    if(point.y < 0){
                        point.y = 0;
                    }
                    if(point.y > $scope.info.currentImageSize.height-$scope.info.pointSize.height){
                        point.y = $scope.info.currentImageSize.height-$scope.info.pointSize.height;
                    }
                }
            }

            /**在containter点击添加点**/
            $scope.event.addPointInContainter = function(event){
                if($scope.info.background.url === ''){
                    return;
                }

                if($scope.info.enterPoint === true){
                    return;
                }
                $scope.event.clearStatus();
                var point = $.extend(true, {}, pointInfo);
                point.num = $scope.info.points.length+1;
                point.x = $scope.info.mousePosition.x - $scope.info.pointSize.width/2;
                point.y = $scope.info.mousePosition.y - $scope.info.pointSize.height/2;
                $scope.event.checkPointEdge(point);
                if($scope.event.checkPointOverlay(point)){
                    return;
                }
                point.value = $scope.info.value + '';
                $scope.info.points.push(point);
                $scope.event.selectPoint($scope.info.points[$scope.info.points.length-1]);
                $scope.event.checkPointLegal();

                getNewPointValue();
            };


            /**清除编辑状态**/
            $scope.event.clearStatus = function () {
                var point;
                for(var i= 0,len=$scope.info.points.length; i<len; i++){
                    point = $scope.info.points[i];
                    if(point.contentEditable === true && point.stopEdit && $.isFunction(point.stopEdit)){
                        point.stopEdit();
                    }
                }
                $scope.event.selectPoint(null);
            };

            /**自适应图片**/
            $scope.event.adjustToSize = function(){
                if($scope.info.background.url === ''){
                    return;
                }

                var position = $scope.info.firstScalePosition;
                $scope.event.scaleTo(position);
                return;
            };

            /**计算图片位置**/
            function calImagePosition(isAdjust){
                var parent = $img.parent();
                var parentWidth = parent.width();//parent.width()  1075
                var parentHeight = parent.height();//parent.height()  652


                var imgWidth = isAdjust?$scope.info.scaleSize[$scope.info.firstScalePosition].width:$scope.info.scaleSize[$scope.info.currentScalePosition].width;
                var imgHeight = isAdjust?$scope.info.scaleSize[$scope.info.firstScalePosition].height:$scope.info.scaleSize[$scope.info.currentScalePosition].height;

                $scope.info.position.left = (parentWidth - imgWidth)/2;
                $scope.info.position.top = (parentHeight - imgHeight)/2;

                $scope.info.background.scale = imgWidth/$scope.info.oriWidth;
            }

            /**更新点位置**/
            function updatePointPosition(oriWidth,newWidth,oriHeight,newHeight){
                var i,len,point;
                for(i=0,len=$scope.info.points.length; i<len; i++){
                    point = $scope.info.points[i];
                    point.x = newWidth*point.x/oriWidth;
                    point.y = newHeight*point.y/oriHeight;
                }
            }

            /**缩放图片到某个尺寸**/
            $scope.event.scaleTo = function(position){
                if(position === $scope.info.currentScalePosition || position >= $scope.info.scaleSize.length || position < 0){
                    return;
                }
                var width = $scope.info.scaleSize[position].width;
                var height = $scope.info.scaleSize[position].height;
                updatePointPosition($img.width(),width,$img.height(),height);
                $img.width(width);
                $img.height(height);
                $scope.info.currentImageSize.width = width;
                $scope.info.currentImageSize.height = height;
                $scope.info.currentScalePosition = position;
                $scope.info.pointSize.width = $scope.info.pointSizeDefault;
                $scope.info.pointSize.height = $scope.info.pointSizeDefault;
                calImagePosition();
                ScrollBar.setValue(position);
                $scope.info.inAdjustModel = false;
            }

            /**缩放图片**/
            $scope.event.scaleImg = function(zoomOut){
                var position
                if(zoomOut){
                    position = $scope.info.currentScalePosition + 1;
                }else{
                    position = $scope.info.currentScalePosition - 1 ;
                }
                $scope.event.scaleTo(position);
                return;
            };
            
            //资源文件的限制使用
            $scope.resourceValidParam = {
            	imageType:['image/jpg', 'image/jpeg', 'image/webp', 'image/gif', 'image/png', 'image/bmp'], 
                imageSize:1*1024*1024
            };
            //改变窗口大小的时候重新适应
            angular.element(window).resize(fun);
            
            function fun(){
            	//重新加载
            	$timeout(function(){

            		var containterWidth = $("#pointsequencing-containter").width() - 20;
            		var containterHeight = $("#pointsequencing-containter").height() - 20;
 
            		$scope.info.adjustSize.width = containterWidth * 5 / 7;
            		$scope.info.adjustSize.height = containterHeight * 5 / 7;
                    
            		$scope.info.maxWidth = containterWidth;
            		$scope.info.maxHeight = containterHeight;
            		
            		var img = new Image();
                    img.src = $filter('filterRefPath')($scope.info.background.url);
                	
                    var sizeBeyond = false;
                    if(img.width > $scope.info.maxWidth || img.height > $scope.info.maxHeight){//超过最大尺寸
                        sizeBeyond = true;
                    }else{
                        sizeBeyond = false;
                    }

                    $scope.info.ratio = img.width/img.height;
                    setScaleSizesEx(sizeBeyond);


                    calImagePosition();

                    $img.width($scope.info.scaleSize[$scope.info.currentScalePosition].width);
                    $img.height($scope.info.scaleSize[$scope.info.currentScalePosition].height);
                    $scope.info.currentImageSize.width = $scope.info.scaleSize[$scope.info.currentScalePosition].width;
                    $scope.info.currentImageSize.height = $scope.info.scaleSize[$scope.info.currentScalePosition].height;
                    ScrollBar.setValue($scope.info.currentScalePosition);
                    
                    if($scope.info.background.url === ''){
                        return;
                    }

                    var position = $scope.info.currentScalePosition;
                    $scope.event.scaleTo(position);
                    $scope.event.scaleImg(false);
                },300);   	
            }
            
            function setScaleSizesEx(sizeBeyond){
                $scope.info.scaleSize = [];
                var width = 0;
                var height = 0;
                var i,len;
                var imgWh,currentWh,adjustWh;

                imgWh = $scope.info.oriWidth/$scope.info.oriHeight;//原始图片大小的宽高比
                adjustWh = $scope.info.adjustSize.width/$scope.info.adjustSize.height;
                if(imgWh > adjustWh){//图片比较宽
                    width = $scope.info.adjustSize.width;
                    height = $scope.info.oriHeight*width/$scope.info.oriWidth;
                    $scope.info.scaleSize.push({width:width,height:height});//先放入自适应尺寸

                    for(i=0; i<2; i++){
                        width = width+35;
                        height = $scope.info.oriHeight*width/$scope.info.oriWidth;
                        $scope.info.scaleSize.push({width:width,height:height});//放入自适应后面的尺寸
                    }

                    width = $scope.info.adjustSize.width;
                    var size;
                    for(i=0; i<$scope.info.firstScalePosition; i++){
                        width = width-35;
                        height = $scope.info.oriHeight*width/$scope.info.oriWidth;
                        size = {width:width,height:height};
                        $scope.info.scaleSize.splice(0,0,size);//放入自适应前面的尺寸
                    }
                }else{//图片比较高
                    height = $scope.info.adjustSize.height;
                    width = $scope.info.oriWidth*height/$scope.info.oriHeight;

                    $scope.info.scaleSize.push({width:width,height:height});//先放入自适应尺寸

                    for(i=0; i<2; i++){
                        height = height+25;
                        width = $scope.info.oriWidth*height/$scope.info.oriHeight;
                        $scope.info.scaleSize.push({width:width,height:height});//先放入自适应尺寸
                    }

                    height = $scope.info.adjustSize.height;
                    var size;
                    for(i=0; i<$scope.info.firstScalePosition; i++){
                        height = height-25;
                        width = $scope.info.oriWidth*height/$scope.info.oriHeight;
                        size = {width:width,height:height};
                        $scope.info.scaleSize.splice(0,0,size);//放入自适应前面的尺寸
                    }
                }

//                $scope.info.currentScalePosition = $scope.info.firstScalePosition;

//                ScrollBar.maxValue=$scope.info.scaleSize.length-1;
                //初始化
                ScrollBar.Initialize();


            }
        }
    ]);

});
