/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
    'jquery',   
    'css!./style.css',
    './js/templates.js'
],function($,css,templates){  
    function GameQuestionSubmitModuleEditor(){
        var module, stage, config;
        //设置关联值
        this.init = function(m,s,c){
            module = m;
            stage = s;
            config = c;              
        };
        //初始化默认值
        this.initDefault = function(moduleWrap){            
                              
        };
        //绘制交互页面
        this.render = function(moduleWrap){
            this.element = $(moduleWrap.getElement());
            $(this.element).html(templates['template.html']).find('.game_question_submit').html(module.getPropertyValue("text"));
        };
    }
    return GameQuestionSubmitModuleEditor;
});