/**
 * Created by oy on 2015/7/30.
 */
define([
	'components/site-directive/foot-tool/time-box/new-time-box',
	'components/site-directive/foot-tool/foot-tool',
	'components/site-directive/edit-box/new-edit-box',
    'components/site-directive/error-tip/error-tip',
    'fillblank/directive/contenteditable/contenteditable',
    'fillblank/directive/setfocus/setfocus'
], function () {

});
