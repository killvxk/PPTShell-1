/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
    'jquery',
    'environmentConfig',
    'espEnvironment/../esp-environment-workspace',
    'espEnvironment/../esp-environment-debug',
    'espEnvironment/../esp-environment-local',
    'espEnvironment/../esp-environment-nw',
    'espEnvironment/../esp-environment-server',
    'espEnvironment/../UrlHelper',
    'espEnvironment/../ReferenceUrlResolver'
], function (
    $,
    config,
    environmentWorkspace,
    environmentDebug,
    environmentLocal,
    environmentNw,
    environmentServer,
    UrlHelper,
    ReferenceUrlResolver
) {
    var environments = {
        debug: environmentDebug,
        local: environmentLocal,
        nw: environmentNw,
        server: environmentServer
    };

    var environment = environmentWorkspace;
    if(!environment){
        var reg = new RegExp("(^|&)environment=([^&]*)(&|$)");
        var r = window.location.search.substr(1).match(reg);
        var environmentKey = (r && decodeURIComponent(r[2])) || null;
        environmentKey ||  (environmentKey = config.environment || 'server');
        environment = environments[environmentKey] || environments['server'];
    }
    var supports = $.extend({
        asset: true
    }, environment.supports);

    var moduleEditorVersions = [];
    var espEnvironment = {
        url: {
            coursewareobjectPreview: function (identifier) {
                return UrlHelper.build(environment.coursewareobjectPreview, {id: identifier});
            },
            coursewareobjectTemplateRoot: function (identifier) {
                return UrlHelper.root(UrlHelper.build(environment.coursewareobjectTemplateRoot, {id: identifier}));
            },
            coursewareobjectRoot: function(identifier){
                return UrlHelper.root(UrlHelper.build(environment.coursewareobjectRoot, {id: identifier}));
            },
            moduleEditorRoot: function(moduleId){
                var version = '1.0.0';
                for(var i=0;i<moduleEditorVersions.length;i++){
                    if(moduleEditorVersions[i].id == moduleId){
                        version = moduleEditorVersions[i].version;
                        break;
                    }
                }
                return UrlHelper.root(UrlHelper.build(environment.moduleEditorRoot, {id: moduleId, version: version}));
            },
            modulePresenterRoot: function(presenterId){
                if(!environment.modulePresenterRoot) return null;
                return UrlHelper.root(UrlHelper.build(environment.modulePresenterRoot, {id: presenterId}));
            },
            jsLibraryRoot: function(name){
				return UrlHelper.root(UrlHelper.build(environment.jsLibraryRoot, {name: name, version: version}));
            }
        },
        createReferenceUrlResolver: function (relativeRootPath, relativePath) {
            return ReferenceUrlResolver(environment.referencePath, relativeRootPath, relativePath);
        },
        declareModuleEditorVersion: function (id, version) {
            if(typeof id === 'string' && typeof version === 'string'){
                moduleEditorVersions.push({id: id, version: version});
            }else if($.isPlainObject(id) && id.id && id.version){
                moduleEditorVersions.push(id);
            }else if($.isArray(id)){
                for(var i=0;i<id.length;i++){
                    espEnvironment.declareModuleEditorVersion(id[i]);
                }
            }
        },
        isSupport: function (name) {
            return supports[name] === true;
        }
    };
    Object.defineProperties(espEnvironment, {
        'service': {
            get: function () {
                return environment.service;
            }
        },
        'serviceConfig': {
            get: function () {
                return environment.serviceConfig;
            }
        },
        'writeMode':{
            get: function () {
                return environment.writeMode || config.writeMode  || 'yes';
            }
        }
    });
    return espEnvironment;
});