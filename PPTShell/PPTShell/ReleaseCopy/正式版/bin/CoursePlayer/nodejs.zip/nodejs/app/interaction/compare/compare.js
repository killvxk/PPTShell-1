/**
 *
 */

define(['app', 'compare/directive/compare.directive'], function(app) {
  'use strict';
  app.controller('compare_ctrl', [
    '$scope', 'skin_service', '$stateParams', 'CustomEditorService', '$rootScope', '$filter',
    function($scope, skin_service, $stateParams, CustomEditorService, $rootScope, $filter) {
      $scope.errorModel = {};
      $scope.optionItems = [];
      $scope.model = {
        "id": "",
        "title": "",
        "skin": {
          code: "wood",
          css_url: "${ref-path}/edu/esp/preparecustomeditor/compare/wood/css/wood.css",
          name: $filter('translate')('linkup.muwen'),
          package_url: "${ref-path}/edu/esp/preparecustomeditor/compare/wood"
        },
        "timer": {
          "timer_type": "sequence", //计时器类型: ["sequence", "countdown"]
          "time_minute": "0", //倒计时初始设置-分钟，timer_type="countdown"时有效
          "time_second": "0" //倒计时初始设置-秒，timer_type="countdown"时有效
        },
        "items": [{
          key: new Date().valueOf(),
          first: '',
          second: '',
          correct: '',
          map: '',
          isAdd: true,
          isShow: false,
          addText: $filter('translate')('compare.addItem.true'),
          delText: $filter('translate')('compare.addItem.false')
        }],
        "symbolMap": [{
          symbol: '＜',
          map: 'lt'
        }, {
          symbol: '＞',
          map: 'gt'
        }, {
          symbol: '≤',
          map: 'lteq'
        }, {
          symbol: '≥',
          map: 'gteq'
        }, {
          symbol: '＝',
          map: 'eq'
        }, {
          symbol: '≈',
          map: 'abeq'
        }]
      };
      var loadingData = function(id) {
        CustomEditorService.getQuestionInfoById(id)
          .then(function(rtnData) {
            if (!rtnData) {
              $scope.errorModel.errorText = $filter('translate')('linkup.unvalidno');
            } else {
              if (rtnData.skin.code != '') {

                angular.extend($scope.model, $scope.decodeCompare(rtnData));
                $scope.model.interaction_hints = rtnData.interaction_hints;
              } else {
                $scope.model.id = rtnData.id;
              }

              $scope.errorModel.errorText = "";
              skin_service.set_skin_by_code($scope.model.skin.code,'v1');
            }
          }, function() {
            $scope.errorModel.errorText = $filter('translate')('linkup.get_title_error');
          });
      };

      var getCorrect = function(map) {
        var correct = '';
        switch (map) {
          case 'lt':
            correct = '＜';
            break;
          case 'gt':
            correct = '＞';
            break;
          case 'lteq':
            correct = '≤';
            break;
          case 'gteq':
            correct = '≥';
            break;
          case 'eq':
            correct = '＝';
            break;
          case 'abeq':
            correct = '≈';
            break;
        }
        return correct;
      };

      //入口
      if (!$stateParams.id) {
//        skin_service.set_skin_by_code($scope.model.skin.code);
    	  skin_service.set_skin_by_code($scope.model.skin.code,"v1");
      } else {
        loadingData($stateParams.id);
      }

      $scope.$on('changgedSkin', function() {
        $rootScope.scaleHtml();
      });

      $scope.validPostData = function() {
        var modelData = $scope.model;
        var items = modelData.items;
        if ($.trim(modelData.title) == '') {
          $scope.errorModel.errorText = $filter('translate')('compare.notnull.desc');
        } else {
          if (items.length == 0) {
            $scope.errorModel.errorText = $filter('translate')('compare.unvalid.count');
            return false;
          } else if (items.length > 5) {
            $scope.errorModel.errorText = $filter('translate')('compare.unvalid.count');
            return false;
          }
          for (var i = 0, len = items.length; i < len; i++) {
            if (!items[i].first || !items[i].second) {
              $scope.errorModel.errorText = $filter('translate')('compare.unvalid.content');
              return false;
            }
            if (!items[i].correct) {
              $scope.errorModel.errorText = $filter('translate')('compare.unvalid.correct');
              return false;
            }
          }
          return true;
        }
      };
      var lastItem = {};
      $scope.userInput = function(item, key, word) {
        var len = 0;
        var temp = '';
        for (var i = 0; i < word.length; i++) {
        	//解决BUG：英文20个字符过长超出编辑框，统一为中文10个字，英文10个字母，全角和半角输入长度一致
        	// if (word[i].match(/[^\x00-\xff]/ig) != null || word[i].match(/[\@\#\%\+\=\~\&]/ig) != null)
        	// len += 2;
        	// else
            len += 1;
          if (len > 10) {
//        	  element.css('border',"1px solid red");
        	  break;
          }
          temp += word[i];
        }
        item[key] = temp;
      };
      $scope.selectThis = function(item, ct) {
        item.correct = ct.symbol;
        item.map = ct.map;
      };
      $scope.showChooseBox = function(item) {
        item.isShow = true;
      };
      $scope.hideChooseBox = function(item) {
        item.isShow = false;
      };
      $scope.addOrDel = function(item) {
        var currentIsAdd = true;
        if (item.isAdd) {
          if ($scope.model.items.length >= 5) {
            $scope.errorModel.errorText = $filter('translate')('compare.unvalid.count');
            return false;
          }
          if ($scope.model.items.length === 4) {
            currentIsAdd = false;
          }
          item.isAdd = false;
          $scope.model.items.push({
            key: new Date().valueOf(),
            first: lastItem.first,
            second: lastItem.second,
            correct: lastItem.correct,
            map: lastItem.map,
            isAdd: currentIsAdd,
            isShow: false,
            addText: $filter('translate')('compare.addItem.true'),
            delText: $filter('translate')('compare.addItem.false')
          });
          lastItem = {};
        } else {
          lastItem = item;
          var len = $scope.model.items.length;
          for (var i = 0; i < len; i++) {
            if ($scope.model.items[i].key === item.key) {
              $scope.model.items.splice(i, 1);
              break;
            }
          }
          if (len > 1) {
            $scope.model.items[len - 2].isAdd = true;
          }
        }
      };

      $scope.encodeCompare = function(model) {
        var newModel = {};
        var newItems = [];
        angular.forEach(model.items, function(v, k) {
          var item = {};
          item.left = window.customHtmlEncode(v.first);
          item.right = window.customHtmlEncode(v.second);
          item.symbol = v.map;
          newItems.push(item);
        });
        newModel.id = model.id;
        newModel.skin = model.skin;
        newModel.title = window.customHtmlEncode(model.title);
        newModel.items = newItems;
        newModel.interaction_hints = model.interaction_hints;
        return newModel;
      };
      $scope.decodeCompare = function(model) {
        var newModel = {};
        var items = [];
        newModel.id = model.id;
        newModel.title = window.customHtmlDecode(model.title);
        newModel.skin = model.skin;
        newModel.symbolMap = [{
          symbol: '＜',
          map: 'lt'
        }, {
          symbol: '＞',
          map: 'gt'
        }, {
          symbol: '≤',
          map: 'lteq'
        }, {
          symbol: '≥',
          map: 'gteq'
        }, {
          symbol: '＝',
          map: 'eq'
        }, {
          symbol: '≈',
          map: 'abeq'
        }];

        //修复bug-40692:比大小题在另存为的编辑页面时，点击删除题目会错删其他行
        var timestamp = new Date().valueOf();
        angular.forEach(model.items, function(v, k) {
          var item = {};
          item.key = timestamp + "_" + k;
          item.first = window.customHtmlDecode(v.left);
          item.second = window.customHtmlDecode(v.right);
          item.map = v.symbol;
          item.correct = getCorrect(v.symbol);
          item.isAdd = false;
          item.isShow = false;
          item.addText = $filter('translate')('compare.addItem.true');
          item.delText = $filter('translate')('compare.addItem.false');
          items.push(item);
        });
        var len = items.length;
        if (len && len < 5) {
          items[len - 1].isAdd = true;
        }
        newModel.timer = {
          "timer_type": "sequence",
          "time_minute": "0",
          "time_second": "0"
        };
        newModel.items = items;

        return newModel;
      };
    }
  ]);

});
