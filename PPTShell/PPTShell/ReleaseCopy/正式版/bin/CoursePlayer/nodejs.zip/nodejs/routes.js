var site = require('./controllers/site');
var questions = require('./controllers/questions');
var interaction = require('./controllers/interaction');
var assets = require('./controllers/assets');
var multipart = require('connect-multiparty');
var multer  = require('multer');
var upload = multer({ dest:  __dirname + "/app/userdatas/edu/esp/assets/" });
var multipartyMiddleware = multipart();
var coursewareobject = require('./app/editor/esp_rest/controller/coursewareobject');

module.exports = function(app) {
    app.all('/', site.index);

    app.post('/v1.3/questions', questions.create);
    app.get('/v1.3/questions/:id', questions.get);
    app.put('/v1.3/questions/:id', questions.save);
    app.get('/v1.3/questions/:id/item', questions.getItem);
    app.put('/v1.3/questions/:id/item', questions.saveItem);
    app.get('/v1.3/questions/:id/handwrite', questions.getHandwrite);
    app.put('/v1.3/questions/:id/handwrite', questions.saveHandwrite);
    app.get('/v1.3/questions/:id/qtiplayer', questions.qtiplayer);
    
    app.post('/v0.1/interaction/:module_type', interaction.create);
    app.get('/v0.1/interaction/:module_type/:module_instance_id', interaction.get);
    app.put('/v0.1/interaction/:module_type/:module_instance_id', interaction.modify);
    //app.post('/v0.1/interaction/upload/:module_instance_id', multipartyMiddleware, interaction.upload);
    //app.get('/v0.1/interaction_ref_assets/:module_instance_id', interaction.getRefAsset);
    
    app.get('/v1.3/assets', assets.search);
    app.get('/v1.3/assets/get', assets.get);
    app.get('/v1.3/assets/proxy', assets.proxy);
    app.get('/v1.3/assets/proxy2', assets.proxy2);
    app.get('/v1.3/assets/proxy3/:base/*', assets.proxy3);
    app.post('/v1.3/assets/actions/upload',upload.single('file'), assets.upload);

    app.post('/v0.1/archives/:file_name', interaction.saveFile);
    app.get('/v0.1/archives/:file_name', interaction.loadFile);


    app.get('/v2.0/courseware_objects/:id', coursewareobject.get);
    app.get('/v2.0/courseware_objects/:id/main', coursewareobject.getMain);
    app.get('/v2.0/courseware_objects/:id/pages/:pageId', coursewareobject.getPage);
    app.get('/v2.0/courseware_objects/:id/resource_files', coursewareobject.searchResourceFiles);

    app.post('/v2.0/courseware_objects', coursewareobject.create);
    app.post('/v2.0/courseware_objects/actions/from_template', coursewareobject.createFromTemplate);
    app.post('/v2.0/courseware_objects/:id/pages', coursewareobject.createPage);
    app.post('/v2.0/courseware_objects/:id/resource_files/actions/upload', coursewareobject.uploadResourceFile);
    app.post('/v2.0/courseware_objects/:id/actions/copy', coursewareobject.copy);

    app.put('/v2.0/courseware_objects/:id/main', coursewareobject.updateMain);
    app.put('/v2.0/courseware_objects/:id/pages/:pageId', coursewareobject.updatePage);
};
