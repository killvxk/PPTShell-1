/**
 * Created by ChenST on 2016/1/19.
 */
var path = require('path');
var DOMParser = require('xmldom').DOMParser;
var pathVar = require('./path-var').PathVar;
require('./js-ext');

/**
 * 描述资源的依赖.
 * @param type
 * @param href
 * @returns {*}
 */
var resourceDependency = function (type, href) {

    if (type == 'file' || type == 'image' || type == 'audio' || type == 'video' || type == 'flash') {
        return pathDependency(href);
    } else if (type == 'question' || type == 'ppt') {
        return {
            type: 'package',
            src: path.dirname(href)
        }
    }
};

/**
 * 描述路径的依赖.
 * @param _path
 * @param relativeDir
 * @returns {*}
 */
var pathDependency = function (_path, relativeDir) {
    var PARENT = '../';
    var CURRENT = './';

    var _relativeDir = relativeDir || 'pages';

    // 去除?后面的参数.
    var index = _path.indexOf('?');
    if (index != -1) {
        _path = _path.substring(0, index);
    }

    var ext = path.extname(_path);
    var isPackage = (ext == undefined || ext == '' || ext == 'pkg');

    // 是一个包.
    if (isPackage) {
        return {
            type: 'package',
            src: _path
        }
    } else {

        var src = '';
        if (_path.startsWith(pathVar.refPath) || _path.startsWith(pathVar.refPathAddon)) {
            src = _path;
        } else if (_path.startsWith(pathVar.refRelative)) {
            src = _path.replace(pathVar.refRelative, '');
        } else if (_path.startsWith(PARENT)) {
            src = _path.substring(PARENT.length);
        } else if (_path.startsWith(CURRENT)) {
            src = path.join(_relativeDir, _path.substring(PARENT.length));
        } else {
            src = path.join(_relativeDir, _path);
        }

        return {
            type: 'file',
            src: src
        }
    }

};

/**
 * 生产sdp-package.xml的内容.
 * @param sdpPackageObj
 */
var generateSdpPackage = function (sdpPackageObj) {

    var header = '<?xml version="1.0" encoding="UTF-8"?>'

    var doc = new DOMParser().parseFromString(header, 'application/xml');

    var version = sdpPackageObj.version || {};
    var targets = sdpPackageObj.targets || [];

    var packageEle = doc.createElement('package');

    packageEle.setAttribute('version', version);

    for (var i = 0; i < targets.length; i++) {
        (function (i) {

            var target = targets[i];
            var targetEle = doc.createElement('target');
            targetEle.setAttribute('name', target.name || 'default');

            // target-add依赖.
            targetEle = appendAdds(doc, targetEle, target.adds);

            // target-group依赖.
            var targetGroups = target.groups || [];
            for (var j = 0; j < targetGroups.length; j++) {

                (function (j) {
                    var groupEle = doc.createElement('group');
                    groupEle.setAttribute('name', targetGroups[j].name || '');
                    groupEle = appendAdds(doc, groupEle, targetGroups[j].adds);
                    targetEle.appendChild(groupEle);
                })(j);

            }

            packageEle.appendChild(targetEle);

        })(i);
    }

    doc.appendChild(packageEle);
    return doc.toString();

};

function appendAdds(doc, parentEle, adds) {
    adds = adds || [];
    for (var i = 0; i < adds.length; i++) {

        // 处理adds.
        (function (i) {
            var addEle = doc.createElement('add');

            if (adds[i].src === '*') {
                addEle.setAttribute('src', adds[i].src);
            } else {
                addEle.setAttribute('type', adds[i].type || 'file');
                addEle.setAttribute('src', adds[i].src || '');
            }

            parentEle.appendChild(addEle);

        })(i)

    }

    return parentEle;
};

/**
 * 路径截断.
 * @param path
 * @param slicePath
 * @returns {string}
 */
var pathSlice = function (_path, slicePath) {
    var sliced = _path.substring(slicePath.length, _path.length);
    return sliced.replace(new RegExp(/\\/g), '/');
};

/**
 * 是否是图片.
 * @param _path
 * @returns {boolean}
 */
var isImage = function (_path) {
    if (_path) {
        var ext = path.extname(_path).toLowerCase();
        var imageExts = ['bmp', 'gif', 'jpeg', 'jpg', 'png', 'psd', 'tiff', 'webp', 'svg'];
        return imageExts.contains(ext);
    }
    return false;
};


module.exports.espUtil = (function () {

    return {
        pack: {
            'resourceDependency': resourceDependency,
            'pathDependency': pathDependency,
            'generateSdpPackage': generateSdpPackage
        },
        util: {
            'pathSlice': pathSlice,
            'isImage': isImage
        }
    }

})();