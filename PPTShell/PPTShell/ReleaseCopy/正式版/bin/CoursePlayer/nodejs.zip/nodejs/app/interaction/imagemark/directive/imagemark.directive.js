/**
 * Created by px on 2015/06/25.
 */
define([
    'components/site-directive/assets-select/assets-select',
    'components/site-directive/edit-box/new-edit-box',
    'components/site-directive/foot-tool/time-box/new-time-box',
    'components/site-directive/foot-tool/foot-tool',
    'components/site-directive/error-tip/error-tip',
    'components/site-directive/image-transform/image-transform',
    'components/site-directive/confirm-popup/confirm-popup',
    'imagemark/directive/mark-type-guide/mark-type-guide',
    'imagemark/directive/imageitem/imageitem',
    'components/site-directive/contenteditable/contenteditable',
    'imagemark/directive/tag/tag',
    'imagemark/directive/tag/areaTag',
    'components/site-directive/draggable/nd-draggable',
    'components/site-services/utils.service'
], function () {


});