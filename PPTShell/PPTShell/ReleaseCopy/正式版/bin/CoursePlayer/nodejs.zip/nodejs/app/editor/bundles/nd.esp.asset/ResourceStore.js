define([
    'jquery',
    'espEnvironment',
    'espService'
],function(
    $,
    espEnvironment,
    espService
){
    var urlResolver = espEnvironment.createReferenceUrlResolver();
    function adjustData(metadata, type){
        var item = {title: metadata.title};
        item.href = urlResolver.parse(metadata.tech_info && metadata.tech_info.href && metadata.tech_info.href.location || '');
        if(metadata.preview){
            for(var key in metadata.preview){
                item.thumbHref = urlResolver.parse(metadata.preview[key]);
                if(key === '120' || key === '240'){
                    break;
                }
            }
        }
        if(!item.thumbHref){
            if('$RA0101' == params.type){
                item.thumbHref = item.href;
            }else if('$RA0102'==category){
            }else if('$RA0103'==category){
            }else{
            }
        }
        if(metadata.tech_info && metadata.tech_info.href && metadata.tech_info.href.requirements && metadata.tech_info.href.requirements.length){
            for(var i=0;i<metadata.tech_info.href.requirements.length;i++){
                var x = metadata.tech_info.href.requirements[i];
                if(x.name == 'resolution'){
                    item.resolution = x.value;
                    var parts = item.resolution && item.resolution.split("*");
                    if(parts && parts.length == 2){
                        item.width = parseInt(parts[0]);
                        item.height = parseInt(parts[1]);
                    }
                }else if(x.name == 'duration'){
                    item.duration = x.value;
                }
            }
        }
        item.size = metadata.tech_info && metadata.tech_info.href && metadata.tech_info.href.size;
        return item;
    }

    return function (name, title, coverage) {
        return {
            name: name || 'asset',
            title: title,
            order: 1,
            paging: 15,
            uploadEnabled: true,
            processUploadResponse: function (response, type) {
                return adjustData(response, type);
            },
            uploadOptions: {
                url: espService.asset.getUploadUrl(),
                multipart_params: {
                    coverage: coverage
                }
            },
            getDataList: function (params) {
                return espService.asset.list($.extend({
                    page:1,
                    size:20,
                    coverage: $.isFunction(coverage) ? coverage() : coverage
                }, params)).then(function (result) {
                    var items = [];
                    for(var i=0;i<result.items.length;i++){
                        for(var i=0;i<result.items.length;i++){
                            items.push(adjustData(result.items[i], params.type));
                        }
                    }
                    return {
                        total_count: result.total_count,
                        items: items
                    };
                });
            }
        };
    };
});