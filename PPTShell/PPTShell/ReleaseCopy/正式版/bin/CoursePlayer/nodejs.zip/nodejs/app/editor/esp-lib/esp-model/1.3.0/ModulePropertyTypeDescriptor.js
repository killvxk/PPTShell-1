/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
    'jquery',
    'espEnvironment',
    'espService',
    'exception'
],function(
    $,
    espEnvironment,
    espService,
    Exception
){
    var descriptors = {};
    function Descriptor(options){
        if(typeof options === 'string'){
            var descriptor = descriptors[options];
            if(!descriptor) throw 'no descriptor with: ' + options;
            return descriptor;
        }
        this._options = $.extend({}, options);
    }
    Descriptor.prototype.read = function (element, referenceUrlResolver) {
        if(this._options.read){
            return this._options.read(element, referenceUrlResolver);
        }
        return null;
    };
    Descriptor.prototype.write = function (element, value, referenceUrlResolver, resourceRegister) {
        var validateResult = this.validate(value);
        if(validateResult !== true){
            throw validateResult;
        }
        if(this._options.write){
            this._options.write(element, value, referenceUrlResolver, resourceRegister);
        }
    };
    Descriptor.prototype.validate = function (value) {
        if(value === null || typeof value === 'undefined'){
            return true;
        }
        if(this._options.validate){
            return this._options.validate(value);
        }
        return true;
    };
    Descriptor.define = function(type, descriptor){
        descriptors[type] = new Descriptor(descriptor);
    };
    /*************************************** Type string *******************************************************/
    Descriptor.define('string', {
        read: function(element, referenceUrlResolver){
            return $(element).attr('value');
        },
        write: function (element, value, referenceUrlResolver, resourceRegister) {
            $(element).attr('value', value || '');
        },
        validate: function (value) {
            return typeof value === 'string' ? true : '值不是 String';
        }
    });
    /*************************************** Type number *******************************************************/
    Descriptor.define('number', {
        read: function(element, referenceUrlResolver){
            return Number($(element).attr('value'));
        },
        write: function (element, value, referenceUrlResolver, resourceRegister) {
            $(element).attr('value', value || '');
        },
        validate: function (value) {
            return typeof value === 'number' ? true : '值不是 Number';
        }
    });
    /*************************************** Type url *******************************************************/
    Descriptor.define('url', {
        read: function(element, referenceUrlResolver){
            return referenceUrlResolver.parse($(element).attr('value'));
        },
        write: function (element, value, referenceUrlResolver, resourceRegister) {
            value = referenceUrlResolver.format(value);
            $(element).attr('value', value || '');
            resourceRegister.register(value);
        },
        validate: function (value) {
            return typeof value === 'string' ? true : '值不是有效的 URL';
        }
    });
    /*************************************** Type boolean *******************************************************/
    Descriptor.define('boolean', {
        read: function(element, referenceUrlResolver){
            return $(element).attr('value') === 'true';
        },
        write: function (element, value, referenceUrlResolver, resourceRegister) {
            $(element).attr('value', value ? 'true' : 'false');
        },
        validate: function (value) {
            return typeof value === 'boolean' ? true : '值不是 Boolean';
        }
    });
    /*************************************** Type html *******************************************************/
    Descriptor.define('html', {
        read: function(element, referenceUrlResolver){
            var html = $(element).text().trim();
            if(!html) return '';
            html = html.replace(/(<(img|video|audio) [^>]*src=['"])([^'"]+)([^>]*>)/gim, function (match, $1, $2, $3, $4) {
                return $1 + referenceUrlResolver.parse($3) + $4;
            });
            return html;
        },
        write: function (element, value, referenceUrlResolver, resourceRegister) {
            if(value){
                value = value.replace(/(<(img|video|audio) [^>]*src=['"])([^'"]+)([^>]*>)/gim, function (match, $1, $2, $3, $4) {
                    $3 = referenceUrlResolver.format($3);
                    resourceRegister.register($3);
                    return $1 + $3 + $4;
                });
            }
            var cdata = element.context.createCDATASection(value || '');
            $(element).append(cdata);
        },
        validate: function (value) {
            return typeof value === 'string' ? true : '值不是有效的 HTML';
        }
    });
    /*************************************** Type json *******************************************************/
    function resolveJsonValue(obj, fn){
        if(typeof obj === 'string'){
            obj = fn(obj);
        }else if($.isArray(obj)){
            for(var i=0;i<obj.length;i++){
                obj[i] = resolveJsonValue(obj[i], fn);
            }
        }else if($.isPlainObject(obj)){
            for(var key in obj){
                obj[key] = resolveJsonValue(obj[key], fn);
            }
        }
        return obj;
    }
    Descriptor.define('json', {
        read: function(element, referenceUrlResolver){
            var text = $(element).text();
            if(!text) return null;
            var value = JSON.parse(text);
            value = resolveJsonValue(value, function (text) {
                return referenceUrlResolver.parse(text);
            });
            return value;
        },
        write: function (element, value, referenceUrlResolver, resourceRegister) {
            value = resolveJsonValue(value, function (text) {
                if(referenceUrlResolver.test(text)){
                    text = referenceUrlResolver.format(text);
                    resourceRegister.register(text);
                }
                return text;
            });
            var cdata = element.context.createCDATASection(value ?  JSON.stringify(value) : '');
            $(element).append(cdata);
        },
        validate: function (value) {
            return $.isPlainObject(value) ? true : '值不是有效的 JSON 对象';
        }
    });
    /*************************************** Type list *******************************************************/
    Descriptor.define('list', {
        read: function(element, referenceUrlResolver){
            var list = [];
            var itemType = $(element).attr('itemType');
            $(element).find('>items>item').each(function () {
                list.push(Descriptor(itemType).read(this));
            });
            return list;
        },
        write: function (element, value, referenceUrlResolver, resourceRegister) {
            throw 'no supported';
        },
        validate: function (value) {
            return $.isArray(value) ? true : '值不是 Array';
        }
    });
    /*************************************** Type ref-module *******************************************************/
    Descriptor.define('ref-module', {
        read: function(element, referenceUrlResolver){
            return $(element).attr('value');
        },
        write: function (element, value, referenceUrlResolver, resourceRegister) {
            $(element).attr('value', value || '');
        },
        validate: function (value) {
            return typeof value === 'string' ? true : '值不是 String';
        }
    });

    return function(type){
        return Descriptor(type);
    };
});