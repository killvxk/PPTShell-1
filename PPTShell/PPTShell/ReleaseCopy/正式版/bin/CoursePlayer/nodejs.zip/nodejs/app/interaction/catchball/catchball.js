/**
 *
 */
define(['app', 'catchball/directive/catchball.directive'], function (app) {
    'use strict';
    app.controller('catchball_ctrl', [
        '$scope', 'skin_service', '$stateParams', 'CustomEditorService', 'UtilsService', '$rootScope', '$filter', '$timeout',
        function ($scope, skin_service, $stateParams, CustomEditorService, UtilsService, $rootScope, $filter, $timeout) {
            $rootScope.moduleScope = $scope;
            $scope.errorModel = {};

            $scope.catchTimesLast = 20;
            $scope.model = {
                "id": "",
                "module_code": "nd_catchball", // 题目类型
                "title": $filter('translate')('catchball.default.title'), //标题
                "skin": {
                    code: "wood",
                    css_url: "",
                    name: $filter('translate')('app.skin.wood'),
                    package_url: "${ref-path}/edu/esp/preparecustomeditor/catchball/wood"
                },
                "timer": {
                    "timer_type": "sequence",  //计时器类型: ["sequence", "countdown"]
                    "time_minute": "0",    //倒计时初始设置-分钟，timer_type="countdown"时有效
                    "time_second": "0"     //倒计时初始设置-秒，timer_type="countdown"时有效
                },
                "properties": [	//模块静态数据模型
                    {
                        "name": "question_id",
                        "display_name": "题目ID",
                        "type": "string",
                        "value": "",
                        "is_localized": false
                    },
                    {
                        "name": "question_url",
                        "display_name": "题目内容",
                        "type": "jsonFile",
                        "value": "",
                        "is_localized": false
                    }
                ],
                "content": {
                    transparent_box: true, //标记盒子是否为透明, true=透明 false=不透明
                    catch_times: $scope.catchTimesLast,       //抓取小球的总次数
                    ball_count: 8,         //小球的总数
                    balls: [
                        {color: 'red', count: 6}, //红色
                        {color: 'yellow', count: 2}, //黄色
                        {color: 'blue', count: null}, //蓝色
                        {color: 'green', count: null} //绿色
                    ]
                }
            };

            //盒子里的球
            $scope.ballCntArray = [6, 2, null, null];
            $scope.insideBoxBalls;
            var BibPosALG = { //盒子内球的摆放算法
                'execute': function () {
                    this.getBoxBalls();
                    this.positioningBalls();
                },
                'getBoxBalls': function () {
                    $scope.insideBoxBalls = [];
                    angular.forEach($scope.model.content.balls, function (ball) {
                        if (ball.count) {
                            for (var i = 0; i < ball.count; i++) {
                                $scope.insideBoxBalls.push({color: ball.color});
                            }
                        }
                    });

                    UtilsService.shuffleArray($scope.insideBoxBalls);
                },
                'positioningBalls': function () {
                    var positionArray = this.generateBallPos();

                    var count = $scope.insideBoxBalls.length;
                    var max_count = 21;
                    var i = 0;
                    while (i * max_count <= count) {
                        var arr = this.getRamdomArr(21);
                        for (var j = 0; j < max_count; j++) {
                            if (i * max_count + j + 1 > count) {
                                break;
                            }
                            var tempP = positionArray[i][arr[j]];
                            var ball = $scope.insideBoxBalls[i * max_count + j];
                            ball.position = {
                                'left': tempP.left + this.getRandom(0, 8) - 4 + 'px',
                                'bottom': tempP.bottom + this.getRandom(0, 4) - 2 + 'px',
                                'z-index': tempP.zIndex
                            };
                        }

                        i++;
                    }
                },
                'generateBallPos': function () {
                    var positionArray = []; //记录所有小球位置的数组
                    var startPoints = [{x: -35, y: 16}, {x: -15, y: 56}, {x: -5, y: 96}];

                    //计算出六十个小球的初始位置
                    for (var k = 0; k < 3; k++) {
                        var tempArr = [];
                        var startP = startPoints[k]; //获取每一层的左下第一个球的初始位置
                        for (var i = 0; i < 3; i++) {
                            startP.x += (k == 0 ? 45 : 35);
                            startP.y += 22;

                            for (var j = 0; j < 7; j++) {
                                var temp = {
                                    left: startP.x + j * 45,
                                    bottom: startP.y - j * 3,
                                    zIndex: 3 - i + k * 3
                                }
                                tempArr.push(temp);
                            }
                        }

                        positionArray.push(tempArr);
                    }

                    return positionArray;
                },
                'getRamdomArr': function (count) { //获取随机数数组
                    var i, l, randomArr = [];
                    for (i = 0 , l = count; i < l; i++) {
                        randomArr[i] = i;
                    }
                    randomArr.sort(function (a, b) {
                        return Math.random() - 0.5;
                    });

                    return randomArr;
                },
                'getRandom': function (a, b) { //获取随机数
                    if (a > b) {
                        var temp = a;
                        a = b;
                        b = temp;
                    }
                    return Math.floor(Math.random() * (b - a ) + a);
                }
            };

            //数据加载
            var loadingData = function (id) {
                $scope.isloadingData = true;
                CustomEditorService.getQuestionInfoById(id)
                    .then(function (rtnData) {
                        if (!rtnData) {
                            $scope.errorModel.errorText = $filter('translate')('app.unvalidno');
                        } else {
                            if (rtnData.skin.code != '') {
                                $scope.model = $scope.decodeData(rtnData, true);
                            } else {
                                $scope.model.id = rtnData.id;
                            }

                            !$scope.model.title && ($scope.model.title = $filter('translate')('catchball.default.title'));//默认标题：设定各颜色小球数量
                            skin_service.set_skin_by_code($scope.model.skin.code, "v1");
                            $scope.errorModel.errorText = "";
                            $scope.isloadingData = false;

                            //BibPosALG.execute();
                        }
                    }, function (error) {
                        $scope.errorModel.errorText = $filter('translate')('app.question.get.error');
                    })
            };

            //入口
            if (!$stateParams.id) { //新增
                skin_service.set_skin_by_code($scope.model.skin.code, "v1");
                //BibPosALG.execute();
            } else { //修改
                loadingData($stateParams.id);
            }

            //数据验证
            $scope.validPostData = function () {

                var isValid = true;
                if ($.trim($scope.model.title) === '') {
                    $scope.errorModel.errorText = $filter('translate')('catchball.no_title');
                    $scope.moduleTitleInvalid = true;

                    isValid = false;

                    $("#moduleTitle").focus();
                } else {
                    $scope.model.content.ball_count = 0;
                    angular.forEach($scope.model.content.balls, function (item, index) {
                        $scope.ballCntArray[index] = item.count;

                        if (item.count > 0) {
                            $scope.model.content.ball_count += item.count;
                        }
                    });

                    if($scope.model.content.ball_count === 0) {
                        $scope.errorModel.errorText = $filter('translate')('catchball.ballscount.invalid');
                        $scope.ballsCountInvalid = true;
                        $timeout(function() {
                            $scope.ballsCountInvalid = false;
                        }, 2500);

                        isValid = false;
                    } else if (!$scope.model.content.catch_times || $scope.model.content.catch_times === 0) {
                        $scope.model.content.catch_times = null;
                        $scope.highlightCatchTime();
                        isValid = false;

                        $("#catchTimesInp").focus();
                    }
                }

                return isValid;
            };

            //数据模型 编码
            $scope.encodeData = function (model) {
//                model.title = window.customHtmlEncode(model.title);

                return model;
            };

            //数据模型 解码
            $scope.decodeData = function (model, isInitLoad) {
//            	model.title = window.customHtmlDecode(model.title);
                $scope.catchTimesLast = model.content.catch_times;
                angular.forEach(model.content.balls, function(ball){
                    ball.isInvalid = false;
                });

                return model;
            };

            //高亮显示
            $scope.highlightBallCount = function(ball) {
                $scope.errorModel.errorText = $filter('translate')('catchball.ballcount.limit');
                ball.isInvalid = true;
                $timeout(function(){ ball.isInvalid = false; }, 2500);
            };

            //高亮提示
            $scope.highlightCatchTime = function() {
                $scope.errorModel.errorText = $filter('translate')('catchball.catchtimes.limit');
                $scope.catchTimesInvalid = true;
                $timeout(function(){ $scope.catchTimesInvalid = false; }, 2500);
            };

            //禁止输入空格
            $scope.onKeypressInput = function(event, ball) {
                if(event.keyCode === 32) {
                    if(ball) {
                        $scope.highlightBallCount(ball);
                    } else {
                        $scope.highlightCatchTime();
                    }
                    event.cancelBubble = true;
                    event.preventDefault();

                    return false;
                }
            };

            $scope.changeBallCount = function (item, index) {
                if(item.count && item.count.match(/\D+/g)) {
                    item.count = toNumber(item.count);
                    $scope.highlightBallCount(item);
                } else if (item.count !== $scope.ballCntArray[index]) {
                    item.count = toNumber(item.count);

                    if (item.count && item.count > 10) {
                        item.count = $scope.ballCntArray[index];
                        $scope.highlightBallCount(item);
                    } else {
                        $scope.ballCntArray[index] = item.count;
                        //BibPosALG.execute();
                    }
                }
            };

            $scope.changeCatchTimes = function (event) {
                if($scope.model.content.catch_times && $scope.model.content.catch_times.match(/\D+/g)) {
                    $scope.model.content.catch_times = $scope.catchTimesLast;
                    $scope.highlightCatchTime();

                    return;
                }

                $scope.model.content.catch_times = toNumber($scope.model.content.catch_times);
                if ($scope.model.content.catch_times === 0) {
                    $scope.model.content.catch_times = null;
                    $scope.highlightCatchTime();
                } else if ($scope.model.content.catch_times > 999) {
                    $scope.model.content.catch_times = $scope.catchTimesLast;
                    $scope.highlightCatchTime();
                } else {
                    $scope.catchTimesLast = $scope.model.content.catch_times;
                }
            };

            $scope.onBoardClick = function(event) {
                var $target = $(event.target);
                if($target.attr('id') === 'toggleBottomBtn') {
                    $scope.bottomHidden = !$scope.bottomHidden;
                } else if(!$target.hasClass('scroll_bottom') && $target.parents('.scroll_bottom').length === 0) {
                    $scope.bottomHidden = true;
                }
            };

            function toNumber(value) {
                if (value) {
                    value = value.replace(/\D/g, '');
                    if (value.length > 0) {
                        value = parseInt(value);
                    }
                }

                return value;
            }
        }
    ]);
});
