/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
], function (
) {
    var servers = {
        coursewareobjectPlayer: 'http://esp-editor.pre1.web.nd',
        cs: 'http://sdpcs.beta.web.sdp.101.com'
    };
    return {
        service: 'http',
        serviceConfig: {
            server: '/'
        },
        coursewareobjectPreview: servers.coursewareobjectPlayer + '/ndplayer/{id}/show?type=coursewareobject&rnd=1452855109479&startPageIndex=0&player-code=wang&_lang_=zh_CN&userId=2107212393&userName=liaolixia&domain=web.nd',
        coursewareobjectTemplateRoot: '/coursewareobject_template/{id}',
        coursewareobjectRoot: servers.cs + '/v0.1/static/prepub_content_edu_product/esp/coursewareobjects/{id}.pkg',
        moduleEditorRoot: 'http://cs.101.com/v0.1/static/esp_developer/modules/{id}/{version}',
        referencePath: servers.cs + '/v0.1/static',
        "supports": {
            "asset": true
        }
    };
});