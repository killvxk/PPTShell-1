/**
 * ccy
 * 
 */
define(['angularAMD'
], function (angularAMD) {
	'use strict';
	var Draggable,
	//__bind用处，当对象相互调用传递方法：如 将a对象的f方法传递给b对象当属性 b={bf:a.f} ; b.bf()的this是b
	//如果 a.f = __bind(a.f,a) ;  b={bf:a.f} ;b.bf()的this是a ;
    __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
    __slice = [].slice;
    Draggable = (function() {

        function Draggable($container, options) {

          this.click = __bind(this.click, this);
          this.moved = __bind(this.moved, this);
          this.ended = __bind(this.ended, this);
          this.began = __bind(this.began, this);
          this.coordinate = __bind(this.coordinate, this);
          this.off = __bind(this.off, this);
          this.on = __bind(this.on, this);
          this.toggle = __bind(this.toggle, this);
          this.bind = __bind(this.bind, this);
          this.$container = $container;
          this.options = angular.extend({},Draggable.DEFAULTS,options);
        
          this.toggle();


        }

        Draggable.DEFAULTS = {
        		"z-index":999,
        		opacity: "0.8",
        		version:"0.01"
        };



        //处理鼠标移动，鼠标键松开事件
        Draggable.prototype.bind = function(method) {
          if (method == null) {
            method = 'on';
          }
          //event.stopPropagation();
          $(document)[method]('mousemove touchmove', this.moved);
          return $(document)[method]('mouseup touchend touchcancel', this.ended);
        };

        Draggable.prototype.toggle = function(method) {
          if (method == null) {
            method = 'on';
          }
//          event.stopPropagation();
          this.$container[method]('mousedown touchstart', this.began);
          return this.$container[method]('click', this.click);
        };

        Draggable.prototype.on = function() {
          return this.toggle('on');
        };

        Draggable.prototype.off = function() {
          return this.toggle('off');
        };

        Draggable.prototype.coordinate = function(event) {
          switch (event.type) {
            case 'touchstart':
            case 'touchmove':
            case 'touchend':
            case 'touchcancel':
              return event.originalEvent.touches[0];
            default:
              return event;
          }
        };
        //鼠标点击开始
        Draggable.prototype.began = function(event) {
        
          var _ref;
          if( (_ref = this.options) != null && typeof _ref.beganStart === "function" ){
        	if(_ref.beganStart(event)===false){
        		return ; 
        	} 
          }
          if (this.$target) {
            return;
          }
          if( this.$container.attr("move-disabled") === 'true' || this.$container.attr("move-disabled") === true ){
        	  return ; 
          }
          event.stopPropagation();
          //event.preventDefault();
          //绑定鼠标移动，鼠标松开事件
          this.bind('on');
          this.$target = this.$container;
          var startPosition= {
        		  x:this.$target[0].offsetLeft , 
        		  y:this.$target[0].offsetTop , 
        		  
          }
          this.$target.css({
        	  position:'absolute',
        	  "z-index" : '99',
        	  left:startPosition.x,
        	  top:startPosition.y
          })
          
          
          this.origin = {
        	  		oPageX :   this.coordinate(event).pageX ,
        	  		oPageY  :  this.coordinate(event).pageY , 
        	        x: this.coordinate(event).pageX - startPosition.x ,
        	        y: this.coordinate(event).pageY - startPosition.y
          };
          
         // console.log("*****ori******"+JSON.stringify(this.origin));
          return (_ref = this.options) != null ? typeof _ref.began === "function" ? _ref.began(event , startPosition) : void 0 : void 0;
        };

        //鼠标拖动
        Draggable.prototype.moved = function(event) {
          //console.log(" Draggable.prototype.moved ...............")
          var _ref;
          if (this.$target == null) {
            return;
          }
          //event.stopPropagation();
          // event.preventDefault();
          var p = {
	        	x :  this.coordinate(event).pageX - this.origin.x, 
	        	y :  this.coordinate(event).pageY - this.origin.y
	      }; 
          
          if( this.options.onlymove ){
        	  if( this.options.onlymove==='x' ){
    	          p.y =  this.$target[0].offsetTop ; 

        	  }else  if( this.options.onlymove==='y' ){
    	          p.x =  this.$target[0].offsetLeft ;
      	  	   
          	  }
          }
          
          //拖动元素的移动范围需在moveRange内
          if(this.options.moveRange){
        	  var xMax = this.options.moveRange.x.max - this.$target.width();
        	  var yMax = this.options.moveRange.y.max - this.$target.height();
	          if( p.x < this.options.moveRange.x.min   ){
	        	  p.x = this.options.moveRange.x.min ; 
	          }else if(  p.x > xMax  ){
	        	  p.x = xMax ; 
	          }
	          if(  p.y < this.options.moveRange.y.min   ){
	        	  p.y =  this.options.moveRange.y.min  ; 
	          }else if( p.y > yMax ){
	        	  p.y = yMax ;
	          }         
          }
          var curPostion = {
         		  x :p.x, 
         	      y :p.y,
         		  addX :this.coordinate(event).pageX - this.origin.oPageX , 
         		  addY :this.coordinate(event).pageY - this.origin.oPageY , 
         	      target: this.$target
          }
          if( this.options.canMove && this.options.canMove(curPostion) === false ) {
        	  return ; 
          }
          if( !this.options.positionByExternal ){
           this.$target.css({
               left: p.x,
               top:  p.y
           });
          }
           
          //当前拖拽的对象
           this.dragged = this.$target;
           
           return (_ref = this.options) != null ? typeof _ref.moved === "function" ? _ref.moved( event , curPostion ) : void 0 : void 0;
         
          
        };

        Draggable.prototype.ended = function(event) {
            var _ref;
            if (this.$target == null) {
              return;
            }
            event.stopPropagation();
            //event.preventDefault();
            var endPosition= {
          		  x:this.$target[0].offsetLeft , 
          		  y:this.$target[0].offsetTop , 
          		  
            }
            console.log("end---------"+endPosition)
            this.bind('off');
            this.$target.removeClass('dragging');
            delete this.$target;

            return (_ref = this.options) != null ? typeof _ref.ended === "function" ? _ref.ended(event,endPosition) : void 0 : void 0;
        };

        Draggable.prototype.click = function(event) {
          if (!this.dragged) {
            return;
          }
          event.stopPropagation();
          //event.preventDefault();
          return delete this.dragged;
        };


        return Draggable;

      })();
    
      function Plugin(option) {

	    	option = option || {} ;
	   
	        var $this   = angular.element(this);

	        var data    = $this.data('my.draggable') ;
	        var options = angular.extend({}, $this.data(), typeof option == 'object' && option)
	          //插件缓存
	        if (!data){
	        	data = new Draggable($this,options) ;
	        	$this.data('my.draggable', data);
	        }

      
     }
	  
    angularAMD.directive('ndDraggable', [ function () {
        return {
			restrict: 'A',
			scope: { options : "=options"},
            link: function(scope, element) {
            	Plugin.apply(element,[scope.options]);
            	
            }
        };
    }]);

});
