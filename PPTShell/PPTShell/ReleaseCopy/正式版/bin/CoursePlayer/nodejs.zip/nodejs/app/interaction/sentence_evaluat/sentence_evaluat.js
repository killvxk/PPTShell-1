/**
 * sentence_evaluat
 * 2015-11-25 16:09:39
 */
define(['app', 'sentence_evaluat/utils','uuid','sentence_evaluat/directive/sentence_evaluat.directive'], function (app,utils,uuid) {
    'use strict';
    app.controller('sentence_evaluat_ctrl', [
        '$scope','$http', 'skin_service', '$stateParams', 'CustomEditorService', '$rootScope', '$filter','sentenceService','$timeout',
        function ($scope, $http,skin_service, $stateParams, CustomEditorService, $rootScope, $filter,sentenceService,$timeout) {
      
            var iframe = document.getElementById('iframepage');
            var messenger =  window.messageIframe.messenger ; 
            window.messageIframe.messenger.addTarget(iframe.contentWindow, 'sentence_evaluat_children');
//
            var audioBlob,  tempRecordAudio ;
            messenger.listen(function (obj) {
                if( obj ){
                    if(  obj.oper === 'complete' ){
                        savaAudioByBlob(obj.blob);
                    }else if( obj.oper === 'start' ){
                        if( obj.errorStatus === 1 ||  obj.errorStatus === 2 ){
                            $scope.errorModel.errorText = $filter('translate')('sentence_evaluat.error.state');
                            $scope.$apply()
                        }
                    }
                }

            });

            function savaAudioByBlob(blob){
                audioBlob =blob ;
                var url = URL.createObjectURL(audioBlob);
                tempRecordAudio = document.createElement('audio');
                tempRecordAudio.controls = false;
                tempRecordAudio.src = url;
                $scope.closeWindow() ;
                $scope.opts.recordWin3 = true ;
                $scope.$apply()
            }

            $rootScope.moduleScope = $scope;
            $scope.errorModel = {};

            $scope.model = {
                "id": "",
                "module_code": "nd_sentence_evaluat", // 题目类型
                "title": "", //标题
                "skin": {
                    code: "wood",
                    css_url: "",
                    name: $filter('translate')('app.skin.wood'),
                    package_url: ""
                },
                "timer": {
                    "timer_type": "sequence",  //计时器类型: ["sequence", "countdown"]
                    "time_minute": "0",    //倒计时初始设置-分钟，timer_type="countdown"时有效
                    "time_second": "0"     //倒计时初始设置-秒，timer_type="countdown"时有效
                },
                "packages": [ // addon 课件打包配置信息，上传依赖外部系统的资源文件

                ],
                "properties": [	//模块静态数据模型
                    {
                        "name": "question_id",
                        "display_name": "题目ID",
                        "type": "string",
                        "value": "",
                        "is_localized": false
                    },
                    {
                        "name": "question_url",
                        "display_name": "题目内容",
                        "type": "jsonFile",
                        "value": "",
                        "is_localized": false
                    }
                ],
                "content": { //Editor数据模型正文
                	sentences:[],//暂时没用
                	units:[],
                	current_unit:'001',
                	show_sentences : [],
                	addSentences:[]
                }
            };

            /**
             * 全局常量
             */
            
            /**
             * 变量
             */
            $scope.opts = {
                recordWin1:false ,
                recordWin2:false ,
                recordWin3:false ,
                recordWin4:false ,
                recordWin5:false,
                startRecord:true,
                cleanSentenceFlag:false

            }
            $scope.opts.recordUrl =  '/interaction/sentence_evaluat/record/record.html';
            //资源文件的限制使用
            $scope.resourceValidParam = {

            };

            $scope.assetResult =  {
                "text": "",       //题干描述
                "asset_type": "", //题干相关素材类型 ["image","video","audio"]
                "asset": ""  ,           //题干相关素材
                "image_extend":{       //旋转，放大缩小等属性，todo：具体属性唐焱鑫补充
                    "rotate":"",
                    "resize":""
                }
            }

            var showContent = $scope.model.content ,  recorder, audioRecord ;
            $scope.errorState = 0 ; // 录音 是否异常 0 不异常， 1 无录音设备支持 2 浏览器不支持getUserMedia方法
            //var USER_ID = $rootScope.token_info.user_id ;
            $scope.showContent = showContent ;

            $scope.addSentence = function(item){
            	if( !item.isAdd ){

	            	item.isAdd = true ;
	            	showContent.addSentences.push(item);
            	}
            }
            //全部句子添加
            $scope.addSentences = function(){
                for(var i=0 ,l = showContent.show_sentences.length; i<l ; i++ ){
                    var item = showContent.show_sentences[i];
                    $scope.addSentence(item);
                }
            }
            $scope.editItem = function( item, index ){

            	item.isEditor = true ;
            	$scope.opts.editorValue = item.sentence ;
            	angular.element("#inputSentenceItem"+index).focus(100);
            }
            //
            $scope.sentencePaste = function(e){
                e.preventDefault();
                var text = null;

                if(window.clipboardData && clipboardData.setData) {
                    // IE
                    text = window.clipboardData.getData('text');
                } else {
                    text = (e.originalEvent || e).clipboardData.getData('text/plain') || prompt('在这里输入文本');
                }
                var textRange ;
                if (document.body.createTextRange) {
                    var sel;
                    if (document.selection) {
                        textRange = document.selection.createRange();
                    } else if (window.getSelection) {
                        sel = window.getSelection();
                        var range = sel.getRangeAt(0);

                        // 创建临时元素，使得TextRange可以移动到正确的位置
                        var tempEl = document.createElement("span");
                        tempEl.innerHTML = "&#FEFF;";
                        range.deleteContents();
                        range.insertNode(tempEl);
                        textRange = document.body.createTextRange();
                        textRange.moveToElementText(tempEl);
                        tempEl.parentNode.removeChild(tempEl);
                    }
                    textRange.text = text;
                    textRange.collapse(false);
                    textRange.select();
                } else {
                    // Chrome之类浏览器
                    document.execCommand("insertText", false, text);
                }
            }
            $scope.editorSentenceItemBlur = function(item,index){
                var $span  =  $("#inputSentence_"+item.id+" span") ;
                var flag = true ;
                if( $span.length === 1 ){
                    $("#inputSentence_"+item.id).html($span.html());
                }

                if( $("#inputSentence_"+item.id).length === 1 ){
                    item.sentence = $("#inputSentence_"+item.id).html();
                }
                item.sentence =  item.sentence.trim();
                var enCharts = ['。','，','？','“','”','‘','’','！','；','：','（','）'] ;
                var cnCharts = ['.',',','?','\"','\"','\'','\'','!',';',':','(',')'] ;
                for(var i = 0, l = enCharts.length ; i< l ; i++ ){
                    item.sentence = item.sentence.replace( new RegExp(enCharts[i], 'g') ,cnCharts[i]);
                }
                item.sentence = item.sentence.replace( / *\n+ */g ,'');
                item.isEditor = false ;
                if( item.sentence === '' ){
                    $scope.errorModel.errorText = $filter('translate')('sentence_evaluat.format.error5');
                    item.isEditor = true ;
                    flag = false ;
                } else if(  /^([a-zA-Z0-9]|[.?!';,\-_+*\\()&^%$#@\s])+$/.test(item.sentence) === false ){
                    $scope.errorModel.errorText = $filter('translate')('sentence_evaluat.format.error');
                    item.isEditor = true ;
                    flag = false ;
                }else if( /.*[.?!]$/.test( item.sentence.trim() ) === false  ){
                    $scope.errorModel.errorText = $filter('translate')('sentence_evaluat.format.error1');
                    item.isEditor = true ;
                    flag = false ;
                }else {
                    var tempArr = item.sentence.split(/[!?,.\s]/) ;
                    var length = tempArr.length ;

                    for( var i = 0,l = tempArr.length ; i<l ; i++){
                        if(tempArr[i] === '' ){
                            length-- ;
                        }
                    }
                    if(length<2 || length>15 ){
                        $scope.errorModel.errorText = $filter('translate')('sentence_evaluat.format.error2');
                        item.isEditor = true ;
                        flag = false ;
                    }else{
                        var same = 0 ;
                        for( var i = 0, l = showContent.addSentences.length ; i<l && item.sentence  ; i++ ){
                            if( item.sentence === showContent.addSentences[i].sentence ){
                                same++ ;
                            }
                        }

                        if( item.sentence  && same === 2){
                            $scope.errorModel.errorText = $filter('translate')('sentence_evaluat.format.error3');
                            item.sentence = '' ;
                            item.isEditor = true ;
                            flag = false ;
                        }
                    }

                }

                if( flag === false  ){
                    sentenceErrorStyle(index) ;
                }

            }

            function sentenceErrorStyle( index ){
                var originBorder =  '2px solid #8f5211';

                var count = 0  ;
                var tempInterval =  setInterval(function(){
                    if( count&1 === 1 ){
                        $('#sentenceList'+index).css({border:'2px solid #e90706'});
                    }else {
                        $('#sentenceList'+index).css({border:'2px solid #8f5211'});
                    }
                    if( count === 6 ){
                        $('#sentenceList'+index).css({border:'2px solid #8f5211'});
                        clearInterval(tempInterval) ;
                    }
                    count++ ;
                },300);
            }

            $scope.dblclickSentence = function(item){
                if( item.isUserAdd ){
                 item.isEditor=true;
                }
            }

            $scope.deleteSentence = function(item){
            	item.isAdd = false ;
            	utils.removeItemByValue(showContent.addSentences ,item);
            }

            $scope.addEmptySentence = function(){
                var item = {
                    "id":uuid.v4(),
                    "isUserAdd":true,
                    "sentence": "",//单词
                    "audio_url": '' ,
                    isEditor:true
                }
                showContent.addSentences.push(item);
                angular.element('#inputSentence_'+item.id).focus(100);
            }

            $scope.deleteSentenceAudio = function(item,index){
                $("#audio"+index)[0].pause();
                item.audio_url = '' ;
                item.audio_name='' ;
            }

            $scope.openRecordWindow = function(){

                $scope.opts.recordWin1=false;
                $scope.opts.recordWin2=true;
                $scope.initIframe();
            }

            //是否清空所有句子弹窗
            $scope.openCleanSentenceWindow = function(){
                if( showContent.addSentences.length === 0 ) return ;
                $scope.opts.cleanSentenceFlag = true ;
            }
            //清空所有句子
            $scope.cleanSentences = function(){
               if( showContent.addSentences.length === 0 ) return ;
               for(var i=0 ,l = showContent.addSentences.length; i<l ; i++ ){
                        if( showContent.addSentences[i].isAdd == true  ){
                            showContent.addSentences[i].isAdd = false ;
                        }
               }
               showContent.addSentences = [];
               $scope.closeWindow();
            }
            //公用关闭窗口方法
            $scope.closeWindow = function( ){
                $scope.opts = $.extend({},$scope.opts,{
                    recordWin1:false ,
                    recordWin2:false ,
                    recordWin3:false ,
                    recordWin4:false ,
                    recordWin5:false ,
                    startRecord:true ,
                    cleanSentenceFlag:false
                });

                $("#iframepage").attr("src", '/interaction/sentence_evaluat/record/record.html') ;
            } ;
            $scope.openWindow1 = function(item){
                //$scope.opts.recordWin1=true;
                $scope.opts.tempItem=item
            }
            //初始化录音iframe弹窗
            $scope.initIframe = function(){
                messenger.targets['sentence_evaluat_children'].send({
                    type:'init',
                    data:$scope.opts.tempItem.sentence
                });
            }

            //播放当前句子录音
            $scope.playAudio = function(index){
                for(var i = 0, l = showContent.addSentences.length ; i<l ; i++  ){
                   if( index !== i && $("#audio"+i).length===1){
                       $("#audio"+i)[0].pause();
                   }
                }
                $("#audio"+index).attr('src', $filter('filterRefPath')( showContent.addSentences[index].audio_url ) )
                $("#audio"+index)[0].play();
            }

            $scope.addAssets = function(type){
                if(  $scope.assetResult.asset ){
                    $scope.opts.tempItem.audio_url = $scope.assetResult.asset;
                    var startIndex = $scope.assetResult.asset.lastIndexOf("/")+1;
                    var title  =  $scope.assetResult.title ;
                    $scope.opts.tempItem.title = title ;
                    if( title.length>30 ){
                        title = title.substr(0,30)+'...'
                    }
                    $scope.opts.tempItem.audio_name =  title;
                    var url =      $scope.opts.tempItem.audio_url ;
                    var same=0 ;
                    var titleSame = 0 ;
                    for( var i = 0, l = showContent.addSentences.length ; i<l  ; i++ ){
                        if( url === showContent.addSentences[i].audio_url ){
                            same++ ;
                        }
                        if( title === showContent.addSentences[i].audio_name ){
                            titleSame++ ;
                        }
                    }
                    if(same>=2 || titleSame>=2){
                        $timeout( function(){
                            $scope.errorModel.errorText = $filter('translate')('sentence_evaluat.format.error4');
                        },550)

                    }
                    $scope.assetResult = {}
                }
            }

            $scope.buttonCallback = {
                previewBefore:function(){

                }
            }

            $scope.tempRecordAudio = function(){
                tempRecordAudio.play();
            } ;
            $scope.sendAudioData = sendForm;


            //数据加载
            var loadingData = function (id) {
                $scope.isloadingData = true;
                CustomEditorService.getQuestionInfoById(id)
                    .then(function (rtnData) {
                        if (!rtnData) {
                            $scope.errorModel.errorText = $filter('translate')('app.unvalidno');
                        } else {
                            if (rtnData.skin.code != '') {
                                $scope.model = $scope.decodeData(rtnData, true);
                            } else {
                                $scope.model.id = rtnData.id;
                            }

                            skin_service.set_skin_by_code($scope.model.skin.code, "v1");
                            getDataFromLc($scope.model.content) ;
                            $scope.errorModel.errorText = "";
                            $scope.isloadingData = false;
                        }
                    }, function (error) {
                        $scope.errorModel.errorText = $filter('translate')('app.question.get.error');
                    })
            };

            //入口
            if (!$stateParams.id) { //新增
                skin_service.set_skin_by_code($scope.model.skin.code, "v1");
                getDataFromLc($scope.model.content) ;
            } else { //修改
                loadingData($stateParams.id);
            }

			$scope.$on('changgedSkin',function(){
                $rootScope.scaleHtml();
            });
            //数据验证
            $scope.validPostData = function () {
                var modelData = $scope.model;

                if($.trim(modelData.title)==''){
                    modelData.title =   $filter('translate')('section_evaluating.placeholder.title') ;
                    //$scope.errorModel.errorText = $filter('translate')('count.notnull.title');
                    //return false ;
                }
                var sentences = modelData.content.addSentences
                if(modelData.content.addSentences.length<=0){
                    $scope.errorModel.errorText =  $filter('translate')('sentence_evaluat.sentences_empty');
                    return false ;
                }
                for(var i =0, l = sentences.length ; i<l ; i++ ){
                    sentences[i].order = i ;
                    if( sentences[i].sentence === '' ){
                        $scope.errorModel.errorText = $filter('translate')('sentence_evaluat.format.error5');
                        sentenceErrorStyle(i) ;
                        return false ;
                    }
                    if( /^([a-zA-Z0-9]|[.?!';,\-_+*\\()&^%$#@\s])+$/.test(sentences[i].sentence) === false ){
                        $scope.errorModel.errorText = $filter('translate')('sentence_evaluat.format.error');
                        sentenceErrorStyle(i) ;
                        return false ;
                    }
                    if( /.*[.?!]$/.test( sentences[i].sentence.trim() ) === false ){
                        $scope.errorModel.errorText = $filter('translate')('sentence_evaluat.format.error1');
                        sentenceErrorStyle(i) ;
                        return false ;
                    }

                    if(  sentences[i].sentence.trim() ){
                        var tempArr = sentences[i].sentence.split(/[!?,.\s]/) ;
                        var length = tempArr.length ;

                        for( var j = 0,jl = tempArr.length ; j<jl ; j++){
                            if(tempArr[j] === '' ){
                                length-- ;
                            }
                        }
                        if(length<2 || length>15 ){
                            $scope.errorModel.errorText = $filter('translate')('sentence_evaluat.format.error2');
                            sentenceErrorStyle(i) ;
                            return false ;
                        }
                    }
                    //录音地址可以为null
                    //if( sentences[i].audio_url.trim().length == 0  ){
                    //    $scope.errorModel.errorText = $filter('translate')('sentence_evaluat.audio.no_null');
                    //    return false ;
                    //}
                }

                var sortSentences = sentences.slice(0).sort(function(a,b){
                    return a.audio_url> b.audio_url? 1:-1 ;
                });
                if( isResetSentenceInArray(sortSentences,'audio_url') === false ){
                    return false ;
                }

                sortSentences = sentences.slice(0).sort(function(a,b){
                    return a.audio_url> b.audio_url? 1:-1 ;
                });
                if( isResetSentenceInArray(sortSentences,'audio_name') === false ){
                    return false ;
                }

                function isResetSentenceInArray(sortSentences,propName){
                    for( var i = 0, l = sortSentences.length - 1 ; i<l ; i++ ){
                        if( sortSentences[i][propName] && ( sortSentences[i][propName] === sortSentences[i+1][propName] ) ){
                            $scope.errorModel.errorText = $filter('translate')('sentence_evaluat.format.error4');
                            sentenceErrorStyle(sortSentences[i].order) ;
                            sentenceErrorStyle(sortSentences[i+1].order) ;
                            return false ;
                        }
                    }
                    return true ;
                }

                return true;
            };

            //数据模型-编码
            $scope.encodeData = function (model) {
                var addSentences  = model.content.addSentences;
            	for( var i = 0 , l = addSentences.length ; i<l ; i++ ){
                    if( addSentences[i].isUserAdd === true ){
                        var tempP={
                            "src": addSentences[i].audio_url,
                            "type": "file"
                        }
                        model.packages.push(tempP);
                    }
            	}
                return model;
            };

            //数据模型-解码
            $scope.decodeData = function (model, isInitLoad) {
            	getDataFromLc(model.content) ;
                showContent = model.content   ;
                $scope.showContent =showContent ;
                return model;
            };

            function getDataFromLc( content ){
                var units = sentenceService.getUnitsByChapter("1");
                if( !content.current_unit ){
                    content.current_unit = units[0].id;
                }
                var sentences =	sentenceService.getSentencesByUnit( content.current_unit );
                content.units = units ;

                for( var i = 0, l = sentences.length ; i<l; i++ ){
                    for( var j = 0, jl =  content.addSentences.length ; j<jl ; j++ ){
                        if( sentences[i].id == content.addSentences[j].id){
                            var temIsAdd = content.addSentences[j].isAdd ;
                            $.extend( content.addSentences[j] ,sentences[i]) ;
                            sentences[i] = content.addSentences[j];
                        }
                    }
                }

                content.show_sentences = sentences ;
            }

            function sendForm() {
                //上传三部曲：第一步1、调用LCMS 上传接口获取session_id ， dist_path上传权限 路径等信息


            }


        }
    ]);
});

