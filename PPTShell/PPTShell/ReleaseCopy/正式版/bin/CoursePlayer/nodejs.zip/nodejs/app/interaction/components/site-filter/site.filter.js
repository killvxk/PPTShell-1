/**
 * Created by px on 2015/6/10.
 */
define(['angularAMD'
], function (angularAMD) {

    var getRefAsset = function ($stateParams, assetPath) {
        if (assetPath) {
            var fromRefBase = false;
            if (assetPath.indexOf('${ref-path}') > -1) {
                assetPath = assetPath.replace('${ref-path}', '');
            } else if(assetPath.indexOf('${ref-base}') > -1) {
                fromRefBase = true;
                assetPath = assetPath.replace('${ref-base}', '');
            } else {
                return assetPath;
            }

            //return "/v0.1/interaction_ref_assets/" + $stateParams.id +
            //    "?from_ref_base=" + fromRefBase +
            //    "&question_base=" + ($stateParams.question_base || '') +
            //    "&filepath=" + assetPath;

            return "/v1.3/assets/get?is_interaction=true" +
                "&from_ref_base=" + fromRefBase +
                "&question_id=" + $stateParams.id +
                "&question_base=" + ($stateParams.question_base || '') +
                "&filepath=" + assetPath;
        }

        return "";
    };

    angularAMD
        .filter('filterGetAPIRouteByWebRoute', ['EnumsRouteQuestionType', function (EnumsRouteQuestionType) {
            return function (input) {
                if (input && EnumsRouteQuestionType[input]) {
                    return EnumsRouteQuestionType[input].api_route;
                } else {
                    return "";
                }
            };
        }])
        .filter('filterGetAPIRouteByWebRouteV2', ['EnumsRouteQuestionType', function (EnumsRouteQuestionType) {
            return function (input) {
                if (input && EnumsRouteQuestionType[input]) {
                    return EnumsRouteQuestionType[input].question_type;
                } else {
                    return "";
                }
            };
        }])
        .filter('filterGetWebRouteByQuestionType', ['EnumsRouteQuestionType', function (EnumsRouteQuestionType) {
            return function (input) {
                if (input) {
                    var webRoute = "";
                    angular.forEach(EnumsRouteQuestionType, function (value, key) {
                        if (value.question_type == input) {
                            webRoute = key;
                        }
                    });
                    return webRoute;
                } else {
                    return "";
                }
            };
        }])
        .filter('filterRefPath', ['$stateParams', function ($stateParams) {
            return function (input) {
                if (input) {

                    return getRefAsset($stateParams, input);
                } else {
                    return "";  //loading.jpg
                }
            };
        }])
        .filter('filterRefPathThumb', ['$stateParams', function ($stateParams) {
            return function (input) {
                if (input) {

                    return getRefAsset($stateParams, input);
                } else {
                    return "";  //loading.jpg
                }
            };
        }])
        .filter('guesswordFilterRefPathThumb', ['$stateParams', function ($stateParams) {
            return function (input) {
                if (input) {

                    return getRefAsset($stateParams, input);
                } else {
                    return "";  //loading.jpg
                }
            };
        }])
        .filter('filterEnumCategory', [function () {
            return function (input) {
                if (input) {
                    return {"image": 'filter.picture', "video": "filter.video", "audio": "filter.audio"}[input];
                } else {
                    return input;
                }
            };
        }])
        .filter('filterPreviewUrl', ['$stateParams', function ($stateParams) {
            return function (rid, param) {
                if (rid) {
                    var mainPath, questionBase = $stateParams.question_base;
                    if (!!questionBase) {
                        questionBase = "file:///" + questionBase.trim();
                        if (questionBase.charAt(questionBase.length - 1) === '/') { //�ⲿ·������"/"
                            mainPath = questionBase + rid + ".pkg/main.xml";
                        } else {
                            mainPath = questionBase + '/' + rid + ".pkg/main.xml";
                        }
                    } else {
                        mainPath = "../userdatas/edu/esp/interaction/" + rid + ".pkg/main.xml";
                    }

                    return (!rid ? '' : [config.editor_host + '/player/index.html?main=' + mainPath,
                        '&player-code=teacher&hidePage=toolbar,footer',
                        '&_lang_=', $stateParams._lang_,
                        '&sys=', $stateParams.sys,
                        '&rnd=', new Date().getTime()].join(''));
                } else {
                    return '';
                }
            };
        }])
        .filter('zeroFill', [function () {
            return function (val) {
                try {
                    val = parseInt(val, 10);
                    if (val < 10 && val > -1) {
                        return "0" + val;
                    } else {
                        return val;
                    }
                } catch (err) {
                    return "0";
                }
            };
        }])
});
