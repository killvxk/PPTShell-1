var AddonThree2DPuzzle_create =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	module.exports = __webpack_require__(1);


/***/ },
/* 1 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _appPresenter = __webpack_require__(2);

	var _appPresenter2 = _interopRequireDefault(_appPresenter);

	exports['default'] = function () {
	  return _appPresenter2['default'];
	};

	module.exports = exports['default'];

/***/ },
/* 2 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenterRun = __webpack_require__(3);

	var _presenterRun2 = _interopRequireDefault(_presenterRun);

	var _presenterSetState = __webpack_require__(33);

	var _presenterSetState2 = _interopRequireDefault(_presenterSetState);

	var _presenterGetState = __webpack_require__(34);

	var _presenterGetState2 = _interopRequireDefault(_presenterGetState);

	var _presenterSetBasePath = __webpack_require__(35);

	var _presenterSetBasePath2 = _interopRequireDefault(_presenterSetBasePath);

	var _presenterDestroy = __webpack_require__(36);

	var _presenterDestroy2 = _interopRequireDefault(_presenterDestroy);

	var _presenterInitViewPrepareLessons = __webpack_require__(37);

	var _presenterGetQuestionInfo = __webpack_require__(38);

	var _presenterGetQuestionInfo2 = _interopRequireDefault(_presenterGetQuestionInfo);

	var _presenterSetPlayerController = __webpack_require__(39);

	var _presenterSetPlayerController2 = _interopRequireDefault(_presenterSetPlayerController);

	var _presenterOnEventReceived = __webpack_require__(40);

	var _presenterOnEventReceived2 = _interopRequireDefault(_presenterOnEventReceived);

	var _presenterPageShow = __webpack_require__(30);

	var _presenterPageShow2 = _interopRequireDefault(_presenterPageShow);

	var _presenterInitViewPrepareLessons2 = _interopRequireDefault(_presenterInitViewPrepareLessons);

	var _presenterRuntime = __webpack_require__(7);

	exports['default'] = {
	  run: _presenterRun2['default'],
	  destroy: _presenterDestroy2['default'],
	  setState: _presenterSetState2['default'],
	  getState: _presenterGetState2['default'],
	  setBasePath: _presenterSetBasePath2['default'],
	  getLengthArray: _presenterInitViewPrepareLessons.getLengthArray,
	  initViewPre: _presenterInitViewPrepareLessons.initViewPre,
	  initViewPrepareLessons: _presenterInitViewPrepareLessons2['default'],
	  getQuestionInfo: _presenterGetQuestionInfo2['default'],
	  setPlayerController: _presenterSetPlayerController2['default'],
	  onEventReceived: _presenterOnEventReceived2['default'],
	  initTeacherMobile: _presenterRuntime.initTeacherMobile,
	  initStudentMobile: _presenterRuntime.initStudentMobile,
	  pageShow: _presenterPageShow2['default']
	};
	module.exports = exports['default'];

/***/ },
/* 3 */
/***/ function(module, exports, __webpack_require__) {

	/**
		* 运行环境下, 初始化Module的方法
		* @param view 运行视图(DOM对象)
		* @param model Module的模型, Key-Value结构
		* @remark 该方法为Module生命周期方法,仅在Module初始化时执行一次
		*/
	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenterLogic = __webpack_require__(4);

	var _presenterLogic2 = _interopRequireDefault(_presenterLogic);

	exports['default'] = function (view, model) {
		(0, _presenterLogic2['default'])(view, model, false);
	};

	module.exports = exports['default'];

/***/ },
/* 4 */
/***/ function(module, exports, __webpack_require__) {

	/* global $ icCreatePlayer */
	/**
	 * Module的逻辑
	 * @param view 视图对象, 根据是否为预览状态传入不同的视图对象
	 * @param model 模型对象
	 * @param isPreview 是否为编辑环境, true=编辑环境, false=运行环境
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _threeManger = __webpack_require__(5);

	var _presenter = __webpack_require__(2);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _EventDocumentEvent = __webpack_require__(12);

	var _EventDocumentEvent2 = _interopRequireDefault(_EventDocumentEvent);

	var _constants = __webpack_require__(6);

	var _runtime = __webpack_require__(7);

	var _runtime2 = _interopRequireDefault(_runtime);

	var _pageShowJs = __webpack_require__(30);

	var _pageShowJs2 = _interopRequireDefault(_pageShowJs);

	exports['default'] = function (view, model, isPreview) {

	    _presenter2['default'].model = model;
	    _presenter2['default'].view = view;
	    // 使用 basePath 替换 view 中的图片 url
	    var $imgs = $(view).find('img');

	    $imgs.each(function () {
	        $(this).attr('src', _presenter2['default'].path + $(this).attr('data-src'));
	    });

	    (0, _threeManger.threeStart)();
	    (0, _EventDocumentEvent2['default'])();
	    //model.question_url={};
	    //model.question_url.content ={};
	    //model.question_url.content.lengthArray = [];
	    //model.question_url.content.lengthArray.push(4)
	};

	module.exports = exports['default'];

/***/ },
/* 5 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});
	exports.threeStart = threeStart;
	exports.addThreeShape = addThreeShape;
	exports.resizeThree = resizeThree;
	exports.destroyThree = destroyThree;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _constants = __webpack_require__(6);

	var _presenter = __webpack_require__(2);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _shapeMatchstick = __webpack_require__(8);

	var _shapeMatchstick2 = _interopRequireDefault(_shapeMatchstick);

	var _UtilsDestroyThreeObjectJs = __webpack_require__(19);

	var _UtilsDestroyThreeObjectJs2 = _interopRequireDefault(_UtilsDestroyThreeObjectJs);

	var renderer;
	var scene;
	var camera;
	var raycaster;
	var intersectObjs;
	var mouse;
	var matchstick;
	var currenAnimate;

	function initThree() {

	  resizeThree();

	  var container = $(_presenter2['default'].view).find('.jigsaw_bd').get(0);
	  _constants.REAL_ESTATE.width = $(container).width();
	  _constants.REAL_ESTATE.height = $(container).height();
	  _constants.REAL_ESTATE.offsetLeft = $(container).offset().left;
	  _constants.REAL_ESTATE.offsetTop = $(container).offset().top;

	  _constants.CONSTRAINT.xmin = -_constants.REAL_ESTATE.width / 2 + 2;
	  _constants.CONSTRAINT.xmax = _constants.REAL_ESTATE.width / 2 - 2;
	  _constants.CONSTRAINT.ymin = -_constants.REAL_ESTATE.height / 2 + 2;
	  _constants.CONSTRAINT.ymax = _constants.REAL_ESTATE.height / 2 - 2;

	  //创建渲染
	  exports.renderer = renderer = new THREE.WebGLRenderer({
	    antialias: true, //抗锯齿
	    alpha: true // apply transparent attribute
	  });
	  renderer.setClearColor(0xFFFFFF, 0);
	  renderer.setSize(_constants.REAL_ESTATE.width, _constants.REAL_ESTATE.height);

	  container.appendChild(renderer.domElement);
	}

	function initScene() {
	  exports.scene = scene = new THREE.Scene();
	}

	function initMatchstick() {
	  "use strict";
	  exports.matchstick = matchstick = new _shapeMatchstick2['default']();
	};

	function initCamera() {
	  //创建Camera
	  var RATIO = 2;
	  exports.camera = camera = new THREE.OrthographicCamera(_constants.REAL_ESTATE.width / -RATIO, _constants.REAL_ESTATE.width / RATIO, _constants.REAL_ESTATE.height / RATIO, _constants.REAL_ESTATE.height / -RATIO, -20000, 20000);
	  camera.position.x = 0;
	  camera.position.y = 0;
	  camera.position.z = 500;
	  camera.lookAt({ x: 0, y: 0, z: 0 });
	}

	function initRaycaster() {
	  //添加点击检测
	  exports.raycaster = raycaster = new THREE.Raycaster();
	  raycaster.linePrecision = 1;

	  exports.intersectObjs = intersectObjs = new Array();
	  exports.mouse = mouse = new THREE.Vector2();
	}

	function initControllerTool() {
	  var planeXY = new THREE.Mesh(new THREE.PlaneBufferGeometry(_constants.REAL_ESTATE.width, _constants.REAL_ESTATE.height, 2, 2), new THREE.MeshBasicMaterial({ color: 0xff0000, transparent: true, opacity: 0 }));
	  planeXY.name = 'boundary';
	  scene.add(planeXY);
	}

	function animate() {
	  currenAnimate = requestAnimationFrame(animate);
	  render();
	}

	function render() {
	  renderer.render(scene, camera);
	}

	function threeStart() {
	  initThree();
	  initCamera();
	  initScene();
	  initRaycaster();
	  animate();
	  initControllerTool();
	  initMatchstick();
	  var light = new THREE.DirectionalLight();
	  light.position.set(2, 5, 3);scene.add(light);
	}

	function addThreeShape(length, position) {
	  var group = matchstick.createShape(length, position);
	  scene.add(group);
	}

	function resizeThree(width, height) {

	  var offset = $(_presenter2['default'].view).find('.jigsaw_bd').offset();
	  "use strict";

	  _constants.REAL_ESTATE.offsetLeft = offset.left;
	  _constants.REAL_ESTATE.offsetTop = offset.top;
	}

	function destroyThree() {
	  (0, _UtilsDestroyThreeObjectJs2['default'])(camera);
	  (0, _UtilsDestroyThreeObjectJs2['default'])(scene);
	  (0, _UtilsDestroyThreeObjectJs2['default'])(renderer);
	  $(renderer.domElement).remove();
	  $(renderer.domElement).splice(0);
	  $(renderer.domElement)[0] = null;
	  exports.renderer = renderer = null;
	  exports.camera = camera = null;
	  exports.mouse = mouse = null;
	  exports.scene = scene = null;
	  exports.raycaster = raycaster = null;
	  exports.intersectObjs = intersectObjs = null;
	  cancelAnimationFrame(currenAnimate);
	}

	exports.renderer = renderer;
	exports.scene = scene;
	exports.camera = camera;
	exports.raycaster = raycaster;
	exports.intersectObjs = intersectObjs;
	exports.mouse = mouse;
	exports.matchstick = matchstick;

/***/ },
/* 6 */
/***/ function(module, exports, __webpack_require__) {

	/* global $ */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});
	exports.getRotationMaterial = getRotationMaterial;
	exports.getMoveMaterial = getMoveMaterial;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _runtime = __webpack_require__(7);

	var _runtime2 = _interopRequireDefault(_runtime);

	var _presenter = __webpack_require__(2);

	var _presenter2 = _interopRequireDefault(_presenter);

	// 定义 addon 的可活动大小
	var REAL_ESTATE = {
	  width: 776,
	  height: 487,
	  offsetLeft: 199.328125,
	  offsetTop: 57.53125
	  ////备课端
	  //width: 676.948,
	  //height: 420.875,
	  //offsetLeft: 248.484375,
	  //offsetTop: 618.90625

	};
	exports.REAL_ESTATE = REAL_ESTATE;
	// 定义快捷工具栏的高度
	var TOOLBAR_HEIGHT = 48;
	exports.TOOLBAR_HEIGHT = TOOLBAR_HEIGHT;
	// 定义几何图形的可活动范围
	var CONSTRAINT = {
	  xmin: -REAL_ESTATE.width / 2 + 2,
	  xmax: REAL_ESTATE.width / 2 - 2,
	  ymin: -REAL_ESTATE.height / 2 + 2,
	  ymax: REAL_ESTATE.height / 2 - 2
	};

	exports.CONSTRAINT = CONSTRAINT;
	// 旋转按钮的大小
	var ROTATE_HANDLER_RADIUS = 10;

	exports.ROTATE_HANDLER_RADIUS = ROTATE_HANDLER_RADIUS;
	// 定义所有的操作类型
	var ACTION_TYPE = {
	  move: 'move',
	  rotate: 'rotate',
	  connect: 'connect',
	  split: 'split',
	  close: 'close',
	  stretching: 'stretching',
	  transform: 'transform'
	};

	exports.ACTION_TYPE = ACTION_TYPE;
	var callNativePath = 'com.nd.pad.icr.ui.IcrJsBridge';

	exports.callNativePath = callNativePath;
	var initType = {
	  TEACHER: 'teacher',
	  STUDENT: 'student'
	};

	exports.initType = initType;
	var addonName = 'Puzzle';
	exports.addonName = addonName;
	var isTeacherMobile = window.icCreatePlayer && _runtime2['default'] === window.icCreatePlayer.RUNTIME.TEACHER_MOBILE;
	exports.isTeacherMobile = isTeacherMobile;
	var isStudentMobile = window.icCreatePlayer && _runtime2['default'] === window.icCreatePlayer.RUNTIME.STUDENT_MOBILE;
	exports.isStudentMobile = isStudentMobile;
	var isProjectionMobile = window.icCreatePlayer && _runtime2['default'] === window.icCreatePlayer.RUNTIME.PROJECTION_MOBILE;
	exports.isProjectionMobile = isProjectionMobile;
	var isWeb = window.icCreatePlayer && _runtime2['default'] === window.icCreatePlayer.RUNTIME.WEB;
	exports.isWeb = isWeb;
	var isTeacherPc = window.icCreatePlayer && _runtime2['default'] === window.icCreatePlayer.RUNTIME.TEACHER_PC;

	exports.isTeacherPc = isTeacherPc;
	//画旋转图标
	var rotationMaterial = undefined;

	function getRotationMaterial() {
	  if (!rotationMaterial) {
	    var loader = new THREE.TextureLoader();
	    loader.setCrossOrigin('anonymous');
	    var texture = loader.load(_presenter2['default'].path + 'resources/rotation.png');
	    rotationMaterial = new THREE.MeshBasicMaterial({ map: texture, transparent: true });
	  }
	  return rotationMaterial;
	}

	//画移动图标
	var moveMaterial = undefined;

	function getMoveMaterial() {
	  if (!moveMaterial) {
	    var loader = new THREE.TextureLoader();
	    loader.setCrossOrigin('anonymous');
	    var texture = loader.load(_presenter2['default'].path + 'resources/move.png');
	    moveMaterial = new THREE.MeshBasicMaterial({ map: texture, transparent: true });
	  }
	  return moveMaterial;
	}

/***/ },
/* 7 */
/***/ function(module, exports, __webpack_require__) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	exports.initTeacherMobile = initTeacherMobile;
	exports.initStudentMobile = initStudentMobile;
	exports.initProjectionMobile = initProjectionMobile;
	exports.initWeb = initWeb;
	exports.initTeacherPc = initTeacherPc;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }

	var _presenter = __webpack_require__(2);

	var _presenter2 = _interopRequireDefault(_presenter);

	function initTeacherMobile() {
	    _presenter2["default"].isTeacherMobile = true;
	}

	;

	function initStudentMobile() {
	    "use strict";
	    _presenter2["default"].isStudentMobile = true;
	}

	;

	function initProjectionMobile() {
	    _presenter2["default"].isProjectionMobile = true;
	}

	;

	function initWeb() {
	    "use strict";
	    _presenter2["default"].isWeb = true;
	}

	;

	function initTeacherPc() {
	    _presenter2["default"].isTeacherPc = true;
	}

	;

	exports["default"] = {
	    initTeacherMobile: initTeacherMobile,
	    initStudentMobile: initStudentMobile,
	    initProjectionMobile: initProjectionMobile,
	    initWeb: initWeb,
	    initTeacherPc: initTeacherPc
	};

/***/ },
/* 8 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

	var _EventMoveJs = __webpack_require__(9);

	var _EventMoveJs2 = _interopRequireDefault(_EventMoveJs);

	var _constants = __webpack_require__(6);

	var _threeMangerJs = __webpack_require__(5);

	var _EventDocumentEventJs = __webpack_require__(12);

	var Matchstick = (function () {
		function Matchstick() {
			var width = arguments.length <= 0 || arguments[0] === undefined ? 100 : arguments[0];
			var height = arguments.length <= 1 || arguments[1] === undefined ? 10 : arguments[1];
			var radius = arguments.length <= 2 || arguments[2] === undefined ? _constants.ROTATE_HANDLER_RADIUS : arguments[2];

			_classCallCheck(this, Matchstick);

			this.width = width;
			this.height = height;
			this.radius = radius;
			this.y = 0;
			this.stickFaceMaterial = new THREE.MeshBasicMaterial({
				color: 0xE8DCCB,
				transparent: false,
				opacity: 1
			});
			this.stickFaceMaterial2 = new THREE.MeshBasicMaterial({
				color: 0xE6D6C0,
				transparent: false,
				opacity: 1
			});

			this.stickFaceMaterial3 = new THREE.MeshBasicMaterial({
				color: 0xDEC6A6,
				transparent: false,
				opacity: 1
			});

			this.stickFaceMaterial4 = new THREE.MeshBasicMaterial({
				color: 0xD8B98F,
				transparent: false,
				opacity: 1
			});

			this.matchFaceMaterial = new THREE.MeshBasicMaterial({
				color: 0x3E8BA8,
				transparent: false,
				opacity: 1
			});

			this.sMatchFaceMaterial = new THREE.MeshBasicMaterial({
				color: 0x6ED1F7,
				transparent: false,
				opacity: 1
			});
			this.oMatchFaceMaterial = new THREE.MeshBasicMaterial({
				color: 0xFAD35B,
				transparent: false,
				opacity: 1
			});
			this.hMatchFaceMaterial = new THREE.MeshBasicMaterial({
				transparent: true,
				opacity: 0
			});
		}

		// 获取棍子的面材质

		_createClass(Matchstick, [{
			key: 'getStickFaceMaterial',
			value: function getStickFaceMaterial() {
				return this.stickFaceMaterial;
			}

			// 获取棍子的面材质
		}, {
			key: 'getStickFaceMaterial2',
			value: function getStickFaceMaterial2() {
				return this.stickFaceMaterial2;
			}

			// 获取棍子的面材质
		}, {
			key: 'getStickFaceMaterial3',
			value: function getStickFaceMaterial3() {
				return this.stickFaceMaterial3;
			}

			// 获取棍子的面材质
		}, {
			key: 'getStickFaceMaterial4',
			value: function getStickFaceMaterial4() {
				return this.stickFaceMaterial4;
			}

			// 获取火柴的面材质
		}, {
			key: 'getMatchFaceMaterial',
			value: function getMatchFaceMaterial() {
				return this.matchFaceMaterial;
			}

			// 获取火柴的面选中材质
		}, {
			key: 'getSMatchFaceMaterial',
			value: function getSMatchFaceMaterial() {
				return this.sMatchFaceMaterial;
			}

			//获取火柴面操作材质
		}, {
			key: 'getOMatchFaceMaterial',
			value: function getOMatchFaceMaterial() {
				return this.oMatchFaceMaterial;
			}

			//获取火柴面操作材质
		}, {
			key: 'getHMatchFaceMaterial',
			value: function getHMatchFaceMaterial() {
				return this.hMatchFaceMaterial;
			}

			// 获取棍子
		}, {
			key: 'getStickShape',
			value: function getStickShape() {
				var width = arguments.length <= 0 || arguments[0] === undefined ? this.width : arguments[0];
				var height = arguments.length <= 1 || arguments[1] === undefined ? this.height : arguments[1];

				var stick = new THREE.Shape();
				var halfWidth = width / 2;
				var halfHeight = height / 2;
				stick.moveTo(-halfWidth, -halfHeight);
				stick.lineTo(halfWidth, -halfHeight);
				stick.lineTo(halfWidth, halfHeight);
				stick.lineTo(-halfWidth, halfHeight);
				stick.moveTo(-halfWidth, -halfHeight);

				return {
					stick: stick,
					halfWidth: halfWidth
				};
			}

			// 获取火柴
		}, {
			key: 'getMatchShape',
			value: function getMatchShape() {
				var match = new THREE.Shape();
				for (var i = 0; i < 64; i++) {
					var r = this.radius;
					var theta = i / 64 * Math.PI * 2;
					if (i == 0) {
						match.moveTo(r * Math.sin(theta), r * Math.cos(theta));
					} else {
						match.lineTo(r * Math.sin(theta), r * Math.cos(theta));
					}
				}
				return match;
			}

			// 获取火柴
		}, {
			key: 'getMatchBound',
			value: function getMatchBound() {
				var match = new THREE.Shape();
				for (var i = 0; i < 64; i++) {
					var r = this.radius + 3;
					var theta = i / 64 * Math.PI * 2;
					if (i == 0) {
						match.moveTo(r * Math.sin(theta), r * Math.cos(theta));
					} else {
						match.lineTo(r * Math.sin(theta), r * Math.cos(theta));
					}
				}
				return match;
			}

			// 将火柴与棍子组合，创建火柴棍
		}, {
			key: 'createShape',
			value: function createShape() {
				var length = arguments.length <= 0 || arguments[0] === undefined ? 1 : arguments[0];
				var position = arguments.length <= 1 || arguments[1] === undefined ? new THREE.Vector2(0, 0) : arguments[1];

				this.width = length * 20;
				var group = new THREE.Object3D();

				var stick1 = this.getStickShape(this.width, this.height / 8).stick;
				var stick2 = this.getStickShape(this.width, this.height / 4).stick;
				var stick3 = this.getStickShape(this.width, this.height / 2).stick;
				var stick4 = this.getStickShape().stick;
				var match = this.getMatchShape();
				var matchBound = this.getMatchBound();

				var stickGeometry = new THREE.ShapeGeometry(stick1, {});
				var stickGeometry2 = new THREE.ShapeGeometry(stick2, {});
				var stickGeometry3 = new THREE.ShapeGeometry(stick3, {});
				var stickGeometry4 = new THREE.ShapeGeometry(stick4, {});
				var matchGeometry = new THREE.ShapeGeometry(match, {});
				var matchBoundGeometry = new THREE.ShapeGeometry(matchBound, {});

				var stickFace = new THREE.Mesh(stickGeometry, this.getStickFaceMaterial());
				var stickFace2 = new THREE.Mesh(stickGeometry2, this.getStickFaceMaterial2());
				var stickFace3 = new THREE.Mesh(stickGeometry3, this.getStickFaceMaterial3());
				var stickFace4 = new THREE.Mesh(stickGeometry4, this.getStickFaceMaterial4());
				var leftMatchFace = new THREE.Mesh(matchGeometry, this.getMatchFaceMaterial());
				var rightMatchFace = new THREE.Mesh(matchGeometry, this.getMatchFaceMaterial());
				var leftMatchLine = new THREE.Line(matchBoundGeometry, this.getOMatchFaceMaterial());
				var rightMatchLine = new THREE.Line(matchBoundGeometry, this.getOMatchFaceMaterial());

				leftMatchFace.position.x = -this.width / 2;
				rightMatchFace.position.x = this.width / 2;

				leftMatchLine.visible = false;
				rightMatchLine.visible = false;

				stickFace.name = 'stick3';
				stickFace.userData.height = this.height / 6;
				stickFace.position.z = 0.09;
				stickFace2.name = 'stick2';
				stickFace2.userData.height = this.height / 4;
				stickFace2.position.z = 0.08;
				stickFace3.name = 'stick1';
				stickFace3.userData.height = this.height / 2;
				stickFace3.position.z = 0.07;
				stickFace4.name = 'stick';
				stickFace4.userData.height = this.height;
				leftMatchFace.name = 'match1';
				rightMatchFace.name = 'match2';
				leftMatchLine.name = 'line1';
				rightMatchLine.name = 'line2';
				leftMatchFace.position.z = 0.1;
				rightMatchFace.position.z = 0.1;

				// 添加属性判断是否与其他点连接
				leftMatchFace.userData.linkState = false;
				// 添加属性以便方便取到同一根棍子的另一个端点
				leftMatchFace.userData.connectId = rightMatchFace.id;
				rightMatchFace.userData.linkState = false;
				rightMatchFace.userData.connectId = leftMatchFace.id;

				// 添加长宽半径属性到父对象
				group.userData.width = this.width;
				group.userData.height = this.height;
				group.userData.radius = this.radius;
				group.name = 'unit';
				group.add(stickFace);
				group.add(stickFace2);
				group.add(stickFace3);
				group.add(stickFace4);
				group.add(leftMatchFace);
				group.add(rightMatchFace);
				leftMatchFace.add(leftMatchLine);
				rightMatchFace.add(rightMatchLine);
				(0, _EventDocumentEventJs.setSelectedShape)(stickFace4);
				(0, _EventDocumentEventJs.setActivedObj)(null);

				// this.y += 20;
				_threeMangerJs.intersectObjs.push(stickFace4);
				_threeMangerJs.intersectObjs.push(leftMatchFace);
				_threeMangerJs.intersectObjs.push(rightMatchFace);
				(0, _EventMoveJs2['default'])(group, position);
				return group;
			}
		}]);

		return Matchstick;
	})();

	exports['default'] = Matchstick;
	module.exports = exports['default'];

/***/ },
/* 9 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/12/11.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});
	exports['default'] = move;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _UtilsUpdateVerticesJs = __webpack_require__(10);

	var _UtilsUpdateVerticesJs2 = _interopRequireDefault(_UtilsUpdateVerticesJs);

	function move(object, distance) {
	  "use strict";
	  if (object.name === 'unit') {
	    var match1 = object.getObjectByName('match1');
	    var match2 = object.getObjectByName('match2');
	    match1.userData.position = new THREE.Vector2().addVectors(match1.position, distance);
	    match2.userData.position = new THREE.Vector2().addVectors(match2.position, distance);
	    (0, _UtilsUpdateVerticesJs2['default'])(object);
	  } else if (object.name === 'collection') {
	    var _iteratorNormalCompletion = true;
	    var _didIteratorError = false;
	    var _iteratorError = undefined;

	    try {
	      for (var _iterator = object.children[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
	        var stick = _step.value;

	        move(stick, distance);
	      }
	    } catch (err) {
	      _didIteratorError = true;
	      _iteratorError = err;
	    } finally {
	      try {
	        if (!_iteratorNormalCompletion && _iterator['return']) {
	          _iterator['return']();
	        }
	      } finally {
	        if (_didIteratorError) {
	          throw _iteratorError;
	        }
	      }
	    }
	  } else if (object.name === 'moveImage' || object.name === 'rotationImage') {
	    var position = new THREE.Vector2().addVectors(object.position, distance);
	    object.position.x = position.x;
	    object.position.y = position.y;
	  }
	}

	module.exports = exports['default'];

/***/ },
/* 10 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/12/11.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	var _GetAngleJs = __webpack_require__(11);

	/**
	 * 更新小棒位置
	 * @param stick
	 */

	exports['default'] = function (matchstick) {
	  "use strict";
	  if (matchstick.name !== 'unit') return;
	  var match1 = matchstick.getObjectByName('match1');
	  var match2 = matchstick.getObjectByName('match2');
	  var point1 = match1.userData.position || match1.position;
	  var point2 = match2.userData.position || match2.position;

	  match1.position.x = point1.x;
	  match1.position.y = point1.y;
	  match2.position.x = point2.x;
	  match2.position.y = point2.y;

	  var _iteratorNormalCompletion = true;
	  var _didIteratorError = false;
	  var _iteratorError = undefined;

	  try {
	    for (var _iterator = matchstick.children[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
	      var stick = _step.value;

	      updateStick(stick, point1, point2);
	    }
	  } catch (err) {
	    _didIteratorError = true;
	    _iteratorError = err;
	  } finally {
	    try {
	      if (!_iteratorNormalCompletion && _iterator['return']) {
	        _iterator['return']();
	      }
	    } finally {
	      if (_didIteratorError) {
	        throw _iteratorError;
	      }
	    }
	  }
	};

	function updateStick(stick, point1, point2) {
	  "use strict";
	  if (stick.name.indexOf('stick') < 0) return;
	  var length = stick.userData.height / 2;

	  var vector1 = (0, _GetAngleJs.rotationAngleVector)(point2, point1, 90, true).vector.setLength(length);
	  var vector2 = (0, _GetAngleJs.rotationAngleVector)(point2, point1, 90, false).vector.setLength(length);
	  var vertices = [];
	  vertices.push(new THREE.Vector2().addVectors(point1, vector2));
	  vertices.push(new THREE.Vector2().addVectors(point2, vector2));
	  vertices.push(new THREE.Vector2().addVectors(point2, vector1));
	  vertices.push(new THREE.Vector2().addVectors(point1, vector1));
	  var orgVertices = stick.geometry.vertices;
	  for (var i = 0; i < orgVertices.length; i++) {
	    orgVertices[i].x = vertices[i].x;
	    orgVertices[i].y = vertices[i].y;
	  }
	  stick.geometry.verticesNeedUpdate = true;
	  stick.geometry.computeBoundingSphere();
	}
	module.exports = exports['default'];

/***/ },
/* 11 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by ChengChangXiong on 2015/11/19.
	 */

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	exports.getAngle = getAngle;
	exports.getVectorAngle = getVectorAngle;
	exports.getTriangleAngle = getTriangleAngle;
	exports.twoPointDistance = twoPointDistance;
	exports.rotationObj = rotationObj;
	exports.combiningPoints = combiningPoints;
	exports.triangleCombinedPoint = triangleCombinedPoint;
	exports.quadrilateralCombinedPoint = quadrilateralCombinedPoint;
	exports.closedGraphCombiningPoint = closedGraphCombiningPoint;
	exports.quadrilateralDiagonalMove = quadrilateralDiagonalMove;
	exports.quadrilateralOppositeMove = quadrilateralOppositeMove;
	exports.rotationAngleVector = rotationAngleVector;
	exports.movingBoundaryDetermination = movingBoundaryDetermination;
	exports.rotationBoundaryJudgment = rotationBoundaryJudgment;
	exports.graphicalRotationBoundaryJudgment = graphicalRotationBoundaryJudgment;

	var _constants = __webpack_require__(6);

	/*
	 first_p：起点坐标，center_p：端点坐标，second_p：末点
	 */

	function getAngle(first_p, center_p, second_p) {
	    var v_ao = new THREE.Vector2().subVectors(first_p, center_p);
	    var v_bo = new THREE.Vector2().subVectors(second_p, center_p);
	    return getVectorAngle(v_ao, v_bo);
	}

	function getVectorAngle(vector1, vector2) {
	    "use strict";
	    var dx1 = undefined,
	        dx2 = undefined,
	        dy1 = undefined,
	        dy2 = undefined,
	        angle = undefined,
	        abs = undefined;
	    dx1 = vector1.x;
	    dy1 = vector1.y;
	    dx2 = vector2.x;
	    dy2 = vector2.y;
	    var c = Math.sqrt(dx1 * dx1 + dy1 * dy1) * Math.sqrt(dx2 * dx2 + dy2 * dy2);
	    if (c == 0) return -1;
	    abs = (dx1 * dx2 + dy1 * dy2) / c;
	    if (abs < 0 && Math.abs(abs) > 1) {
	        //当abs>且是负数的时候，向量方向相反重合，为180°
	        return 180;
	    }
	    if (Math.abs(abs) > 1) {
	        //当abs>1且是正数数的时候，向量方向一致且重合，为0°
	        return 0;
	    }
	    angle = Math.acos((dx1 * dx2 + dy1 * dy2) / c) * 180 / Math.PI;

	    var isClockWise = vector1.x * vector2.y - vector1.y * vector2.x < 0;

	    return {
	        //弧度
	        angle: angle * Math.PI / 180,

	        //second_p相对于first_p顺逆时针，true标示顺时针
	        clockWise: isClockWise,

	        //角度
	        angleValue: angle
	    };
	}

	/** 三角形传入边长A,B,C  返回边A，B的夹角 */

	function getTriangleAngle(lengthA, lengthB, lengthC) {

	    var sumPowOfThreeLines = Math.pow(lengthA, 2) + Math.pow(lengthB, 2) - Math.pow(lengthC, 2);
	    var cosLineABangle = sumPowOfThreeLines / (2 * lengthA * lengthB);
	    var lineABangle = Math.acos(cosLineABangle) * 180 / Math.PI;

	    return lineABangle;
	}

	//计算两点的距离（四舍五入取整）

	function twoPointDistance(firstPoint, secondPoint) {
	    var squareSum = Math.pow(firstPoint.x - secondPoint.x, 2) + Math.pow(firstPoint.y - secondPoint.y, 2);
	    return Math.sqrt(squareSum);
	}

	/**
	 * 方法：旋转后返回的对象包括，弧度，角度，顺逆时针
	 * @param startPoint 连接旋转点，需要旋转到合并点的端点
	 * @param rotationPoint 旋转点，取三角形不动那条边的左端点
	 * @param datumPoint 取三角形不动那条边的右端点
	 * @param auxiliaryPoint 连接右端点（非旋转点）的那条边，需要旋转到合并点的端点
	 */

	function rotationObj(startPoint, triangleLetfPoint, triangleRightPoint, auxiliaryPoint) {

	    //let combinPot = combiningPoint(startPoint, triangleLetfPoint, triangleRightPoint, auxiliaryPoint);
	    var combinObj = combiningPoint(startPoint, triangleLetfPoint, triangleRightPoint, auxiliaryPoint);
	    if (combinObj == null) return null;
	    var combinPot = combinObj.sameDirPoint;

	    var letfPointObj = getAngle(startPoint, triangleLetfPoint, combinPot);
	    var rightPointObj = getAngle(auxiliaryPoint, triangleRightPoint, combinPot);

	    return {
	        leftRotation: letfPointObj,
	        rightRotation: rightPointObj
	    };
	}

	/**
	 * 方法：计算非闭合图形，合并点的坐标....
	 * @param startPoint 连接旋转点，需要旋转到合并点的端点
	 * @param rotationPoint 旋转点，取三角形不动那条边的左端点
	 * @param datumPoint 取三角形不动那条边的右端点
	 * @param auxiliaryPoint 连接右端点（非旋转点）的那条边，需要旋转到合并点的端点
	 */

	function combiningPoints(startPoint, rotationPoint, datumPoint, auxiliaryPoint) {

	    //基准的边长，即三角形不动的那条边
	    var lengthA = twoPointDistance(datumPoint, rotationPoint);

	    //旋转点上，需移动到结合点的边长
	    var lengthB = twoPointDistance(startPoint, rotationPoint);
	    var lengthC = twoPointDistance(auxiliaryPoint, datumPoint);

	    //判断如果不能组成三角形，直接返回
	    if (lengthA + lengthB <= lengthC || Math.abs(lengthA - lengthB) >= lengthC) return null;

	    //组合成三角形的角度
	    var endAngle = getTriangleAngle(lengthA, lengthB, lengthC);
	    var angleObj = getAngle(datumPoint, rotationPoint, startPoint);

	    var sameDirVectorObj = rotationAngleVector(datumPoint, rotationPoint, endAngle, angleObj.clockWise);
	    var sameDirVector = sameDirVectorObj.vector.setLength(lengthB);
	    var samePoint = new THREE.Vector2().addVectors(rotationPoint, sameDirVector);

	    var differentDirVectorObj = rotationAngleVector(datumPoint, rotationPoint, endAngle, !angleObj.clockWise);
	    var differentDirVector = differentDirVectorObj.vector.setLength(lengthB);
	    var differentPoint = new THREE.Vector2().addVectors(rotationPoint, differentDirVector);

	    return {
	        sameDirPoint: samePoint,
	        differentDirPoint: differentPoint,
	        clockwise: angleObj.clockWise
	    };
	}

	/**
	 * 方法：计算三角形结合点
	 * @param startPoint 连接旋转点，需要旋转到合并点的端点
	 * @param triangleLetfPoint 不动边的左端点
	 * @param triangleRightPoint 不动边的右端点
	 * @param auxiliaryPoint 连接右端点（非旋转点）的那条边，需要旋转到合并点的端点
	 */

	function triangleCombinedPoint(startPoint, triangleLetfPoint, triangleRightPoint, auxiliaryPoint) {

	    var combinObj = combiningPoints(startPoint, triangleLetfPoint, triangleRightPoint, auxiliaryPoint);
	    if (combinObj == null) return null;
	    return combinObj.sameDirPoint;
	}

	/**
	 * 方法：计算四边形结合点
	 * @param startPoint 连接旋转点，需要旋转到合并点的相对（结合点和fixedPoint连线）左端点
	 * @param quadrilateralLetfPoint 不动边的左端点
	 * @param quadrilateralRightPoint 不动边的右端点
	 * @param auxiliaryPoint 连接右端点（非旋转点）的那条边，需要旋转到合并点的端点
	 * @param fixedPoint 两条不动边的交点.
	 */

	function quadrilateralCombinedPoint(startPoint, quadrilateralLetfPoint, quadrilateralRightPoint, auxiliaryPoint, fixedPoint) {

	    var combinObj = combiningPoints(startPoint, quadrilateralLetfPoint, quadrilateralRightPoint, auxiliaryPoint);
	    if (combinObj == null) return null;

	    var angleObj = getAngle(quadrilateralRightPoint, quadrilateralLetfPoint, fixedPoint);
	    var combinPoint = combinObj.clockwise == angleObj.clockWise ? combinObj.differentDirPoint : combinObj.sameDirPoint;
	    return combinPoint;
	}

	/**
	 * 方法：鼠标移动后，对角线两侧对应变化的点
	 * @param originalVertexPoint 连接旋转点，需要旋转到合并点的相对（结合点和fixedPoint连线）左端点
	 * @param fixedPoint 不动边的左端点
	 * @param originalDatumPoint 不动边的右端点
	 * @param movePoint 连接右端点（非旋转点）的那条边，需要旋转到合并点的端点
	 * @param lengthB 连接originalVertexPoint的边长
	 * @param lengthC 连接movePoint的那条边长
	 */

	function closedGraphCombiningPoint(originalVertexPoint, fixedPoint, originalDatumPoint, movePoint, lengthB, lengthC) {

	    //即移动那条边长
	    var lengthA = twoPointDistance(movePoint, fixedPoint);

	    //判断如果不能组成三角形，直接返回
	    if (lengthA + lengthB <= lengthC || Math.abs(lengthA - lengthB) >= lengthC) return null;

	    //开始的角度
	    var angleObj = getAngle(movePoint, fixedPoint, originalVertexPoint);
	    var endAngle = getTriangleAngle(lengthA, lengthB, lengthC);

	    var combinVectorObj = rotationAngleVector(movePoint, fixedPoint, endAngle, angleObj.clockWise);
	    var combinVector = combinVectorObj.vector.setLength(lengthB);
	    var combinPoint = new THREE.Vector2().addVectors(fixedPoint, combinVector);
	    return combinPoint;
	}

	/**
	 * 方法：计算四边形对角线拖动后，对角线两侧对应变化的两个端点坐标
	 * @param originalLeftVertexPoint 相对于拖动对角线的左端点
	 * @param fixedPoint 固定不动的点
	 * @param originalRightVertexPoint 相对于拖动对角线的右端点
	 * @param originalDatumPoint 对角线上需要移动点的原始坐标
	 * @param mousePoint 鼠标点
	 * @param leftLineLength, bottomLineLength, rightLineLength, topLineLength 传入点对应的边长
	 */

	function quadrilateralDiagonalMove(originalLeftVertexPoint, fixedPoint, originalRightVertexPoint, originalDatumPoint, mousePoint, leftLineLength, bottomLineLength, rightLineLength, topLineLength) {

	    var angle = getAngle(mousePoint, fixedPoint, originalDatumPoint);
	    var mouseVector = new THREE.Vector2().subVectors(mousePoint, fixedPoint);
	    var fixVector = new THREE.Vector2().subVectors(originalDatumPoint, fixedPoint);
	    if (angle.angleValue > 90) {
	        angle.angleValue = 180 - angle.angleValue;
	        fixVector = new THREE.Vector2().subVectors(fixedPoint, originalDatumPoint);
	    }
	    var length = mouseVector.length() * Math.cos(angle.angleValue * Math.PI / 180);
	    var movePoint = new THREE.Vector2().addVectors(fixedPoint, fixVector.setLength(length));

	    //console.log(movePoint);
	    var combinLeftPot = closedGraphCombiningPoint(originalLeftVertexPoint, fixedPoint, originalDatumPoint, movePoint, leftLineLength, topLineLength);
	    var combinRightPot = closedGraphCombiningPoint(originalRightVertexPoint, fixedPoint, originalDatumPoint, movePoint, bottomLineLength, rightLineLength);
	    if (combinLeftPot == null || combinRightPot == null) return null;

	    //平移后的向量坐标
	    return {
	        combinLeftPoint: combinLeftPot,
	        combinRightPoint: combinRightPot,
	        diagonalPoint: movePoint
	    };
	}

	/**
	 * 方法：计算四边形对边平移后，对边两端点上的坐标
	 * @param originLeftPoint 拖动对边的左端点
	 * @param originRightPoint 拖动对边的右端点
	 * @param fixedLeftPoint 固定边左端点
	 * @param fixedRightPoint 固定边右端点
	 * @param mouseDownPoint，mouseMovingPoint 鼠标点击点和移动点
	 */

	function quadrilateralOppositeMove(originLeftPoint, originRightPoint, fixedLeftPoint, fixedRightPoint, mouseDownPoint, mouseMovingPoint, topLineLength, leftLineLength, rightLineLength) {

	    var mouMoveObj = getAngle(mouseDownPoint, fixedLeftPoint, mouseMovingPoint);

	    //左边顶点移动后的点的坐标

	    var leftVertexObj = rotationAngleVector(originLeftPoint, fixedLeftPoint, mouMoveObj.angleValue, mouMoveObj.clockWise),
	        currentVertexVector = leftVertexObj.vector.setLength(leftLineLength),
	        currentLeftPoint = new THREE.Vector2().addVectors(fixedLeftPoint, currentVertexVector);

	    var diagonalDis = twoPointDistance(currentLeftPoint, fixedRightPoint);
	    if (topLineLength + rightLineLength <= diagonalDis || Math.abs(topLineLength - rightLineLength) >= diagonalDis) return null;
	    var finalAngle = getTriangleAngle(diagonalDis, topLineLength, rightLineLength);

	    var angleObj = getAngle(fixedRightPoint, currentLeftPoint, fixedLeftPoint);
	    var rightRotObj = rotationAngleVector(fixedRightPoint, currentLeftPoint, finalAngle, !angleObj.clockWise),
	        currentRightVector = rightRotObj.vector.setLength(topLineLength),
	        currentRightPoint = new THREE.Vector2().addVectors(currentLeftPoint, currentRightVector);

	    return {
	        leftPoint: currentLeftPoint,
	        rightPoint: currentRightPoint
	    };
	}

	/**
	 * 向量旋转后的向量，返回旋转后的点和向量;
	 * @param movePoint 旋转角度
	 * @param fixedPoint 旋转轴点（固定的点）
	 * @param angle 旋转角度
	 * @param clockwise 旋转方向
	 */

	function rotationAngleVector(movePoint, fixedPoint, angle, clockwise) {

	    var tempVector = new THREE.Vector2(movePoint.x - fixedPoint.x, movePoint.y - fixedPoint.y);
	    var valueX = undefined,
	        valueY = undefined;
	    var radian = angle / 180 * Math.PI;

	    if (clockwise) {
	        valueX = tempVector.x * Math.cos(radian) + tempVector.y * Math.sin(radian) + fixedPoint.x;
	        valueY = tempVector.y * Math.cos(radian) - tempVector.x * Math.sin(radian) + fixedPoint.y;
	    } else {
	        valueX = tempVector.x * Math.cos(radian) - tempVector.y * Math.sin(radian) + fixedPoint.x;
	        valueY = tempVector.y * Math.cos(radian) + tempVector.x * Math.sin(radian) + fixedPoint.y;
	    }

	    var afterRotationPoint = new THREE.Vector2(valueX, valueY);
	    var afterRotationVector = new THREE.Vector2(valueX - fixedPoint.x, valueY - fixedPoint.y);

	    return {
	        point: afterRotationPoint,
	        vector: afterRotationVector
	    };
	}

	/**
	 * 平移达到边界判定方法：传入向量方向上移动的最大距离,如果到边界则返回(0, 0);
	 * @param pointGroup 需要移动的所有点
	 * @param directionVector 旋转点方向上的坐标
	 */

	function movingBoundaryDetermination(pointGroup, directionVector) {
	    //存放x, y轴上的最值
	    var minXPoint = undefined,
	        maxXPoint = undefined,
	        minYPoint = undefined,
	        maxYPoint = undefined;
	    minXPoint = maxXPoint = minYPoint = maxYPoint = pointGroup[0];

	    //移动的最大距离,作为返回值
	    var moveMaxDistansVector = new THREE.Vector2(0, 0);
	    var pointXGroup = [],
	        pointYGroup = [];
	    var _iteratorNormalCompletion = true;
	    var _didIteratorError = false;
	    var _iteratorError = undefined;

	    try {
	        for (var _iterator = pointGroup[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
	            var point = _step.value;

	            pointXGroup.push(point.x);
	            pointYGroup.push(point.y);
	        }
	    } catch (err) {
	        _didIteratorError = true;
	        _iteratorError = err;
	    } finally {
	        try {
	            if (!_iteratorNormalCompletion && _iterator["return"]) {
	                _iterator["return"]();
	            }
	        } finally {
	            if (_didIteratorError) {
	                throw _iteratorError;
	            }
	        }
	    }

	    minXPoint = Math.min.apply(Math, pointXGroup);
	    maxXPoint = Math.max.apply(Math, pointXGroup);
	    minYPoint = Math.min.apply(Math, pointYGroup);
	    maxYPoint = Math.max.apply(Math, pointYGroup);

	    var newMinXPoint = minXPoint + directionVector.x - _constants.ROTATE_HANDLER_RADIUS;
	    var newMaxXPoint = maxXPoint + directionVector.x + _constants.ROTATE_HANDLER_RADIUS;
	    var newMinYPoint = minYPoint + directionVector.y - _constants.ROTATE_HANDLER_RADIUS;
	    var newMaxYPoint = maxYPoint + directionVector.y + _constants.ROTATE_HANDLER_RADIUS;

	    if (newMinXPoint < _constants.CONSTRAINT.xmin) {
	        if (minXPoint > _constants.CONSTRAINT.xmin + _constants.ROTATE_HANDLER_RADIUS) {
	            directionVector.x = _constants.CONSTRAINT.xmin + _constants.ROTATE_HANDLER_RADIUS - minXPoint;
	        } else {
	            directionVector.x = directionVector.x > 0 ? directionVector.x : 0;
	        }
	    }
	    if (newMaxXPoint > _constants.CONSTRAINT.xmax) {
	        if (_constants.ROTATE_HANDLER_RADIUS + maxXPoint < _constants.CONSTRAINT.xmax) {
	            directionVector.x = _constants.CONSTRAINT.xmax - _constants.ROTATE_HANDLER_RADIUS - maxXPoint;
	        } else {
	            directionVector.x = directionVector.x < 0 ? directionVector.x : 0;
	        }
	    }
	    if (newMinYPoint < _constants.CONSTRAINT.ymin) {
	        if (minYPoint > _constants.CONSTRAINT.ymin + _constants.ROTATE_HANDLER_RADIUS) {
	            directionVector.y = _constants.CONSTRAINT.ymin + _constants.ROTATE_HANDLER_RADIUS - minYPoint;
	        } else {
	            directionVector.y = directionVector.y > 0 ? directionVector.y : 0;
	        }
	    }
	    if (newMaxYPoint > _constants.CONSTRAINT.ymax) {
	        if (_constants.ROTATE_HANDLER_RADIUS + maxYPoint < _constants.CONSTRAINT.ymax) {
	            directionVector.y = _constants.CONSTRAINT.ymax - _constants.ROTATE_HANDLER_RADIUS - maxYPoint;
	        } else {
	            directionVector.y = directionVector.y < 0 ? directionVector.y : 0;
	        }
	    }

	    if (minXPoint <= _constants.CONSTRAINT.xmin + _constants.ROTATE_HANDLER_RADIUS && maxXPoint >= _constants.CONSTRAINT.xmax - _constants.ROTATE_HANDLER_RADIUS) {
	        directionVector.x = 0;
	    }

	    if (minYPoint < _constants.CONSTRAINT.ymin + _constants.ROTATE_HANDLER_RADIUS && maxYPoint > _constants.CONSTRAINT.ymax - _constants.ROTATE_HANDLER_RADIUS) {
	        directionVector.y = 0;
	    }
	}

	/**
	 * 旋转达到边界判定方法：返回达到边界的弧度;
	 * @param movePoint 移动点
	 * @param rotationPoint 旋转点的不动点
	 * @param options 对象，可以获取旋转方向，角度
	 */

	function rotationBoundaryJudgment(movePoint, rotationPoint, options) {

	    //弧度
	    var radian = options.angle;

	    //let tempVector = new THREE.Vector2(movePoint.x - rotationPoint.x, movePoint.y - rotationPoint.y);
	    var tempVector = new THREE.Vector2().subVectors(movePoint, rotationPoint);
	    var valueX = undefined,
	        valueY = undefined;
	    var clockwise = options.clockWise;

	    if (clockwise) {
	        valueX = tempVector.x * Math.cos(radian) + tempVector.y * Math.sin(radian) + rotationPoint.x;
	        valueY = tempVector.y * Math.cos(radian) - tempVector.x * Math.sin(radian) + rotationPoint.y;
	    } else {
	        valueX = tempVector.x * Math.cos(radian) - tempVector.y * Math.sin(radian) + rotationPoint.x;
	        valueY = tempVector.y * Math.cos(radian) + tempVector.x * Math.sin(radian) + rotationPoint.y;
	    }

	    var combiningPoint = new THREE.Vector2(valueX, valueY);

	    if (valueX < _constants.CONSTRAINT.xmin + _constants.ROTATE_HANDLER_RADIUS / 2 || valueX > _constants.CONSTRAINT.xmax - _constants.ROTATE_HANDLER_RADIUS / 2 || valueY < _constants.CONSTRAINT.ymin + _constants.ROTATE_HANDLER_RADIUS / 2 || valueY > _constants.CONSTRAINT.ymax - _constants.ROTATE_HANDLER_RADIUS / 2) return false;

	    return true;
	}

	/*
	 * 方法：图形边界判定
	 * @param pointGroup 点的数组
	 * @param rotationPoint 旋转点的不动点
	 * @param options 对象，可以获取旋转方向，角度
	 */

	function graphicalRotationBoundaryJudgment(pointGroup, rotationPoint, options) {

	    var collisionObjs = [];

	    for (var i = 0; i < pointGroup.length; i++) {
	        var movePoint = pointGroup[i];
	        var canRotate = rotationBoundaryJudgment(movePoint, rotationPoint, options);
	        if (!canRotate) return false;
	    }
	    return true;
	}

/***/ },
/* 12 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.setActivedObj = setActivedObj;
	exports.setSelectedShape = setSelectedShape;
	exports['default'] = documentInit;
	exports.removeEventListerner = removeEventListerner;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _threeMangerJs = __webpack_require__(5);

	var _constantsJs = __webpack_require__(6);

	var _UtilsGetAngle = __webpack_require__(11);

	var _UtilsCatchPoints = __webpack_require__(13);

	var _UtilsCatchPoints2 = _interopRequireDefault(_UtilsCatchPoints);

	var _UtilsGetCenterPoint = __webpack_require__(14);

	var _UtilsGetCenterPoint2 = _interopRequireDefault(_UtilsGetCenterPoint);

	var _presenter = __webpack_require__(2);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _runtime = __webpack_require__(7);

	var _runtime2 = _interopRequireDefault(_runtime);

	var _UtilsCheckRotatePositionJs = __webpack_require__(15);

	var _UtilsCheckRotatePositionJs2 = _interopRequireDefault(_UtilsCheckRotatePositionJs);

	var _UtilsCheckMovePositionJs = __webpack_require__(16);

	var _UtilsCheckMovePositionJs2 = _interopRequireDefault(_UtilsCheckMovePositionJs);

	var _UtilsSetZPosition = __webpack_require__(17);

	var _UtilsSetZPosition2 = _interopRequireDefault(_UtilsSetZPosition);

	var _UtilsDrawMergeJs = __webpack_require__(18);

	var _moveJs = __webpack_require__(9);

	var _moveJs2 = _interopRequireDefault(_moveJs);

	var _splitJs = __webpack_require__(20);

	var _splitJs2 = _interopRequireDefault(_splitJs);

	var _rotationJs = __webpack_require__(21);

	var _rotationJs2 = _interopRequireDefault(_rotationJs);

	var _mergeStickJs = __webpack_require__(22);

	var _mergeStickJs2 = _interopRequireDefault(_mergeStickJs);

	var _UtilsAdjustAngleJs = __webpack_require__(24);

	var _UtilsAdjustAngleJs2 = _interopRequireDefault(_UtilsAdjustAngleJs);

	var _UtilsDetectBoundaryJs = __webpack_require__(25);

	var _UtilsDetectBoundaryJs2 = _interopRequireDefault(_UtilsDetectBoundaryJs);

	var _closeShapeJs = __webpack_require__(26);

	var _closeShapeJs2 = _interopRequireDefault(_closeShapeJs);

	var _angleDistortionJs = __webpack_require__(27);

	var _angleDistortionJs2 = _interopRequireDefault(_angleDistortionJs);

	var _sideDistortionJs = __webpack_require__(28);

	var _sideDistortionJs2 = _interopRequireDefault(_sideDistortionJs);

	var _selectStickJs = __webpack_require__(29);

	var _selectStickJs2 = _interopRequireDefault(_selectStickJs);

	// 当前操作的类型
	var actionType = '',

	// 当前旋转的match
	selectedMatch,

	// 作为旋转点的match
	staticMatch,

	// 作为参考点的match
	activedObj = null,
	    _connected = false,

	// 二维平面对象
	boundary,

	// 存放鼠标对象的data
	mouseData = {},

	// 当前操作的stick
	selectedStick;
	// 当前选中的图形，用于删除
	var selectedShape = undefined;
	exports.selectedShape = selectedShape;

	function setActivedObj(val) {
	    activedObj = val;
	}

	function setSelectedShape(val) {
	    (0, _selectStickJs2['default'])(val, selectedShape);
	    exports.selectedShape = selectedShape = val;
	}

	function documentInit() {
	    _presenter2['default'].view.getElementsByTagName('canvas')[0].addEventListener('mousedown', onDocumentMouseDown, false);
	    _presenter2['default'].view.getElementsByTagName('canvas')[0].addEventListener('touchstart', onDocumentMouseDown, false);
	    _presenter2['default'].view.addEventListener('mouseup', checkMatchInView, false);
	    _presenter2['default'].view.addEventListener('touchend', checkMatchInView, false);
	}

	function intersectObjects(pointer, objects) {
	    var pageY = pointer.clientY + $(_presenter2['default'].view).find('.com_layout').scrollTop() + $('body').scrollTop();
	    var pageX = pointer.clientX + $(_presenter2['default'].view).find('.com_layout').scrollLeft() + $('body').scrollLeft();
	    var pointerVector = new THREE.Vector2((pageX - _constantsJs.REAL_ESTATE.offsetLeft) / _constantsJs.REAL_ESTATE.width * 2 - 1, -((pageY - _constantsJs.REAL_ESTATE.offsetTop) / _constantsJs.REAL_ESTATE.height) * 2 + 1);
	    _threeMangerJs.raycaster.setFromCamera(pointerVector, _threeMangerJs.camera);

	    var intersections = _threeMangerJs.raycaster.intersectObjects(objects, true);
	    return intersections;
	}

	function onDocumentMouseDown(event) {
	    var pointer = undefined;
	    boundary = _threeMangerJs.scene.getObjectByName('boundary');

	    if (event.touches) {
	        if (event.touches.length === 1) {
	            event.preventDefault();
	            pointer = event.changedTouches[0];
	        } else {
	            return;
	        }
	    } else {
	        event.preventDefault();
	        pointer = event;
	    }

	    var intersects = intersectObjects(pointer, _threeMangerJs.intersectObjs);
	    var startPoint = intersectObjects(pointer, [boundary])[0];

	    mouseData.startPoint = startPoint.point;

	    if (intersects.length > 0) {
	        setSelectedShape(intersects[0].object);
	        var sel = intersects[0].object;
	        _threeMangerJs.intersectObjs.current = sel.parent;

	        switch (sel.name) {
	            // 选中移动图标
	            case 'moveImage':
	                actionType = _constantsJs.ACTION_TYPE.move;
	                break;
	            // 选中旋转图标
	            case 'rotationImage':
	                actionType = _constantsJs.ACTION_TYPE.rotate;
	                mouseData.centerPoint = (0, _UtilsGetCenterPoint2['default'])(_threeMangerJs.intersectObjs.current);
	                break;
	            // 选中棍子
	            case 'stick':
	                if (_threeMangerJs.intersectObjs.current.parent.name == 'collection') {
	                    if (_threeMangerJs.intersectObjs.current.parent.userData.close) {
	                        if (_threeMangerJs.intersectObjs.current.parent.userData.stick == 4) {
	                            actionType = _constantsJs.ACTION_TYPE.stretching;
	                            selectedStick = sel.parent;
	                        }
	                    } else {
	                        actionType = _constantsJs.ACTION_TYPE.move;
	                    }
	                    _threeMangerJs.intersectObjs.current = _threeMangerJs.intersectObjs.current.parent;
	                } else {
	                    actionType = _constantsJs.ACTION_TYPE.move;
	                }
	                break;
	            // 选中圆点
	            case 'match1':
	            case 'match2':
	                if (_threeMangerJs.intersectObjs.current.parent.name == 'collection' && _threeMangerJs.intersectObjs.current.parent.userData.close) {
	                    if (_threeMangerJs.intersectObjs.current.parent.userData.stick == 4) {
	                        actionType = _constantsJs.ACTION_TYPE.transform;
	                        _threeMangerJs.intersectObjs.current = _threeMangerJs.intersectObjs.current.parent;
	                        selectedMatch = sel;
	                    }
	                } else {
	                    if (!sel.userData.linkState) {
	                        selectedMatch = sel;
	                        staticMatch = _threeMangerJs.intersectObjs.current.getObjectById(sel.userData.connectId);
	                        mouseData.centerPoint = staticMatch.position;
	                        actionType = _constantsJs.ACTION_TYPE.rotate;
	                        if (activedObj !== null) {
	                            if (activedObj != selectedMatch && activedObj.parent != _threeMangerJs.intersectObjs.current) {
	                                _connected = true;
	                            } else {
	                                activedObj = selectedMatch;
	                                _connected = false;
	                            }
	                        } else {
	                            activedObj = selectedMatch;
	                        }
	                    }
	                }
	                break;
	        }
	        (0, _UtilsSetZPosition2['default'])(_threeMangerJs.intersectObjs.current);
	    } else {
	        actionType = _constantsJs.ACTION_TYPE.split;
	        activedObj = null;
	        _threeMangerJs.intersectObjs.current = null;
	        selectedMatch = null;
	        staticMatch = null;
	        setSelectedShape(null);
	    }

	    _presenter2['default'].view.getElementsByTagName('canvas')[0].addEventListener('mousemove', onDocumentMouseMove, false);
	    _presenter2['default'].view.getElementsByTagName('canvas')[0].addEventListener('mouseup', onDocumentMouseUp, false);
	    _presenter2['default'].view.getElementsByTagName('canvas')[0].addEventListener('touchend', onDocumentMouseUp, false);
	    _presenter2['default'].view.getElementsByTagName('canvas')[0].addEventListener("touchcancel", onDocumentMouseUp, false);

	    _presenter2['default'].view.getElementsByTagName('canvas')[0].addEventListener('touchmove', onDocumentMouseMove, false);
	    _presenter2['default'].view.getElementsByTagName('canvas')[0].addEventListener('mouseout', onDocumentMouseUp, false);
	    _presenter2['default'].view.getElementsByTagName('canvas')[0].addEventListener('touchleave', onDocumentMouseUp, false);
	}

	function onDocumentMouseMove(event) {

	    var pointer = event.changedTouches ? event.changedTouches[0] : event;
	    var movePoint = intersectObjects(pointer, [boundary])[0];
	    if (!movePoint) {
	        return;
	    }
	    mouseData.movePoint = movePoint.point;

	    if (actionType == 'split') {
	        var intersects = intersectObjects(pointer, _threeMangerJs.intersectObjs);
	        if (intersects.length > 0) {
	            var current = intersects[0].object;
	            _threeMangerJs.intersectObjs.current = current.parent;
	            if (current.userData.linkState) {
	                (0, _splitJs2['default'])(current, _threeMangerJs.intersectObjs.current.parent.getObjectById(current.userData.linkId));
	                actionType = '';
	            }
	        }
	        return;
	    }

	    if (Math.abs(mouseData.movePoint.x - mouseData.startPoint.x) > 5 || Math.abs(mouseData.movePoint.y - mouseData.startPoint.y) > 5) {
	        activedObj = null;
	        _connected = false;

	        if (actionType == 'move') {
	            activedObj = null;
	            _connected = false;
	            var distanceX = +mouseData.movePoint.x - mouseData.startPoint.x;
	            var distanceY = +mouseData.movePoint.y - mouseData.startPoint.y;
	            var disVector = new THREE.Vector2(distanceX, distanceY);
	            (0, _UtilsCheckMovePositionJs2['default'])(_threeMangerJs.intersectObjs.current, disVector);
	            (0, _moveJs2['default'])(_threeMangerJs.intersectObjs.current, disVector);
	            mouseData.startPoint = mouseData.movePoint;
	        }

	        if (actionType == 'rotate' || actionType == 'rotateDone') {
	            var rotation = (0, _UtilsGetAngle.getAngle)(mouseData.startPoint, mouseData.centerPoint, mouseData.movePoint);
	            var canRotate = (0, _UtilsCheckRotatePositionJs2['default'])(_threeMangerJs.intersectObjs.current, mouseData.centerPoint, rotation);
	            canRotate ? (0, _rotationJs2['default'])(_threeMangerJs.intersectObjs.current, mouseData.centerPoint, rotation) : null;
	            mouseData.startPoint = mouseData.movePoint;
	            actionType = 'rotateDone';
	        }

	        if (actionType == 'transform') {
	            (0, _angleDistortionJs2['default'])(selectedMatch, mouseData.movePoint);
	        }

	        if (actionType == _constantsJs.ACTION_TYPE.stretching) {
	            (0, _sideDistortionJs2['default'])(selectedStick, mouseData.startPoint, mouseData.movePoint);
	            mouseData.startPoint = mouseData.movePoint;
	        }
	    }
	}

	function onDocumentMouseUp(event) {

	    if (_connected && activedObj) {
	        if (activedObj.parent.parent.name == 'collection' && activedObj.parent.parent == selectedMatch.parent.parent) {
	            actionType = _constantsJs.ACTION_TYPE.close;
	            (0, _closeShapeJs2['default'])(selectedMatch, activedObj);
	            (0, _UtilsDrawMergeJs.addMergeIcon)(activedObj.parent.parent);
	            setSelectedShape(selectedMatch);
	        } else {
	            actionType = _constantsJs.ACTION_TYPE.connect;
	            (0, _mergeStickJs2['default'])(selectedMatch, activedObj);
	            setSelectedShape(selectedMatch);
	        }
	        activedObj = null;
	        _connected = false;
	    }

	    if (actionType == 'rotateDone') {
	        // 判断旋转后是否与连接的棍子平行或垂直
	        if (staticMatch && staticMatch.userData.linkState) {
	            (0, _UtilsAdjustAngleJs2['default'])(staticMatch);
	        }
	        if (selectedMatch && !selectedMatch.userData.linkState) {
	            setSelectedShape(staticMatch.parent.getObjectByName('stick'));
	        }
	    }

	    actionType = '';
	    _threeMangerJs.intersectObjs.current = null;
	    selectedMatch = null;
	    staticMatch = null;
	    mouseData = {};

	    _presenter2['default'].view.getElementsByTagName('canvas')[0].removeEventListener('mousemove', onDocumentMouseMove, false);
	    _presenter2['default'].view.getElementsByTagName('canvas')[0].removeEventListener('mouseup', onDocumentMouseUp, false);
	    _presenter2['default'].view.getElementsByTagName('canvas')[0].removeEventListener('mouseout', onDocumentMouseUp, false);

	    _presenter2['default'].view.getElementsByTagName('canvas')[0].removeEventListener('touchmove', onDocumentMouseMove, false);
	    _presenter2['default'].view.getElementsByTagName('canvas')[0].removeEventListener('touchend', onDocumentMouseUp, false);
	    _presenter2['default'].view.getElementsByTagName('canvas')[0].removeEventListener("touchcancel", onDocumentMouseUp, false);
	    _presenter2['default'].view.getElementsByTagName('canvas')[0].removeEventListener('touchleave', onDocumentMouseUp, false);
	}

	function checkMatchInView(event) {
	    var pointer = undefined;
	    boundary = _threeMangerJs.scene.getObjectByName('boundary');

	    if (event.changedTouches) {
	        pointer = event.changedTouches[0];
	    } else {
	        pointer = event;
	    }

	    var startPoint = intersectObjects(pointer, [boundary])[0];
	    if (startPoint && _presenter2['default']._stickLength) {
	        (0, _threeMangerJs.addThreeShape)(_presenter2['default']._stickLength, startPoint.point);
	        //setSelectedShape(null);
	    }
	    _presenter2['default']._stickLength = null;
	    if (!startPoint && event.target.className != 'btn_del') setSelectedShape(null);
	}

	function removeEventListerner() {
	    if (_presenter2['default'].view.getElementsByTagName('canvas')[0]) {
	        _presenter2['default'].view.getElementsByTagName('canvas')[0].removeEventListener('mousedown', onDocumentMouseDown, false);
	        _presenter2['default'].view.getElementsByTagName('canvas')[0].removeEventListener('touchstart', onDocumentMouseDown, false);
	        _presenter2['default'].view.removeEventListener('mouseup', checkMatchInView, false);
	        _presenter2['default'].view.removeEventListener('touchend', checkMatchInView, false);
	    }
	}

/***/ },
/* 13 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	var _GetAngle = __webpack_require__(11);

	exports['default'] = function (refer, movePoint) {
		if (!refer) {
			return;
		}

		var connectMatch = refer.parent.getObjectById(refer.userData.connectId); // refer连接的另一个端点
		var linkMatch = refer.parent.parent.getObjectById(connectMatch.userData.linkId); // 与connectMatch链接的点
		var linkConnectMatch = refer.parent.parent.getObjectById(linkMatch.userData.connectId); //与linkMatch连接的另一个端点

		//与refer链接的点
		var refer2 = refer.parent.parent.getObjectById(refer.userData.linkId);
		// 与refer2连接的另一个端点
		var connectMatch2 = refer2.parent.getObjectById(refer2.userData.connectId);
		// 与connectMatch2链接的点
		var linkConnectMatch2 = connectMatch2.parent.parent.getObjectById(connectMatch2.userData.linkId);
		// 与linkConnectMatch2连接的另一个端点
		var connectMatch3 = linkConnectMatch2.parent.getObjectById(linkConnectMatch2.userData.connectId);

		var rotation = (0, _GetAngle.quadrilateralDiagonalMove)(linkMatch.userData.center, linkConnectMatch.userData.center, refer.userData.center, movePoint);
		if (rotation) {
			connectMatch.userData.center.x += rotation.distance.x;
			connectMatch.userData.center.y += rotation.distance.y;
			connectMatch2.userData.center.x += rotation.distance.x;
			connectMatch2.userData.center.y += rotation.distance.y;
			if (refer.userData.center.x > linkConnectMatch.userData.center.x) {
				var rotationData1 = (0, _GetAngle.rotationObj)(linkMatch.userData.center, linkConnectMatch.userData.center, rotation.movingPoint, connectMatch.userData.center);
				var rotationData2 = (0, _GetAngle.rotationObj)(linkConnectMatch2.userData.center, connectMatch3.userData.center, rotation.movingPoint, connectMatch2.userData.center);
				if (!rotationData1 || !rotationData2) return;
				var rotation1 = rotationData1.leftRotation;
				var rotation2 = rotationData1.rightRotation;
				var rotation3 = rotationData2.leftRotation;
				var rotation4 = rotationData2.rightRotation;
				updateVertices({ object: refer.parent, distanceX: rotation.distance.x, distanceY: rotation.distance.y, action: 'move' });
				updateVertices({ object: connectMatch2.parent, distanceX: rotation.distance.x, distanceY: rotation.distance.y, action: 'move' });

				updateVertices({ object: linkConnectMatch.parent, centerPoint: linkConnectMatch.userData.center, angle: rotation1.angle, clockwise: rotation1.clockWise, action: 'rotate' });

				updateVertices({ object: connectMatch3.parent, centerPoint: connectMatch3.userData.center, angle: rotation3.angle, clockwise: rotation3.clockWise, action: 'rotate' });
				updateVertices({ object: refer.parent, centerPoint: refer.userData.center, angle: rotation2.angle, clockwise: rotation2.clockWise, action: 'rotate' });
				updateVertices({ object: refer2.parent, centerPoint: refer2.userData.center, angle: rotation4.angle, clockwise: rotation4.clockWise, action: 'rotate' });
			}
		}
	};

	module.exports = exports['default'];

/***/ },
/* 14 */
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	exports['default'] = function (collection) {
		if (!collection.userData.close) {
			return;
		}
		var pointsY = [];
		var pointsX = [];
		var _iteratorNormalCompletion = true;
		var _didIteratorError = false;
		var _iteratorError = undefined;

		try {
			for (var _iterator = collection.children[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
				var stick = _step.value;

				if (stick.name != 'unit') continue;
				var match1 = stick.getObjectByName('match1');
				var match2 = stick.getObjectByName('match2');
				pointsY.push(match1.position.y);
				pointsY.push(match2.position.y);
				pointsX.push(match1.position.x);
				pointsX.push(match2.position.x);
			}
		} catch (err) {
			_didIteratorError = true;
			_iteratorError = err;
		} finally {
			try {
				if (!_iteratorNormalCompletion && _iterator['return']) {
					_iterator['return']();
				}
			} finally {
				if (_didIteratorError) {
					throw _iteratorError;
				}
			}
		}

		var maxY = Math.max.apply(Math, pointsY);
		var maxX = Math.max.apply(Math, pointsX);
		var minX = Math.min.apply(Math, pointsX);
		var minY = Math.min.apply(Math, pointsY);
		return new THREE.Vector2((maxX + minX) / 2, (maxY + minY) / 2);
	};

	module.exports = exports['default'];

/***/ },
/* 15 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	var _GetAngle = __webpack_require__(11);

	exports['default'] = function (obj, center, angle) {
	    var points = [];
	    // if (options.action == 'move') {

	    if (obj.name == 'unit') {
	        points.push(obj.getObjectByName('match1').position, obj.getObjectByName('match2').position);
	    } else {
	        var children = obj.children;
	        for (var i = 0; i < children.length; i++) {
	            if (children[i].name != 'unit') continue;
	            points.push(children[i].getObjectByName('match1').position, children[i].getObjectByName('match2').position);
	        }
	    }

	    var collision = (0, _GetAngle.graphicalRotationBoundaryJudgment)(points, center, angle);

	    return collision;
	};

	module.exports = exports['default'];

/***/ },
/* 16 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	var _GetAngle = __webpack_require__(11);

	exports['default'] = function (obj, distantce) {
	    var points = [];

	    if (obj.name == 'unit') {
	        points.push(obj.getObjectByName('match1').position, obj.getObjectByName('match2').position);
	    } else if (obj.name == 'collection') {
	        var children = obj.children;
	        for (var i = 0; i < children.length; i++) {
	            if (children[i].name != 'unit') {
	                points.push(children[i].position);
	            } else {
	                points.push(children[i].getObjectByName('match1').position, children[i].getObjectByName('match2').position);
	            }
	        }
	    }

	    (0, _GetAngle.movingBoundaryDetermination)(points, distantce);
	};

	module.exports = exports['default'];

/***/ },
/* 17 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	var zPosition = 0;

	exports["default"] = function (shape) {
		++zPosition;
		shape.position.z = zPosition;
	};

	module.exports = exports["default"];

/***/ },
/* 18 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/12/9.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});
	exports.addMergeIcon = addMergeIcon;
	exports.removeMergeIcon = removeMergeIcon;
	exports.updateMergeIcon = updateMergeIcon;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _GetAngleJs = __webpack_require__(11);

	var _destroyThreeObjectJs = __webpack_require__(19);

	var _destroyThreeObjectJs2 = _interopRequireDefault(_destroyThreeObjectJs);

	var _threeMangerJs = __webpack_require__(5);

	var _presenter = __webpack_require__(2);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _constants = __webpack_require__(6);

	/**
	 * 组合图形组合封闭时添加操作图标
	 * @param mergeShape
	 */

	function addMergeIcon(mergeShape) {
	  "use strict";
	  if (!mergeShape.userData.close) return;
	  //获取最上方的点
	  var topMatch = null;
	  var unitId = null;
	  var pointsY = [];
	  var pointsX = [];
	  var _iteratorNormalCompletion = true;
	  var _didIteratorError = false;
	  var _iteratorError = undefined;

	  try {
	    for (var _iterator = mergeShape.children[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
	      var stick = _step.value;

	      if (stick.name != 'unit') continue;
	      var match1 = stick.getObjectByName('match1');
	      if (!topMatch) topMatch = match1;
	      if (match1.position.y > topMatch.position.y) topMatch = match1;
	      var _match2 = stick.getObjectByName('match2');
	      if (_match2.position.y > topMatch.position.y) topMatch = _match2;
	      pointsY.push(match1.position.y);
	      pointsY.push(_match2.position.y);
	      pointsX.push(match1.position.x);
	      pointsX.push(_match2.position.x);
	    }
	  } catch (err) {
	    _didIteratorError = true;
	    _iteratorError = err;
	  } finally {
	    try {
	      if (!_iteratorNormalCompletion && _iterator['return']) {
	        _iterator['return']();
	      }
	    } finally {
	      if (_didIteratorError) {
	        throw _iteratorError;
	      }
	    }
	  }

	  unitId = topMatch.parent.id;
	  //测试
	  //计算移动图标位置
	  var center = topMatch.position;
	  var point1 = mergeShape.getObjectById(topMatch.userData.connectId).position;
	  var match2 = mergeShape.getObjectById(mergeShape.getObjectById(topMatch.userData.linkId).userData.connectId);
	  var point2 = match2.position;
	  var clockwise = (0, _GetAngleJs.getAngle)(point1, center, point2).clockWise;

	  var referVector = (0, _GetAngleJs.rotationAngleVector)(point1, center, 90, !clockwise).vector;
	  var referPoint = new THREE.Vector2((point1.x + center.x) / 2, (point1.y + center.y) / 2);
	  var position = new THREE.Vector2().addVectors(referPoint, referVector.setLength(20));

	  //画移动图标
	  //let loader = new THREE.TextureLoader();
	  //loader.setCrossOrigin('anonymous');
	  //let texture = loader.load(presenter.path+'resources/move.png');
	  //let material = new THREE.MeshBasicMaterial({ map: texture,transparent: true});
	  var moveMesh = new THREE.Mesh(new THREE.PlaneBufferGeometry(24, 24), (0, _constants.getMoveMaterial)());
	  moveMesh.position.x = position.x;
	  moveMesh.position.y = position.y;
	  moveMesh.name = 'moveImage';
	  moveMesh.userData.matchId = topMatch.id;
	  _threeMangerJs.intersectObjs.push(moveMesh);
	  mergeShape.add(moveMesh);

	  //计算旋转图标位置
	  var maxY = Math.max.apply(Math, pointsY);
	  var maxX = Math.max.apply(Math, pointsX);
	  var minX = Math.min.apply(Math, pointsX);
	  var minY = Math.min.apply(Math, pointsY);
	  var boundcenter = new THREE.Vector2((maxX + minX) / 2, (maxY + minY) / 2);
	  var directionVec = new THREE.Vector2().subVectors(point2, boundcenter);
	  var rotationPosition = new THREE.Vector2().addVectors(point2, directionVec.setLength(24));

	  //画旋转图标
	  //let loader2 = new THREE.TextureLoader();
	  //loader2.setCrossOrigin('anonymous');
	  //let texture2 = loader2.load(presenter.path+'resources/rotation.png');
	  //let material2 = new THREE.MeshBasicMaterial({ map: texture2,transparent: true});
	  var rotationMesh = new THREE.Mesh(new THREE.PlaneBufferGeometry(24, 24), (0, _constants.getRotationMaterial)());

	  rotationMesh.name = 'rotationImage';
	  rotationMesh.position.x = rotationPosition.x;
	  rotationMesh.position.y = rotationPosition.y;
	  rotationMesh.userData.matchId = match2.id;
	  rotationMesh.userData.unitId = unitId;
	  _threeMangerJs.intersectObjs.push(rotationMesh);
	  mergeShape.add(rotationMesh);
	}

	/**
	 * 组合图形切割后移除操作图标
	 * @param mergeShape
	 */

	function removeMergeIcon(mergeShape) {

	  var moveImage = mergeShape.getObjectByName('moveImage');
	  var index = _threeMangerJs.intersectObjs.indexOf(moveImage);
	  _threeMangerJs.intersectObjs.splice(index, 1);
	  mergeShape.remove(moveImage);
	  (0, _destroyThreeObjectJs2['default'])(moveImage);
	  var rotationImage = mergeShape.getObjectByName('rotationImage');
	  var index2 = _threeMangerJs.intersectObjs.indexOf(rotationImage);
	  _threeMangerJs.intersectObjs.splice(index2, 1);
	  mergeShape.remove(rotationImage);
	  (0, _destroyThreeObjectJs2['default'])(rotationImage);
	}

	function updateMergeIcon(mergeShape) {
	  "use strict";
	  var rotationMesh = mergeShape.getObjectByName('rotationImage');
	  var moveMesh = mergeShape.getObjectByName('moveImage');
	  var rotationPoint = mergeShape.getObjectById(rotationMesh.userData.matchId).position;

	  var pointsY = [];
	  var pointsX = [];
	  var _iteratorNormalCompletion2 = true;
	  var _didIteratorError2 = false;
	  var _iteratorError2 = undefined;

	  try {
	    for (var _iterator2 = mergeShape.children[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
	      var stick = _step2.value;

	      if (stick.name != 'unit') continue;
	      var match1 = stick.getObjectByName('match1');
	      var match2 = stick.getObjectByName('match2');
	      pointsY.push(match1.position.y);
	      pointsY.push(match2.position.y);
	      pointsX.push(match1.position.x);
	      pointsX.push(match2.position.x);
	    }
	    //计算旋转图标位置
	  } catch (err) {
	    _didIteratorError2 = true;
	    _iteratorError2 = err;
	  } finally {
	    try {
	      if (!_iteratorNormalCompletion2 && _iterator2['return']) {
	        _iterator2['return']();
	      }
	    } finally {
	      if (_didIteratorError2) {
	        throw _iteratorError2;
	      }
	    }
	  }

	  var maxY = Math.max.apply(Math, pointsY);
	  var maxX = Math.max.apply(Math, pointsX);
	  var minX = Math.min.apply(Math, pointsX);
	  var minY = Math.min.apply(Math, pointsY);
	  var boundcenter = new THREE.Vector2((maxX + minX) / 2, (maxY + minY) / 2);
	  var directionVec = new THREE.Vector2().subVectors(rotationPoint, boundcenter);
	  var rotationPosition = new THREE.Vector2().addVectors(rotationPoint, directionVec.setLength(20));
	  rotationMesh.position.x = rotationPosition.x;
	  rotationMesh.position.y = rotationPosition.y;

	  //计算移动图标位置
	  var topMatch = mergeShape.getObjectById(moveMesh.userData.matchId);
	  var center = topMatch.position;
	  var point1 = mergeShape.getObjectById(topMatch.userData.connectId).position;
	  var point2 = mergeShape.getObjectById(mergeShape.getObjectById(topMatch.userData.linkId).userData.connectId).position;
	  var clockwise = (0, _GetAngleJs.getAngle)(point1, center, point2).clockWise;

	  var referVector = (0, _GetAngleJs.rotationAngleVector)(point1, center, 90, !clockwise).vector;
	  var referPoint = new THREE.Vector2((point1.x + center.x) / 2, (point1.y + center.y) / 2);
	  var position = new THREE.Vector2().addVectors(referPoint, referVector.setLength(24));
	  moveMesh.position.x = position.x;
	  moveMesh.position.y = position.y;
	}

/***/ },
/* 19 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports["default"] = destroyThreeObject;

	function destroyThreeObject(object) {
	  "use strict";
	  if (!object) return;
	  if (object.children && object.children.length > 0) {
	    for (var i = 0; i < object.children.length; i++) {
	      destroyThreeObject(object.children[i]);
	    }
	  }
	  if (object.geometry) object.geometry.dispose();
	  if (object.material) {
	    object.material.dispose();
	    if (object.material.map && object.material.map.dispose) object.material.map.dispose();
	  }
	  object = null;
	}

	module.exports = exports["default"];

/***/ },
/* 20 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _UtilsGetAngle = __webpack_require__(11);

	var _UtilsDrawMerge = __webpack_require__(18);

	var _rotationJs = __webpack_require__(21);

	var _rotationJs2 = _interopRequireDefault(_rotationJs);

	var _threeMangerJs = __webpack_require__(5);

	var _constants = __webpack_require__(6);

	exports['default'] = function (refer, target) {
		// 与refer连接的另一个端点
		var referConnectMatch = refer.parent.getObjectById(refer.userData.connectId),
		   
		// 与target连接的另一个端点
		targetConnectMatch = target.parent.getObjectById(target.userData.connectId),
		   
		// refer所在棍子与target所在棍子之间的夹角
		angle = (0, _UtilsGetAngle.getAngle)(targetConnectMatch.position, refer.position, referConnectMatch.position),
		   
		// 该组合的父对象
		parent = refer.parent.parent;

		rotation(target, targetConnectMatch, refer, referConnectMatch, angle);

		// 闭合图形转为非闭合
		if (parent.userData.close) {
			parent.userData.close = false;
			(0, _UtilsDrawMerge.removeMergeIcon)(parent);
		} else {
			// 各自端点是否有链接点
			if (referConnectMatch.userData.linkState && targetConnectMatch.userData.linkState) {
				var extraStick = parent.getObjectById(targetConnectMatch.userData.linkId).parent,
				    emptyCollection = new THREE.Object3D();

				emptyCollection.name = 'collection';
				emptyCollection.userData.stick = 2;
				emptyCollection.add(target.parent);
				emptyCollection.add(extraStick);
				parent.userData.stick--;
				parent.userData.stick--;
				_threeMangerJs.scene.add(emptyCollection);
			} else if (referConnectMatch.userData.linkState || targetConnectMatch.userData.linkState) {
				!referConnectMatch.userData.linkState ? (_threeMangerJs.scene.add(refer.parent), parent.remove(refer.parent)) : (_threeMangerJs.scene.add(target.parent), parent.remove(target.parent));
				parent.userData.stick--;
			} else {
				_threeMangerJs.scene.add(refer.parent);
				_threeMangerJs.scene.add(target.parent);
				_threeMangerJs.scene.remove(parent);
			}
		}
		refer.userData.linkState = !refer.userData.linkState;
		refer.userData.linkId = null;
		target.userData.linkState = !target.userData.linkState;
		target.userData.linkId = null;
	};

	function rotation(target, targetConnectMatch, refer, referConnectMatch, angle) {
		"use strict";
		if (new THREE.Vector2().subVectors(target.position, refer.position).length() > _constants.ROTATE_HANDLER_RADIUS * 2 + 2) return;
		angle.angleValue = 3;
		(0, _rotationJs2['default'])(target.parent, targetConnectMatch.position, angle);
		angle.clockWise = !angle.clockWise;
		(0, _rotationJs2['default'])(refer.parent, referConnectMatch.position, angle);

		angle.clockWise = !angle.clockWise;
		rotation(target, targetConnectMatch, refer, referConnectMatch, angle);
	}
	module.exports = exports['default'];

/***/ },
/* 21 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/12/11.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});
	exports['default'] = rotation;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _UtilsUpdateVerticesJs = __webpack_require__(10);

	var _UtilsUpdateVerticesJs2 = _interopRequireDefault(_UtilsUpdateVerticesJs);

	var _UtilsGetAngleJs = __webpack_require__(11);

	function rotation(object, center, angle) {
	  "use strict";
	  if (object.name === 'unit') {
	    var match1 = object.getObjectByName('match1');
	    var match2 = object.getObjectByName('match2');
	    match1.userData.position = (0, _UtilsGetAngleJs.rotationAngleVector)(match1.position, center, angle.angleValue, angle.clockWise).point;
	    match2.userData.position = (0, _UtilsGetAngleJs.rotationAngleVector)(match2.position, center, angle.angleValue, angle.clockWise).point;
	    (0, _UtilsUpdateVerticesJs2['default'])(object);
	  } else if (object.name === 'collection') {
	    var _iteratorNormalCompletion = true;
	    var _didIteratorError = false;
	    var _iteratorError = undefined;

	    try {
	      for (var _iterator = object.children[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
	        var stick = _step.value;

	        rotation(stick, center, angle);
	      }
	    } catch (err) {
	      _didIteratorError = true;
	      _iteratorError = err;
	    } finally {
	      try {
	        if (!_iteratorNormalCompletion && _iterator['return']) {
	          _iterator['return']();
	        }
	      } finally {
	        if (_didIteratorError) {
	          throw _iteratorError;
	        }
	      }
	    }
	  } else if (object.name === 'moveImage' || object.name === 'rotationImage') {
	    var position = (0, _UtilsGetAngleJs.rotationAngleVector)(object.position, center, angle.angleValue, angle.clockWise).point;
	    object.position.x = position.x;
	    object.position.y = position.y;
	  }
	}

	module.exports = exports['default'];

/***/ },
/* 22 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/12/14.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _moveJs = __webpack_require__(9);

	var _moveJs2 = _interopRequireDefault(_moveJs);

	var _UtilsGetAngleJs = __webpack_require__(11);

	var _rotationJs = __webpack_require__(21);

	var _rotationJs2 = _interopRequireDefault(_rotationJs);

	var _threeMangerJs = __webpack_require__(5);

	var _UtilsMessagesJs = __webpack_require__(23);

	var _UtilsMessagesJs2 = _interopRequireDefault(_UtilsMessagesJs);

	exports['default'] = function (refer, opera) {
	  "use strict";
	  var referGroup = refer.parent.parent.name == 'collection' ? refer.parent.parent : null;
	  var operaGroup = opera.parent.parent.name == 'collection' ? opera.parent.parent : null;

	  var stickNum = referGroup ? referGroup.userData.stick : 1;
	  stickNum += operaGroup ? operaGroup.userData.stick : 1;

	  if (stickNum > 4) {
	    (0, _UtilsMessagesJs2['default'])('maxStickNumError');
	    return;
	  } //合成后小棒数量大于等于4返回

	  var group = referGroup || operaGroup || new THREE.Object3D();

	  var disVector = new THREE.Vector2().subVectors(refer.position, opera.position);

	  //获取移动的小棒在目标小棒的方向
	  var match1 = refer.parent.getObjectById(refer.userData.connectId);
	  var point1 = match1.position;
	  var match2 = opera.parent.getObjectById(opera.userData.connectId);
	  var point2 = match2.position;

	  var orgAngle = (0, _UtilsGetAngleJs.getAngle)(point1, refer.position, point2);

	  //移动小棒
	  (0, _moveJs2['default'])(operaGroup || opera.parent, disVector);

	  //重叠
	  var angle = (0, _UtilsGetAngleJs.getAngle)(point1, refer.position, point2);
	  if (angle.angleValue < 5) {
	    (0, _rotationJs2['default'])(operaGroup || opera.parent, refer.position, { angleValue: 10, clockWise: orgAngle.clockWise });
	  }

	  var adjustAngle = 90 - angle.angleValue;
	  //垂直感应
	  if (Math.abs(adjustAngle) < 5 && adjustAngle != 0) {
	    var clockWise = adjustAngle > 0 ? angle.clockWise : !angle.clockWise;
	    (0, _rotationJs2['default'])(operaGroup || opera.parent, refer.position, { angleValue: Math.abs(adjustAngle), clockWise: clockWise });
	  }

	  //平行感应
	  if (match1.userData.linkState) {
	    var oppositeMatch1 = group.getObjectById(match1.userData.linkId);
	    var oppositeMatch2 = group.getObjectById(oppositeMatch1.userData.connectId);

	    angle = (0, _UtilsGetAngleJs.getVectorAngle)(new THREE.Vector2().subVectors(match2.position, opera.position), new THREE.Vector2().subVectors(oppositeMatch2.position, oppositeMatch1.position));
	    if (angle.angleValue < 5) {
	      (0, _rotationJs2['default'])(operaGroup || opera.parent, opera.position, angle);
	    }

	    if (180 - angle.angleValue < 5) {
	      angle.angleValue = 180 - angle.angleValue;
	      angle.clockWise = !angle.clockWise;
	      (0, _rotationJs2['default'])(operaGroup || opera.parent, opera.position, angle);
	    }
	  }

	  //更新连接数据
	  refer.userData.linkState = !refer.userData.linkState;
	  refer.userData.linkId = opera.id;
	  opera.userData.linkState = !opera.userData.linkState;
	  opera.userData.linkId = refer.id;

	  //更新组合情况
	  if (group === referGroup) {
	    if (operaGroup) {
	      while (operaGroup.children.length > 0) {
	        group.add(operaGroup.children[0]);
	      }
	      group.userData.stick += operaGroup.userData.stick;
	      _threeMangerJs.scene.remove(operaGroup);
	    } else {
	      group.add(opera.parent);
	      group.userData.stick++;
	    }
	  } else if (group === operaGroup) {
	    refer.parent.position.z = 0;
	    group.add(refer.parent);
	    group.userData.stick++;
	  } else {
	    group.name = 'collection';
	    group.userData.stick = 2;
	    refer.parent.position.z = 0;
	    opera.parent.position.z = 0;
	    group.add(refer.parent);
	    group.add(opera.parent);
	    _threeMangerJs.scene.add(group);
	  }
	};

	module.exports = exports['default'];

/***/ },
/* 23 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(2);

	var _presenter2 = _interopRequireDefault(_presenter);

	var messages = {
		lengthError: '两边之和小于第三边，无法组成图形',
		targetError: '同一线段的两点无法再连接',
		maxStickNumError: '最多只能连接四根小棒',
		fourLengthError: '两边之和小于两固定端点的距离无法连接'
	};

	exports['default'] = function (options) {
		if (!options) {
			return;
		}
		var $field = $(_presenter2['default'].view).find('.three2DPuzzle-tips');
		$field.html(messages[options]);
		$field.show(150).delay(2000).hide(200);
	};

	module.exports = exports['default'];

/***/ },
/* 24 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/12/15.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _GetAngleJs = __webpack_require__(11);

	var _EventRotationJs = __webpack_require__(21);

	var _EventRotationJs2 = _interopRequireDefault(_EventRotationJs);

	exports['default'] = function (staticMatch) {
	  "use strict";
	  var group = staticMatch.parent.parent;
	  var match1 = group.getObjectById(staticMatch.userData.linkId);
	  var match2 = group.getObjectById(match1.userData.connectId);
	  var selectedMatch = group.getObjectById(staticMatch.userData.connectId);
	  var angle = (0, _GetAngleJs.getAngle)(match2.position, staticMatch.position, selectedMatch.position);
	  var adjustAngle = 90 - angle.angleValue;
	  //垂直感应
	  if (Math.abs(adjustAngle) < 5 && adjustAngle != 0) {
	    var clockWise = adjustAngle > 0 ? angle.clockWise : !angle.clockWise;
	    (0, _EventRotationJs2['default'])(staticMatch.parent, staticMatch.position, { angleValue: Math.abs(adjustAngle), clockWise: clockWise });
	    return;
	  }

	  //平行感应
	  if (match2.userData.linkState) {
	    var oppositeMatch1 = group.getObjectById(match2.userData.linkId);
	    var oppositeMatch2 = group.getObjectById(oppositeMatch1.userData.connectId);

	    angle = (0, _GetAngleJs.getVectorAngle)(new THREE.Vector2().subVectors(selectedMatch.position, staticMatch.position), new THREE.Vector2().subVectors(oppositeMatch2.position, oppositeMatch1.position));
	    if (angle.angleValue < 5) {
	      (0, _EventRotationJs2['default'])(staticMatch.parent, staticMatch.position, angle);
	      return;
	    }

	    if (180 - angle.angleValue < 5) {
	      angle.angleValue = 180 - angle.angleValue;
	      angle.clockWise = !angle.clockWise;
	      (0, _EventRotationJs2['default'])(staticMatch.parent, staticMatch.position, angle);
	    }
	  }
	};

	module.exports = exports['default'];

/***/ },
/* 25 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	var _constants = __webpack_require__(6);

	exports['default'] = function (pointGroup) {
	    //存放x, y轴上的最值
	    var minXPoint = undefined,
	        maxXPoint = undefined,
	        minYPoint = undefined,
	        maxYPoint = undefined,
	        pointXGroup = [],
	        pointYGroup = [];

	    var _iteratorNormalCompletion = true;
	    var _didIteratorError = false;
	    var _iteratorError = undefined;

	    try {
	        for (var _iterator = pointGroup[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
	            var point = _step.value;

	            pointXGroup.push(point.x);
	            pointYGroup.push(point.y);
	        }
	    } catch (err) {
	        _didIteratorError = true;
	        _iteratorError = err;
	    } finally {
	        try {
	            if (!_iteratorNormalCompletion && _iterator['return']) {
	                _iterator['return']();
	            }
	        } finally {
	            if (_didIteratorError) {
	                throw _iteratorError;
	            }
	        }
	    }

	    minXPoint = Math.min.apply(Math, pointXGroup);
	    maxXPoint = Math.max.apply(Math, pointXGroup);
	    minYPoint = Math.min.apply(Math, pointYGroup);
	    maxYPoint = Math.max.apply(Math, pointYGroup);

	    if (minXPoint < _constants.CONSTRAINT.xmin + _constants.ROTATE_HANDLER_RADIUS) {
	        return true;
	    }
	    if (maxXPoint > _constants.CONSTRAINT.xmax - _constants.ROTATE_HANDLER_RADIUS) {
	        return true;
	    }
	    if (minYPoint < _constants.CONSTRAINT.ymin + _constants.ROTATE_HANDLER_RADIUS) {
	        return true;
	    }
	    if (maxYPoint > _constants.CONSTRAINT.ymax - _constants.ROTATE_HANDLER_RADIUS) {
	        return true;
	    }

	    return false;
	};

	module.exports = exports['default'];

/***/ },
/* 26 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/12/15.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _UtilsGetAngleJs = __webpack_require__(11);

	var _rotationJs = __webpack_require__(21);

	var _rotationJs2 = _interopRequireDefault(_rotationJs);

	var _UtilsUpdateVerticesJs = __webpack_require__(10);

	var _UtilsUpdateVerticesJs2 = _interopRequireDefault(_UtilsUpdateVerticesJs);

	var _UtilsMessagesJs = __webpack_require__(23);

	var _UtilsMessagesJs2 = _interopRequireDefault(_UtilsMessagesJs);

	exports['default'] = function (refer, opera) {
	  "use strict";
	  var group = refer.parent.parent;
	  if (group.userData.stick < 3) {
	    (0, _UtilsMessagesJs2['default'])('targetError');
	    return;
	  }

	  var referOther = refer.parent.getObjectById(refer.userData.connectId);
	  var operaOther = opera.parent.getObjectById(opera.userData.connectId);

	  if (group.userData.stick === 3) {
	    var newpoint = (0, _UtilsGetAngleJs.triangleCombinedPoint)(refer.position, referOther.position, operaOther.position, opera.position);
	    if (!newpoint) {
	      (0, _UtilsMessagesJs2['default'])('lengthError');
	      return;
	    }
	    refer.userData.position = newpoint;
	    opera.userData.position = newpoint;
	    (0, _UtilsUpdateVerticesJs2['default'])(refer.parent);
	    (0, _UtilsUpdateVerticesJs2['default'])(opera.parent);
	  } else {
	    var oppositeMatch1 = group.getObjectById(referOther.userData.linkId);
	    var oppositeMatch2 = group.getObjectById(oppositeMatch1.userData.connectId);

	    var newpoint = (0, _UtilsGetAngleJs.quadrilateralCombinedPoint)(refer.position, referOther.position, operaOther.position, opera.position, oppositeMatch2.position);
	    if (!newpoint) {
	      (0, _UtilsMessagesJs2['default'])('fourLengthError');
	      return;
	    }
	    refer.userData.position = newpoint;
	    opera.userData.position = newpoint;
	    (0, _UtilsUpdateVerticesJs2['default'])(refer.parent);
	    (0, _UtilsUpdateVerticesJs2['default'])(opera.parent);
	  }

	  refer.userData.linkState = !refer.userData.linkState;
	  refer.userData.linkId = opera.id;
	  opera.userData.linkState = !opera.userData.linkState;
	  opera.userData.linkId = refer.id;
	  group.userData.close = true;
	};

	module.exports = exports['default'];

/***/ },
/* 27 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/12/15.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _UtilsGetAngleJs = __webpack_require__(11);

	var _UtilsDrawMergeJs = __webpack_require__(18);

	var _UtilsDetectBoundaryJs = __webpack_require__(25);

	var _UtilsDetectBoundaryJs2 = _interopRequireDefault(_UtilsDetectBoundaryJs);

	var _UtilsUpdateVerticesJs = __webpack_require__(10);

	var _UtilsUpdateVerticesJs2 = _interopRequireDefault(_UtilsUpdateVerticesJs);

	exports['default'] = function (match, mousePoint) {
	  "use strict";
	  var group = match.parent.parent;
	  var match1 = group.getObjectById(match.userData.connectId);
	  var match2 = group.getObjectById(match1.userData.linkId);
	  var match3 = group.getObjectById(match2.userData.connectId);
	  var match4 = group.getObjectById(match3.userData.linkId);
	  var match5 = group.getObjectById(match4.userData.connectId);
	  var match6 = group.getObjectById(match5.userData.linkId);
	  var match7 = group.getObjectById(match6.userData.connectId);

	  var result = (0, _UtilsGetAngleJs.quadrilateralDiagonalMove)(match1.position, match3.position, match5.position, match7.position, mousePoint, match2.parent.userData.width, match4.parent.userData.width, match6.parent.userData.width, match.parent.userData.width);
	  if (!result) return;
	  var points = [result.combinLeftPoint, result.diagonalPoint, result.combinRightPoint];
	  if ((0, _UtilsDetectBoundaryJs2['default'])(points)) {
	    return;
	  }
	  match1.userData.position = result.combinLeftPoint;
	  match2.userData.position = result.combinLeftPoint;
	  match5.userData.position = result.combinRightPoint;
	  match6.userData.position = result.combinRightPoint;
	  match7.userData.position = result.diagonalPoint;
	  match.userData.position = result.diagonalPoint;

	  var _iteratorNormalCompletion = true;
	  var _didIteratorError = false;
	  var _iteratorError = undefined;

	  try {
	    for (var _iterator = group.children[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
	      var stick = _step.value;

	      (0, _UtilsUpdateVerticesJs2['default'])(stick);
	    }
	  } catch (err) {
	    _didIteratorError = true;
	    _iteratorError = err;
	  } finally {
	    try {
	      if (!_iteratorNormalCompletion && _iterator['return']) {
	        _iterator['return']();
	      }
	    } finally {
	      if (_didIteratorError) {
	        throw _iteratorError;
	      }
	    }
	  }

	  (0, _UtilsDrawMergeJs.updateMergeIcon)(group);
	};

	module.exports = exports['default'];

/***/ },
/* 28 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/12/15.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _UtilsGetAngleJs = __webpack_require__(11);

	var _UtilsDrawMergeJs = __webpack_require__(18);

	var _UtilsDetectBoundaryJs = __webpack_require__(25);

	var _UtilsDetectBoundaryJs2 = _interopRequireDefault(_UtilsDetectBoundaryJs);

	var _UtilsUpdateVerticesJs = __webpack_require__(10);

	var _UtilsUpdateVerticesJs2 = _interopRequireDefault(_UtilsUpdateVerticesJs);

	exports['default'] = function (stick, startPoint, mousePoint) {
	  "use strict";
	  var group = stick.parent;
	  var match1 = stick.getObjectByName('match1');
	  var match2 = stick.getObjectByName('match2');
	  var match3 = group.getObjectById(match1.userData.linkId);
	  var match4 = group.getObjectById(match3.userData.connectId);
	  var match5 = group.getObjectById(match4.userData.linkId);
	  var match6 = group.getObjectById(match5.userData.connectId);
	  var match7 = group.getObjectById(match6.userData.linkId);
	  var match8 = group.getObjectById(match7.userData.connectId);

	  var result = (0, _UtilsGetAngleJs.quadrilateralOppositeMove)(match1.position, match2.position, match5.position, match6.position, startPoint, mousePoint, match1.parent.userData.width, match3.parent.userData.width, match7.parent.userData.width);

	  if (!result) return;

	  var points = [result.leftPoint, result.rightPoint];
	  if ((0, _UtilsDetectBoundaryJs2['default'])(points)) {
	    return;
	  }
	  match1.userData.position = result.leftPoint;
	  match3.userData.position = result.leftPoint;
	  match2.userData.position = result.rightPoint;
	  match8.userData.position = result.rightPoint;

	  var _iteratorNormalCompletion = true;
	  var _didIteratorError = false;
	  var _iteratorError = undefined;

	  try {
	    for (var _iterator = group.children[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
	      var _stick = _step.value;

	      (0, _UtilsUpdateVerticesJs2['default'])(_stick);
	    }
	  } catch (err) {
	    _didIteratorError = true;
	    _iteratorError = err;
	  } finally {
	    try {
	      if (!_iteratorNormalCompletion && _iterator['return']) {
	        _iterator['return']();
	      }
	    } finally {
	      if (_didIteratorError) {
	        throw _iteratorError;
	      }
	    }
	  }

	  (0, _UtilsDrawMergeJs.updateMergeIcon)(group);
	};

	module.exports = exports['default'];

/***/ },
/* 29 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/12/22.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	var _threeMangerJs = __webpack_require__(5);

	exports['default'] = function (shape, preShape) {
	  "use strict";
	  if (preShape) {
	    var preGroup = preShape.parent.parent && preShape.parent.parent.name == 'collection' ? preShape.parent.parent : preShape.parent;
	    unSelectStick(preGroup);
	    preGroup.position.z = 0;
	  }
	  if (shape) {
	    var group = shape.parent.parent && shape.parent.parent.name == 'collection' ? shape.parent.parent : shape.parent;
	    selectStick(group);
	    group.position.z = 1;
	  }

	  if (shape && shape.name.indexOf('match') >= 0) {
	    if (!shape.userData.linkState) {
	      shape.material = _threeMangerJs.matchstick.getOMatchFaceMaterial();
	      shape.children[0].visible = true;
	    }
	  }
	};

	function selectStick(shape) {
	  var _iteratorNormalCompletion = true;
	  var _didIteratorError = false;
	  var _iteratorError = undefined;

	  try {
	    for (var _iterator = shape.children[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
	      var _shape = _step.value;

	      selectStick(_shape);
	    }
	    //if(shape.name == 'stick') shape.material.color = new THREE.Color(0xE6BB7B);
	  } catch (err) {
	    _didIteratorError = true;
	    _iteratorError = err;
	  } finally {
	    try {
	      if (!_iteratorNormalCompletion && _iterator['return']) {
	        _iterator['return']();
	      }
	    } finally {
	      if (_didIteratorError) {
	        throw _iteratorError;
	      }
	    }
	  }

	  if (shape.name == 'match1' || shape.name == 'match2') shape.material = _threeMangerJs.matchstick.getSMatchFaceMaterial();
	}

	function unSelectStick(shape) {
	  var _iteratorNormalCompletion2 = true;
	  var _didIteratorError2 = false;
	  var _iteratorError2 = undefined;

	  try {
	    for (var _iterator2 = shape.children[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
	      var _shape2 = _step2.value;

	      unSelectStick(_shape2);
	    }
	    //if(shape.name == 'stick') shape.material.color = new THREE.Color(0xE7B265);
	  } catch (err) {
	    _didIteratorError2 = true;
	    _iteratorError2 = err;
	  } finally {
	    try {
	      if (!_iteratorNormalCompletion2 && _iterator2['return']) {
	        _iterator2['return']();
	      }
	    } finally {
	      if (_didIteratorError2) {
	        throw _iteratorError2;
	      }
	    }
	  }

	  if (shape.name == 'match1' || shape.name == 'match2') {
	    shape.material = _threeMangerJs.matchstick.getMatchFaceMaterial();
	    shape.children[0].visible = false;
	  }
	  if (shape.name == 'unit') {
	    shape.position.z = 0;
	  }
	}
	module.exports = exports['default'];

/***/ },
/* 30 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by wuyukun on 2015/12/10.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _initViewDepends = __webpack_require__(31);

	var _initViewDepends2 = _interopRequireDefault(_initViewDepends);

	exports['default'] = function (view, model) {
	  (0, _initViewDepends2['default'])(model, view);
	};

	module.exports = exports['default'];

/***/ },
/* 31 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/12/8.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.unbindAll = unbindAll;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(2);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _constants = __webpack_require__(6);

	var _EventRemoveShape = __webpack_require__(32);

	var _EventRemoveShape2 = _interopRequireDefault(_EventRemoveShape);

	var _threeManger = __webpack_require__(5);

	var $view = null;
	var $dragMatch = undefined;

	exports['default'] = function (model, view) {
	    $view = $(view);
	    initSelect();
	    $view.find('#selector_dummy').val(3);
	    $dragMatch = $view.find('#dragMatch');
	    // bindStyle();
	    bindMouseDown();
	    bindRemove();
	    bindReSize();
	    if (!model.question_url) {
	        return;
	    }
	    var lengthArray = model.question_url.content.lengthArray;
	    $view.find('.matchCount').val(lengthArray.length);
	    initMatch(lengthArray);
	    if (_presenter2['default'].isTeacherMobile) {
	        bindStop(model);
	    } else if (_presenter2['default'].isStudentMobile) {
	        $view.find('.twobox').remove();
	        $view.find('.js-stop-sync-button').remove();
	        $view.find('.jigsaw_fd').css('bottom', 0);
	    }
	};

	// function bindStyle(){
	//     let selectorDiv=presenter.view.getElementsByClassName('dwc')[0];//选择框位置调整
	//     selectorDiv.setAttribute("style","padding: 0px 0px 0px 0px;display: block;");
	//     let selectorSize=presenter.view.getElementsByClassName('dwi')[0];
	//     selectorSize.setAttribute('style','width: 62px;');
	//     let selectorItems=presenter.view.getElementsByClassName('dw-bf')[0];//选择框样式
	//     selectorItems.setAttribute('style','width: 30px;position: absolute;top: -70px;left: 6px;;');
	//     let sizeDiv=presenter.view.getElementsByClassName('dww')[0];//选择框可见内容
	//     sizeDiv.id='sizeDiv';
	//     sizeDiv.setAttribute("style", "height: 53px;");
	// }
	function bindRemove() {
	    $view.find('.btn_del').bind('click', function () {
	        (0, _EventRemoveShape2['default'])();
	    });
	}
	function bindChange() {
	    var selector = $view.find('#selector_dummy');
	    var value = selector.val();
	    var temp = value;
	    value = selector.val();
	    if (temp != value) {
	        temp = value;
	        var Length = value;
	        var condition = undefined;
	        var spanL = document.createElement('span');
	        spanL.innerHTML = Length + 'cm';
	        spanL.className = 'match_wit';
	        spanL.style = 'display:none';
	        if (Length >= 2 && Length <= 7) {
	            condition = 'match_pic match_s';
	        } else if (Length >= 8 && Length <= 13) {
	            condition = 'match_pic match_m';
	        } else if (Length >= 14 && Length <= 20) {
	            condition = 'match_pic match_l';
	        }
	        $view.find('.match_two').children('span')[0].className = condition;
	        if ($view.find('.match_two').children('span')[1] !== undefined) {
	            $view.find('.match_two').children('span')[1].remove();
	        }
	        $view.find('.match_two').append(spanL);
	    }
	}
	function initMatch(lengthArray) {
	    for (var i = 0; i < lengthArray.length; i++) {
	        var Length = lengthArray[i];
	        var a = document.createElement('a');
	        a.className = 'match match_' + i;
	        var spanP = document.createElement('span');
	        var spanL = document.createElement('span');
	        var line = document.createElement('span');
	        var condition = undefined;
	        line.className = 'line';
	        if (Length >= 2 && Length <= 7) {
	            condition = 'match_pic match_s';
	        } else if (Length >= 8 && Length <= 13) {
	            condition = 'match_pic match_m';
	        } else if (Length >= 14 && Length <= 20) {
	            condition = 'match_pic match_l';
	        }
	        spanP.className = condition;
	        spanL.innerHTML = Length + 'cm';
	        spanL.className = 'match_wit';
	        a.appendChild(spanP);
	        a.appendChild(spanL);
	        var threeBox = $view.find('.threebox')[0];
	        threeBox.appendChild(a);
	        threeBox.appendChild(line);
	        bindMouseDown();
	    }
	}
	var mousex = 0,
	    mousey = 0;
	var divLeft, divTop;
	function bindMouseDown() {
	    $view.find('.match').bind('mousedown', mouseDownEven);
	    $view.find('.match').bind('touchstart', mouseDownEven);
	    $view.find('.match').bind('mousedown', mouseDownDrag);
	    $view.find('.match').bind('touchstart', mouseDownDrag);
	}
	var $selectMatch = undefined;
	function mouseDownEven(event) {
	    //let e=event.originalEvent.changedTouches ? event.originalEvent.changedTouches[0] : event;
	    if ($(this)[0].className.indexOf('match_input') >= 0) {
	        return;
	    }
	    var selItem = $view.find('.selMatch');
	    selItem.removeClass('selMatch');
	    $(this).addClass('selMatch');
	}
	function mouseDownDrag(event) {
	    var e = event.originalEvent.changedTouches ? event.originalEvent.changedTouches[0] : event;
	    if ($(this).hasClass('match_input')) {
	        return;
	    }
	    var offset1 = $(this).offset();
	    var offset2 = $view.find('.jigsaw_content').offset();
	    divLeft = parseInt(offset1.left - offset2.left, 10);
	    divTop = parseInt(offset1.top - offset2.top, 10);
	    mousey = e.clientY;
	    mousex = e.clientX;
	    $selectMatch = $(this);
	    $view[0].addEventListener('mousemove', dragElement, false);
	    $view[0].addEventListener('touchmove', dragElement, false);
	    $view[0].addEventListener('mouseup', mouseUpEvent, false);
	    $view[0].addEventListener('touchend', mouseUpEvent, false);
	    event.preventDefault();
	}
	function dragElement(event) {
	    var e = event.changedTouches ? event.changedTouches[0] : event;
	    var left = divLeft + (e.clientX - mousex);
	    var top = divTop + (e.clientY - mousey);
	    $dragMatch.css({
	        'top': top + 'px',
	        'left': left + 'px'
	    });
	    if ($selectMatch && $dragMatch.css('display') == 'none') {
	        $dragMatch.show();
	        var val = $selectMatch.find('.match_wit').html();
	        if (!val || val == '') val = $view.find('#selector_dummy').val();
	        var _length = parseInt(val);
	        _presenter2['default']._stickLength = _length;
	    }
	    event.preventDefault();
	}

	function mouseUpEvent(e) {
	    $dragMatch.hide();
	    $view[0].removeEventListener('mousemove', dragElement, false);
	    $view[0].removeEventListener('touchmove', dragElement, false);
	    $view[0].removeEventListener('mouseup', mouseUpEvent, false);
	    $view[0].removeEventListener('touchend', mouseUpEvent, false);
	    $selectMatch = null;
	    event.preventDefault();
	}
	function bindStop(model) {
	    var btn = $view.find('.js-stop-sync-button');
	    btn.style = 'display:block';
	    btn.bind('click', function (e) {
	        _presenter2['default'].eventBus.sendEvent('Sync', {
	            source: model.ID,
	            type: 'cancel',
	            value: {
	                syncId: _presenter2['default'].syncId
	            }
	        });
	    });
	}
	function bindReSize() {
	    var $view = $(_presenter2['default'].view);
	    $view.bind('resize', _threeManger.resizeThree);
	}

	function unbindAll() {
	    "use strict";
	    if ($view) {
	        $view.find('.match').unbind('mousedown', mouseDownEven);
	        $view.find('.match').unbind('touchstart', mouseDownEven);
	        $view.find('.match').unbind('mousedown', mouseDownDrag);
	        $view.find('.match').unbind('touchstart', mouseDownDrag);
	        $view = null;
	        $dragMatch = null;
	    }
	}

	function initSelect() {
	    var h = $view.find('.numbox').height();
	    var opt = {};
	    opt.select = { preset: 'select' };
	    $view.find('#selector').val('').scroller('destroy').scroller($.extend(opt['select'], {
	        theme: 'android-ics light', mode: 'scroller', height: h, display: 'inline', lang: ''
	    }));
	    $view.find('#selector_dummy').val(3);
	    $view.find('.android-ics.light .dw-ul').css('margin-top', -2 * h);
	}

/***/ },
/* 32 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _threeMangerJs = __webpack_require__(5);

	var _UtilsDestroyThreeObjectJs = __webpack_require__(19);

	var _UtilsDestroyThreeObjectJs2 = _interopRequireDefault(_UtilsDestroyThreeObjectJs);

	var _DocumentEventJs = __webpack_require__(12);

	exports['default'] = function () {
		if (!_DocumentEventJs.selectedShape) {
			return;
		}
		var group = _DocumentEventJs.selectedShape.parent.parent.name == 'collection' ? _DocumentEventJs.selectedShape.parent.parent : _DocumentEventJs.selectedShape.parent;
		_threeMangerJs.scene.remove(group);
		spliceIntersect(group);
		(0, _UtilsDestroyThreeObjectJs2['default'])(group);
		(0, _DocumentEventJs.setSelectedShape)(null);
		(0, _DocumentEventJs.setActivedObj)(null);
	};

	function spliceIntersect(shape) {
		"use strict";
		var _iteratorNormalCompletion = true;
		var _didIteratorError = false;
		var _iteratorError = undefined;

		try {
			for (var _iterator = shape.children[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
				var child = _step.value;

				spliceIntersect(child);
			}
		} catch (err) {
			_didIteratorError = true;
			_iteratorError = err;
		} finally {
			try {
				if (!_iteratorNormalCompletion && _iterator['return']) {
					_iterator['return']();
				}
			} finally {
				if (_didIteratorError) {
					throw _iteratorError;
				}
			}
		}

		var pos = _threeMangerJs.intersectObjs.indexOf(shape);
		if (pos > -1) {
			_threeMangerJs.intersectObjs.splice(pos, 1);
		}
	}
	module.exports = exports['default'];

/***/ },
/* 33 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	exports["default"] = function (state) {
	  var currentState;
	  if (state) {
	    currentState = JSON.parse(state);
	    // ToDo:处理Module的状态恢复
	  }
	};

	module.exports = exports["default"];

/***/ },
/* 34 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 获得当前Module的状态信息
	 * 可用于Module的状态恢复和保存
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(2);

	var _presenter2 = _interopRequireDefault(_presenter);

	exports['default'] = function () {
	  // TODO: 添加符合Module需求的状态对象
	  var moduleState = JSON.stringify({
	    module_id: _presenter2['default'].model.ID
	  });
	  return moduleState;
	};

	module.exports = exports['default'];

/***/ },
/* 35 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(2);

	var _presenter2 = _interopRequireDefault(_presenter);

	exports['default'] = function (path) {
	  _presenter2['default'].path = path;
	};

	module.exports = exports['default'];

/***/ },
/* 36 */
/***/ function(module, exports, __webpack_require__) {

	// 销毁 module 占用的内存
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	var _EventDocumentEventJs = __webpack_require__(12);

	var _initViewDependsJs = __webpack_require__(31);

	var _threeMangerJs = __webpack_require__(5);

	exports['default'] = function () {
	  "use strict";
	  (0, _EventDocumentEventJs.removeEventListerner)();
	  (0, _threeMangerJs.destroyThree)();
	  (0, _initViewDependsJs.unbindAll)();
	};

	module.exports = exports['default'];

/***/ },
/* 37 */
/***/ function(module, exports) {

	/**
	 * Created by Administrator on 2015/12/7.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});
	exports.getLengthArray = getLengthArray;
	exports.initViewPre = initViewPre;

	exports['default'] = function (scope) {
		
        var h = 64;
        var opt = {};
        opt.select = { preset: 'select' };
        $('#selector').val('').scroller('destroy').scroller($.extend(opt['select'], {
            theme: 'android-ics light', mode: 'scroller', height: h, display: 'inline', lang: ''
        }));
        $('#selector_dummy').val(3);
        $('.android-ics.light .dw-ul').css('margin-top', -2 * h);

	    // bindStyle();
	    bindAdd(scope);
	    bindRemove();
	    bindMouseDown();
	    //bindInput();
	};

	function initMatch(lengthArray) {
	    for (var i = 0; i < lengthArray.length; i++) {
	        var Length = lengthArray[i];
	        var a = document.createElement('a');
	        a.className = 'match match_' + i;
	        var spanP = document.createElement('span');
	        var spanL = document.createElement('span');
	        var line = document.createElement('span');
	        var condition = undefined;
	        line.className = 'line';
	        if (Length >= 2 && Length <= 7) {
	            condition = 'match_pic match_s';
	        } else if (Length >= 8 && Length <= 13) {
	            condition = 'match_pic match_m';
	        } else if (Length >= 14 && Length <= 20) {
	            condition = 'match_pic match_l';
	        }
	        spanP.className = condition;
	        spanL.innerHTML = Length + 'cm';
	        spanL.className = 'match_wit';
	        a.appendChild(spanP);
	        a.appendChild(spanL);
	        var threeBox = document.getElementsByClassName('threebox')[0];
	        threeBox.appendChild(a);
	        threeBox.appendChild(line);
	        bindMouseDown();
	        //bindClick(i);
	    }
	}
	// function bindStyle(){
	//     let selectorDiv=document.getElementsByClassName('dwc')[0];//选择框位置调整
	//     selectorDiv.setAttribute("style","padding: 0px 0px 0px 0px;display: block;");
	//     let selectorSize=document.getElementsByClassName('dwi')[0];
	//     selectorSize.setAttribute('style','width: 62px;');
	//     let selectorItems=document.getElementsByClassName('dw-bf')[0];//选择框样式
	//     selectorItems.setAttribute('style','width: 30px;position: absolute;top: -70px;left: 6px;;');
	//     let sizeDiv=document.getElementsByClassName('dww')[0];//选择框可见内容
	//     sizeDiv.id='sizeDiv'
	//     sizeDiv.setAttribute("style", "height: 33px;");
	// }
	function bindAdd(scope) {
	    var matcjAdd = $('.match_add');
	    matcjAdd.bind('click', function () {
	        var count = $('.matchCount').val();
	        if (count < 5) {
	            var Length = parseInt($('#selector_dummy').val());
	            for (var i = 0; i < count; i++) {
	                var temp = $('.match_' + i).children('span')[1].innerHTML;
	                if (Length + 'cm' == temp) {
	                    scope.$apply(function (scope) {
	                        scope.errorModel.errorText = '不能重复添加相同规格的小棒!';
	                    });
	                    return;
	                }
	            }
	            var a = document.createElement('a');
	            a.className = 'match match_' + count;
	            var spanP = document.createElement('span');
	            var spanL = document.createElement('span');
	            var line = document.createElement('span');
	            var condition = undefined;
	            line.className = 'line';
	            if (Length >= 2 && Length <= 7) {
	                condition = 'match_pic match_s';
	            } else if (Length >= 8 && Length <= 13) {
	                condition = 'match_pic match_m';
	            } else if (Length >= 14 && Length <= 20) {
	                condition = 'match_pic match_l';
	            }
	            spanP.className = condition;
	            spanL.innerHTML = Length + 'cm';
	            spanL.className = 'match_wit';
	            a.appendChild(spanP);
	            a.appendChild(spanL);
	            var threeBox = document.getElementsByClassName('threebox')[0];
	            threeBox.appendChild(a);
	            threeBox.appendChild(line);
	            //bindClick(count);
	            $('.matchCount').val(++count);
	        } else {
	            scope.$apply(function (scope) {
	                scope.errorModel.errorText = '最多只能添加5个小棒!';
	            });
	        }
	        bindMouseDown();
	    });
	}
	function bindRemove() {
	    $('.btn_del').bind('click', function () {
	        var count = $('.matchCount').val();
	        if (count == 0) {
	            return;
	        }
	        var deleteIndex = $('.selectedMatch').val();
	        if (deleteIndex == "" || deleteIndex == undefined) {
	            return;
	        }
	        var threeBox = document.getElementsByClassName('threebox')[0];
	        var deleteMatch = document.getElementsByClassName('match_' + deleteIndex)[0];
	        var line = document.getElementsByClassName('line')[deleteIndex];
	        threeBox.removeChild(deleteMatch);
	        threeBox.removeChild(line);
	        for (var i = deleteIndex; i < count - 1; i++) {
	            var movemMatch = document.getElementsByClassName('match_' + (parseInt(i) + 1))[0];
	            movemMatch.className = 'match match_' + i;
	            //bindClick(i);
	            bindMouseDown();
	        }
	        $('.selectedMatch').val('');
	        $('.matchCount').val(parseInt(count) - 1);
	        return;
	    });
	}

	function getLengthArray() {
	    var lengthArray = new Array();
	    var count = $('.matchCount').val();
	    for (var i = 0; i < count; i++) {
	        var match = $('.match_' + i);
	        var _length = match.children('.match_wit');
	        if (_length.text().length == 3) {
	            lengthArray.push(_length.text().substr(0, 1));
	        } else if (_length.text().length == 4) {
	            lengthArray.push(_length.text().substr(0, 2));
	        }
	    }
	    return lengthArray;
	}

	var mousex = 0,
	    mousey = 0;
	var divLeft, divTop;
	function bindMouseDown() {
	    $(document).unbind('mouseup');
	    $('.matchbox').unbind('mousedown');
	    $('.match').mousedown(function (e) {
	        if ($(this)[0].className.indexOf('match_input') >= 0) {
	            return;
	        }
	        var selItem = $('.selMatch');
	        selItem.removeClass('selMatch');
	        $(this).addClass('selMatch');
	        var offset = $(this).position();
	        divLeft = parseInt(offset.left, 10);
	        divTop = parseInt(offset.top, 10);
	        mousey = e.pageY;
	        mousex = e.pageX;
	        var selectItem = this.className.substr(12, 1);
	        $('.selectedMatch').val(parseInt(selectItem));
	        //$(this).bind('mousemove', dragElement);
	    });
	    function dragElement(event) {
	        if ($('.dragMatch')[0] === undefined) {
	            $(this).clone(true).appendTo($('.jigsaw_fd')).addClass('dragMatch');
	        }
	        var left = divLeft + (event.pageX - mousex);
	        var top = divTop + (event.pageY - mousey);
	        $('.dragMatch').css({
	            'top': top + 'px',
	            'left': left + 'px',
	            'position': 'absolute'
	        });
	        return true;
	    }
	    $(document).mouseup(function (e) {
	        $('.match').unbind('mousemove');
	        $('.dragMatch').remove();
	        return true;
	    });
	}

	function initViewPre(lengthArray) {
	    if (lengthArray !== undefined) {
	        initMatch(lengthArray);
	        $('.matchCount').val(lengthArray.length);
	    } else if (lengthArray) {
	        return;
	    }
	}

	var index = undefined;
	function bindInput() {
	    $('.dw-li').bind('mousedown', function () {
	        $('.dw-li').unbind('mousemove', dragInput);
	        $('.dw-li').bind('mousemove', dragInput);
	    });
	}
	function dragInput() {
	    console.log('move');
	    if (index === undefined) {
	        index = parseInt($(this).find('div').text());
	        console.log(index);
	    }
	    $('.dw-li').bind('mouseup', mouseupInput);
	}
	function mouseupInput() {
	    $('.dw-li').unbind('mousemove', dragInput);
	    index = undefined;
	}

/***/ },
/* 38 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/12/14.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(2);

	var _presenter2 = _interopRequireDefault(_presenter);

	exports['default'] = function () {
	    var question_id = '',
	        question_url = '';
	    if (_presenter2['default'].model !== undefined) {
	        try {
	            question_id = _presenter2['default'].model.question_id;
	            question_url = JSON.stringify(_presenter2['default'].model.question_url);
	        } catch (e) {}
	    }

	    return {
	        id: question_id,
	        dispatchOnly: true,
	        type_code: 'nd_puzzle',
	        type_name: '拼图工具',
	        url: question_url
	    };
	};

	module.exports = exports['default'];

/***/ },
/* 39 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by Administrator on 2015/12/15.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(2);

	var _presenter2 = _interopRequireDefault(_presenter);

	exports['default'] = function (controller) {
	    _presenter2['default'].controller = controller;
	    _presenter2['default'].eventBus = controller.getEventBus();
	    _presenter2['default'].eventBus.addEventListener('SyncCallback', _presenter2['default']);
	    _presenter2['default'].eventBus.addEventListener('PageLoaded', _presenter2['default']);
	};

	module.exports = exports['default'];

/***/ },
/* 40 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
	    value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(2);

	var _presenter2 = _interopRequireDefault(_presenter);

	exports['default'] = function (eventName, eventData) {
	    switch (eventName) {
	        case 'SyncCallback':
	            SyncCallback(eventData);
	            break;
	        case 'PageLoaded':
	            //console.log('PageLoaded');
	            break;
	        default:
	        // console.log nothing
	    }
	};

	var SyncCallback = function SyncCallback(eventData) {
	    var type = eventData.type;
	    var value = eventData.value;

	    var $button = $(_presenter2['default'].view).find('.js-stop-sync-button');
	    switch (type) {
	        case 'request':
	            // 发送任务
	            _presenter2['default'].syncId = value.syncId;
	            if (value.result) {
	                // 成功
	                $button.show();
	            } else {
	                window.ClassroomUtils.showTipMessageBox('同步题目失败');
	            }
	            break;
	        case 'cancel':
	            // 结束同步
	            if (value.result) {
	                $button.hide();
	            } else {
	                window.ClassroomUtils.showMessageBox([{
	                    html: '关闭'
	                }, {
	                    html: '重试',
	                    target: 'h5',
	                    callback: {
	                        eventName: 'Three2DPuzzle',
	                        eventData: {
	                            source: _presenter2['default'].model.ID,
	                            item: 'retry'
	                        }
	                    }
	                }], '结束任务失败！');
	            }
	            break;
	    }
	};
	module.exports = exports['default'];

/***/ }
/******/ ]);