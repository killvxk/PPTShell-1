/**
 * Created by px on 2015/6/11.
 */

define(['angularAMD', 'customeditor.service'
], function (angularAMD) {
    angularAMD
        .directive('cancelButton', [function () {
            return {
                restrict: 'EA',
                templateUrl: 'interaction/components/site-directive/save-buttons/cancel-button.html',

                controller: ['$scope', function ($scope) {
                    var postMsg = function (strMsg) {
                        window.messageIframe.messenger.targets['parent'].send({message: strMsg});
                    }
                    $scope.cancel = function () {
                        postMsg("QuestionEditCancel");
                    }
                }]
            };
        }])
        .directive('newSaveButtons', ['ngDialog', 'CustomEditorService', '$stateParams', '$http', '$timeout', function (ngDialog, CustomEditorService, $stateParams, $http, $timeout) {
            return {
                restrict: 'E',
                replace: true,
                templateUrl: 'interaction/components/site-directive/foot-tool/save-buttons/new-save-buttons.html',
                scope: {postData: '=postData', validData: '=', encodeData: '=', decodeData: '=', version: '@'},
                controller: ['$scope', '$q', '$filter', 'diskpathService', function ($scope, $q, $filter, diskpathService) {
                    $http.get("/prepare/mapping").success(function (data) {
                        $scope.types = data.interact_question;
                    });
                    $scope.lang = $stateParams._lang_;
                    $scope.is_modify = ($stateParams.is_modify === 'true' || $stateParams.is_modify === true); //是否为编辑模式
                    var saveQuestion = function () {
                        if ($scope.validData) {
                            if ($scope.$parent.errorModel) {
                                $scope.$parent.errorModel.errorText = "";
                            }

                            if ($scope.validData() != true) {
                                var deferred = $q.defer();
                                deferred.reject();
                                return deferred.promise;
                            }
                        }
                        var doAjax = null;
                        if (!$scope.postData.id) {
                            doAjax = CustomEditorService.addQuestion($scope.encodeData($scope.postData));
                        } else {
                            doAjax = CustomEditorService.updateQuestion($scope.encodeData($scope.postData));
                        }

                        return doAjax.then(function (rtnData) {
                            angular.extend($scope.postData, $scope.decodeData(rtnData));
                        }, function (error) { //添加后台交互发生错误情况的处理
                            if ($scope.$parent.errorModel) {
                                //error { data, status, statusText }
                                console.error(error);
                                if (error.data) {
                                    $scope.$parent.errorModel.errorText = "发生系统错误：[" + error.data.message + "].";
                                } else {
                                    $scope.$parent.errorModel.errorText = "发生系统错误：[status:" + error.status + ", text:" + error.statusText + "].";
                                }
                            }

                            var deferred = $q.defer();
                            deferred.reject();
                            return deferred.promise;
                        });
                    };
                    var postMsg = function (strMsg) {
//                    window.messageIframe.messenger.targets['parent'].send({message:strMsg, id: $scope.postData.id,isCustom:true,question_type:$stateParams.question_type});
                        var postParam = {
                            message: strMsg,
                            id: $scope.postData.id,
                            isCustom: true,
                            question_type: $stateParams.question_type
                        };

                        switch ($stateParams.question_type) {
                            case 'linkup':
                            case 'nd_memorycard':
                                postParam.skin = $scope.postData.skin.css_url;
                                postParam.spirit_root = $scope.postData.skin.package_url;
                                if ($scope.postData.timer) {
                                    postParam.timer_type = $scope.postData.timer.timer_type;
                                    postParam.time_limit = parseInt($scope.postData.timer.time_minute || 0) * 60 + parseInt($scope.postData.timer.time_second || 0);
                                }
                                break;
                            default:
                                postParam.skin = $scope.postData.skin.css_url;
                                postParam.question_title = window.customHtmlEncode($scope.postData.title);
                                if ($scope.postData.timer) {
                                    postParam.timer_type = $scope.postData.timer.timer_type;
                                    postParam.time_limit = parseInt($scope.postData.timer.time_minute || 0) * 60 + parseInt($scope.postData.timer.time_second || 0);
                                }
                        }

                        window.messageIframe.messenger.targets['parent'].send(postParam);
                    };
                    var showSuccessSaved = function () {
                        angular.element('.exam_wood .global_success_tip').hide().show();
                        $timeout(function () {
                            angular.element('.exam_wood .global_success_tip').hide();
                        }, 3000);
                    };
                    $scope.preview = function () {

                        saveQuestion().then(function () {
                            postMsg("QuestionPreview");

                            CustomEditorService.getPreviewUrl().then(function (data) {
                                //$scope.previewUrl = $filter('filterPreviewUrl')($scope.postData.id);
                                 $scope.previewUrl = data.url +
                                    '&_lang_=' + $stateParams._lang_ +
                                    '&sys=' + $stateParams.sys +
                                    '&rnd=' +  new Date().getTime();

                                var $window = angular.element(window);
                                var width = Math.min($window.width() * 0.85, 1282),
                                    height = Math.min($window.height() * 0.85, 802);
                                $scope.dialogBodyStyle = {padding: '0', height: height + 'px'};
                                $scope.iframeStyle = {width: width + 'px', height: height + 'px', border: '0 none'};
                                ngDialog.open({
                                    templateUrl: 'interaction/components/site-directive/save-buttons/preview.html',
                                    scope: $scope,
                                    className: "bk-dialog bk-dialog-previewtask"
                                });
                            });
                        })
                    }
                    var findCode = function (type) {
                        var types = $scope.types;
                        for (var i = 0; i < types.length; i++) {
                            if (types[i].type == type) {
                                return types[i].code;
                            }
                        }
                    }
                    $scope.save = function () {
                        saveQuestion().then(function () {
                            showSuccessSaved();
                            postMsg("QuestionSaved");
                            console.log(JSON.stringify({
                                message: "QuestionSaved",
                                id: $scope.postData.id,
                                question_type: $stateParams.question_type,
                                question_code: findCode($stateParams.question_type),
                                action: "save",
                                file_path: $scope.postData.physic_path
                            }));
                        });
                    }
                    $scope.add = function () {
                        saveQuestion().then(function (rtnData) {
                            postMsg("QuestionAdd");

                            console.log(JSON.stringify({
                                message: "QuestionAdd",
                                id: $scope.postData.id,
                                question_type: $stateParams.question_type,
                                question_code: findCode($stateParams.question_type),
                                action: "save",
                                file_path: diskpathService.getFilepath()
                            }));
                        });
                    }
                }]
            };
        }])

});
