define([
	'jquery',
	'./ResourceExplorer/script'
],function(
	$,
	ResourceExplorer
){
	return function(){
		var stores = [];
		return {
			requires:'workbench',
			activator : function(bundleContext){
			},
			extensionPoints:[{
				point:'store',
				resolve:function(config){
					config = !config ? [] : ($.isArray(config) ? config : [config]);
					$.each(config, function(){
						stores.push(this);
					});
				}
			}],
			extensions :  function(bundleContext){
				return [{
					targetBundle:'workbench',
					point:'dialog',
					config:[{
						name: 'nd.esp.resource.select',
						title: '资源库',
						content: function (bodyEl, contentOptions, layer) {
							var storeParams = contentOptions['storeParams'];
							var explorer = new ResourceExplorer(bodyEl, contentOptions.type, stores, storeParams);
							explorer.on('select', function (data) {
								layer.data = data;
							});
						},
						width: 1008,
						height: 678,
						buttons: ['ok', 'cancel']
					}]
				}];
			}
		};
	};
});