/**
 * Created by px on 2015/6/15.
 */
define(['angularAMD'
], function (angularAMD) {
    angularAMD
        .directive('cardItem', [ function () {
            return {
                restrict: 'E',
                templateUrl: 'interaction/probabilitycard/directive/card-item/card-item.html',
                scope: {itemsData: '=itemsData', itemData: '=itemData', minCardCount:'=minCardCount', selectCard:'&', deleteCard:'&'},
                controller: ['$scope', '$filter', function ($scope, $filter) {
                	//插入底图
                	$scope.insertImage = function() {
                		$scope.itemData.hasImage = true;
                		$scope.itemData.isEmpty = false;
                	};
                	
                	//插入文字
                	$scope.insertText = function(event) {
                		$scope.itemData.hasText=true;
                		$scope.itemData.isEmpty = false;
                		
                		$(event.target).parents("li.card_list").find(".text").focus();
                	};
                	
                	//高度自适应
                	$scope.onTextChange = function(event) {
                		$scope.itemData.text_style.height = (!$scope.itemData.text ? 4 * 1.1 + 0.2 : ($scope.itemData.text.length * 1.1 + 0.2)) + 'em';
                	};
                	
                	$scope.onKeydown = function(event) {
                		if(event.which === 13 || (event.which === 32 && !event.target.value)) { //回车键
                			event.cancelable = true;
                    		event.preventDefault();
                    		
                    		return false;
                		}
                	};
                	
                	$scope.onFocus = function(event) {
                		$(event.target).attr('placeholder', '');
                	};
                	
                	$scope.onBlur = function(event) {
                		$(event.target).attr('placeholder', $filter('translate')('probabilitycard.cardname.input'));
                	};
                	
                	$scope.onTextChange();
                }]
            };
        }])
});