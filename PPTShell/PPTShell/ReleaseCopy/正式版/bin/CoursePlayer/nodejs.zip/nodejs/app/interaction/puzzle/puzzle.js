/**
 * puzzle
 * 2015-12-02 14:19:19
 */
define(['app', 'puzzle/directive/puzzle.directive'], function (app) {
    'use strict';
    app.controller('puzzle_ctrl', [
        '$scope', 'skin_service', '$stateParams', 'CustomEditorService', '$rootScope', '$filter',
        function ($scope, skin_service, $stateParams, CustomEditorService, $rootScope, $filter) {
            $rootScope.moduleScope = $scope;
            $scope.errorModel = {};

            $scope.model = {
                "id": "",
                "module_code": "nd_puzzle", // 题目类型
                "title": "拼图", //标题
                "skin": {
                    code: "wood",
                    css_url: "",
                    name: $filter('translate')('app.skin.wood'),
                    package_url: ""
                },
                "timer": {
                    "timer_type": "sequence",  //计时器类型: ["sequence", "countdown"]
                    "time_minute": "0",    //倒计时初始设置-分钟，timer_type="countdown"时有效
                    "time_second": "0"     //倒计时初始设置-秒，timer_type="countdown"时有效
                },
                "properties": [	//模块静态数据模型
                    {
                        "name": "question_id",
                        "display_name": "题目ID",
                        "type": "string",
                        "value": "",
                        "is_localized": false
                    },
                    {
                        "name": "question_url",
                        "display_name": "题目内容",
                        "type": "jsonFile",
                        "value": "",
                        "is_localized": false
                    }
                ],
                "content": {
                    "test1":1
                }
            };

            //数据加载
            var loadingData = function (id) {

                $scope.isloadingData = true;
                CustomEditorService.getQuestionInfoById(id)
                    .then(function (rtnData) {
                        console.log('start');
                        if (!rtnData) {
                            $scope.errorModel.errorText = $filter('translate')('app.unvalidno');
                        } else {
                            if (rtnData.skin.code != '') {
                                $scope.model = $scope.decodeData(rtnData, true);
                            } else {
                                $scope.model.id = rtnData.id;
                            }
                            try{
                                AddonThree2DPuzzle_create().initViewPre($scope.model.content.lengthArray);
                            }catch (e){
                                return;
                            }
                            skin_service.set_skin_by_code($scope.model.skin.code, "v1");
                            $scope.errorModel.errorText = "";
                            $scope.isloadingData = false;
                        }
                    }, function (error) {
                        $scope.errorModel.errorText = $filter('translate')('app.question.get.error');
                    })
            };

            //入口
            if (!$stateParams.id) { //新增
                skin_service.set_skin_by_code($scope.model.skin.code, "v1");
                console.log($stateParams.id);
            } else { //修改
                loadingData($stateParams.id);
            }
			
			$scope.$on('changgedSkin',function(){
                $rootScope.scaleHtml();
            });

            //数据验证
            $scope.validPostData = function () {
               var length=AddonThree2DPuzzle_create().getLengthArray();
                if(length==0){
                    $scope.errorModel.errorText = '当前未添加任何小棒!';
                    return false;
                }
                return true;
            };

            //数据模型-编码
            $scope.encodeData = function (model) {
                var addon=AddonThree2DPuzzle_create();
                model.content.lengthArray=new Object();
                model.content.lengthArray=addon.getLengthArray();
                    //$scope.$apply(function(scope){
                    //    scope.errorModel.errorText = '当前未添加任何小棒!';
                    //});
                    //var date = new Date();
                    //var curDate = null;
                    //do { curDate = new Date(); }
                    //while(curDate-date < 5000);

                return model;
            };

            //数据模型-解码
            $scope.decodeData = function (model, isInitLoad) {

                return model;
            };


        }
    ]);
});
