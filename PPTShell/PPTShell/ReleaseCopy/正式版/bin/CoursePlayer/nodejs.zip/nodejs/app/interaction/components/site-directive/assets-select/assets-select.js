define(['angularAMD'
], function (angularAMD) {
    angularAMD.directive('assetsSelect', ['$rootScope', '$stateParams', 'ngDialog', '$filter', '$q','$http',
        function ($rootScope, $stateParams, ngDialog, $filter, $q, $http) {
            return {
                restrict: 'EA',
                scope: {
                    imageDataNew: '=imageData',
                    imageColumn: '@',
                    imageTitle: '@',
                    imageSize: '@',
                    afterAdd: '&',
                    afterClose: '&',
                    isCommonValid: '@',
                    commonValidParam: '='
                },
                link: function (scope, element, attrs) {
                    attrs.itemType = !attrs.itemType ? 'image' : attrs.itemType;
                    attrs.selectType = !attrs.selectType ? 'single' : attrs.selectType;

                    attrs.space = !$stateParams.space ? 'personal' : $stateParams.space;
                    scope.model = {
                        item_type: attrs.itemType,
                        href: [
                            window.location.protocol + "//" + window.location.host + '/questions/question.html#/select_asset',
                            '?sys=prepare&is_interaction=true',
                            '&category=', attrs.itemType,
                            '&select_type=', attrs.selectType,
                            '&space=', attrs.space,
                            '&id=', $stateParams.id,
                            '&question_base=', $stateParams.question_base || '',
                            '&chapter_id=', $stateParams.chapter_id || '',
                            '&token_info=', encodeURIComponent($stateParams.token_info),
                            '&chapter_name=', encodeURIComponent($stateParams.chapter_name || ''),
                            '&_lang_=', $stateParams._lang_ || ''
                        ].join('')
                    };

                    element.click(function () {
                        var cancelClick = element.attr("cancelClick");
                        if (cancelClick === 'true' || cancelClick === true) return;

                        ngDialog.open({
                            templateUrl: 'interaction/components/site-directive/assets-select/assets-select.html',
                            scope: scope,
                            className: "bk-dialog",
                            overlay: false
                        }).closePromise.then(function (data) {
                                scope.afterClose();
                            });

                        if (window.messageIframe) {
                            window.messageIframe.doMessage = function (dataMessage) {
                                if (dataMessage.message == "AssetsSelected") {
                                    scope.$apply(function () {
                                        if(dataMessage.data.length === 1) {
                                            if(dataMessage.data[0].indexOf('${ref-path}') === -1 && dataMessage.data[0].indexOf('${ref-base}') === -1) {
                                                var title = dataMessage.titles[0];
                                                $http.get(dataMessage.data[0] + "&is_interaction=true")
                                                    .success(function(data, status, headers, config) {
                                                        scope.imageDataNew[scope.imageColumn] = data;
                                                        !!scope.imageTitle && (scope.imageDataNew[scope.imageTitle] = title);
                                                        scope["$$childTail"].closeThisDialog();
                                                        scope.afterAdd();
                                                    })
                                                    .error(function(data, status, headers, config) {
                                                        console.log(data);
                                                        console.log('资源下载失败!');
                                                    });
                                            } else {
                                                scope.imageDataNew[scope.imageColumn] = dataMessage.data[0].replace('${ref-base}/_ref/', '${ref-path}/');
                                                !!scope.imageTitle && (scope.imageDataNew[scope.imageTitle] = dataMessage.titles[0]);
                                                scope["$$childTail"].closeThisDialog();
                                                scope.afterAdd();
                                            }
                                        } else {
                                            scope.imageDataNew[scope.imageColumn] = dataMessage.data.replace('${ref-base}/_ref/', '${ref-path}/');
                                            !!scope.imageTitle && (scope.imageDataNew[scope.imageTitle] = dataMessage.title);
                                            scope["$$childTail"].closeThisDialog();
                                            scope.afterAdd();
                                        }
                                    });
                                }
                            };
                        }
                    });
                }
            };
        }])

});