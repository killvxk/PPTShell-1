
define(['angularAMD',
	'components/site-directive/foot-tool/foot-tool-time',
	'components/site-directive/foot-tool/save-buttons/new-save-buttons',
	'components/site-directive/interaction-hint/interaction-hint'
], function (angularAMD) {
	angularAMD.directive('footTool', ['skin_service','$stateParams', '$rootScope', 'UserDataService', function (skin_service,$stateParams,$rootScope, UserDataService) {
		return {
			restrict: 'E',
			scope: {
				isSimpleMode:'=isSimpleMode',
				descriptionId:'=descriptionId',
				model:'=model',
				postData:'=postData',
				validData:'=',
				encodeData:'=',
				decodeData:'=',
				buttonCallback:'=',
				arrayHide:'=arrayHide',
				apiVersion:'@',
				interactionHint: '@'
			},
			templateUrl: 'interaction/components/site-directive/foot-tool/foot-tool.html',

			link: function ($scope, element, attrs) {
				$scope.showInteractionHint = !($scope.interactionHint === false || $scope.interactionHint === 'false');
				$('#description-id a.mainlink').attr('draggable', 'false');

				var i , l ;
				$scope.arrHide = [false,false,false,false,false,false];
				if($scope.arrayHide){
					for( i = 0,l=$scope.arrayHide.length ; i<l ; i++ ){
						$scope.arrHide[$scope.arrayHide[i]-1] = true ;
					}
				}

				var $own = angular.element(".com_lay_foottool");
				$own.on('click','ul.left_ul > li',function(e){
					var $target = angular.element(e.target) ;
					var $li = $(this) ;
					if( $target.hasClass("btn_submit") ||  $target.hasClass("btn_cancel")){
						$li.has(".toolpop").removeClass("on");
						return false  ;
					}
					if($li.hasClass('disprtion') && !$li.hasClass('on')) {
						$rootScope.QuestionGuideOpenTime = new Date().getTime();

						var phase = $rootScope.$$phase;
						if (!(phase == '$apply' || phase == '$digest')) {
							$rootScope.$apply();
						}
					}
					if( $li.hasClass('on') ){
						return false ;
					}else {
						$li.siblings("li").removeClass("on");
						$li.has(".toolpop").addClass("on");
						e.stopPropagation();
						e.preventDefault();
						angular.element('.exam_wood').on("click",function(){
							$li.has(".toolpop").removeClass("on");
							angular.element('.exam_wood').off("click");

							if(!angular.element("#descriptionTemplate").hasClass('on')) {
								$rootScope.stopQuestionGuidePlayer && $rootScope.stopQuestionGuidePlayer();
							}
							if($li.attr("id") === 'timesetId'){
								angular.element('#timesetId').trigger("resetTime");
							}

						});
					}

				})
				setTimeout(function(){
					!!!$scope.model.id && skin_service.set_skin_by_code('wood','v1');

					//题型描述
//                	angular.element("#descriptionTemplate").html(angular.element("#"+$scope.descriptionId).html());
					$(angular.element("#"+$scope.descriptionId).children()).appendTo(angular.element("#descriptionTemplate"));
					/**
					 * 通过H5 LocalStorage
					 * 判断当前用户($stateParams.token_info)是否[初次打开]该习题编辑器($stateParams.question_type);
					 * 若是，自动弹出题型描述;
					 */
					UserDataService.checkUserActivity(angular.element(".com_lay_foottool").find(".disprtion"));
				},100);

				//皮肤

				skin_service.get_skins().then(function (data) {
					$scope.list = data;
					angular.forEach($scope.list,function(item){
						item.cover_url = 'interaction/' + $stateParams.area+'/assets/css/'+item.code+'.png?'+require.s.contexts._.config.urlArgs;
					});
				});

				$scope.selectSkin = function (skin) {

					skin_service.set_skin(skin,version);

					//皮肤数据存到题型module中
					angular.extend(model.skin, skin);
					//关闭popup
					$scope.$parent.$parent.hide();
				}
				//皮肤end

			}
		};
	}])

});