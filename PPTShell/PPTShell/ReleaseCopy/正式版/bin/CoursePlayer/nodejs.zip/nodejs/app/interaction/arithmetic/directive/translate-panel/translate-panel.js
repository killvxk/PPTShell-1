/**
 * Created by zy on 2015/7/6.
 */
define(['angularAMD'
], function (angularAMD) {
    angularAMD .directive('translatePanel', [ function () {
        return {
            restrict:'E',
            templateUrl:'interaction/arithmetic/directive/translate-panel/translate-panel.html',
            scope: {
            	calNum:'=calNum',
            },
            link:function(scope,element,attrs){
            	//console.log(scope.calNum) ; 
               // scope.first_data_bai=scope.inputData.first_data;
            	
                scope.checkNum = function( item ){
                	item.hide = !item.hide;
                	if( !item.hide ) return ; 
                	//item.showNum = item.showNum===''?item.num:'';
                	var oper = scope.calNum.operator.operator ; 
                	if( oper === "+" || oper === '-' ){
                    	if(   mulResult(item) ){
                    		
                    	}else {
                    		item.hide = !item.hide;
                    		scope.$parent.errorModel.errorText = "当前的编辑格子会存在多解...." ; 
                    	}
                	}else if( oper === "×" || oper === '-' ){
                		
                	}

                }
                
                function mulResult(item){
                    var n1,n2,n3 ; 
                    var findItemByIndex = function(numItems){
                        for( var i = 0 , l =  numItems.length ; i<l ; i++ ){
                          if( numItems[i].index === item.index ){
                            return  numItems[i] ; 
                          }
                        }
                        return false;
                   }
                    n1 = findItemByIndex(scope.calNum.number_first.items) ; 
                    //减法的时候转化成加法计算
                    if( parseInt(scope.calNum.number_first.number)<0 ){
                      n3 = findItemByIndex(scope.calNum.number_second.items) ; 
                      n2 = findItemByIndex(scope.calNum.number_result.items) ; 
                    }else {
                      n2 = findItemByIndex(scope.calNum.number_second.items) ; 
                      n3 = findItemByIndex(scope.calNum.number_result.items) ; 
                    }

                    if( n1 && n2 && n1.hide && n2.hide ){
                      if( n1.num == n2.num && (n1==="0"||n1==="9")){
                        return true //单解
                      }else {
                        return false ;
                      }
                    }else if(  n1 && n3 && (n1.hide && n3.hide) ||  n3 && n2 &&(n2.hide && n3.hide)  ){
                    	if( !n2.hide && n1.num === "9" && n3.num === "0" ){
                    		return true ;
                    	}
                    	if( !n1.hide && n2.num === "9" && n3.num === "0" ){
                    		return true ;
                    	}
                    	return false ; //加减法多解
                    }

                    return true ; 
                    
               }
                
                

                
            }
            
        };
    }])

});
