/**
 *
 */
define(['app', 'wordpuzzle/directive/wordpuzzle.directive'
], function (app) {
    'use strict';
    app.controller('wordpuzzle_ctrl', [
        '$scope','skin_service','$stateParams','CustomEditorService','CharsetService','$rootScope',"$filter","$timeout",
        function ($scope,skin_service,$stateParams,CustomEditorService,CharsetService,$rootScope,$filter,$timeout) {
        	//常量定义 5、6格用.largeBox,,7、8格用.normalBox,9、10格用.smallBox
            var DIRECTION = {
            	HORIZONTAL: "horizontal",
            	VERTICAL: "vertical",
				LARGEBOX : "largeBox",
				NORMALBOX:"normalBox",
				SMALLBOX:"smallBox"
            };
            //最大行列
            var MAX_WIDTH = 10, MAX_HEIGHT = 10, MIN_WIDTH = 5, MIN_HEIGHT = 5;
			$scope.opts = {
				wordboardClass:DIRECTION.LARGEBOX
			};
            $rootScope.moduleScope = $scope;
            $scope.errorModel = {};
			var DEFAULT_TITLE = $filter('translate')('wordpuzzle.default_title');
            $scope.model = {
            	"title": DEFAULT_TITLE,
                "skin": {
                    code: "wood",
                    css_url: "${ref-path}/edu/esp/preparecustomeditor/wordpuzzle/wood/css/wood.css",
                    name:  $filter('translate')('wordpuzzle.muwen'),
                    package_url: "${ref-path}/edu/esp/preparecustomeditor/wordpuzzle/wood"
                },
                "timer": {
                    "timer_type":"sequence",
                    "time_minute":"0",
                    "time_second":"0"
                },
                border: {"width": MIN_WIDTH, "height": MIN_HEIGHT},
                words: [],
                chars: []
            };
			$scope.focusOnTitle = function($event) {
				if($.trim($scope.model.title) == DEFAULT_TITLE) {
					$scope.model.title = "";
					$($event.target).css({'color': ''});
				}
			};
			$scope.blurOnTitle = function($event) {
				if(!!!$scope.model.title) {
					$scope.model.title =  DEFAULT_TITLE;
					$($event.target).css({'color': '#D3D3D3'});
				}
			};
            
            var loadingData = function(id){
            	$scope.isloadingData=true;
                CustomEditorService.getQuestionInfoById(id)
                    .then(function(rtnData){
                        if(!rtnData){
                            $scope.errorModel.errorText = $filter('translate')('wordpuzzle.unvalidno');
                        }else{
                            if(rtnData.skin.code!=''){
                                $scope.model=$scope.decodeData(rtnData);
                                skin_service.set_skin_by_code($scope.model.skin.code,'v1');
                            }else{

                                $scope.showGuide = true;
                                $scope.model.id=rtnData.id;
                                skin_service.set_skin_by_code($scope.model.skin.code,'v1');
                            }
                            $scope.errorModel.errorText = "";
                            $scope.isloadingData=false;

							if($.trim($scope.model.title) != DEFAULT_TITLE) {
								angular.element('#module_title_ta').css({'color': ''});
							}
                            setValues();
                        }
                    },function(error){
                        $scope.errorModel.errorText = $filter('translate')('wordpuzzle.get_title_error');
                    })
            };
            
            $scope.horizontalTips = []; //横向提示
            $scope.verticalTips = [];   //纵向提示
            $scope.rows = [];           //单元格
            var isHorizontal = function(direction) {
            	return direction == DIRECTION.HORIZONTAL;
            };
            var isNotEmptyArray = function(array) {
            	return $.isArray(array) && array.length > 0;
            };
            var mapKey = function(x, y) {
            	return x + "&" + y;
            };
            var setValues = function() {
            	//字符 --> key: x_y, value: char
            	var wordCoordinateMap = [];
            	angular.forEach($scope.model.words, function(item){
            		var charIndex = 0;
            		if(isHorizontal(item.direction)) {
            			var x = item.start_axis.x;
            			var startIndex = item.start_axis.y;
            			var endIndex = item.end_axis.y;
            			for(var y = startIndex; y <= endIndex; y++) {
            				wordCoordinateMap[mapKey(x, y)] = item.word.charAt(charIndex++);
            			}
            		} else {
            			var y = item.start_axis.y;
            			var startIndex = item.start_axis.x;
            			var endIndex = item.end_axis.x;
            			for(var x = startIndex; x <= endIndex; x++) {
            				wordCoordinateMap[mapKey(x, y)] = item.word.charAt(charIndex++);
            			}
            		}
            	});
            	
                //提示
            	var coordinateTipsMap = []; // key: x_y, value: [tip,...]
            	var tipCoordinateMap = []; // key: x_y, value: {char, horizontalIndex, verticalIndex}
            	var tipCoordinate = null, horizontalIndex = 0, verticalIndex = 0;
                angular.forEach($scope.model.chars, function(item){
                	if(angular.isObject(item.hints)) {
                		tipCoordinate = {};
                		if(item.hints.horizontal != "") {
                			tipCoordinate.horizontalIndex = ++horizontalIndex;
                			var tip = {
                				chars: item.hints.horizontal,
                				x: item.x,
                    			y: item.y,
                    			word: item.word.horizontal,
                    			direction: DIRECTION.HORIZONTAL
                			};
                			$scope.horizontalTips.push(tip);
                			
                			var endIndex = item.y + item.word.horizontal.length;
                			for(var y = item.y; y < endIndex; y++) {
                				var coordinateTips = coordinateTipsMap[mapKey(item.x, y)];
                				if(!coordinateTips) {
                					coordinateTips = [];
                					coordinateTipsMap[mapKey(item.x, y)] = coordinateTips;
                				}
                				
                				coordinateTips.push(tip);
                			}
                		}
                    	if(item.hints.vertical != "") {
                    		tipCoordinate.verticalIndex = ++verticalIndex;
                    		var tip = {
                    			chars: item.hints.vertical,
                    			x: item.x,
                    			y: item.y,
                    			word: item.word.vertical,
                    			direction: DIRECTION.VERTICAL
                    		};
                    		$scope.verticalTips.push(tip);
                    		
                    		var endIndex = item.x + item.word.vertical.length;
                			for(var x = item.x; x < endIndex; x++) {
                				var coordinateTips = coordinateTipsMap[mapKey(x, item.y)];
                				if(!coordinateTips) {
                					coordinateTips = [];
                					coordinateTipsMap[mapKey(x, item.y)] = coordinateTips;
                				}
                				
                				coordinateTips.push(tip);
                			}
                    	}

                    	tipCoordinate.char = item.char;
                    	tipCoordinateMap[mapKey(item.x, item.y)] = tipCoordinate;
                	}
                });
                
                //单元格
                var rowNum = Math.min($scope.model.border.height, MAX_HEIGHT);
                var colNum = Math.min($scope.model.border.width, MAX_WIDTH);
                var cols, tipCoordinate, word, wordBox;
            	for(var i = 1; i <= rowNum; i++) {
        			cols = [];
                	for(var j = 1; j <= colNum; j++) {
                		tipCoordinate = tipCoordinateMap[mapKey(i, j)];
                		word = wordCoordinateMap[mapKey(i, j)];
                		if(tipCoordinate) {
                			wordBox = {
                				x: i,
                				y: j,
                				char: word ? word : "",
                				horizontalIndex: tipCoordinate.horizontalIndex,
                				verticalIndex: tipCoordinate.verticalIndex,
                				tipsLinked: coordinateTipsMap[mapKey(i, j)] ? coordinateTipsMap[mapKey(i, j)] : []
                    		};
                		} else {
                			wordBox = {
                				x: i,
                				y: j,
                				char: word ? word : "",
                				tipsLinked: coordinateTipsMap[mapKey(i, j)] ? coordinateTipsMap[mapKey(i, j)] : []
                			};
                		}
                		
                		cols.push(wordBox);
                    }
                	
                	$scope.rows.push(cols);
                }
				//当行列>7时改变样式
				if(colNum>7 || rowNum>7){
					$scope.opts.wordboardClass = DIRECTION.NORMALBOX;
				}
            	//tip 关联单元格
            	angular.forEach($scope.horizontalTips, function(tip) {
            		tip.boxesLinked = [];
            		for(var i = 0; i < tip.word.length; i++) {
            			tip.boxesLinked.push($scope.rows[tip.x - 1][tip.y - 1 + i]);
            		}
            	});
            	angular.forEach($scope.verticalTips, function(tip) {
            		tip.boxesLinked = [];
            		for(var i = 0; i < tip.word.length; i++) {
            			tip.boxesLinked.push($scope.rows[tip.x - 1 + i][tip.y - 1]);
            		}
            	});
            };
            
            //入口
            if(!$stateParams.id) {
                //新增
                skin_service.set_skin_by_code($scope.model.skin.code,'v1');
                setValues();
            } else {
                //修改
                loadingData($stateParams.id);
            }
            
            $scope.$on('changgedSkin',function(){
                $rootScope.scaleHtml();
            });
            
            //数据验证
            $scope.validPostData = function() {
            	var modelData =$scope.model;
                if($.trim(modelData.title)=='') {
                    $scope.errorModel.errorText =  $filter('translate')('wordpuzzle.no_title');
                } else {
                	if(!isNotEmptyArray($scope.horizontalTips)) {
                		$scope.errorModel.errorText =  $filter('translate')('wordpuzzle.no_horizontal_tip');
                		
                		return false;
                	} else if(!isNotEmptyArray($scope.verticalTips)) {
                		$scope.errorModel.errorText =  $filter('translate')('wordpuzzle.no_vertical_tip');
                		
                		return false;
                	}
                	
                	var isOk = true;
                	angular.forEach($scope.horizontalTips, function(tip) {
                		if(!tip.chars || tip.chars.length == 0) {
                			$scope.tipOnOver(tip);
                			$scope.errorModel.errorText =  $filter('translate')('wordpuzzle.empty_tip');
                			isOk = false;
                			
                			return false;
                		}
                	});
                	
                	angular.forEach($scope.verticalTips, function(tip) {
                		if(!tip.chars || tip.chars.length == 0) {
                			$scope.tipOnOver(tip);
                			$scope.errorModel.errorText =  $filter('translate')('wordpuzzle.empty_tip');
                			isOk = false;
                			
                			return false;
                		}
                	});
                	
                	if(isOk) {
						var isUnifiedWord= checkUnifiedwords();
						if(!isUnifiedWord) {
							return false;
						}

                		var hasWords = false;
                		angular.forEach($scope.rows, function(row) {
							if(isOk) {
								angular.forEach(row, function(col) {
									if(isOk) {
										if(col.char && col.char.length > 0) {
											hasWords = true;

											if(!isNotEmptyArray(col.tipsLinked)) {
												$scope.errorModel.errorText =  $filter('translate')('wordpuzzle.tip_word_notmatch');
												isOk = false;
											}
										}
									}
								});
							}
                    	});
                		
                		if(!hasWords) {
                			$scope.errorModel.errorText =  $filter('translate')('wordpuzzle.no_words');
                			isOk = false;
                		}
                	}

					//去除冗余的行列
					isOk && removeUnusedBoxes(++removeUnusedBoxesCounter);
                	return isOk;
                }
            };
            
            $scope.encodeData = function(model){
            	var newModel = angular.copy(model);
            	newModel.title = window.customHtmlEncode(newModel.title);
            	newModel.border.width = $scope.rows[0].length;
            	newModel.border.height = $scope.rows.length;
            	
            	// words, chars
            	newModel.words = [];
            	newModel.chars = [];
            	var coordinateTipsMap = [];
            	angular.forEach($scope.horizontalTips, function(tip) {
            		tip.word = "";
            		angular.forEach(tip.boxesLinked, function(box){
            			tip.word += box.char;
    				});
            		
            		var char = {
            			x: tip.x,
            			y: tip.y,
            			hints: { horizontal: window.customHtmlEncode(tip.chars) },
            			word: { horizontal: tip.word }
            		};
            		
            		coordinateTipsMap[mapKey(tip.x, tip.y)] = char;
            		newModel.chars.push(char);
            		newModel.words.push({
            			word: tip.word,
  					    direction: DIRECTION.HORIZONTAL,
  					    start_axis: {x: tip.x, y: tip.y},
  					    end_axis: {x: tip.x, y: tip.y + tip.word.length - 1}
            		});
            	});
            	angular.forEach($scope.verticalTips, function(tip) {
            		tip.word = "";
            		angular.forEach(tip.boxesLinked, function(box){
            			tip.word += box.char;
    				});
            		
            		var char = coordinateTipsMap[mapKey(tip.x, tip.y)];
            		if(char) {
            			char.hints.vertical = tip.chars;
            			char.word.vertical = tip.word;
            		} else {
            			var char = {
                			x: tip.x,
                			y: tip.y,
                			hints: { vertical: window.customHtmlEncode(tip.chars) },
                			word: { vertical: tip.word }
                		};
                		
                		newModel.chars.push(char);
            		}
            		
            		newModel.words.push({
            			word: tip.word,
  					    direction: DIRECTION.VERTICAL,
  					    start_axis: {x: tip.x, y: tip.y},
  					    end_axis: {x: tip.x + tip.word.length - 1, y: tip.y}
            		});
            	});
            	
            	return newModel;
            };
            
            $scope.decodeData = function(model){
            	var newModel = angular.copy(model);
            	newModel.title = window.customHtmlDecode(newModel.title);
            	angular.forEach(newModel.chars, function(item){
            		if(angular.isObject(item.hints)) {
	            		item.hints.horizontal = window.customHtmlDecode(item.hints.horizontal);
	            		item.hints.vertical = window.customHtmlDecode(item.hints.vertical);
            		}
            	});
            	
            	return newModel;
            };

			//移除冗余的行列
			var removeUnusedBoxesCounter = 0;
			function removeUnusedBoxes(currentCounter, activedBox) {
				if (currentCounter != removeUnusedBoxesCounter ||   //因为blurOnBox中做了定时延迟执行，所以如果timeout后已经执行删除冗余行列，这里定时的就不需要再做了
					($scope.rows.length <= MIN_HEIGHT && $scope.rows[0].length <= MIN_WIDTH)) {
					return;
				}

				var rowIndex = MIN_HEIGHT, colIndex = MIN_WIDTH;
				if (!!activedBox) {
					rowIndex = Math.max(activedBox.x, rowIndex);
					colIndex = Math.max(activedBox.y, colIndex);
				}

				//移除冗余的空行
				for (var i = $scope.rows.length - 1; i >= rowIndex; i--) {
					var isEmptyRow = true;
					for (var j = 0; j < $scope.rows[0].length; j++) {
						if (!!$scope.rows[i][j].char) {
							isEmptyRow = false;
							break;
						}
					}
					if (isEmptyRow) {
						$scope.rows.splice(i, 1);
					} else {
						break;
					}
				}

				//移除冗余的空列
				for (var j = $scope.rows[0].length - 1; j >= colIndex; j--) {
					var isEmptyCol = true;
					for (var i = 0; i < $scope.rows.length; i++) {
						if (!!$scope.rows[i][j].char) {
							isEmptyCol = false;
							break;
						}
					}
					if (isEmptyCol) {
						for (var i = 0; i < $scope.rows.length; i++) {
							$scope.rows[i].splice(j, 1);
						}
					} else {
						break;
					}
				}

				if ($scope.rows.length >=7 || $scope.rows[0].length >=7) {
					$scope.opts.wordboardClass = DIRECTION.NORMALBOX;
				} else {
					$scope.opts.wordboardClass = DIRECTION.LARGEBOX;
				}
			}
            
            /* ============================ 填字区操作  ============================ */
            /* 按下鼠标并滑动，选择需要提示的单词或语句  */
			var isMouseDown = false;

            /**
             * slidingDirection：滑动方向，横向或纵向
             * isReversed：是否反方向滑动，如：从右到左、从下到上
             * startBox: 滑动过程中，第一个选中的单元格
             * boxesSelected：滑动过程，选中的单元格集合
             *
             **/
            var slidingDirection, isReversed, startBox, boxesSelected;
            $scope.mousedown = function($event) { //需要解决与click事件的冲突
            	var coordinate = getBoxCoordinate($event.target);
            	if(coordinate) {
            		startBox = $scope.rows[coordinate.x - 1][coordinate.y - 1];
            		
            		if(startBox.char) {
            			isMouseDown = true;
                    	boxesSelected = [];
                    	
                    	slidingDirection = null;
                    	startBox.forNewtip = true;
                    	
                    	if($.inArray(startBox, boxesSelected) <= -1) {
    						boxesSelected.push(startBox);
    					}
            		}
            	}
            };
            
            //单元格 鼠标滑过事件
			$scope.mouseover = function($event) {
				var coordinate = getBoxCoordinate($event.target);
				if(isMouseDown) {
					if(slidingDirection == null && boxesSelected.length > 1) { //判断用户滑动方向
						if(boxesSelected[0].x == boxesSelected[1].x) {
							slidingDirection = DIRECTION.HORIZONTAL;
							isReversed = (boxesSelected[0].y > boxesSelected[1].y);
						} else if(boxesSelected[0].y == boxesSelected[1].y) {
							slidingDirection = DIRECTION.VERTICAL;
							isReversed = (boxesSelected[0].x > boxesSelected[1].x);
						} else {
							stopSliding(true);
							
							return false;
						}
					}
					
					if(coordinate) {
						var box = $scope.rows[coordinate.x - 1][coordinate.y - 1];
						//判断当前滑动到的单元格是否偏离了方向
						if(!box.char || 
							(slidingDirection != null && !onRightDirection(slidingDirection, boxesSelected[boxesSelected.length - 1], box))) {
							stopSliding();
						} else {
							selectBox(box);
						}
					} else {
						stopSliding();
						
						angular.forEach(boxesSelected, function(box){
							box.forNewtip = false;
						});
					}
				}
				
				//高亮显示单元格关联的提示
				if(!isMouseDown && coordinate) {
					var box = $scope.rows[coordinate.x - 1][coordinate.y - 1];
					if(isNotEmptyArray(box.tipsLinked)) {
						angular.forEach(box.tipsLinked, function(tip){
							tip.selected = true;
							
							angular.forEach(tip.boxesLinked, function(box) {
								box.selected = true;
							});
						});
					}
				}
			};
			
			//单元格 鼠标放开事件
			$scope.mouseup = function($event) {
				if(isMouseDown) {
					var coordinate = getBoxCoordinate($event.target);
					selectBox($scope.rows[coordinate.x - 1][coordinate.y - 1]);
					
					stopSliding();
				}
			};
			
			//单元格 鼠标离开事件
			$scope.mouseleave = function($event, item){
				if(isNotEmptyArray(item.tipsLinked)) {
					angular.forEach(item.tipsLinked, function(tip){
						tip.selected = false;
						if(tip.chars) tip.actived = false;
						
						angular.forEach(tip.boxesLinked, function(box) {
							box.selected = false;
							if(!isMouseDown) box.forNewtip = false;
						});
					});
				}
			};

			//判断是否存在汉字或字母的混合
			function checkUnifiedwords() {
				var charBuffer = "";
				angular.forEach($scope.rows, function(row) {
					angular.forEach(row, function(col) {
						if(col.char && col.char.length > 0) {
							charBuffer += col.char;
						}
					});
				});

				var chineseChars = CharsetService.getChineses(charBuffer);
				var isUnifiedwords = (chineseChars.length === 0 || chineseChars.length === charBuffer.length);
                if(!isUnifiedwords) {
					$scope.errorModel.errorText = $filter('translate')('wordpuzzle.not_unified_tip');
				}

				return isUnifiedwords;
			}

			//聚焦到元素
			function focusElement(element, immediate) {
            	if(immediate) {
            		element.focus();
            	} else {
            		$timeout(function(){
    					element.focus();
                    }, 100);
            	}
			}
			
			//获取单元格坐标
			function getBoxCoordinate(target) {
            	var $box;
            	if(angular.uppercase(target.tagName) == "DIV") {
            		$box = $(target);
				} else {
					$box = $(target).parents("div:first");
				}
            	
            	if($box.hasClass("wordBox")) {
            		return {x: $box.attr("boxX"), y: $box.attr("boxY")};
            	}
            	
            	return null;
            }
			
			//判断选择单元格过程中是否偏离原来的方向，如横向跨行、纵向跨列
			function onRightDirection(direction, boxSrc, boxDest) {
            	return isHorizontal(direction) ? boxSrc.x == boxDest.x : boxSrc.y == boxDest.y;
            }
			
			//选择单元格
            function selectBox(box) {
            	if($.inArray(box, boxesSelected) <= -1) {
            		if(slidingDirection != null) {
            			if(isHorizontal(slidingDirection)) {
                			var startY = boxesSelected[boxesSelected.length - 1].y;
							if(!isReversed) {
								for(var i = startY; i < box.y; i++) { //弥补鼠标滑过却没有被触发mouseover的单元格
									var boxTemp = $scope.rows[box.x - 1][i];
									boxTemp.forNewtip = true;
									boxesSelected.push(boxTemp);
								}
							} else {
								for(var i = startY; i > box.y; i--) { //弥补鼠标滑过却没有被触发mouseover的单元格
									var boxTemp = $scope.rows[box.x - 1][i - 2];
									boxTemp.forNewtip = true;
									boxesSelected.push(boxTemp);
								}
							}

                		} else {
                			var startX = boxesSelected[boxesSelected.length - 1].x;
							if(!isReversed) {
								for(var i = startX; i < box.x; i++) { //弥补鼠标滑过却没有被触发mouseover的单元格
									var boxTemp = $scope.rows[i][box.y - 1];
									boxTemp.forNewtip = true;
									boxesSelected.push(boxTemp);
								}
							} else {
								for(var i = startX; i > box.x; i--) { //弥补鼠标滑过却没有被触发mouseover的单元格
									var boxTemp = $scope.rows[i - 2][box.y - 1];
									boxTemp.forNewtip = true;
									boxesSelected.push(boxTemp);
								}
							}
                		}
                	} else {
                		box.forNewtip = true;
        				boxesSelected.push(box);
                	}
            	}
            }
            
            //结束单元格选择
			function stopSliding(cancel) {
				isMouseDown = false;
				if(cancel) {
					angular.forEach(boxesSelected, function(box){
						box.forNewtip = false;
					});
				} else {
					if(boxesSelected.length < 2) { //Click Event
						startBox.forNewtip = false;
					} else {
						//判断是否选中整个单词，否则无效
						var isValid = true;
						var startBoxTemp, endBox;

                        if(isReversed) {
                            endBox = startBox;
                            startBoxTemp = boxesSelected[boxesSelected.length - 1];
                        } else {
                            startBoxTemp = startBox;
                            endBox = boxesSelected[boxesSelected.length - 1];
                        }

						if(isHorizontal(slidingDirection)) {
							if(endBox.y < $scope.rows[0].length && !!$scope.rows[endBox.x - 1][endBox.y].char) {
                                isValid = false;
                            } else if(startBoxTemp.y > 1 && !!$scope.rows[startBoxTemp.x - 1][startBoxTemp.y - 2].char) {
                                isValid = false;
                            }
						} else {
                            if(endBox.x < $scope.rows.length && !!$scope.rows[endBox.x][endBox.y - 1].char) {
                                isValid = false;
                            } else if(startBoxTemp.x > 1 && !!$scope.rows[startBoxTemp.x - 2][startBoxTemp.y - 1].char) {
                                isValid = false;
                            }
						}
						
						if(isValid) {
                            endBox = boxesSelected[boxesSelected.length - 1];
							addTip(startBox.x == endBox.x ? DIRECTION.HORIZONTAL : DIRECTION.VERTICAL,
								   boxesSelected);
						} else {
							angular.forEach(boxesSelected, function(box){
								box.forNewtip = false;
							});
							
							$scope.errorModel.errorText =  $filter('translate')('wordpuzzle.invalid_tip_onbox');
						}
					}
				}
			}
			
			//获取当前选中单元格中的第一个单元格
			function getBeginBox(direction, boxesSelected) {
				var boxFirst = boxesSelected[0];
				var boxLast = boxesSelected[boxesSelected.length - 1];
				
				if(isHorizontal(direction)) {
					return boxLast.y > boxFirst.y ? boxFirst : boxLast;
				} else {
					return boxLast.x > boxFirst.x ? boxFirst : boxLast;
				}
			}
			
			//单个单元格重复定义同向提示检测
			function checkDuplicateTips(direction, boxesSelected) {
				var isExistedTip = false;
				if(isHorizontal(direction)) {
					angular.forEach(boxesSelected, function(box){
						if(isNotEmptyArray(box.tipsLinked)) {
							angular.forEach(box.tipsLinked, function(tip){
								if(isHorizontal(tip.direction)) {
									isExistedTip = true;
									
									return false;
								}
							});
						}
					});
				} else {
					angular.forEach(boxesSelected, function(box){
						if(isNotEmptyArray(box.tipsLinked)) {
							angular.forEach(box.tipsLinked, function(tip){
								if(!isHorizontal(tip.direction)) {
									isExistedTip = true;
									
									return false;
								}
							});
						}
					});
				}
				
				if(isExistedTip) { //已存在同向提示
					angular.forEach(boxesSelected, function(box){
						box.forNewtip = false;
					});
					
					$scope.errorModel.errorText =  $filter('translate')('wordpuzzle.duplicate_tips_onbox');
					return false;
				}
				
				return true;
			}
			
			//新建提示
			function addTip(direction, boxesSelected) {
				if(!checkDuplicateTips(direction, boxesSelected)) return false;
				
				var beginBox = getBeginBox(direction, boxesSelected);
				var newTip = {
					actived: true,
					x: beginBox.x,
					y: beginBox.y,
					word: "",
					direction: direction,
					boxesLinked: boxesSelected
				};
				angular.forEach(boxesSelected, function(box){
					box.tipsLinked.push(newTip);
					newTip.word += box.char;
				});
				
				if(isHorizontal(direction)) {
					$scope.horizontalTips.push(newTip);
					beginBox.horizontalIndex = $scope.horizontalTips.length;
					
					$timeout(function(){
						focusElement($('.horizontalTip li:last-child input'), true);
					}, 100);
				} else {
					$scope.verticalTips.push(newTip);
					beginBox.verticalIndex = $scope.verticalTips.length;
					
					$timeout(function(){
						focusElement($('.verticalTip li:last-child input'), true);
					}, 100);
				}
			}
			
			//聚焦单元格
			function focusWordBox(wordBox) {
				if(currentWordBox != null) currentWordBox.actived = false;
				wordBox.actived = true;
				currentWordBox = wordBox;
				
				focusElement($($(".wordboard li")[wordBox.x - 1]).find("input")[wordBox.y - 1]);
			}
			
			//扩展单元格
			function extendsWordBox(direction, fromBox, boxNum, chars) {
				if(isHorizontal(direction)) { //扩展列
					for(var i = 1; i <= boxNum; i++) {
						angular.forEach($scope.rows, function(row, index) {
							row.push({
								x: index + 1,
								y: fromBox.y + i,
								tipsLinked: []
							});
						});

						if(chars && chars.length >= i) {
							$scope.rows[fromBox.x - 1][fromBox.y + i - 1].char = chars.charAt(i - 1);
						}
					}
					//当行列>7时改变样式
					if($scope.rows[0].length>7){
						$scope.opts.wordboardClass = DIRECTION.NORMALBOX;
					}
					$timeout(function(){
						focusWordBox($scope.rows[fromBox.x - 1][fromBox.y + boxNum - 1]);
					}, 100);
				} else { //扩展行
					var cols = $scope.rows[0].length, newRow;
					for(var i = 1; i <= boxNum; i++) {
						newRow = [];
						for(var j = 0; j < cols; j++) {
							newRow.push({
								x: fromBox.x + i,
								y: j + 1,
								tipsLinked: []
							});
						}
						$scope.rows.push(newRow);
						
						if(chars && chars.length >= i) {
							$scope.rows[fromBox.x + i - 1][fromBox.y - 1].char = chars.charAt(i - 1);
						}
					}
					//当行列>7时改变样式
					if($scope.rows.length>7){
						$scope.opts.wordboardClass = DIRECTION.NORMALBOX;
					}
					$timeout(function(){
						focusWordBox($scope.rows[fromBox.x + boxNum - 1][fromBox.y - 1]);
					}, 100);
				}
			}
			
			//填字区操作 - 单元格激活
			var currentWordBox = null;
			$scope.activeWordBox = function(item, $event) {
				++removeUnusedBoxesCounter;

				if(!item.actived) {
					if(currentWordBox != null) currentWordBox.actived = false;
					item.actived = true;
					currentWordBox = item;
					
					$scope.textDirection = DIRECTION.HORIZONTAL;//书写方向，默认从左到右
					if(angular.uppercase($event.target.tagName) == "DIV") {
						focusElement($($event.target).find("input"));
					} else {
						focusElement($($event.target).parents("div:first").find("input"));
					}
				}
			};
			
			//填字区操作 - 上下左右移动、回车
			$scope.keydownOnBoard = function($event){
				if($event.keyCode == 229 || $event.keyCode == 197) { //中文输入法
					isChineseInput = true;
				} else {
					isChineseInput = false;
					if(currentWordBox) {
						switch($event.keyCode) {
						case 8: //回退按钮
							if(!currentWordBox.char && currentWordBox.y > 1) {
								focusWordBox($scope.rows[currentWordBox.x - 1][currentWordBox.y - 2]);
							}
							break;
						case 13: //回车键 切换书写方向为从上到下
							$scope.textDirection = DIRECTION.VERTICAL; //书写方向，默认从上到下
							break;
						case 37: //LEFT
							if(currentWordBox.y > 1) {
								focusWordBox($scope.rows[currentWordBox.x - 1][currentWordBox.y - 2]);
							}
							break;
						case 38: //UP
							if(currentWordBox.x > 1) {
								focusWordBox($scope.rows[currentWordBox.x - 2][currentWordBox.y - 1]);
							}
							break;
						case 39: //RIGHT
							if(currentWordBox.y < $scope.rows[0].length) {
								focusWordBox($scope.rows[currentWordBox.x - 1][currentWordBox.y]);
							} else if(currentWordBox.y < MAX_WIDTH) { //扩展列
								extendsWordBox(DIRECTION.HORIZONTAL, currentWordBox, 1)
							}
							
							break;
						case 40: //DOWN
							if(currentWordBox.x < $scope.rows.length) {
								focusWordBox($scope.rows[currentWordBox.x][currentWordBox.y - 1]);
							} else if(currentWordBox.x < MAX_HEIGHT) { //扩展行
								extendsWordBox(DIRECTION.VERTICAL, currentWordBox, 1)
							}
							break;
						default:
						}
					}
				}
			};
			
			/**
			 * 填字区操作 - 单元格输入内容
			 * 
			 * c) 每个单元格内只能输入一个字母或汉字，当从输入法中接收到一串字符时，将其拆散按书写方向排列
			 * d) 在当前单元格输入内容后，系统按当前书写顺序自动激活下一个单元格，当输入的矩阵空间不足时，自动按书写方向向右或向下增行/列
			 * 
			 */
			var isChineseInput = false; //中文输入标识
			$scope.changeOnBox = function($event, item) {
				if(!!item.char) {
					item.char = CharsetService.getChineseAlpha(item.char);
					if(!!!item.char) {
						$scope.errorModel.errorText = $filter('translate')('wordpuzzle.char_wrong_tip');
					}

					if(item.char.length > 1) {
						var chars = item.char;
						if(isChineseInput) { //中文输入,只保留中文
							chars = CharsetService.getChineses(item.char);
						}

						if(isHorizontal($scope.textDirection)) {
							var colNum = $scope.rows[0].length, fromBox = item;
							if(chars.length > 0) {
								if(currentWordBox.y == MAX_WIDTH) {
									item.char = chars.charAt(1);
								} else {
									item.char = chars.charAt(0);
									for(var i = 0; i < chars.length - 1; i++) {
										if(item.y + i < colNum) {
											fromBox = $scope.rows[item.x - 1][item.y + i];
											fromBox.char = chars.charAt(i+1);
										}
									}

									if(item.y + chars.length > colNum && colNum < MAX_WIDTH) {
										var extendNum = Math.min(MAX_WIDTH - colNum, item.y + chars.length - colNum - 1);
										extendsWordBox($scope.textDirection, fromBox, extendNum, chars.substring(fromBox.y - item.y + 1));
									} else if(fromBox != item) {
										focusWordBox(fromBox);
									}
								}
							} else {
								item.char = "";
							}
						} else {
							var rowNum = $scope.rows.length, fromBox = item;
							if(chars.length > 0) {
								if(currentWordBox.x == MAX_HEIGHT) {
									item.char = chars.charAt(1);
								} else {
									item.char = chars.charAt(0);
									for(var i = 0; i < chars.length - 1; i++) {
										if(item.x + i < rowNum) {
											fromBox = $scope.rows[item.x + i][item.y - 1];
											fromBox.char = chars.charAt(i+1);
										}
									}

									if(item.x + chars.length > rowNum && rowNum < MAX_HEIGHT) {
										var extendNum = Math.min(MAX_HEIGHT - rowNum, item.x + chars.length - rowNum - 1);
										extendsWordBox($scope.textDirection, fromBox, extendNum, chars.substring(fromBox.x - item.x + 1));
									} else if(fromBox != item) {
										focusWordBox(fromBox);
									}
								}
							} else {
								item.char = "";
							}
						}
					}

					if(item.char.length > 0) {
						if(isChineseInput) {
							$timeout(function() { //中文输入法 会触发两次change事件，第一次中文拼音，第二次中文汉字
								checkUnifiedwords();
							}, 100);
						} else {
							checkUnifiedwords();
						}
					}
				}
			};
			
			//单元格失去焦点：如果已关联提示，并且将单元格内容清空，则删除关联提示
			$scope.blurOnBox = function($event, item) {
				item.actived = false;
				if(!item.char || item.char.length == 0) {
					item.horizontalIndex = null;
					item.verticalIndex = null;
					
					var length = item.tipsLinked.length;
					for(var i = 0; i < length; i++) {
						var tip = item.tipsLinked[0];
						
						var $index = -1;
						if(isHorizontal(tip.direction)) {
							$index = $.inArray(tip, $scope.horizontalTips);
						} else {
							$index = $.inArray(tip, $scope.verticalTips);
						}
						
						deleteTip(tip, $index);
					}
				}

				//去除冗余的行列
				$timeout((function (counter) {
					return function () {
						removeUnusedBoxes(counter);
					}
				})(++removeUnusedBoxesCounter), 100);
			};
			$scope.focusOnBox = function(item) {
				//去除冗余的行列
				removeUnusedBoxes(++removeUnusedBoxesCounter, item);
			};
			
			/* ============================ 提示区操作  ============================ */
			//提示区操作 - 提示信息输入框激活
			var currentTipBox;
			$scope.activeTipBox = function(item, $event){
				if(currentTipBox) currentTipBox.actived = false;
				item.actived = true;
				currentTipBox = item;
				
				if(angular.uppercase($event.target.tagName) == "LI") {
					focusElement($($event.target).find("input"));
				} else {
					focusElement($($event.target).parents("li:first").find("input"));
				}
			};
			
			//提示区 操作 - 提示信息输入框失去焦点
			$scope.tipOnBlur = function(item) {
				item.actived = false;
				item.text_s = CharsetService.getTextBytes(item.chars) > 51;
			};
			
			//提示区 操作 - 提示信息鼠标MouseOver事件
			$scope.tipOnOver = function(item) {
				item.selected = true;
				angular.forEach(item.boxesLinked, function(box) {
					box.selected = true;
				});
			};
			
			//提示区 操作 - 提示信息鼠标MouseOut事件
			$scope.tipOnOut = function(item) {
				item.selected = false;
				angular.forEach(item.boxesLinked, function(box) {
					box.selected = box.forNewtip = false;
				});
			};
			
			//提示区操作 - 保存提示（按回车）
			$scope.saveTip = function($event, item) {
				if($event.keyCode == 13) {
					item.actived = false;
				}
			};
			
			//提示区操作 - 移除提示
			$scope.removeTip = function($event, tip, $index) {
				deleteTip(tip, $index);
				
				if ($event.stopPropagation) $event.stopPropagation();
			    if ($event.preventDefault) $event.preventDefault();
			    $event.cancelBubble = true;
			    $event.returnValue = false;
			};

			//删除提示操作
			function deleteTip(tip, $index) {
				//Step1. 删除提示
				if(isHorizontal(tip.direction)) {
					$scope.horizontalTips.splice($index, 1)[0];
				} else {
					$scope.verticalTips.splice($index, 1)[0];
				}

				//Step2. 删除填字区的关联项
				var matchIndex;
				angular.forEach($scope.rows, function(row){
					angular.forEach(row, function(col){
						matchIndex = $.inArray(tip, col.tipsLinked);
						if(matchIndex > -1) {
							col.tipsLinked.splice(matchIndex, 1);
						}
						
						col.selected = col.forNewtip = false;
					});
				});
				
				//Step3. 更新提示信息索引
				if(isHorizontal(tip.direction)) {
					$scope.rows[tip.x - 1][tip.y - 1].horizontalIndex = null;
					if($scope.horizontalTips.length > $index) { //不是删除最后一个
						angular.forEach($scope.horizontalTips, function(item, index) {
							if($scope.rows[item.x - 1][item.y - 1].horizontalIndex) {
								$scope.rows[item.x - 1][item.y - 1].horizontalIndex = index + 1;
							}
						});
					}
				} else {
					$scope.rows[tip.x - 1][tip.y - 1].verticalIndex = null;
					if($scope.verticalTips.length > $index) { //不是删除最后一个
						angular.forEach($scope.verticalTips, function(item, index) {
							if($scope.rows[item.x - 1][item.y - 1].verticalIndex) {
								$scope.rows[item.x - 1][item.y - 1].verticalIndex = index + 1;
							}
						});
					}
				}
			}


			$scope.returnStyle = function(box) {
				//var hasHorizontal = false, hasVertical = false;
				//angular.forEach(box.tipsLinked, function(tip){
				//	if(isHorizontal(tip.direction)) {
				//		hasHorizontal = true;
				//	} else {
				//		hasVertical = true;
				//	}
				//});
                //
				////ed_fix,水平用ed_x,垂直用ed_y
				//if(hasHorizontal && hasVertial) {
				//	return "ed_fix";
				//} else {
				//	return hasHorizontal ? "ed_x" : "ed_y";
				//}

				//高亮显示单元格关联的提示
				if(!isMouseDown && coordinate) {
					var box = $scope.rows[coordinate.x - 1][coordinate.y - 1];
					if(isNotEmptyArray(box.tipsLinked)) {
						angular.forEach(box.tipsLinked, function(tip){
							tip.selected = true;

							angular.forEach(tip.boxesLinked, function(box) {
								box.selected = true;
									if(isHorizontal(tip.direction)) {
										box.hasHorizontal = true;
									} else {
										box.hasVertical = true;
									}
							});
						});
					}
				}
				return true;
			};
			

        }
    ]);
});
