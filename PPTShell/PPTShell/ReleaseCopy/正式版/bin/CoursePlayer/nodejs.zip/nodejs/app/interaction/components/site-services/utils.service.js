/**
 * Created by lxq on 2015/08/11.
 */
define(['angularAMD'], function(angularAMD) {
    'use strict';
    angularAMD
        .service('UtilsService', [function() {

        return {
        	//计算两点的角度
        	getAngle: function (x1, y1, x2, y2) {
            	var x = Math.abs(x1 - x2);
                var y = Math.abs(y1 - y2);
                var z = Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));
                
                var angle = Math.asin(y / z) / Math.PI * 180;
                if(x1 > x2) {
                	if(y1 > y2) {
                		angle -= 180;
                	} else {
                		angle = 180 - angle;
                	}
                } else if(y1 > y2) {
                	angle *= -1;
                }
                
                return angle;
            },
        
            //计算Matrix后的坐标位置
            translateMatrixPoint: function(matrix, point) {
	        	if(!angular.isArray(matrix) || matrix.length < 6)
	        		return point;
	        	
	        	//ax + cy + e; bx + dy + f
	        	var x = matrix[0] * point.x + matrix[2] * point.y + matrix[4];
	        	var y = matrix[1] * point.x + matrix[3] * point.y + matrix[5];
	        	
	        	return { x: x, y: y };
	        },
	        //获取Matrix属性值[M11, M12, M21, M22, M31, M32]
	        getElementMatrix: function(element) {
            	var transform = element.css("transform");
            	if(transform) {
            		transform = transform.toLowerCase().replace(/\s/g, "");
            		var matrixKey = "matrix(";
            		var startIndex = transform.indexOf(matrixKey);
            		if(startIndex > -1) {
            			var matrixAttr = transform.substring(startIndex + matrixKey.length, transform.indexOf(")", startIndex));
            			
            			var matrix = [];
            			angular.forEach(matrixAttr.split(","), function(item) {
            				matrix.push(parseFloat(item));
            			});
            			
            			return matrix;
            		}
            	}
            	
            	return null;
            },
            //获取缩放比例
	        getScalePercent: function(element) {
                var matrix = this.getElementMatrix(element);
            	if(matrix) return matrix[0];
            	
            	return 1;
            },
            //获取点所在的象限
            getQuadrantIndex: function(point, rangeWidth, rangeHeight) {
            	var halfWidth = rangeWidth / 2;
            	var halfHeight = rangeHeight / 2;
            	if(point.y < halfHeight) {
            		if(point.x < halfWidth) {
            			return 1;
            		} else {
            			return 2;
            		}
            	} else {
            		if(point.x < halfWidth) {
            			return 3;
            		} else {
            			return 4;
            		}
            	}
            },
            //判断一个点是否在多边形内
            isPointInsidePoly: function(point, poly) {
            	var length = poly.length;
                for (var c = false, i = -1, j = length - 1; ++i < length; j = i) {
                    ((poly[i].y <= point.y && point.y < poly[j].y) || (poly[j].y <= point.y && point.y < poly[i].y))
                    && (point.x < (poly[j].x - poly[i].x) * (point.y - poly[i].y) / (poly[j].y - poly[i].y) + poly[i].x)
                    && (c = !c);
                }
                
                return c;
            },
            //检查两个矩形框是否交叉
            checkRectsCross: function(rectA, rectB) {
            	/**
            	 * 矩形A的宽 Wa = Xa2-Xa1 高 Ha = Ya2-Ya1
                 * 矩形B的宽 Wb = Xb2-Xb1 高 Hb = Yb2-Yb1
                 * 矩形A的中心坐标 (Xa3,Ya3) = （ (Xa2+Xa1)/2 ，(Ya2+Ya1)/2 ）
                 * 矩形B的中心坐标 (Xb3,Yb3) = （ (Xb2+Xb1)/2 ，(Yb2+Yb1)/2 ）
                 * 所以只要同时满足下面两个式子，就可以说明两个矩形相交。
                 *   1) | Xb3-Xa3 | <= Wa/2 + Wb/2
                 *   2) | Yb3-Ya3 | <= Ha/2 + Hb/2
                 *   即:
                 *   1) | Xb2+Xb1-Xa2-Xa1 | <= Xa2-Xa1 + Xb2-Xb1
                 *   2) | Yb2+Yb1-Ya2-Ya1 | <= Ya2-Ya1 + Yb2-Yb1
            	 */
            	return Math.abs(rectB.right + rectB.left - rectA.right - rectA.left) <= (rectA.right - rectA.left + rectB.right - rectB.left)
            	       &&
            	       Math.abs(rectB.bottom + rectB.top - rectA.bottom - rectA.top) <= (rectA.bottom - rectA.top + rectB.bottom - rectB.top);
            },
            
            /**
             * 检查两个圆是否交叉
             * circle {
             *   x, y 中心点坐标
             *   radius: 半径
             * }
             */
            checkCircleCross: function(circleA, circleB) {
            	var distance = Math.sqrt(Math.pow(circleA.x - circleB.x, 2) + Math.pow(circleA.y - circleB.y, 2));
            	
            	return distance < (circleA.radius + circleB.radius) * 2;
            },
            
            //移动光标到末尾
            moveCursor2End: function(editor) {
            	var sel, range;
        	    if (window.getSelection && document.createRange) {
	        	    range = document.createRange();
	        	    range.selectNodeContents(editor);
	        	    range.collapse(true);
	        	    range.setEnd(editor, editor.childNodes.length);
	        	    range.setStart(editor, editor.childNodes.length);
	        	    sel = window.getSelection();
	        	    sel.removeAllRanges();
	        	    sel.addRange(range);
        	    } else if (document.body.createTextRange) {
	        	    range = document.body.createTextRange();
	        	    range.moveToElementText(editor);
	        	    range.collapse(true);
	        	    range.select();
        	    }
            },
            //计算两点间距离
            calTwoPointDistance: function( pa , pb ){
            	return Math.sqrt(Math.pow( pa.x - pb.x , 2 ) + Math.pow( pa.y - pb.y , 2 )) ; 
            },
            //计算点到直线的距离 ： 参数p及点坐标{x,y} , abc:{a,b,c} :　ax+by+c = 0 
            calPointToLineDistance: function( p, abc  ){
            	return Math.abs(abc.a*p.x + abc.b*p.y+abc.c) / Math.sqrt( abc.a*abc.a + abc.b*abc.b );
            },
            //根据两点获取直线的坐标方程式  abc:{a,b,c} :　ax+by+c = 0 
            getEquation: function( pa,pb ){
            	return {
            		a: pb.y - pa.y , 
            		b: pb.x - pa.x , 
            		c: pb.x*pa.y-pa.x*pb.y
            	}
            },
            //数组洗牌
            shuffleArray: function(array, preSize) {
            	if ($.isArray(array) && array.length > 0) {
            		if(preSize === undefined || preSize < 0) preSize = array.length;
                    var size = array.length;
                    
                    for (var i = 0; i < preSize && i < size - 1; i++) {
                        var rd = Math.max(Math.floor(Math.random() * (size - i)), 1) + i;
                        if (rd != i) {
                            var temp = array[i];
                            array[i] = array[rd];
                            array[rd] = temp;
                        }
                    }
                }

                return array;
            },
			safeApply: function(scope, fn) {
				if(scope && fn) {
					var phase = scope.$root.$$phase;
					if (phase == '$apply' || phase == '$digest') {
						if (fn && (typeof(fn) === 'function')) {
							fn();
						}
					} else {
						scope.$apply(fn);
					}
				}
			}
        };
    }]);
});
