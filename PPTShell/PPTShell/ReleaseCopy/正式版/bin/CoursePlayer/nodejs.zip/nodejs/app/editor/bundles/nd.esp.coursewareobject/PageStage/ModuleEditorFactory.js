/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
    'jlang',
    'jquery',
    'espModel'
],function(
    jlang,
    $,
    espModel
){
    var moduleTypes = {
        'GENERAL': 1,
        'FUNCTIONAL': 2
    };
    /******************************************* Editor Interface****************************************************************/
    var interfaceDefinitions = {
        'Border': ['setBorder'],
        'Background': ['setBackground'],
        'Text': ['getText','setText'],
        'Timer': ['getTime','setTime']
    };
    function createInterface(interfaceDefinition){
        var interfaces = [];
        if(!interfaceDefinition){
            interfaceDefinition = {};
        }else if(typeof interfaceDefinition === 'string'){
            interfaceDefinition = {interfaceDefinition: {}};
        }else if($.isArray(interfaceDefinition) && typeof interfaceDefinition[0] === 'string'){
            var t = {};
            t[interfaceDefinition[0]] = interfaceDefinition[1];
            interfaceDefinition = t;
        }else if(!$.isPlainObject(interfaceDefinition)){
            throw 'invalid interface definition';
        }
        for(var key in interfaceDefinition){
            var interface = new Interface(key, interfaceDefinition[key]);
            interfaces.push(interface);
        }
        return new ProxyInterface(interfaces);
    }
    function isCustomFunction(name){
        return name != 'call' && name != 'isSupport';
    }
    /******************* Interface **************************/
    function Interface(name, implements){
        this._name = name;
        implements = implements || {};
        var def = interfaceDefinitions[name];
        if(def){
            for(var i=0;i<def.length;i++){
                this[def[i]] = implements[def[i]] || $.noop;
            }
        }else{
            $.extend(this, implements);
        }
    }
    Interface.prototype.isSupport = function(name){
        return this._name === name;
    };
    Interface.prototype.call = function(name){
        var fn = this[name];
        if($.isFunction(fn)){
            return fn.apply(this, $.makeArray(arguments).slice(1));
        }
    };
    /******************* CompositeInterface **************************/
    function CompositeInterface(name, interfaces){
        this._name = name;
        this._interfaces = interfaces = interfaces || [];
        var def = interfaceDefinitions[name];
        this._invoke = function(name){
            return $.proxy(function(){
                var args = $.makeArray(arguments);
                args.unshift(name);
                return this.call.apply(this, args);
            }, this);
        }
        if(def){
            for(var i=0;i<def.length;i++){
                this[def[i]] = this._invoke(def[i]);
            }
        }else{
            var sample = this._interfaces[0];
            if(sample){
                for(var name in sample){
                    if(isCustomFunction(name) && $.isFunction(sample[name])){
                        this[name] = this._invoke(name);
                    }
                }
            }
        }
        this.length = this._interfaces.length;
    }
    CompositeInterface.prototype.isSupport = function(name){
        return this._name === name;
    };
    CompositeInterface.prototype.each = function (callback) {
        return $.each(this._interfaces, callback);
    };
    CompositeInterface.prototype.call = function(name){
        var args = $.makeArray(arguments);
        var results = [];
        for(var i=0;i<this._interfaces.length;i++){
            var interface = this._interfaces[i];
            results.push(interface.call.apply(interface, args));
        }
        return results;
    };
    /******************* ProxyInterface **************************/
    function ProxyInterface(interfaces){
        this._interfaces = interfaces || [];
        for(var i=0;i<this._interfaces.length;i++){
            var interface = this._interfaces[i];
            for(var name in interface){
                var value = interface[name];
                if(isCustomFunction(name) && $.isFunction(value)){
                    this[name] = $.proxy(value, interface);
                }
            }
        }
    }
    ProxyInterface.prototype.isSupport = function(name){
        for(var i=0;i<this._interfaces.length;i++){
            if(this._interfaces[i].isSupport(name)){
                return true;
            }
        }
        return false;
    };
    ProxyInterface.prototype.as = function(name){
        for(var i=0;i<this._interfaces.length;i++){
            if(this._interfaces[i].isSupport(name)){
                return this._interfaces[i];
            }
        }
        return null;
    };
    ProxyInterface.prototype.call = function(name){
        var fn = this[name];
        if($.isFunction(fn)){
            return fn.apply(this, $.makeArray(arguments).slice(1));
        }
    };

    /******************************************* Editor ****************************************************************/
    function ModuleEditor(editorDef){
        this.init = function(module,stage,config){};
        this.initDefault = function(moduleWrap){};
        this.render = function(moduleWrap){};
        this.clean = function (moduleWrap) {};
        this.save = function () {};
        this.destroy = function () {};
        this.getTemplate = function () {};
        this.getTemplateUrl = function () {};
        this.getInterfaceDefinition = function(){
        };
        this.getInterface = function(){
            return interfaceObject;
        };
        $.extend(this, jlang.EventManager(), editorDef);
        var interfaceObject = createInterface(this.getInterfaceDefinition());
    }
    function ErrorModuleEditorDef(editorId, message, cause){
        this.render = function(moduleWrap){
            var backgroundEl = $('<div class="slides-module-error-content"></div>').appendTo(moduleWrap.getElement());
            var imgEl = $('<div class="_image"></div>').appendTo(backgroundEl);
            $('<p></p>').appendTo(backgroundEl).text(message + '-->' + cause);
        };
    }
    function getEditorDef(editorId) {
        var deferred = $.Deferred();
        requirejs([espModel.repository.moduleEditor(editorId).getResourceUrl('script.js')], function (editorDef) {
            deferred.resolve(editorDef);
        }, function (error) {
            deferred.reject('无法加载 Editor 脚本文件 [' + editorId + ']：' + error);
        });
        return deferred.promise();
    }

    function getEditorConfig(editorId){
        var deferred = $.Deferred();
        $.ajax({
            type: 'GET',
            url: espModel.repository.moduleEditor(editorId).getResourceUrl('config.json'),
            dataType: 'json'
        }).then(function(config){
            if(!$.isArray(config)){
                config = [config];
            }
            deferred.resolve(config);
        },function(error){
            console.info('读取 Editor [' + editorId + '] 配置信息失败，将使用默认配置', error);
            deferred.resolve([]);
        });
        return deferred.promise();
    }
    function getEditorConfigForPresenter(editorId, presenterId){
        var moduleRepository = espModel.repository.moduleEditor(editorId);
        return getEditorConfig(editorId).then(function (configs) {
            var anyMatchConfig;
            for(var i=0;i<configs.length;i++){
                var presenter = configs[i].presenter;
                if(presenter == '*'){
                    anyMatchConfig = configs[i].config;
                }else if(presenter == presenterId || ($.isArray(presenter) && $.inArray(presenterId, presenter) != -1)){
                    return resolveEditorConfig(configs[i].config, moduleRepository);
                }
            }
            return resolveEditorConfig(anyMatchConfig, moduleRepository).then(null, function(error){
                return '解析 Editor [' + editorId + '],[' + presenterId + '] 配置信息发生错误' + error;
            });
        });
    }
    function resolveEditorConfig(config, moduleRepository){
        config = config || {};
        var result = {}, promises = [], promiseKeys = [];
        for(var key in config){
            var value = parseEditorConfigValue(config[key], moduleRepository);
            if(value && $.isFunction(value.then)){
                promiseKeys.push(key);
                promises.push(value);
            }else{
                result[key] = value;
            }
        }
        if(promises.length){
            return $.when.apply(null, promises).then(function () {
                for(var i=0;i<promiseKeys.length;i++){
                    result[promiseKeys[i]] = arguments[i];
                }
                return result;
            });
        }else{
            return $.when(result);
        }
    }
    function parseEditorConfigValue(value, moduleRepository){
        if(typeof value === 'string' && value.indexOf('js::') == 0){
            var url = moduleRepository.getResourceUrl(value.substring(4));
            var deferred = $.Deferred();
            requirejs([url],function(result){
                deferred.resolve(result);
            },function(error){
                deferred.reject(error);
            });
            return deferred.promise();
        }else{
            return value;
        }
    }

    var  ModuleEditorFactory = {
        create: function (editorId, presenterId) {
            return getEditorDef(editorId).then(function(editorDef){
                try{
                    if($.isFunction(editorDef)){
                        editorDef = new editorDef();
                    }
                    var editor = new ModuleEditor(editorDef);
                    return editor;
                }catch(e){
                    var errorMessage = '实例化 Editor [' + editorId + '] 时发生错误';
                    console.error(errorMessage, e);
                    var editorDef = new ErrorModuleEditorDef(editorId, errorMessage, e);
                    var editor = new ModuleEditor(editorDef);
                    return editor;
                }
            },function(error){
                var errorMessage = '加载编辑态失败';
                console.error(errorMessage, error);
                var editor = new ModuleEditor(new ErrorModuleEditorDef(editorId, errorMessage, error));
                return $.when(editor);
            });
        },
        compositeInterface: function(name, interfaces){
            return new CompositeInterface(name, interfaces);
        }
    };
    return ModuleEditorFactory;
});