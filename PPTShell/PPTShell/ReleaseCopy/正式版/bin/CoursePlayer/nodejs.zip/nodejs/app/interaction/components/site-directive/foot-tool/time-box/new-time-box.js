/**
 * Created by px on 2015/6/11.
 */

define(['angularAMD'], function (angularAMD) {
    angularAMD.directive('newTimeBox', [function () {
        return {
            restrict: 'EA',
            templateUrl: 'interaction/components/site-directive/foot-tool/time-box/time-box.html',
            scope: false,
            replace:true
        };
    }])
});
