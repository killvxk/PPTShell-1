/**
 * wordcard_search
 * 2015-11-10 11:25:26
 * author :ccy
 */
define(['app','wordcard_search/directive/preview/preview-window','wordcard_search/directive/search/search-window','css!wordcard_search/assets/css/wood.css'], function (app) {
    'use strict';
    app.controller('wordcard_search_ctrl', [
        '$scope',  '$stateParams', '$rootScope', '$filter',
        function ($scope,  $stateParams,  $rootScope, $filter) {
        	$scope.content={
        			chapter_id :''  , 
        			search_word:'' ,
        			grade:'',
        			words:[],
        			select_words:[] ,
        			oper:$stateParams.oper 
        	}
        	//search:弹出搜索窗口 ， preview：弹出预览窗口
        	if( $stateParams.oper ){
        		$scope.oper = $stateParams.oper  ; 
        	}

			//$scope.oper = 'search' ;
			if( $scope.oper == 'search'){
        		initSearch() ; 
        	}else if( $scope.oper.indexOf( 'preview')>-1 ){
        		initPreview() ; 
        	}

        	function initSearch(){

            	if($stateParams.chapter_id){
            		$scope.content.chapter_id = $stateParams.chapter_id
            	}
            	if($stateParams.grade){
            		$scope.content.grade = $stateParams.grade
            	}
            	//获取URL参数
            	if($stateParams.search_word){
            		$scope.content.search_word  =$stateParams.search_word;
            	}
        	}
        	
        	function initPreview(){
        		if($stateParams.id){
            		$scope.content.id = $stateParams.id ; 
            	}
            	if($stateParams.grade){
            		$scope.content.grade = $stateParams.grade
            	}
				if($stateParams._lang_){
					$scope.content.json_url = $stateParams._lang_
				}
        	}
        	
        	

            	
        }
    ]);
});
