/**
 * HTML 文本编辑器: input | textarea
 * 
 */
define(['angularAMD'
], function (angularAMD) {
    angularAMD.directive('textEditor', [ function () {
        return {
        	require:"?ngModel",
			restrict: 'A',
			scope: { },
            link: function(scope, element, attr, ngModel) {
            	if(attr.maxlength) {
	            	element.on('keydown', function(event) {
	            		var editor = event.target;
	            		if(editor.value.length >= attr.maxlength) {
	                		if(event.keyCode != 8 && event.keyCode != 46 && (event.which < 37 || event.which > 40)) { //后退按钮或删除键
	                			if(editor.selectionStart === editor.selectionEnd) { //无选中文字
	                    			event.cancelable = true;
	                        		event.preventDefault();
	                        		
	                        		return false;
	                    		}
	                		}
	                	}
	            	});
            	}

				if(attr.placeholder) {
					//元素获取焦点后, 不显示placeholder
					element.on('focus', function(event) {
						element.attr('placeholder', '');
					});

					//元素失去焦点后, 显示placeholder
					element.on('blur', function(event) {
						element.attr('placeholder', attr.placeholder);
					});
				}

				//空格
				//if(ngModel && (attr.nonTrim === "true" || attr.nonTrim === true)) {
				//	element.on('keyup blur', function(event) {
				//		if(event.target.value != ngModel.$viewValue) {
				//			scope.$apply(function(){
				//				ngModel.$setViewValue(event.target.value);
				//			});
				//		}
				//	});
				//}

				if(ngModel && (attr.escapseBlank === "true" || attr.escapseBlank === true)) {
					element.on('blur', function(event) {
						if($.trim(event.target.value) === '') {
							event.target.value = '';
							scope.$apply(function(){
								ngModel.$setViewValue('');
							});
						}
					});
				}
            	
//            	if(attr.valueType) {
//            		switch(attr.valueType) {
//            		case 'number':
//            			element.on('keyup afterpaste change', function() {
//            				element.val(element.val().replace(/\D/g,''));
//            				if(element.val().length > 1) {
//            					element.val(parseInt(element.val()));
//            				}
//            				
//            				if(ngModel) {
//            					ngModel.$setViewValue(element.val());
//            				}
//            			});
//            			
//            			if(ngModel) {
//            				ngModel.$viewChangeListeners.push(function(){
//            					console.log("ngModel.$viewValue：" + ngModel.$viewValue);
//            				});
//            			}
//            			break;
//            		default:
//            		}
//            	}
            }
        };
    }]);

});
