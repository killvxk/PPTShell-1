/**
 * Created by leo.wei on 2015/7/6.
 */
define(['angularAMD'
], function (angularAMD) {
    angularAMD.directive('ngDraggable', ['$document', '$rootScope', function ($document, $rootScope) {
        return {
            restrict: 'A',
            scope: {
                dragOptions: '=ngDraggable'
            },
            link: function (scope, elem, attr) {
                var secondHandElement = angular.element(document.querySelector('.second_hand'));
                var hourHandElement = angular.element(document.querySelector('.hour_hand'));
                var minuteHandElement = angular.element(document.querySelector('.minute_hand'));

                var selectedElement;
                var circleElement = angular.element(document.querySelector('.circle'));

                elem.on('mousedown', function (e) {

                    if (e.toElement.classList.contains('hour_hand')) {
                        selectedElement = hourHandElement;
                        offset = hourHandElement.offset();
                        //if ($rootScope.isLink) {
                        //    // 联动模式不响应时针拖动
                        //    return;
                        //}
                    } else if (e.toElement.classList.contains('minute_hand')) {
                        selectedElement = minuteHandElement;
                        offset = minuteHandElement.offset();
                    } else {
                        console.log("click second down:" + modelContent.minDegree);
                        selectedElement = secondHandElement;
                        offset = secondHandElement.offset();
                    }

                    changeDegree(e);

                    e.preventDefault();
                    $document.on('mousemove', mousemove);
                    $document.on('mouseup', mouseup);
                });

                function mousemove(e) {
                    changeDegree(e);
                }

                function mouseup(e) {
                    $document.unbind('mousemove', mousemove);
                    $document.unbind('mouseup', mouseup);
                }

                var tmpPoint, tmpIntervel;
                var isShun;

                function changeDegree(event) {
                    var center_x = circleElement.offset().left + circleElement.width() / 2;
                    var center_y = circleElement.offset().top + circleElement.height() / 2;
                    var mouse_x = event.pageX;
                    var mouse_y = event.pageY;

                    var radians = Math.atan2(mouse_x - center_x, mouse_y - center_y);
                    var degree;
                    var point;
                    if (selectedElement === hourHandElement) {
                        degree = -radians * (180 / Math.PI) + 90;
                        point = 15 + Math.round(degree / 6);
                    } else if (selectedElement === minuteHandElement) {
                        degree = -radians * (180 / Math.PI) + 180;
                        point = Math.round(degree / 6);
                    } else {
                        degree = -radians * (180 / Math.PI) - 90;
                        point = 45 + Math.round(degree / 6);
                    }
                    var intervel = Math.floor(degree % 6);

                    if (tmpIntervel == intervel) {
                        return;
                    }
                    tmpIntervel = intervel;

                    if (intervel == 0 || intervel == -6) {
                        if (tmpPoint != point) {
                            if (tmpPoint < point) {
                                // 判断是顺时针还是逆时针
                                if (point - tmpPoint > 30) {
                                    isShun = false;
                                } else {
                                    isShun = true;
                                }
                            } else {

                                if (tmpPoint > point) {// 45 10
                                    if (tmpPoint - point > 30) {
                                        // 旧的点快速滑动到新的点，顺时针
                                        isShun = true;
                                    } else {
                                        isShun = false;
                                    }
                                } else {
                                    isShun = false;
                                }
                            }
                        }
                        //console.log(isShun ? "顺时针" : "逆时针", tmpPoint, point);
                        // 设置时间
                        if (selectedElement === hourHandElement) {
                            modelContent.curdate.setHours(point / 5);
                            if (modelContent.isLink == 1) {
                                modelContent.curdate.setMinutes((point % 5) * 12);
                            }
                        } else if (selectedElement === minuteHandElement) {
                            modelContent.curdate.setMinutes(point);
                            if (modelContent.isLink) {
                                //console.log(isShun, point < tmpPoint);
                                if (isShun) {
                                    if (point < tmpPoint) {
                                        modelContent.curdate.setHours(modelContent.curdate.getHours() + 1);
                                    }
                                } else if (point > tmpPoint) {
                                    // FIXME
                                    modelContent.curdate.setMinutes(59);
                                    modelContent.curdate.setHours(modelContent.curdate.getHours() - 1);
                                }
                            }

                        } else {
                            if (modelContent.isLink) {
                                if (isShun) {
                                    if (point < tmpPoint) {
                                        modelContent.curdate.setMinutes(modelContent.curdate.getMinutes() + 1);
                                    }
                                } else if (point > tmpPoint) {
                                    modelContent.curdate.setMinutes(modelContent.curdate.getMinutes() - 1);
                                }
                            }
                            modelContent.curdate.setSeconds(point);
                        }
                        //console.log("当前时间是：" + modelContent.curdate);
                        modelContent.timeStamp = Math.round(modelContent.curdate.getTime() / 1000);

                        var hour_as_degree = ( modelContent.curdate.getHours() + modelContent.curdate.getMinutes() / 60 ) / 12 * 360 - 90;
                        var minute_as_degree = modelContent.curdate.getMinutes() / 60 * 360;
                        var second_as_degree = ( modelContent.curdate.getSeconds() + modelContent.curdate.getMilliseconds() / 1000 ) / 60 * 360 + 90;
                        if (modelContent.isLink) {
                            // 联动状态下
                            if (selectedElement === hourHandElement) {
                                // 根据需求要求，时针转动，秒针分针不动
                                moveMinAndSecond(hour_as_degree);
                            } else {
                                moveMinAndSecond(hour_as_degree, minute_as_degree, second_as_degree);
                            }

                        } else {
                            if (selectedElement === hourHandElement) {
                                moveMinAndSecond(degree);
                            }
                            if (selectedElement === minuteHandElement) {
                                moveMinAndSecond('undefined', minute_as_degree);
                            }
                            if (selectedElement === secondHandElement) {
                                moveMinAndSecond('undefined', 'undefined', second_as_degree);
                            }
                        }

                        tmpPoint = point;
                    }
                }

                function moveMinAndSecond(hour_as_degree, minute_as_degree, second_as_degree) {
                    if (typeof (hour_as_degree) != 'undefined' && hour_as_degree != 'undefined') {
                        modelContent.hourDegree = hour_as_degree;
                        hourHandElement.css({
                            webkitTransform: 'rotate(' + hour_as_degree + 'deg)',
                            transform: 'rotate(' + hour_as_degree + 'deg)'
                        });
                    }
                    if (typeof (minute_as_degree) != 'undefined' && minute_as_degree != 'undefined') {
                        modelContent.minDegree = minute_as_degree;
                        minuteHandElement.css({
                            webkitTransform: 'rotate(' + minute_as_degree + 'deg)',
                            transform: 'rotate(' + minute_as_degree + 'deg)'
                        });
                    }
                    if (typeof (second_as_degree) != 'undefined' && second_as_degree != 'undefined') {
                        //console.log("down " + modelContent.secondDegree);
                        modelContent.secondDegree = second_as_degree;
                        secondHandElement.css({
                            webkitTransform: 'rotate(' + second_as_degree + 'deg)',
                            transform: 'rotate(' + second_as_degree + 'deg)'
                        });
                    }

                    console.log("moveMinAndSecond " + modelContent);

                }

            }
        }
    }
    ])
})
;
