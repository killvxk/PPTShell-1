define(['angularAMD','angular', 'angular-ui-router', 'restangular','css!assets/css/common.css'
    ,'cors-custom','messenger','angular-bindonce','site-directive','utils','userdata.service','diskpath.service'
    ,'tripledes','ngDialog','site.filter','http-auth','angular-file-upload','components/site-directive/question-guide/question-guide'], function (angularAMD) {
  'use strict';
  return angularAMD;
});
