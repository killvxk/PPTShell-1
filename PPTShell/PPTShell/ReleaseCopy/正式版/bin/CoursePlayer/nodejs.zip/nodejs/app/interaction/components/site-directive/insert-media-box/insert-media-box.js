/**
 * Created by tinler on 2015/12/23.
 */

define(['angularAMD',
    'components/site-directive/event-load/event-load'
], function (angularAMD) {
    angularAMD.directive('insertMediaBox', ['$stateParams','ngDialog', function ($stateParams, ngDialog) {
        return {
            restrict:'EA',
            templateUrl:'interaction/components/site-directive/insert-media-box/insert-media-box.html',
            scope:{
                mediaItem:'=mediaItem',
                imageSize:'@',
                audioSize:'@',
                videoSize:'@'
            },
            controller:function($scope){
                $scope.removeMediaItem = function(){
                    $scope.mediaItem.asset_type = '';
                    $scope.mediaItem.asset = '';
                    $scope.mediaItem.other = {};
                };
                //图片已加载标识
                $scope.imageLoadedFlag = false;
                $scope.addAssets = function(asset_type){
                	$scope.showEdit = false;
                    $scope.mediaItem.asset_type = asset_type;
                    if(asset_type === 'video' || asset_type === 'audio'){
                        $scope.mediaItem.other = {
                            controls:'controls',
                            preload:'false',
                            style:"height:100%; width:100%;"
                        };
                    } else {
                        $scope.imageLoadedFlag = false;
                    }
                };
                $scope.imageLoad = function() {
                    if(!$scope.imageLoadedFlag) {
                        $scope.imageLoadedFlag = true;
                        $('.insert_mvp .insert_pic_box').css('height', 'auto');
                    }
                };
                $scope.onClickMedia = function() {
                	$scope.showEdit = !$scope.showEdit;
                };
                
                //资源文件的限制使用
                $scope.resourceValidParam = {
                    imageType:['image/jpg', 'image/jpeg', 'image/webp', 'image/gif', 'image/png', 'image/bmp'], 
                    imageSize:1*1024*1024, 
                    videoType:'video/mp4', 
                    videoSize:5*1024*1024, 
                    audioType:['audio/mp3', 'audio/mpeg'], 
                    audioSize:1*1024*1024
                };
            }
        };
    }])

});