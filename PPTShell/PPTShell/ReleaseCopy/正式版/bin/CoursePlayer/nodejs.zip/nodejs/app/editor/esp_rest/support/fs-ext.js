/**
 * Created by ChenST on 2016/1/20.
 */
var fs = require('fs');
var path = require('path');
var Q = require('q');

var walk = function (dir, callbak) {
    var results = [];

    // 如果目录不存在,则返回空.
    Q.nfcall(fs.stat, dir).then(function () {
        fs.readdir(dir, function (err, files) {
            if (err) return callbak(err);
            var i = 0;
            (function next() {
                var file = files[i++];
                if (!file) return callbak(null, results);
                file = path.join(dir, file);
                fs.stat(file, function (err, stat) {
                    if (stat && stat.isDirectory()) {
                        walk(file, function (err, res) {
                            results = results.concat(res);
                            next();
                        });
                    } else {
                        results.push(file);
                        next();
                    }
                });
            })();
        });
    }, function (err) {
        callbak(null, results)
    });


};

module.exports.walk = walk;