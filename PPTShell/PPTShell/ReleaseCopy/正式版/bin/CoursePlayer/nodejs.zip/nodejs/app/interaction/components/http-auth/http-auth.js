/**
 * Created by Administrator on 2015/4/3.
 */
define(['angularAMD','moment'], function (angularAMD,moment) {
    'use strict';
    angularAMD
        .service('httpUrlFormat', function () {
            return function (urlOld, dataUrl, method) {
                if (dataUrl) {
                    var urlArray = [];

                    dataUrl = angular.isArray(dataUrl) ? (dataUrl.length > 0 ? dataUrl[0] : []) : dataUrl;
                    angular.forEach(dataUrl, function (value, key) {

                        if (urlOld.indexOf(":" + key, value) != -1) {
                            urlOld = urlOld.replace(":" + key, value);
                            delete dataUrl[key];
                        } else {
                            if (method.toUpperCase() === 'GET' || method.toUpperCase() === 'DELETE') {
                                urlArray.push(key + "=" + value);
                            }
                        }
                    });
                    
                    //Sort by key, keep the same url as angular, or 401(Unauthorization) may occur due to Mac签名错误
                    urlArray.sort(function(a, b){
                    	return a.localeCompare(b);
                    });
                    
                    urlOld = urlOld + (urlArray.length > 0 ? ("?" + urlArray.join('&')) : '');
                }
                return urlOld;
            }
        })
        .service('httpAuth', ['$window', 'UserDataService', '$http', '$location', 'httpUrlFormat', function (win, UserDataService, $http, $location, httpUrlFormat) {

            return function (configHttp, host) {
                if (!host) {
                    host = win.config.lms_host;//默认备课系统
                }
                var userObj = UserDataService.getUserObj();
                if (!userObj || !userObj.token) {
                    $location.url('/');
                    throw new Error("请先登录");
                }
                configHttp.url = httpUrlFormat(configHttp.url, configHttp.data, configHttp.method);
                //configHttp.headers = angular.extend({"X-HTTP-Method-Override":configHttp.method},configHttp.headers);
                configHttp.headers = angular.extend({"Content-Type": 'application/json', "Authorization": CryptoJS.HmacAuth(userObj.token.access_token, userObj.token.mac_key, configHttp.method, configHttp.url, host.replace("http://", "").replace("https://", ""), moment(userObj.token.server_time), moment(userObj.token.local_time))}, configHttp.headers);
                configHttp.url = host + configHttp.url;
                return $http(configHttp).
                    error(function (data) {
                        throw new Error(data.message);
                    });
            }
        }])
        .service('httpNonAuth', ['$window', '$http', 'httpUrlFormat', function (win, $http, httpUrlFormat) {
            return function (configHttp, host) {
                if (!host) {
                    host = win.config.lifecycle_host;//默认资源平台
                }
                //configHttp.headers = angular.extend({"X-HTTP-Method-Override":configHttp.method},configHttp.headers);
                configHttp.url = httpUrlFormat(configHttp.url, configHttp.data, configHttp.method);
                configHttp.url = host + configHttp.url;
                return $http(configHttp).
                    error(function (data) {
                        throw new Error(data.message);
                    });
            }
        }])
        .service('RestAngularCustom', ['Restangular', function (Restangular) {
            return function (version, host) {
                return  Restangular.withConfig(function (Configurer) {
                    Configurer.setBaseUrl([!host ? window.config.lms_host : host, '/', (!version ? 'v0.3' : version)].join(''));
                });
            }
        }])
        .service('RestAngularLms', ['Restangular', function (Restangular) {
            return function (version) {
                return  Restangular.withConfig(function (Configurer) {
                    Configurer.setBaseUrl([window.config.lms_host, '/', (!version ? 'v0.3' : version)].join(''));
                });
            }
        }])
        .service('RestAngularLifecycle', ['Restangular', function (Restangular) {
            return function (version) {
                return  Restangular.withConfig(function (Configurer) {
                    Configurer.setBaseUrl([window.config.lifecycle_host, '/', (!version ? 'v0.3' : version)].join(''));
                });
            }
        }])
        .service('RestAngularEditor', ['Restangular', function (Restangular) {
            return function (version) {
                return  Restangular.withConfig(function (Configurer) {
                    Configurer.setBaseUrl([window.config.editor_host, '/', (!version ? 'v0.2' : version)].join(''));
                });
            }
        }])
        .service('RestAngularClassroom', ['Restangular', function (Restangular) {
            return function (version) {
                return  Restangular.withConfig(function (Configurer) {
                    Configurer.setBaseUrl([window.config.classroom_host, '/', (!version ? 'v03' : version)].join(''));
                });
            }
        }])
        .service('RestAngularCustomEditor', ['Restangular', function (Restangular) {
            return function (version) {
                return  Restangular.withConfig(function (Configurer) {
                    Configurer.setBaseUrl([window.config.custom_editor_host, '/', (!version ? 'v0.1' : version)].join(''));

                });
            }
        }])
    ;
});
