/**
 * Created by px on 2015/5/15.
 */
define(['angularAMD', 'css!components/site-directive/div-loading/loading'
], function (angularAMD) {
    angularAMD .directive('customLoading', [ function () {
        return {
            restrict:'EA',
            templateUrl:'components/site-directive/div-loading/loading.html'
        };
    }])

});