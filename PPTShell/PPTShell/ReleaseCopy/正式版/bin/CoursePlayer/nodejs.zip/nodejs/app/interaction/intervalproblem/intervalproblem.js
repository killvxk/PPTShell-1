/**
 * intervalproblem
 * 2016-01-12 16:33:18
 */
define(['app', 'intervalproblem/directive/intervalproblem.directive','threejs','threex_dynamictexture'], function (app) {
    'use strict';
    app.controller('intervalproblem_ctrl', [
        '$scope', 'skin_service', '$stateParams', 'CustomEditorService', '$rootScope', '$filter',
        function ($scope, skin_service, $stateParams, CustomEditorService, $rootScope, $filter) {
            $rootScope.moduleScope = $scope;
            $scope.errorModel = {};
            $scope.presenter;
            $scope.model = {
                "id": "",
                "module_code": "nd_intervalproblem", // 题目类型
                "title": "", //标题
                "skin": {
                    code: "wood",
                    css_url: "",
                    name: $filter('translate')('app.skin.wood'),
                    package_url: ""
                },
                "timer": {
                    "timer_type": "sequence",  //计时器类型: ["sequence", "countdown"]
                    "time_minute": "0",    //倒计时初始设置-分钟，timer_type="countdown"时有效
                    "time_second": "0"     //倒计时初始设置-秒，timer_type="countdown"时有效
                },
                "properties": [	//模块静态数据模型
                    {
                        "name": "question_id",
                        "display_name": "题目ID",
                        "type": "string",
                        "value": "",
                        "is_localized": false
                    },
                    {
                        "name": "question_url",
                        "display_name": "题目内容",
                        "type": "jsonFile",
                        "value": "",
                        "is_localized": false
                    }
                ],
                "content": { //Editor数据模型正文
                    "displayHtml":'',
                    "intervals":[{"min":{num:"","contain":"0"},"max":{"num":"","contain":"0"}}],
                    "answer":""
                }
            };

            $scope.previewAnswer = function () {
                if(!$scope.validPostData())return;
                if(!$scope.presenter) {
                    $scope.presenter = new Addon_create();
                    $scope.presenter.run(document.body,$scope.model);
                }else {
                    $scope.presenter.destroy();
                    $scope.presenter.run(document.body,$scope.model);
                }

                $scope.presenter.previewAnswer($scope.model.content.answer);
            };

            //数据加载
            var loadingData = function (id) {
                $scope.isloadingData = true;
                CustomEditorService.getQuestionInfoById(id)
                    .then(function (rtnData) {
                        if (!rtnData) {
                            $scope.errorModel.errorText = $filter('translate')('app.unvalidno');
                        } else {
                            if (rtnData.skin.code != '') {
                                $scope.model = $scope.decodeData(rtnData, true);
                            } else {
                                $scope.model.id = rtnData.id;
                            }

                            skin_service.set_skin_by_code($scope.model.skin.code, "v1");
                            $scope.errorModel.errorText = "";
                            $scope.isloadingData = false;
                        }
                    }, function (error) {
                        $scope.errorModel.errorText = $filter('translate')('app.question.get.error');
                    })
            };

            //入口
            if (!$stateParams.id) { //新增
                skin_service.set_skin_by_code($scope.model.skin.code, "v1");
            } else { //修改
                loadingData($stateParams.id);
            }
			
			      $scope.$on('changgedSkin',function(){
                $rootScope.scaleHtml();
            });

            //数据验证
            $scope.validPostData = function () {
                var items = $scope.model.content.intervals;
                for(var i=0;i<items.length;i++) {
                    var item = items[i];
                    item.isBlank = false;
                    if(item.min.num !== '' && item.max.num !=='') {
                        if(item.min.num-0 > item.max.num-0) {
                            $scope.errorModel.errorText = "区间左端点不能大于右端点";
                            return false;
                        }
                        if(item.min.num-0 === item.max.num-0 && (item.min.contain=="0" || item.max.contain=="0")){
                            item.isBlank = true;
                        }
                    }
                }

                var answer = getResultInterval(items);
                //if(answer.length==0){
                //    $scope.errorModel.errorText = "区间结果为空，请输入正确的区间或区间运算式";
                //    return false;
                //}
                console.log(answer)
                $scope.model.content.answer = answer;
                return true;
            };

            //数据模型-编码
            $scope.encodeData = function (model) {
                if(model.title == '') {
                    model.title = '根据题干，在数轴上标出区间';
                }
                return model;
            };

            //数据模型-解码
            $scope.decodeData = function (model, isInitLoad) {
                return model;
            };

            function getResultInterval(items){
                var interval;
                if(items.length==1) {
                    if(items[0].isBlank)return [];
                    return items;
                }

                for(var i=0;i<items.length;i++) {
                    var item = items[i]
                    if(item.min.num === ''){
                        item.min.num = -21;
                    }
                    if(item.max.num === '') {
                        item.max.num = 21;
                    }
                    item.min.num = item.min.num*1;
                    item.max.num = item.max.num*1;
                }

                for(var i=1;i<items.length;i++) {
                    if(items[i] && items[i].addType== 0) {//并集
                        if(!interval){
                            interval = getUnion(items[i-1],items[i]);
                        }else {
                            if(interval.length>0){
                                var temp;
                                var temps = [];
                                for(var j=0;j<interval.length;j++){
                                    if(!temp || temp.length >1) {
                                        if(temp && temp.length >1) temps.pop();
                                        temp = getUnion(interval[j],items[i]);
                                        temps = temps.concat(temp);
                                    }else{
                                        temp = getUnion(temp[0],interval[j]);
                                        temps = temp;
                                    }
                                }
                                interval = temps;
                            }else{
                                interval = getUnion(null,items[i]);
                            }
                        }
                    }
                    if(items[i] && items[i].addType== 1) {//交集
                        if(!interval){
                            interval = getIntersection(items[i-1],items[i]);
                        }else {
                            if(interval.length>0) {
                                var temps = [];
                                for (var j = 0; j < interval.length; j++) {
                                    temps = temps.concat(getIntersection(interval[j], items[i]));
                                }
                                interval = temps;
                            }
                        }
                    }

                }

                for(var i=0;i<items.length;i++) {
                    var item = items[i];
                    if(item.min.num == -21){
                        item.min.num = '';
                    }
                    if(item.max.num == 21) {
                        item.max.num = '';
                    }
                }

                for(var i=0;i<interval.length;i++) {
                    var item = interval[i];
                    if(item.min.num == -21){
                        item.min.num = '';
                    }
                    if(item.max.num == 21) {
                        item.max.num = '';
                    }
                }

                return interval;
            }

            function getIntersection(inter,inter2){
                if(!inter) return [];
                if(inter.isBlank || inter2.isBlank) return [];
                if(inter2.min.num > inter.max.num
                  || (inter2.min.num == inter.max.num && (inter2.min.contain=="0" || inter.max.contain=="0"))
                  || inter.min.num > inter2.max.num
                  || (inter.min.num == inter2.max.num && (inter.min.contain=="0" || inter2.max.contain=="0"))) {
                    return [];
                }else {
                    var min = {};
                    var max = {};
                    if(inter.min.num>inter2.min.num
                      || (inter.min.num==inter2.min.num && inter.min.contain=="0")){
                        min = inter.min;
                    }else {
                        min = inter2.min;
                    }
                    if(inter.max.num < inter2.max.num
                      || (inter.max.num==inter2.max.num && inter.max.contain =="0")){
                        max = inter.max;
                    }else {
                        max = inter2.max;
                    }
                    return [{min:min,max:max}];
                }
            }

            function getUnion(inter,inter2){
                if(!inter)return [inter2];
                if(inter.isBlank && inter2.isBlank){
                    return [];
                } else if(inter.isBlank && !inter2.isBlank){
                    return [inter2]
                }else if(!inter.isBlank && inter2.isBlank){
                    return [inter]
                }
                if(inter2.min.num > inter.max.num
                || (inter2.min.num == inter.max.num && inter2.min.contain=="0" && inter.max.contain=="0")
                || inter.min.num > inter2.max.num
                || (inter.min.num == inter2.max.num && inter.min.contain=="0" && inter2.max.contain=="0")) {
                    return [inter,inter2];
                }else {
                    var min = {};
                    var max = {};
                    if(inter.min.num<inter2.min.num
                      || (inter.min.num==inter2.min.num && inter.min.contain=="1")){
                        min = inter.min;
                    }else {
                        min = inter2.min;
                    }
                    if(inter.max.num > inter2.max.num
                    || (inter.max.num==inter2.max.num && inter.max.contain=="1")){
                        max = inter.max;
                    }else {
                        max = inter2.max;
                    }
                    return [{min:min,max:max}];
                }
            }
            $scope.btnOnkeyPress = function(event){
                event.preventDefault();
                event.stopPropagation();
            }
        }
    ]);
});
