/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
    'jquery',
    'espService',
    'espModel',
    'prompter'
],function(
    $,
    espService,
    espModel,
    prompter
){
    return function(config, workbench, coursewareobjectMetadata){
        config = $.extend({},config);
        workbench.switchPerspective('nd.esp.coursewareobject.interactionQ');
        workbench.openEditor({
            type: 'coursewareobject',
            key: coursewareobjectMetadata.identifier,
            data:coursewareobjectMetadata
        },'nd.esp.coursewareobject.InteractionQEditor',config);
    };
});