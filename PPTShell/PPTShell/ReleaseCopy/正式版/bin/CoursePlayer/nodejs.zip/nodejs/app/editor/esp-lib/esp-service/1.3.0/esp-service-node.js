/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
    'jquery',
    'espEnvironment',
    'espService/../esp-service-exceptions'
], function (
    $,
    espEnvironment,
    EspExceptions
) {
    function getNodeService(){
        return require('../service/core/coursewareobject.js');
    }
    function promise(q){
        var deferred = $.Deferred();
        q.then(function (result) {
            deferred.resolve(result);
        }, function (result) {
            deferred.reject(result);
        });
        return deferred.promise();
    }
    var service = {};
    service.coursewareobject = {
        create: function (coursewareObject) {
            return promise(getNodeService().create(coursewareObject));
        },
        createByTemplate: function (templateCode) {
            return promise(getNodeService().createFromTemplate(templateCode));
        },
        get: function (coursewareObjectId) {
            return promise(getNodeService().get(coursewareObjectId));
        },
        getMainXml: function (coursewareObjectId) {
            return promise(getNodeService().getMain(coursewareObjectId));
        },
        updateMainXml: function (coursewareObjectId, mainXml) {
            return promise(getNodeService().updateMain(coursewareObjectId, mainXml));
        },
        getPageXml: function (coursewareObjectId, pageId) {
            return promise(getNodeService().getPage(coursewareObjectId, pageId));
        },
        createPageXml: function (coursewareObjectId, pageXml) {
            return promise(getNodeService().createPage(coursewareObjectId, pageXml));
        },
        updatePageXml: function (coursewareObjectId, pageId, pageXml) {
            return promise(getNodeService().updatePage(coursewareObjectId, pageId, pageXml));
        },
        copyAs: function (coursewareObjectId, newCoursewareObjectId) {
            return promise(getNodeService().copy(coursewareObjectId, newCoursewareObjectId));
        },
        getAssetFileWriter: function (coursewareObjectId) {
            return function (file) {
                console.log('write file', file);
            };
        },
        listAssets: function (coursewareObjectId, params) {
            return promise(getNodeService().searchResourceFiles(coursewareObjectId, params && params.type));
        }
    };

    return service;
});
