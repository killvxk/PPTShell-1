/*!
 * jQuery Placeholder plugin
 *
 * This plugin is used to support the HTML5 placeholder attribute on most non-HTML5-compliant browsers.
 * 
 * Usage: $.Placeholder.init({ color : "rgb(0,0,0)" });
 * 
 * Date: Sept 2011
 * Author: Otacon (byf1987_at_gmail.com)
 * Project page: https://code.google.com/p/jquery-placeholder-js/
 * Version: 1.3
 * Changelog: 
 1.3 Added cleanBeforeSubmit global function, so that user can call before submitting form by JS. thanks to Krzysztof (kot**********ztof_at_gmail.com) for contributing this idea and some codes.
 1.2 Added semicolons to the end of function, so that the min version work. thanks to Tony (ty*****_at_gmail.com) for pointing this out and providing fix.
 1.1	Updated the code to meet jQuery plugin format. Added parameterized init.
 1.0 Initial release.
 * Tested on: Chrome (latest dev version); IE6 (IETester); IE8 (IETester)
 * Known Issues: 
 * 	Placeholder for Password is currently not supported
 */
define(['angular', 'css!components/placeholder/placeholder'], function (angular) {
    return {
        init: function () {
            if ('placeholder' in document.createElement('input')) { //if support placeholder
                return;
            }
            function target(e) {
                var e = e || window.event;
                return e.target || e.srcElement;
            };
            function getContent(element) {
                return angular.element(element).val();
            };
            function isContentEmpty(element) {
                var content = getContent(element);
                return (content.length === 0);
            };
            function keyupevent(el) {
                if (!el || el.tagName != 'INPUT' && el.tagName != 'TEXTAREA') return;
                var emptyHintEl = el.__emptyHintEl;
                if (emptyHintEl) {
                    if (isContentEmpty(el)) {
                        emptyHintEl.style.display = '';
                    } else {
                        emptyHintEl.style.display = 'none';
                    }
                }
            };

            function inputFn() {
                keyupevent(this);
            };
            function changeproperty(self) {
                if (window.event.propertyName == 'placeholder') {
                    var element = target(self);
                    var placeholdertx = element.getAttribute('placeholder');
                    if (placeholdertx)

                        angular.element(element).prev().text(placeholdertx);
                }
            };
            function proxy(fn, context) {
                // Simulated bind
                var args = arguments,
                    proxy = function () {
                        return fn.apply(context, args);
                    };
                return proxy;
            };
            var elss = [document.getElementsByTagName('input'), document.getElementsByTagName('textarea')];
            var isIE9 = document.documentMode === 9;
            for (var n = 0; n < 2; n++) {
                var els = elss[n];
                for (var i = 0; i < els.length; i++) {
                    var el = els[i];

                    var placeholder = el.getAttribute('placeholder');
                    if (!placeholder) {
                        continue;
                    }
                    var emptyHintEl = el.__emptyHintEl;
                    if (!emptyHintEl) {
                        emptyHintEl = document.createElement('label');
                        if (placeholder)
                            emptyHintEl.innerHTML = placeholder;
                        emptyHintEl.className = 'ipt-placeholder';
                        emptyHintEl.onclick = function (el) {
                            return function () {
                                try {
                                    el.focus();
                                } catch (ex) {
                                }
                            }
                        }(el);
                        if (el.value) emptyHintEl.style.display = 'none';
                        el.parentNode.insertBefore(emptyHintEl, el);
                        el.__emptyHintEl = emptyHintEl;
                    }
                    if (document.addEventListener) {
                        angular.element(el).bind("input", inputFn);
                    } else {
                        angular.element(el).bind('propertychange', inputFn);
                    }
                    if (isIE9) {
                        angular.element(el).bind('keyup', function (event) {
                            if (event.ctrlKey == true && event.keyCode == 90) {//IE9 Ctrl+Z Unable to trigger selectionchange
                                keyupevent(target(event));
                            }
                        });
                        var proxyNew;
                        angular.element(el).bind('focus', function (e) { //IE9 input Unable to trigger
//                        document.addEventListener("selectionchange", inputFn.call(this));
                            proxyNew = proxy(inputFn, this, el)
                            document.addEventListener("selectionchange", proxyNew);
                        });
                        angular.element(el).bind('blur', function (e) {
//                        document.removeEventListener("selectionchange", inputFn.call(this));
                            document.removeEventListener("selectionchange", proxyNew);
                        });
                    }
                    if (window.attachEvent) {
                        el.attachEvent('onpropertychange', changeproperty);
                    }
                    else {
                        angular.element(el).bind('change', changeproperty);
                    }
                }
            }
        }
    };
});