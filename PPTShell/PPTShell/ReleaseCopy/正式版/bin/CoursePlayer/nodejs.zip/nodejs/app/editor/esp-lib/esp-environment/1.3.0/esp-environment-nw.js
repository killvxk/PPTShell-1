/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
], function (
) {
    return {
        service: 'node',
        coursewareobjectPreview: '/',
        modulePresenterRoot: '../presenters/{id}',
        coursewareobjectTemplateRoot: '../coursewareobject_template/{id}',
        coursewareobjectRoot: '../coursewareobject/{id}.pkg',
        moduleEditorRoot: '../modules/{id}',
        referencePath: '/cs',
        "supports": {
            "asset": false
        }
    };
});