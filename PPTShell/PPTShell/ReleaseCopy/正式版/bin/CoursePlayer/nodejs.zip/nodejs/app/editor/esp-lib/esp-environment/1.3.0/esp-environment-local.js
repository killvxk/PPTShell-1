/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
], function (
) {
    return {
        service: 'http',
        serviceConfig: {
            server: '/'
        },
        coursewareobjectPreview: '/player/index.html?type=coursewareobject&&main=/userdatas/edu/esp/interaction/{id}.pkg/main.xml',
        //modulePresenterRoot: 'presenters/{id}',
        coursewareobjectTemplateRoot: 'coursewareobject_template/{id}',
        coursewareobjectRoot: '/userdatas/edu/esp/interaction/{id}.pkg',
        moduleEditorRoot: 'modules/{id}',
		jsLibraryRoot: 'js-library/{name}/{version}',
        referencePath: 'http://localhost:3000',
        "supports": {
            "asset": false
        }
    };
});