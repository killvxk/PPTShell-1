/**
 * Created by px on 2015/7/2.
 */
define(['angularAMD'
], function (angularAMD) {
    angularAMD.directive('customLink', [ function () {
        return {
            restrict:'E',
            replace:true,
            template:'<link rel="stylesheet" ng-href="{{hrefNew}}"/>',
            scope:{
                href:'@'
            },
            link:function($scope){
                $scope.hrefNew = [$scope.href,'?',require.s.contexts._.config.urlArgs].join('');
            }
        };
    }])

});