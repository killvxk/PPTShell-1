/**
 *
 */
define(['app', 'guessword/directive/guessword.directive'
], function (app) {
    'use strict';
    app.controller('guessword_ctrl', [
        '$scope', 'skin_service', '$stateParams', 'CustomEditorService', 'CharsetService', 'UtilsService', 'UserDataService', '$rootScope', "$filter", "$timeout",
        function ($scope, skin_service, $stateParams, CustomEditorService, CharsetService, UtilsService, UserDataService, $rootScope, $filter, $timeout) {
            $scope.LANGUAGE = {
                CHINESE: 'chinese',
                ENGLISH: 'english'
            };
            $scope.ITEM_TYPE = {
                PICTURE: 'picture',
                VIDEO: 'video',
                AUDIO: 'audio'
            };

            $rootScope.moduleScope = $scope;
            $scope.errorModel = {};
            $scope.model = {
                "title": "",
                "skin": {
                    code: "wood",
                    css_url: "${ref-path}/edu/esp/preparecustomeditor/guessword/wood/css/wood.css",
                    name: $filter('translate')('guessword.muwen'),
                    package_url: "${ref-path}/edu/esp/preparecustomeditor/guessword/wood"
                },
                "timer": {
                    "timer_type": "countdown",  //计时器类型: ["sequence", "countdown"]
                    "time_minute": "1",    //倒计时初始设置-分钟，timer_type="countdown"时有效
                    "time_second": "0"     //倒计时初始设置-秒，timer_type="countdown"时有效
                },
                "items": []
            };

            $scope.MAX_SIZE = 5;
            $scope.currentItem = null;
            $scope.currentItemIndex = 0;
            $scope.language = $scope.LANGUAGE.CHINESE;
            var loadingData = function (id) {
                $scope.isloadingData = true;
                CustomEditorService.getQuestionInfoById(id)
                    .then(function (rtnData) {
                        if (!rtnData) {
                            $scope.errorModel.errorText = $filter('translate')('guessword.unvalidno');
                        } else {
                            if (rtnData.skin.code != '') {
                                $scope.model = $scope.decodeData(rtnData);
                                skin_service.set_skin_by_code($scope.model.skin.code, "v1");
                            } else {
                                $scope.model.id = rtnData.id;
                                skin_service.set_skin_by_code($scope.model.skin.code, "v1");
                            }
                            $scope.errorModel.errorText = "";
                            $scope.isloadingData = false;

                            setValues();
                        }
                    }, function (error) {
                        $scope.errorModel.errorText = $filter('translate')('guessword.get_title_error');
                    })
            };

            var setValues = function () {
                if ($.isArray($scope.model.items) && $scope.model.items.length > 0) {
                    $scope.currentItem = $scope.model.items[0];
                    $scope.language = $scope.currentItem.language;
                }
            };

            //入口
            if (!$stateParams.id) {
                skin_service.set_skin_by_code($scope.model.skin.code, "v1");
                setValues();
            } else {
                loadingData($stateParams.id);
            }
            $scope.$on('changgedSkin', function () {
                $rootScope.scaleHtml();
            })
            //数据验证
            $scope.validPostData = function () {
                var modelData = $scope.model;
                if ($.trim(modelData.title) == '') {
                    $scope.errorModel.errorText = $filter('translate')('guessword.no_title');
                } else {
                    var isValid = true;

                    if ($scope.model.items.length == 0) {
                        $scope.errorModel.errorText = $filter('translate')('guessword.no_words');
                        isValid = false;
                    } else {
                        angular.forEach($scope.model.items, function (item) {
                            if (!item.item_path || false) { //未选择素材
                                $scope.errorModel.errorText = $filter('translate')('guessword.no_sucai');

                                isValid = false;
                                return false;
                            }

                            if (!item.answer_string || false) { //未设置答案
                                $scope.errorModel.errorText = $filter('translate')('guessword.no_answer');

                                isValid = false;
                                return false;
                            }
                        });
                    }


                    return isValid;
                }
            };

            var CHAR_AMOUNT = 32;
            $scope.encodeData = function (model) {
                stopMedia();

                var newModel = angular.copy(model);
                newModel.title = window.customHtmlEncode(newModel.title);

                angular.forEach(newModel.items, function (item) {
                    item.correct_answer = [];
                    item.word_sequence = [];
                    var char;
                    for (var i = 0; i < item.answer_string.length; i++) {
                        char = item.answer_string.charAt(i);
                        item.correct_answer.push(char);
                        item.word_sequence.push(char);
                    }

                    if (item.language == $scope.LANGUAGE.CHINESE) {
                        for (var i = 0; i < CHAR_AMOUNT - item.answer_string.length; i++) {
                            item.word_sequence.push(CharsetService.getRandomChineseChar());
                        }
                    } else {
                        for (var i = 0; i < CHAR_AMOUNT - item.answer_string.length; i++) {
                            item.word_sequence.push(CharsetService.getRandomAlphabet().toLowerCase());
                        }
                    }

                    //乱序正确答案与干扰项
                    UtilsService.shuffleArray(item.word_sequence, item.answer_string.length);
                });

                var option = "";
                var other;
                for (var i = 0; i < newModel.items.length; i++) {
                    option = "";
                    if (newModel.items[i] && newModel.items[i].item_type == "picture") { //&& newModel.items[i].item_url && newModel.items[i].item_url.indexOf("<img") != 0
                        other = newModel.items[i].other;
                        if(newModel.items[i].other){
                            for(var o in other){
                                option = option + " " +  o + "='" + other[o] + "'";
                            }
                        }
                        newModel.items[i].item_url = "<img src='" + newModel.items[i].item_path + "' "+option+"/>"

                    }
                }

                return newModel;
            };

            //点击预览、保存、插入按钮 停止播放多媒体
            function stopMedia() {
                angular.forEach($(".sidebar audio"), function (media) {
                    media.currentTime = 0;
                    media.pause();
                });

                angular.forEach($(".sidebar video"), function (media) {
                    media.currentTime = 0;
                    media.pause();
                });
            }

            $scope.decodeData = function (model) {
                angular.forEach(model.items, function (item) {
                    if ($.isArray(item.correct_answer)) {
                        item.answer_string = item.correct_answer.join("");
                    }

                    //素材类型 兼容 image-transform $scope.$watch('description.asset_type')
                    item.asset_type = (item.item_type == 'picture' ? 'image' : item.item_type);
                });


                var newModel = angular.copy(model);
                newModel.title = window.customHtmlDecode(newModel.title);
                if (newModel.items.length > 0) {
                    $scope.currentItem = newModel.items[$scope.currentItemIndex];
                }

                return newModel;
            };

            $scope.addItem = function () {
                $scope.currentItem = {
                    item_path: '', item_type: '', language: $scope.language,
                    "image_extend": {       //旋转，放大缩小等属性，todo：具体属性唐焱鑫补充
                        "rotate": "",
                        "resize": ""
                    }
                };
                $scope.model.items.push($scope.currentItem);

                $scope.currentItemIndex = $scope.model.items.length - 1;
            }

            $scope.removeItem = function () {
                if ($scope.currentItem != null) {
                    var itemIndex = $.inArray($scope.currentItem, $scope.model.items);
                    if (itemIndex > -1) {
                        $scope.model.items.splice(itemIndex, 1);
                    }

                    if ($scope.model.items.length > itemIndex) {
                        $scope.currentItem = $scope.model.items[itemIndex];
                    } else if ($scope.model.items.length > 0) {
                        $scope.currentItemIndex = $scope.model.items.length - 1;
                        $scope.currentItem = $scope.model.items[$scope.currentItemIndex];
                    } else {
                        $scope.currentItem = null;
                        $scope.currentItemIndex = 0;
                    }
                }
            }

            $scope.selectItem = function (item, itemIndex) {
                $scope.currentItem = item;
                $scope.currentItemIndex = itemIndex;
                $scope.language = item.language;
            }

            $scope.changeOnTip = function () {
                if ($scope.currentItem.hint.length > 30) {
                    $scope.currentItem.hint = $scope.currentItem.hint.substring(0, 30);
                }
            }

            $scope.setLanguage = function (language, event) {
                $scope.language = language;
                if ($scope.currentItem) {
                    if ($scope.currentItem.language != language) {
                        $scope.currentItem.answer_string = "";
                    }

                    $scope.currentItem.language = language;
                }
            };

            /* ==============  以下这些代码都是为了解决汉字和字母的限制，应该有更好的方法，待优化  begin.... ============== */
//            var isChineseInput = false;
//            var isPinyin = true;
//            $scope.keydownOnBoard = function($event){
//				if($event.keyCode == 229 || $event.keyCode == 197) { //中文输入法
//					isChineseInput = true;
//				}
//            }
//            
//            var pinyin, pinyinIndex, hanzi, suffix;
//            $scope.changeOnAnswer = function() {
//            	if($scope.language == $scope.LANGUAGE.CHINESE) {
//            		if(isChineseInput) {
//            			if(!isPinyin) {
//            				$scope.currentItem.answer_string = CharsetService.getChineses($scope.currentItem.answer_string);
//            				if(suffix && suffix.length > 0) { //场景：输入多个汉字后，再将光标移入汉字中间，再进行中文输入
//            					var answerTemp = $scope.currentItem.answer_string;
//            					
//            					//需要三段相加， 如：中guo人 中人国 --》 中国人
//            					$scope.currentItem.answer_string = answerTemp.substring(0, pinyinIndex)
//            					                                 + answerTemp.substring(hanzi.length)
//            					                                 + suffix;
//            					
//            					setCursorPosition($(".answer textarea")[0], $scope.currentItem.answer_string.length - suffix.length);
//            				}
//            				
//            				suffix = null;
//            				isChineseInput = false;
//            				isPinyin = true;
//            			} else {
//            				pinyin = CharsetService.getAlphabets($scope.currentItem.answer_string);
//            				hanzi = CharsetService.getChineses($scope.currentItem.answer_string);
//            				if(hanzi && hanzi.length > 0) {
//            					pinyinIndex = $scope.currentItem.answer_string.indexOf(pinyin);
//            					
//            					//当在多个汉字中间输入时，suffix肯定不为空
//            					suffix = $scope.currentItem.answer_string.substring(pinyinIndex + pinyin.length);
//            				}
//            				
//            				$scope.currentItem.answer_string = hanzi;
//            				isPinyin = false;
//            			}
//            		} else {
//            			$scope.currentItem.answer_string = CharsetService.getChineses($scope.currentItem.answer_string);
//            		}
//            	} else {
//            		$scope.currentItem.answer_string = CharsetService.getAlphabets($scope.currentItem.answer_string).toLowerCase();
//            	}
//            	
//            	if($scope.currentItem.answer_string.length > 15) {
//            		$scope.currentItem.answer_string = $scope.currentItem.answer_string.substring(0, 15);
//        		}
//            }
//            
//            //设置光标位置
//            function setCursorPosition(elem, index) {
//                var len = elem.value.length
//                if (len < index) return;
//                
//                setTimeout(function() {
//                    elem.focus()
//                    if (elem.setSelectionRange) { // 标准浏览器
//                        elem.setSelectionRange(index, index)   
//                    } else { // IE9-
//                        var range = elem.createTextRange()
//                        
//                        range.moveStart("character", -len)
//                        range.moveEnd("character", -len)
//                        range.moveStart("character", index)
//                        range.moveEnd("character", 0)
//                        range.select()
//                    }
//                }, 10);
//            }

            $scope.changeOnAnswer = function () {
                $timeout(checkCurrentItemText, 50);
            }
            function checkCurrentItemText() {
                var answerString = $scope.currentItem.answer_string;
                if ($scope.language == $scope.LANGUAGE.CHINESE) {
                    answerString = CharsetService.getChineses(answerString);
                } else {
                    answerString = CharsetService.getAlphabets(answerString).toLowerCase();
                }

                if (answerString.length > 15) {
                    answerString = answerString.substring(0, 15);
                }

                $scope.currentItem.answer_string = answerString;
            }

            /* ==============  以上包含的这些代码都是为了解决汉字和字母的限制，应该有更好的方法，待优化 end. ============== */

        }
    ])
});
