/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
    'jquery',
    'espEnvironment',
    'espService',
    'espModel/../ModulePropertyTypeDescriptor',
    'exception'
],function(
    $,
    espEnvironment,
    espService,
    TypeDescriptor,
    Exception
){
    var ModelExceptions = {
        GET_MODULE_DEFINITION: new Exception('ESP-MODEL-00001','Module 定义不存在: {0}'),

        PARSE_COURSEWAREOBJECT_MAIN: new Exception('ESP-MODEL-00002','解析 main.xml [{0}] 发生错误'),
        PARSE_COURSEWAREOBJECT_PAGE: new Exception('ESP-MODEL-00003','解析 page.xml [{0}] 发生错误'),
        PARSE_COURSEWAREOBJECT_PAGE_MODULE: new Exception('00003','解析 module [{0}] 发生错误'),
        PARSE_MODULE_DEFINITION: new Exception('ESP-MODEL-00003','解析 module 定义 [{0}] 发生错误'),
    };

    var resourceTypeMapping = {
        image: ['jpg', 'png', 'gif'],
        audio: ['mp3'],
        video: ['mp4'],
        flash: ['swf'],
        question: [/\/question\/.+\.pkg\/item\.xml/],
        ppt: [/\/coursewares\/.+\.pkg\/.+\/Slide\d*\.xml/],
    };
    function resolveTypeByUrl(url){
        if(!url) return null;
        var path = url, sIndex = -1;
        if((sIndex = url.indexOf('?')) !== -1){
            path = url.substring(0, sIndex);
        }
        var type;
        for(var key in resourceTypeMapping){
            var matchs = resourceTypeMapping[key];
            for(var i=0;i<matchs.length;i++){
                var match = matchs[i];
                if(
                    (typeof match === 'string' && path.lastIndexOf('.' + match) === path.length - match.length -1) ||
                    (typeof match.test === 'function' && match.test(url)) ||
                    (typeof match === 'function' && match(url, path) === true)
                ){
                    type = key;
                    break;
                }
            }
            if(type) break;
        }
        return type || 'file';
    }
    /************************************ Model ************************************/
    /************************************ Class Coursewareobject ************************************/
    function Coursewareobject(id, pages){
        this._id = id;
        this._pages = pages || [];
    }
    Object.defineProperties(Coursewareobject.prototype, {
        'id': {
            get: function () {
                return this._id;
            }
        },
        'href': {
            get: function () {
                return this._href;
            }
        }
    });
    Coursewareobject.prototype.getPageReferenceAt = function(index){
        return this._pages[index];
    };
    Coursewareobject.prototype.addPageReference = function(page){
        this._pages.push(page);
        return page;
    };
    Coursewareobject.prototype.removePageReference = function(pageOrId){
        var removedPage = false;
        for(var i=0;i<this._pages.length;i++){
            var page = this._pages[i];
            if(page == pageOrId || (typeof pageOrId === 'string' && page.id == pageOrId)){
                removedPage = page;
                this._pages.splice(i,1);
                break;
            }
        }
        return removedPage;
    };
    function PageReference(pageId, href){
        this._id = pageId;
        this._href = href;
    }
    Object.defineProperties(PageReference.prototype, {
        'id': {
            get: function () {
                return this._id;
            }
        },
        'href': {
            get: function () {
                return this._href;
            }
        }
    });

    /************************************ Class Page ************************************/
    function Page(id, modules){
        this._id = id;
        this._modules = modules || [];
    }
    Object.defineProperties(Page.prototype, {
        'id': {
            get: function () {
                return this._id;
            }
        },
        'modules': {
            get: function () {
                return this._modules;
            }
        }
    });
    Page.prototype.getModuleAt = function(index){
        return this._modules[index];
    };
    Page.prototype.addModule = function(module){
        this._modules.push(module);
    };
    Page.prototype.removeModule = function(moduleOrId){
        var removedModule = false;
        for(var i=0;i<this._modules.length;i++){
            var module = this._modules[i];
            if(module == moduleOrId || (typeof moduleOrId === 'string' && module.id == moduleOrId)){
                removedModule = module;
                this._modules.splice(i,1);
                break;
            }
        }
        return removedModule;
    };
    /************************************ Class Module ************************************/
    function Module(instanceId, moduleId, properties, events, presenters){
        this._id = instanceId;
        this._moduleId = moduleId;
        this._editorId = null;
        this._presenterId = null;
        this._properties = properties || [];
        this._events = events || [];
        this._presenters = presenters || [];
        this._visible = true;
        this._locked = false;
        this._style = '';
        this._position = {
            left: '0',
            top: '0'
        };
        this._size = {
            width: '0',
            height: '0',
        };
        this._rotate = 0;

        this.lazyInit = false;

        this._repository = espModel.repository.module(this._moduleId);
    }
    Object.defineProperties(Module.prototype, {
        'id': {
            get: function () {
                return this._id;
            }
        },
        'moduleId': {
            get: function () {
                return this._moduleId;
            }
        },
        'editorId': {
            get: function () {
                return this._editorId;
            },
            set: function (val) {
                this._editorId = val;
            }
        },
        'presenterId': {
            get: function () {
                return this._presenterId;
            },
            set: function (val) {
                this._presenterId = val;
            }
        },
        'presenters': {
            get: function () {
                return this._presenters;
            }
        },
        'position': {
            get: function () {
                return $.extend({},this._position);
            },
            set: function (val) {
                this._position.top = (val && val.top && val.top+'') || this._position.top;
                this._position.left = (val && val.left && val.left+'') || this._position.left;
            }
        },
        'size': {
            get: function () {
                return $.extend({},this._size);
            },
            set: function (val) {
                this._size.width = (val && val.width && val.width+'') || this._size.width;
                this._size.height = (val && val.height && val.height+'') || this._size.height;
            }
        },
        'rotate': {
            get: function () {
                return this._rotate;
            },
            set: function (val) {
                val = parseInt(val);
                if(isNaN(val)) return;
                this._rotate = val;
            }
        },
        'visible': {
            get: function () {
                return this._visible;
            },
            set: function (val) {
                this._visible = !!val;
            }
        },
        'locked': {
            get: function () {
                return this._locked;
            },
            set: function (val) {
                this._locked = !!val;
            }
        },
        'style': {
            get: function () {
                return this._style;
            },
            set: function (val) {
                this._style = val || '';
            }
        },
        'lazyInit': {
            get: function () {
                return this._lazyInit;
            },
            set: function (val) {
                this._lazyInit = !!val;
            }
        },
        'properties': {
            get: function () {
                return this._properties;
            }
        },
        'repository': {
            get: function () {
                return this._repository;
            }
        },
        'editorRepository': {
            get: function () {
                return espModel.repository.moduleEditor(this.editorId);
            }
        }
    });
    Module.prototype.getProperty = function (name) {
        for(var i=0;i<this._properties.length;i++){
            var p = this._properties[i];
            if(p.name == name){
                return p;
            }
        }
        return null;
    };
    Module.prototype.getPropertyValue = function (name) {
        var property = this.getProperty(name);
        return property && property.value;
    };
    Module.prototype.setPropertyValue = function (name, value, type) {
        var property = this.getProperty(name);
        if(property == null && type){
            property = new Property(name, type);
            this._properties.push(property);
        }
        if(property){
            property.value = value;
        }else{
            throw 'no property for name: ' + name + ', you must be specify type for the property';
        }
    };
    /************************************ Class Property ************************************/
    function Property(name, type, displayName){
        this._name = name;
        this._type = type;
        this._displayName = displayName;
    }
    Object.defineProperties(Property.prototype, {
        'name': {
            get: function () {
                return this._name;
            }
        },
        'type': {
            get: function () {
                return this._type;
            }
        },
        'displayName': {
            get: function () {
                return this._displayName;
            }
        },
        'value': {
            get: function () {
                return this._value;
            },
            set: function (val) {
                var validateResult = TypeDescriptor(this.type).validate(val);
                if(validateResult !== true){
                    throw validateResult;
                }
                this._value = val;
            }
        }
    });


    /************************************ Class ModuleDefinition ************************************/
    function ModuleDefinition(moduleId, properties, events, presenters){
        this._moduleId = moduleId;
        this._properties = properties || [];
        this._events = events || [];
        this._presenters = presenters || [];
    }
    ModuleDefinition.prototype.newModule = function(instanceId){
        var properties = [], events = [], presenters = this._presenters;
        $.each(this._properties, function(i, p){
            var property = new Property(p.name, p.type, p.displayName);
            properties.push(property);
        });
        var module = new Module(instanceId, this._moduleId, properties, events, presenters);
        return module;
    };

    var espModel = {};
    /************************************ Xml Converter ************************************/
    function parseXML(xml){
        return typeof xml === 'string' ? $.parseXML(xml) : xml;
    }
    function formatXML(xml){
        return new XMLSerializer().serializeToString(xml);
    }
    function ResourceRegister(){
        this._resources = [];
    }
    ResourceRegister.prototype.register = function (url, type) {
        if(!url) return;
        this._resources.push({
            url: url,
            type: type || resolveTypeByUrl(url)
        });
    };
    espModel.xmlConverter = {
        toCoursewareobject: function(identifier, xml){
            try{
                var root = $('coursewareObject',parseXML(xml));
                var pageReferences = [];
                root.find('pages>page').each(function(i){
                    var pr = new PageReference($(this).attr('id'), $(this).attr('href'));
                    pageReferences.push(pr);
                });
                return new Coursewareobject(identifier, pageReferences);
            }catch(e){
                throw ModelExceptions.PARSE_COURSEWAREOBJECT_MAIN.as(identifier, e);
            }
        },
        toPage: function (pageId, xml, referenceUrlResolver) {
            try{
                xml = parseXML(xml);
            }catch(e){
                throw ModelExceptions.PARSE_COURSEWAREOBJECT_PAGE.as(pageId, e);
            }
            var root = $('page',xml);
            var modulePromises = [];
            root.find('modules>module').each(function(i){
                var promise = espModel.repository.module($(this).attr('editorId')).getDefinition().then($.proxy(function(moduleDefinition){
                    try{
                        var el = $(this);
                        var module = moduleDefinition.newModule(el.attr('id'));
                        module.editorId = el.attr('editorId');
                        module.presenterId = el.attr('presenterId');
                        module.position = {
                            left: el.attr('left'),
                            top: el.attr('top')
                        };
                        module.size = {
                            width: el.attr('width'),
                            height: el.attr('height')
                        };
                        module.rotate = el.attr('rotate');
                        module.visible = el.attr('isVisible')!=='false';
                        module.locked = el.attr('isLocked')==='true';
                        module.style = el.attr('style');
                        module.lazyInit = el.attr('lazy-init')==='true';
                        el.find('properties>property').each(function(){
                            var value = TypeDescriptor($(this).attr('type')).read(this, referenceUrlResolver);
                            module.setPropertyValue($(this).attr('name'), value, $(this).attr('type'));
                        });
                        return module;
                    }catch(e){
                        return ModelExceptions.PARSE_COURSEWAREOBJECT_PAGE_MODULE.reject($(this).attr('id'), e);
                    }
                },this));
                modulePromises.push(promise);
            });
            return $.when.apply(null,modulePromises).then(function(){
                var modules = [];
                for(var i=0;i<arguments.length;i++){
                    modules.push(arguments[i]);
                }
                var page = new Page(pageId, modules);
                return page;
            },Exception.fail(ModelExceptions.PARSE_COURSEWAREOBJECT_PAGE, pageId));
        },
        fromPage: function(page, referenceUrlResolver){
            var doc = parseXML('<?xml version="1.0" encoding="UTF-8" ?><page></page>');
            var root = $(doc).find('page');
            root.attr({
                name: page.id,
                layout: 'pixels'
            });
            var presentersEl = root.append('<presenters></presenters>').children('presenters');
            var modulesEl = root.append('<modules></modules>').children('modules');
            var modules = page.modules;
            $.each(modules, function(i,module){
                var presenterEl = presentersEl.append('<presenter></presenter>').children('presenter').last();
                presenterEl.attr('id', module.presenterId);
                var modulePresenterRoot = espEnvironment.url.modulePresenterRoot(module.presenterId);
                if(modulePresenterRoot){
                    presenterEl.attr('href', modulePresenterRoot('dist/main.xml'));
                }
                var moduleEl = modulesEl.append('<module></module>').children('module').last();
                var resourceRegister = new ResourceRegister();
                moduleEl.attr({
                    id: module.id,
                    editorId: module.editorId,
                    presenterId: module.presenterId,
                    left: module.position.left,
                    top: module.position.top,
                    width: module.size.width,
                    height: module.size.height,
                    rotate: module.rotate,
                    isVisible: module.visible,
                    isLocked: module.locked,
                    style: module.style,
                    'lazy-init': module.lazyInit
                });
                var properties = module.properties;
                if(properties.length){
                    var propertiesEl = moduleEl.append('<properties></properties>').children('properties');
                    $.each(properties, function(ii,property){
                        var propertyEl = propertiesEl.append('<property></property>').children('property').last();
                        propertyEl.attr({
                            name: property.name,
                            type: property.type
                        });
                        TypeDescriptor(property.type).write(propertyEl, property.value, referenceUrlResolver, resourceRegister);
                    });
                }
                if(resourceRegister._resources.length){
                    var resourcesEl = moduleEl.append('<resources></resources>').children('resources');
                    $.each(resourceRegister._resources, function(ii,resource){
                        var resourceEl = resourcesEl.append('<resource></resource>').children('resource').last();
                        resourceEl.attr({
                            type: resource.type,
                            href: resource.url
                        });
                    });
                }
            });
            return formatXML(doc);
        },
        toModuleDefinition: function (moduleId, xml) {
            try{
                var root = $('module', parseXML(xml));
                var properties = [], events = [], presenters = [];
                root.find('properties>property').each(function(i){
                    var el = $(this);
                    properties.push({
                        name: el.attr('name'),
                        type: el.attr('type'),
                        displayName: el.attr('displayName')
                    });
                });
                root.find('presenters>presenter').each(function(i){
                    var el = $(this);
                    presenters.push({
                        id: el.attr('id')
                    });
                });
                return new ModuleDefinition(moduleId, properties, events, presenters);
            }catch(e){
                return ModelExceptions.PARSE_MODULE_DEFINITION.reject(moduleId, e);
            }
        }
    };
    /************************************ Repositorys ************************************/
    /************************************ CoursewareobjectTemplateRepository ************************************/
    function CoursewareobjectTemplateRepository(identifier){
        this._identifier = identifier;
        this._urlRoot = espEnvironment.url.coursewareobjectTemplateRoot(identifier);
    }
    CoursewareobjectTemplateRepository.prototype.getResourceUrl = function(path, v1, v2, v3){
        return this._urlRoot(path, v1, v2, v3);
    };
    /************************************ CoursewareobjectRepository ************************************/
    var tempCoursewareobjectIdentifier = '$coursewareobject-temp';
    function CoursewareobjectRepository(identifier){
        this._identifier = identifier;
        this._orginalIdentifier = null;
        this._urlRoot = espEnvironment.url.coursewareobjectRoot(identifier);
    }
    CoursewareobjectRepository.prototype.getResourceUrl = function(path, v1, v2, v3){
        return this._urlRoot(path, v1, v2, v3);
    };
    CoursewareobjectRepository.prototype.getAssetUploadUrl = function(){
        return $.isFunction(espService.coursewareobject.getAssetUploadUrl) ?
            espService.coursewareobject.getAssetUploadUrl(this._identifier) : null;
    };
    CoursewareobjectRepository.prototype.getAssetFileWriter = function(){
        return $.isFunction(espService.coursewareobject.getAssetFileWriter) ?
                    espService.coursewareobject.getAssetFileWriter(this._identifier) : null;
    };
    CoursewareobjectRepository.prototype.listAssets = function(params){
        return espService.coursewareobject.listAssets(this._identifier, params);
    };
    CoursewareobjectRepository.prototype.getMainXml = function(){
        return espService.coursewareobject.getMainXml(this._identifier);
    };
    CoursewareobjectRepository.prototype.updateMainXml = function(xml){
        return espService.coursewareobject.updateMainXml(this._identifier, xml);
    };
    CoursewareobjectRepository.prototype.getPageXml = function(pageId){
        return espService.coursewareobject.getPageXml(this._identifier, pageId);
    };
    CoursewareobjectRepository.prototype.updatePageXml = function(pageId,xml){
        return espService.coursewareobject.updatePageXml(this._identifier, pageId, xml);
    };
    CoursewareobjectRepository.prototype.get = function(){
        return this.getMainXml().then($.proxy(function(xml){
            try{
                return espModel.xmlConverter.toCoursewareobject(this._identifier, xml);
            }catch(e){
                return $.Deferred().reject(e);
            }
        },this));
    };
    CoursewareobjectRepository.prototype.getPage = function(pageId){
        return this.getPageXml(pageId).then($.proxy(function (xml) {
            try{
                return espModel.xmlConverter.toPage(pageId, xml, espEnvironment.createReferenceUrlResolver(this._urlRoot(), 'pages'));
            }catch(e){
                return $.Deferred().reject(e);
            }
        }, this));
    };
    CoursewareobjectRepository.prototype.updatePage = function(page){
        try{
            var xml = espModel.xmlConverter.fromPage(page, espEnvironment.createReferenceUrlResolver(this._urlRoot(), 'pages'));
            return this.updatePageXml(page.id, xml);
        }catch(e){
            return $.Deferred().reject(e);
        }
    };
    CoursewareobjectRepository.prototype.copyAs = function (newIdentifier) {
        newIdentifier = newIdentifier && newIdentifier.replace('{id}', this._orginalIdentifier || this._identifier);
        if(this._identifier === newIdentifier){
            return $.when(newIdentifier);
        }
        return espService.coursewareobject.copyAs(this._identifier, newIdentifier).then($.proxy(function () {
            this._orginalIdentifier = this._identifier;
            this._identifier = newIdentifier;
            this._urlRoot = espEnvironment.url.coursewareobjectRoot(this._identifier);
            return this._identifier;
        }, this));
    };

    /************************************ ModuleRepository ************************************/
    function ModuleRepository(moduleId){
        this._moduleId = moduleId;
        this._urlRoot = espEnvironment.url.moduleEditorRoot(moduleId);
    }
    ModuleRepository.prototype.getDefinitionXml = function(){
        return $.ajax({
            type: 'GET',
            url: this._urlRoot('module.xml'),
            dataType: 'xml'
        }).then(null, Exception.fail(ModelExceptions.GET_MODULE_DEFINITION, this._moduleId));
    };
    ModuleRepository.prototype.getDefinition = function(){
        if(!this._moduleId){
            return $.when(new ModuleDefinition());
        }
        return $.when(this.getDefinitionXml().then($.proxy(function (xml) {
            try{
                return espModel.xmlConverter.toModuleDefinition(this._moduleId, xml);
            }catch(e){
                return $.Deferred().reject(e);
            }
        }, this)));
    };
    /************************************ ModuleEditorRepository ************************************/
    function ModuleEditorRepository(editorId){
        this._editorId = editorId;
        this._urlRoot = espEnvironment.url.moduleEditorRoot(editorId);
    }
    ModuleEditorRepository.prototype.getResourceUrl = function(path, v1, v2, v3){
        return this._urlRoot(path, v1, v2, v3);
    };
    ModuleEditorRepository.prototype.getResource = function(path, v1, v2, v3, type){
        var dataType;
        if(typeof type === 'string'){
            dataType = type;
        }else if(typeof v3 === 'string'){
            dataType = v3;
            v3 = null;
        }else if(typeof v2 === 'string'){
            dataType = v2;
            v2 = v3 = null;
        }else if(typeof v1 === 'string'){
            dataType = v1;
            v1 = v2 = v3 = null;
        }
        return $.get(this._urlRoot(path, v1, v2, v3), dataType);
    };

    {
        var repositories = {
            coursewareobject: {},
            coursewareobjectTemplate: {},
            module: {},
            moduleEditor: {}
        };
        espModel.repository = {
            coursewareobjectTemplate: function (identifier) {
                if(repositories.coursewareobjectTemplate[identifier]){
                    return repositories.coursewareobjectTemplate[identifier];
                }
                return repositories.coursewareobjectTemplate[identifier] = new CoursewareobjectTemplateRepository(identifier);
            },
            coursewareobject: function (identifier) {
                if(repositories.coursewareobject[identifier]){
                    return repositories.coursewareobject[identifier];
                }
                return repositories.coursewareobject[identifier] = new CoursewareobjectRepository(identifier);
            },
            module: function (moduleId) {
                if(repositories.module[moduleId]){
                    return repositories.module[moduleId];
                }
                return repositories.module[moduleId] = new ModuleRepository(moduleId);
            },
            moduleEditor: function (editorId) {
                if(repositories.moduleEditor[editorId]){
                    return repositories.moduleEditor[editorId];
                }
                return repositories.moduleEditor[editorId] = new ModuleEditorRepository(editorId);
            }
        };
    }
    return espModel;
});
