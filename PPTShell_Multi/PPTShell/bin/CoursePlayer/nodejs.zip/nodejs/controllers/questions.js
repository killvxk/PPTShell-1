var path = require('path');
var asset=require('./assets');
var refpathreplacer = require('./question_tools/refpath_replacer');
var templates = require('./questions.template');
var uuid = require('node-uuid');
var openapi = require('./../common/openapi');
var imageSplitter = require('./../common/ImageSplitter');
var fs = require('fs');
var Q = require("q");
var ncp = require('ncp').ncp;
var imageinfo = require('imageinfo');
var pathHelper = require('./question_tools/question_path_helper');


var checkDir = function(path, callback){
    fs.stat(path, function(err,stats){
        if(err){           
            mkdir(path, callback);
        } else{
            callback();
            return;
        }
    });
}
var mkdir = function(path, callback){
    var parentDir = path.substring(0, path.lastIndexOf("/"));
    checkDir(parentDir, function(){
        fs.mkdir(path, 777, callback);
    })
}

var createParam = {
  "question_type": {type: String, required: true},
  "id":{type:String,required:false}
};

function getParamValue(value) {
	if(value!=undefined && value!=null)
		return value;
	return "";
}
var templateFiles = {};
function loadTemplate(filename){
	if(templateFiles[filename]) return templateFiles[filename];
	var templateBase = "app/questions/template/";
	var result = fs.readFileSync(templateBase+filename,"utf-8");
	templateFiles[filename]=result;	
	return result;
}
function replaceByParams(template,params){
	for(var key in params){
		var value = params[key];
		var newTemplate = template.replace("{{"+key+"}}",value);
		while(newTemplate!=template){
			template = newTemplate;
			newTemplate = template.replace("{{"+key+"}}",value);
		}
	}
	return template;
}
function saveToFile(path,data){
    var deferred = Q.defer();		
	var parentDir = path.substring(0, path.lastIndexOf("/"));
	checkDir(parentDir,function(err){        
		fs.writeFile(path, data,function(err){
            if(err){               
                deferred.reject(err);
            }
            else{                
                deferred.resolve();
            }
		});
	});	
    return deferred.promise;
}
var question_types =[
	{code:'$RE0201',category:'objective',name:'choice',label:'单选题',P:true,S:true},
	{code:'$RE0202',category:'objective',name:'multiplechoice',label:'多选题',P:true,S:true},
	{code:'$RE0204',category:'objective',name:'order',label:'排序题',P:true,S:false},
	{code:'$RE0203',category:'objective',name:'judge',label:'判断题',P:true,S:true},
	{code:'$RE0209',category:'objective',name:'textentry',label:'填空题',P:true,S:false},
	{code:'$RE0216',category:'objective',name:'textentrymultiple',label:'填空题',P:false,S:true},
	{code:'$RE0205',category:'objective',name:'match',label:'连线题',P:true,S:false},
	{code:'$RE0206',category:'subjective',name:'extendedtext',label:'问答题',P:true,S:false},
	{code:'$RE0207',category:'objective',name:'graphicgapmatch',label:'拼图题',P:true,S:false},
	{code:'$RE0211',category:'subjective',name:'drawing',label:'作文题',P:true,S:false},
	{code:'$RE0215',category:'objective',name:'gapmatch',label:'分类表格题',P:true,S:false},
	{code:'$RE0217',category:'objective',name:'inlinechoice',label:'文本选择题',P:true,S:false},
	{code:'$RE0210',category:'subjective',name:'handwrite',label:'手写题',P:true,S:false},
	{code:'$RE0445',category:'subjective',name:'nd_handwritequestion',label:'手写题',P:true,S:false},
	{code:'$RE0212',category:'subjective',name:'specialcomplextext',label:'所见即所得填空题',P:true,S:false},
	{code:'$RE0225',category:'objective',name:'vote',label:'投票题',P:true,S:false},
	{code:'$RE0208',category:'compound',name:'data',label:'复合题',P:true,S:false},
	{code:'$RE0213',category:'compound',name:'reading',label:'阅读题',P:true,S:false},
	{code:'$RE0218',category:'compound',name:'comprehensivelearning',label:'综合学习题',P:true,S:false},
	{code:'$RE0219',category:'compound',name:'application',label:'应用题',P:true,S:false},
	{code:'$RE0220',category:'compound',name:'calculation',label:'计算题',P:true,S:false},
	{code:'$RE0223',category:'compound',name:'proof',label:'证明题',P:true,S:false},
	{code:'$RE0221',category:'compound',name:'explain',label:'解答题',P:true,S:false},
	{code:'$RE0222',category:'compound',name:'readingcomprehension',label:'阅读理解题',P:true,S:false},
	{code:'$RE0214',category:'compound',name:'experimentandinquiry',label:'实验与探究题',P:true,S:false},
	{code:'$RE0224',category:'compound',name:'inference',label:'推断题',P:true,S:false},
	{code:'$RE0226',category:'subjective',name:'applicationbase',label:'应用题',P:true,S:false},
	{code:'$RE0227',category:'subjective',name:'proofbase',label:'证明题',P:true,S:false},
	{code:'$RE0228',category:'subjective',name:'calculationbase',label:'计算题',P:true,S:false},
	{code:'$RE0229',category:'subjective',name:'explainbase',label:'解答题',P:true,S:false},
	{code:'$RE0230',category:'subjective',name:'readingbase',label:'阅读题',P:true,S:false},
	{code:'$RE0231',category:'subjective',name:'readingcomprehensionbase',label:'阅读理解题',P:true,S:false},
	{code:'$RE0232',category:'subjective',name:'subjectivebase',label:'主观基础题',P:true,S:false}
];
function getQuestionType(metadata){
	var type = metadata.categories.res_type;
	for(var i=0;i<type.length;i++){
		if(type[i].taxoncode!='$RE0200'){
			for(var j=0;j<question_types.length;j++){
				if(question_types[j].code ==type[i].taxoncode ){
					return question_types[j];
				}
			}
		}
	}
	return {};
}
function formatDate(date){
	return (1900+date.getYear())+""+(1+date.getMonth())+""+date.getDate()+""+date.getHours()+""+date.getMinutes()+""+date.getSeconds();
}
 
function copyDefaultImages(folder){	
    var deferred = Q.defer();	
	checkDir(folder,function(){
		ncp.limit = 16;
		ncp(__dirname + "/../app/questions/template/question_resource",folder+"/resources",function(error){
			if(error){
                deferred.reject(err);
            }
            else{
                deferred.resolve();
            }
		});	
	});	
    return deferred.promise;
}
function createCourseware(questionMetadata,item,req){ 
	var identifier = questionMetadata.identifier;
	var pageId = identifier;
	var template = loadTemplate("courseware/metadata.json");
	var questionType = getQuestionType(questionMetadata);
	var addonId = questionType.name == 'subjectivebase' ? 'Subjectivity':
		(questionType.name=='drawing'?'StudentComposition':'BasicQuestionViewer');
	var params = {
		identifier : identifier,
		date : formatDate(new Date()),//20151216135748,
		page_id:pageId,
		question_id: identifier,
		type_code:questionType.name,
		type_name:questionType.label,
		addonId:addonId
	};
	template = replaceByParams(template,params);
	var metadata = JSON.parse(template);	
	
	var packagePath = pathHelper.getQuestionBase(questionMetadata.identifier,req);
    
	var refPath = pathHelper.getQuestionRefPackagePath(questionMetadata.identifier,req);                 
	//save courseware metadata
	return saveToFile(packagePath+"/metadata.json",JSON.stringify(metadata)).then(function(){
        //save main.xml
        return saveToFile(packagePath+"/main.xml",replaceByParams(loadTemplate("courseware/main.xml"),params)).then(function(){            
            //save main-student.xml
            //return saveToFile(packagePath+"/main-student.xml",replaceByParams(loadTemplate("courseware/main-student.xml"),params)).then(function(){
                //save page.xml
                return saveToFile(packagePath+"/pages/"+pageId+".xml",replaceByParams(loadTemplate("courseware/page.xml"),params)).then(function(){  
                    return copyDefaultImages(refPath).then(function(){                               
                       
                    });                            
                });
            //});
        });
    });
    
}


exports.create = function(req, res, next) {
	var param = openapi.getOpenApiParam(req, createParam);
	if(param.question_type=='nd_handwritequestion'){
		createHandwrite(req).then(function(result){		
			return res.send(result);	
		});
		return;
	}
	var questionInfo = req.body;
	var metadataData = templates.metadatas[param.question_type];
	//console.log(questionInfo);
	metadataData.description = getParamValue(questionInfo.description);
	metadataData.tags = getParamValue(questionInfo.tags);
	metadataData.life_cycle.creator = getParamValue(questionInfo.creator);
	metadataData.life_cycle.status = "CREATED";
	metadataData.life_cycle.provider= getParamValue(questionInfo.provider);
	metadataData.life_cycle.provider_source= getParamValue(questionInfo.provider_source);
	metadataData.life_cycle.create_time= new Date();
	metadataData.life_cycle.last_update= new Date();
	metadataData.education_info.difficulty = getParamValue(questionInfo.difficulty);

	for(var i=0; i<metadataData.coverages.length;i++)//覆盖范围
	{
		metadataData.coverages[i].target = getParamValue(questionInfo.creator);
	}
	for(var i=0; i<metadataData.relations.length;i++)//覆盖关系
	{
		metadataData.relations[i].source = getParamValue(questionInfo.chapter_id);
		metadataData.relations[i].source_title = getParamValue(questionInfo.chapter_name);
	}
	metadataData.categories.source=[];
	metadataData.categories.source.push({"taxoncode": "RF01008"});//题目来源-其它表示本地

	var id = param.id ? param.id : uuid.v4();
	var packagePath = pathHelper.getQuestionBase(id,req);	
	var refPath = pathHelper.getQuestionRefPackagePath(id,req);
	
	//console.log(metadataData);
	if(param.id){
		var exists = fs.existsSync(packagePath);
		if(exists){
			return res.status(500).send({code:"LS/QUESTION_EXIST",message:"习题已存在，无需重复创建。"});
		}
	}
	metadataData.identifier = id;
	metadataData.tech_info.href.location = metadataData.tech_info.href.entry = pathHelper.getQuestionRefPath(id)+"/item.json";
	metadataData.tech_info.nd_href = {format: "application/edu.nd-question-editor",requirements:[]};
	metadataData.tech_info.nd_href.location = metadataData.tech_info.nd_href.entry = pathHelper.getQuestionRefPath(id)+"/main.xml";
	if(!metadataData.custom_properties){
		metadataData.custom_properties = {};
	}
	metadataData.custom_properties.question_type = param.question_type;

	var itemData = templates.items[param.question_type];
	itemData.identifier = id;

    
	createCourseware(metadataData,itemData,req).then(function(){		
		 //save questionMetadata
        return saveToFile(refPath+"/metadata.json",JSON.stringify(metadataData)).then(function(){
            //save item.json
            return saveToFile(refPath+"/item.json",JSON.stringify(itemData)).then(function(){
            	return saveToFile(refPath+"/sdp-package.xml",loadTemplate("courseware/sdp-package.xml")).then(function(){            	
            	});
            });
        });
	}).then(function(){
		return res.send(metadataData);
	});
};



var getParam = {
  "id": {type: String, required: true}
};
exports.get = function(req, res, next) {
	var param = openapi.getOpenApiParam(req, getParam);
	var metadata_path = pathHelper.getQuestionRefPackagePath(param.id,req)+"/metadata.json";	
	
	fs.readFile(metadata_path, function(err, data){
		if(err){
            return res.status(500).send({code:"LS/QUESTION_NOT_FOUND",message:"习题不存在。"});
        }		
		return res.send(JSON.parse(data));
	});
};

exports.save = function(req, res, next) {
	var param = req.body;
	var metadata_path = pathHelper.getQuestionRefPackagePath(param.identifier,req)+"/metadata.json";	
	fs.writeFile(metadata_path, JSON.stringify(param),function(err){
 		if (err) {
            return res.status(500).send({code:"LS/QUESTION_NOT_FOUND",message:"习题不存在。"});
        }  		
	});
	return res.send(param);
};
function imageInfo(imagePath){
	var deferred = Q.defer();	
	fs.readFile(imagePath, function(error, data) {
		if (error){
			deferred.reject(error);
		}else{
			var info = imageinfo(data);
			deferred.resolve(info);
		}
	});
	return deferred.promise;
}
var dealUrl=function(filepath,questionId,req){		    
	var realPath = pathHelper.resolveFilePath(filepath,questionId,req);    
	return path.resolve(realPath);
};

exports.getItem = function(req, res, next) {
	var param = openapi.getOpenApiParam(req, getParam);
	var questionId = param.id;
	var itemdata_path = pathHelper.getQuestionRefPackagePath(param.id,req)+"/item.json";
	
	var resourcesFolder = pathHelper.getQuestionRefPackagePath(param.id,req);
	var copyPromise = Q.when();
	if(!fs.existsSync(resourcesFolder+"/resources/default_audio.png")){
		copyPromise = copyDefaultImages(resourcesFolder);
	}
	copyPromise.then(function(){
		fs.readFile(itemdata_path,'utf-8',function(err, data){
			if(err){
	            return res.status(500).send({code:"LS/QUESTION_NOT_FOUND",message:"习题不存在。"});
	        }
			if(!data){
				return res.send({});
			}
			return refpathreplacer.refPathToRefBase(data,questionId,pathHelper,req).then(function(result){
				var savePromise = result==data ? Q.when() : saveToFile(itemdata_path,result).then(function(){					
					return saveToFile(resourcesFolder+"/sdp-package.xml",loadTemplate("courseware/sdp-package.xml"));
				});
				return savePromise.then(function(){
					data = refpathreplacer.fromRefpath(result,questionId,req);	
					data = JSON.parse(data)
					data.physic_path = path.normalize(pathHelper.getQuestionBase(param.id,req));
					return res.send(data);
				});
			});
			
		});
	}); 
};
var isGraphChange=function(item){
	if(item.graphchange){
		return true;
	}
	return false;
}
var dealData=function(data,id,req){
	var outputPath = pathHelper.getQuestionRefPackagePath(id,req)+"/resources/";	
	var resoucePath= pathHelper.getQuestionRefBase(id)+"/resources/";	
	var blankImg = resoucePath+"background.jpg";
	var deferred = Q.defer();
	var length=0;
	if(data.items){
		data.items.forEach(function(item){
			if(item.type==="graphicgapmatch") {
				if(!item.object||(item.object&&!item.object.data)){
					length++;
					if(data.items.length===length){
						deferred.resolve(data);
					}
					return;
				}
                if(!isGraphChange(item)){
                    console.log("graph not change");
                    length++;
                    if(data.items.length===length){
						deferred.resolve(data);
					}
					return;
                }
				var params= {};
				params["rows"]=item.rows;
				params["columns"]=item.columns;
				params["blankImage"]=blankImg;
				params["originalImage"]=item.object.data;
				
				item.object.params=params;                  
				var imagePath = dealUrl(item.object.data,id,req);
				imageInfo(imagePath).then(function(file){
					item.object.width= file.width;
					item.object.height= file.height;
					imageSplitter.split(imagePath,item.rows,item.columns, outputPath).then(function (items) {
						var gap_imgs=[];
						var hot_imgs=[];
						var corrects=[];
						for (var row = 0; row < item.rows; row++) {
							var rows = items[row];
							for (var column = 0; column < item.columns; column++) {
								var image = rows[column];                                
								var path=resoucePath+image.fileName;                                
								var gap_id="GAP_"+(row+1)+"_"+(column+1);
								var hot_id="HOTSPOT_"+(row+1)+"_"+(column+1);
								gap_imgs.push({
									"type":"",
									"width":Math.round(image.width),
									"height":Math.round(image.height),
									"data":path,
									"identifier":gap_id,
									"text":gap_id
								});
								hot_imgs.push({
									"identifier":hot_id,
									"shape":"rect",
									"coords":Math.round(image.left)+","
										+Math.round(image.top)+","
										+Math.round(image.right)+","
										+Math.round(image.bottom)
								});								
								corrects.push(gap_id+" "+hot_id);
							}
						}
						item.gap_imgs=gap_imgs;
						item.associable_hotspots=hot_imgs;
						if(data.responses){
							for (var index = 0; index < data.responses.length; index++) {
								if (item.response_identifier === data.responses[index].identifier) {
									data.responses[index].corrects = corrects;
									break;
								}
							}
						}

						length++;
						if(data.items.length===length){
							deferred.resolve(data);
						}
					},function(){
						length++;
						if(data.items.length===length){
							deferred.resolve(data);
						}
					});
				},function(){
					item.object.width= 0;
					item.object.height= 0;
					length++;
					if(data.items.length===length) {
						deferred.resolve(data);
					}
				});
			}else{
				length++;
				if(data.items.length===length){
					deferred.resolve(data);
				}
			}
		});
	}
	else{
		deferred.resolve(data);
	}
	return deferred.promise;
}
exports.saveItem = function(req, res, next) {
	var param = req.body;	
    var identifier = openapi.getOpenApiParam(req, getParam).id;
    param.identifier = identifier;
	var itemdata_path = pathHelper.getQuestionRefPackagePath(identifier,req) + "/item.json";
	var use_data=param;
    storeRemotFile(param,identifier,req,function(formatData){        
        dealData(formatData,identifier,req).then(function(data){            
            param = JSON.stringify(data);            
            param = refpathreplacer.toRefpath(param,identifier);           
            fs.writeFile(itemdata_path,param ,function(err){                
                if (err){
                     return res.status(500).send({code:"LS/QUESTION_SAVED_ERROR",message:"习题保存失败。"});
                }
                var item = JSON.parse(param);
                if(item.items.length>0){
                	var prompt = item.items[0].prompt;                
                	var metadata_path = pathHelper.getQuestionRefPackagePath(identifier,req) + "/metadata.json";                	
                	fs.readFile(metadata_path,'utf-8',function(err, data){                		                		                        
                		var metadata = JSON.parse(data);
                		metadata.description = prompt;
                		if(metadata.life_cycle&&metadata.life_cycle.status=="CREATING"){
                			metadata.life_cycle.status = "CREATED";
                		}
                		fs.writeFile(metadata_path, JSON.stringify(metadata),function(err){	                			                            
	                	});
                	});
                	
                }
            });             
            return res.send(data);
        });
    });
}; 

exports.getHandwrite = function(req, res, next) {	
	var id = req.params.id;
	
	var basePath = pathHelper.getInteractionRefBase(id,req);
	var pagepath = pathHelper.getInteractionBase(id,req)+"/pages/"+id+".xml";
	var refpath = "";
	fs.readFile(pagepath,function(err,data){
		if(err){
			return res.status(500).send({code:"LS/QUESTION_NOT_FOUND",message:"习题不存在。"});			
		}
		var text =data.toString();
		
		var index = text.indexOf("<property name='text' type='html'>");		
		index = text.indexOf("<![CDATA[",index||0);		
		if(index!=-1){
			var next = text.indexOf("]]>",index);		
			text =text.substring(index+'<![CDATA['.length,next);
		}
		data = {content:text,location:basePath+"/main.xml"};		 
		data.physic_path =  path.normalize(pathHelper.getInteractionBase(id,req)); 
		return res.send(data);
	});
	
}
exports.qtiplayer = function(req,res,next){ 
	var suffix = "&hidePage=toolbar&_lang_=zh_CN&hidePage=footer";
	var id = req.params.id;
	var base = req.param('question_base');
	if(base){
		
		var player = //"/player/index.html?main=file:///"+pathHelper.getQuestionBase(id,req)+"/main.xml"; 
		"file:///"+__dirname+"/../app/player/index.html?main=file:///"+pathHelper.getQuestionBase(id,req)+"/main.xml"+suffix;
		return res.send({url:player});/*
		var baseFolder = pathHelper.getPlayerBase(id,req);
		var encodeBaseFolder = new Buffer(baseFolder).toString('base64');
		var main = encodeURIComponent("/v1.3/assets/proxy3/" +encodeBaseFolder+"/main.xml");
		return res.send({url:"/player/index.html?main="+main});*/
	}
	//var main = encodeURIComponent("/v1.3/assets/proxy3?file=/main.xml&base="+pathHelper.getPlayerBase(id,req));
	return res.send({url:"/player/index.html?main="+pathHelper.getQuestionRefPath(id,req).replace('${ref-path}','/userdatas')+"/main.xml"+suffix});
		
}
exports.saveHandwrite = function(req, res, next) {
	var id = req.params.id;
	var content = req.body.content;
	var handwriteparams ={
        question_id:id,
        question_prompt: content
    };
	var path = pathHelper.getInteractionBase(id,req);
	return saveToFile(path+"/pages/"+id+".xml",replaceByParams(loadTemplate("handwrite/page.xml"),handwriteparams)).then(function(){
    	return res.send({content:content});
	});
}
function createHandwrite(req){
	var identifier = uuid.v4();
	var questionInfo = req.body;
	var templatemetadata = loadTemplate("handwrite/metadata.json");
    var mainurl = pathHelper.getInteractionRefBase(identifier,req);
	var params = {
		chapter_id: questionInfo.chapter_id,
		creator: questionInfo.creator,
		create_time: formatDate(new Date()),//20151216135748,
		identifier : identifier,
		page_id : identifier,
		question_type:'nd_handwritequestion',
        mainurl:mainurl
	};
	templatemetadata = replaceByParams(templatemetadata,params);
	var metadata = JSON.parse(templatemetadata);
	if(!questionInfo.chapter_id){
		metadata.relations = [];
	}; 	
	metadata.page_id = "page";
	var path = pathHelper.getInteractionBase(identifier,req)
	return saveToFile(path+"/metadata.json",JSON.stringify(metadata)).then(function(){
		 //save main.xml
        return saveToFile(path+"/main.xml",replaceByParams(loadTemplate("courseware/main.xml"),params)).then(function(){            
            //save main-student.xml
            //return saveToFile(path+"/main-student.xml",replaceByParams(loadTemplate("courseware/main-student.xml"),metadata)).then(function(){
            	return saveToFile(path+"/sdp-package.xml",replaceByParams(loadTemplate("courseware/sdp-package.xml"),metadata)).then(function(){
            		 //save page.xml
	            	 var handwriteparams ={
				        question_id:identifier,
				        question_prompt: ''
				    };
	                return saveToFile(path+"/pages/"+identifier+".xml",replaceByParams(loadTemplate("handwrite/page.xml"),handwriteparams)).then(function(){
	                	return saveToFile(path+"/sdp-package.xml",loadTemplate("courseware/sdp-package.xml")).then(function(){
	                		return metadata;
	                	});
	                });
            	});               
            //});
        });
	});	
} 
 

function isHandwrite(data){
    if(data.items){
		for(var i=0;i<data.items.length;i++){
            var item =data.items[i];
            if(item.type==="handwrite") {
                return true;
            }
        }
    }
    return false;
            
}
    
var checkFile = function(question_id,path,url,assetType,req){
    var deferred = Q.defer();
    asset.check_proxy(question_id,path,url,assetType,req,function(){
        deferred.resolve();
    }); 
	return deferred.promise;    
}
var storeRemotFile=function(data,identifier,req,callback){    
    var strData = JSON.stringify(data);
    var saveFiles = [];    
    strData = strData.replace(/\/v1.3\/assets\/proxy\?(.*?)filepath=(.*?)end=true/gi,function(str,none,param){    
        var strs = param.split("&");
        if(strs&&strs.length>=3){
            var path = decodeURIComponent(strs[0]);
            var url = strs[1].indexOf("=")!=-1 ? strs[1].substring(strs[1].indexOf("=")+1):strs[1];            
            var assetType=strs[1].indexOf("=")!=-1 ? strs[1].substring(strs[1].indexOf("=")+1):strs[1];   
            url = decodeURIComponent(url);
            saveFiles.push({path:path,url:url,assetType:assetType});
            var REFPATH = "${ref-base}";
            return path.indexOf(REFPATH)==0 ? path : REFPATH+path;
        }
        else{
            str;
        }
        return "";
    });    
    var all = [];
    for(var i=0;i<saveFiles.length;i++){
        all.push(checkFile(identifier,saveFiles[i].path,saveFiles[i].url,saveFiles[i].assetType,req));
    }
    Q.all(all).then(function(){
        callback(JSON.parse(strData));
    });
}
