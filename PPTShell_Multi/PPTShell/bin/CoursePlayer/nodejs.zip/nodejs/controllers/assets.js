var http = require('http');
var util = require('util');
var uuid = require('node-uuid');
var fs = require('fs');
var path = require('path');
var sizeOf = require('image-size');
var pathHelper = require('./question_tools/question_path_helper');
var Q = require("q");

var getQuestionBase = function(identifier){
	return "edu/esp/questions";
}
function getQuestionPackagePath(identifier,req){
	return pathHelper.getQuestionRefPackagePath(identifier,req);
}


var convertBaiduImageToLocalImage = function(questionId,questionBase,baiduItems){
    var items = [];
    var baseid ="bd_"+new Date().getTime();
    for(var i=0;i<baiduItems.length;i++){
        var id = baseid+""+i;
        var item = baiduItems[i];        
        var filepath = "/resources/"+id+"."+item.Pictype;
        var url = '/v1.3/assets/proxy?'+questionBase+'question_id='+questionId+'&filepath='+encodeURIComponent(filepath)+"&url="+encodeURIComponent(item.ObjUrl)+"&end=true";
        items.push({
            identifier:id,
            title:item.Desc,
            tech_info:{
                href:{
                    format:'',
                    location:url,
                    requirements:[{
                        type:'QUOTA',
                        name:'resolution',
                        value:item.Width+'*'+item.Height
                    }]
                }
            },
            preview:{
                 '240':"/v1.3/assets/proxy2?url="+encodeURIComponent(item.ObjUrl)
            },
            type:'$RA0101'
        });
    };
    return items;
};

var checkDir = function(path, callback){
    fs.stat(path, function(err,stats){
        if(err){
            mkdir(path, callback);
        } else{
            callback();
            return;
        }
    });
}
var mkdir = function(path, callback){
    var parentDir = path.substring(0, path.lastIndexOf("/"));
    checkDir(parentDir, function(){
        fs.mkdir(path, 777, callback);
    });
}

exports.search = function(req, res, next) {
	var questionBase = '';
	var question_base_param = req.param('question_base');
	if(question_base_param){
		questionBase = "question_base="+encodeURIComponent(question_base_param)+"&";
	}
	var coverage = req.query.coverage;
    var assettype = req.query.type;
    var id = req.query.question_id;
    //个人库
	if(coverage.indexOf("User")!=-1){        
        var localPath = getQuestionPackagePath(id,req);	
        var folder = localPath+"/resources/";        
        var assetBasePath = pathHelper.getQuestionRefBase(id)+"/resources/";
        var types = {
        	jpg:{code:'$RA0101',minetype:''},
        	jpeg:{code:'$RA0101',minetype:''},
        	gif:{code:'$RA0101',minetype:''},
        	png:{code:'$RA0101',minetype:''},
        	bmp:{code:'$RA0101',minetype:''},
        	mp4:{code:'$RA0103',minetype:''},
        	mp3:{code:'$RA0102',minetype:''}        	
        };     
        mkdir(folder,function(){          
            var items = [];
            var files = fs.readdirSync(folder);            
            for(var i=0;i<files.length;i++){
                if(files[i].indexOf(".")==-1){
                    continue;
                }
                var href = assetBasePath+files[i];
                var assetId = files[i].substring(0,files[i].lastIndexOf(".")-1);               
                var suffix = files[i].substring(files[i].lastIndexOf(".")+1);
                var type = types[suffix.toLowerCase()];
                if(['audio.png','background.jpg','default_audio.png','default_video.png','image.png','papertype_1.png'
                    ,'papertype_2.png','papertype_3.png','papertype_4.png','papertype_5.png','video.png'].indexOf(files[i])!=-1){
                	continue;
                }
                if(files[i].indexOf("sf-")==0){
                	continue;
                }
		        if(type&&type.code==assettype){
		        	var data = {
				        identifier: assetId,
				        title: assetId+"."+suffix,
				        tech_info : {
				            href : {
				                "format" : type.mimetype,
				                "location":href,
				                requirements:[{
				                    type:"QUOTA",
				                    name:"resolution"
				                }]
				            }
				        },
				        type:type.code
				    };
				    if(type.code == '$RA0101'){
				        //var dimensions =  sizeOf(file.path);
				        var dimensions =  sizeOf(folder+files[i]);			
				        data.tech_info.href.requirements[0].value =dimensions.width+"*"+dimensions.height; 
				    }   
				    items.push(data);
		        }       
            }
            res.send({
                items:items
            });
        });
	}
    //公共库
	else if(coverage.indexOf("Org/nd")!=-1){
        var server = req.query.slideServer;
        var csserver = req.query.csserver;
        if(server&&server.indexOf("//")!=-1){
            server = server.substring(server.indexOf("//")+2);
        }
        if(server&&server.lastIndexOf("/")!=-1){
            server = server.substring(0,server.lastIndexOf("/"));
        }
        var url = "/v1.3/assets?type="+req.query.type+"&coverage=Org/nd/OWNER"
            +"&page="+(req.query.page||1)
            +"&size="+(req.query.size||24)
            +"&chapter_id="+(req.query.chapter_id||'')
            +"&words="+encodeURIComponent(req.query.words||'');
        http.get({
                host:server,
                path:url,
                headers: {                   
                }                
            },function(result){             
                var body = "";
                result.on("data", function(chunk) {
                    body = body +chunk;
                });
                result.on("end",function(){
                    try{                        
                        var response = JSON.parse(body);
                        if(response.code){                           
                            return res.status(500).send({code:response.code,message:response.message});
                        }
                        var items = response.items;
                        var baseid ="nd_"+new Date().getTime();
                        for(var i=0;i<items.length;i++){
                            var item = items[i];                            
                            var href = item.tech_info.href.location;
                            href = href.replace("${ref-path}",csserver);
                            var previews = item.preview;
                            var assetid = baseid+""+i;
                            var suffix = href.substring(href.lastIndexOf(".")+1);
                            var filepath = "/resources/"+assetid+"."+suffix;
                            if(!previews || previews.length == 0 ){
                                item.preview = {
                                    "240":href,
                                    "media":href
                                }
                            }
                            else{
                                for(var key in previews){
                                    previews[key]= previews[key].replace("${ref-path}",csserver);
                                }
                                //previews['media']=href
                            }                           
                            item.tech_info.href.location = '/v1.3/assets/proxy?'+questionBase+'question_id='+id+'&filepath='+encodeURIComponent(filepath)+"&url="+encodeURIComponent(href)+"&assetType="+req.query.type+"&end=true";;
                        }
                        return res.send(response);
                        //handle items ....
                    }
                    catch(ex){                        
                        res.status(500).send({code:'LS/JSON_PARSE_FAIL',message:'请求返回的数据格式错误。'});
                    }     
                });           
            });            
    }
    //百度图库
    else if(coverage.indexOf("Baidu/bd/")!=-1&&assettype=="$RA0101"){
        if(req.query.words==''){
            return res.send({items:[]});	
        }
        var pageNumber = (req.query.page||1) -1;
        var baiduurl = "/image_search/search/search?word="+encodeURIComponent(req.query.words||'')+"&pn="+pageNumber+"&rn="+(req.query.size||24)+"&assetType=$RA0101&ie=utf-8";        
        http.get({
                host:'apis.baidu.com',
                path:baiduurl,
                headers: {
                    apikey:'de4eb4b4a1ae4e1c529b0774f931d1f8'
                }              
            },function(result){ 
                var body = "";
                result.on("data", function(chunk) {
                    body = body +chunk;
                });
                result.on("end",function(){                   
                    var response = JSON.parse(body);
                    var code = response.status.code;
                    if(code!='0'){
                        return res.status(500).send({code:code,message:response.status.msg});                        
                    }
                    var itemCount = response.data.ReturnNumber;
                    var total = response.data.TotalNumber;
                    var items = convertBaiduImageToLocalImage(id,questionBase,response.data.ResultArray);
                    return res.send({
                        item_count:itemCount,
                        total_count:total,
                        items:items
                    });
                });
            });
    }
    else{
        return res.send({items:[]});	
    }
};
exports.get=function(req,res,next){ 
	var refPath= __dirname + "/../app/userdatas/";
	var filepath = req.query.filepath;
	var question_id = req.query.question_id; 
	if(!question_id){
		return res.status(400).send({code:"LS/MISSING_QUESTION_ID",message:"参数不正确，缺少习题ID。"});
	}	
    if(filepath&&filepath.indexOf("?")!=-1){
        filepath = filepath.substring(0,filepath.indexOf("?"));
    }
	var realPath = pathHelper.resolveFilePath(filepath,question_id,req);		
	return res.sendFile(path.resolve(realPath));
}
exports.check_proxy= function(questionId,filepath,url,assetType,req,callback){
    handleProxyFile(questionId,filepath,url,assetType,req,callback);
}
exports.proxy2=function(req,res,next){ 	
    var url = req.query.url;
    var request = http.get(url, function(response) {
        response.pipe(res); 
    }).end();
}

exports.proxy3=function(req,res,next){ 	
    var url = req.params[0];
    var base = req.params.base;
    console.log("before decode ",base);
    base = new Buffer(base, 'base64').toString('ascii')
    if(base.indexOf('?')!=-1){
    	base = base.substring(0,base.indexOf("?"));
    }
    console.log("real url ",base,url);
    res.sendFile(path.resolve(base,url));
}


exports.proxy=function(req,res,next){ 
	var questionId = req.query.question_id;
	var filepath = req.query.filepath;
    var url = req.query.url;
    var assetType = req.query.assetType;
    handleProxyFile(questionId,filepath,url,assetType,req,function(realPath){
         return res.sendFile(path.resolve(realPath));
    });
}
var handleProxyFile = function(question_id,filepath,url,assetType,req,callback){
    var refPath= __dirname + "/../app/userdatas/";    
    if(filepath&&filepath.indexOf("?")!=-1){
        filepath = filepath.substring(0,filepath.indexOf("?"));
    }
    var filename = filepath.substring(filepath.lastIndexOf("/")+1);
    var assetId = filename.substring(0,filename.lastIndexOf("."));
	var realPath = pathHelper.resolveFilePath(filepath,question_id,req);
    if(!fs.existsSync(realPath)){
        //download file to location     
        var file = fs.createWriteStream(realPath);
        var request = http.get(url, function(response) {
            var mimetype = response.headers['content-type'];
            if(mimetype){
                mimetype = mimetype.trim();
            }            
            response.pipe(file);            
            file.on('finish', function() {            	 
                file.close(function(){                    
                    return callback(realPath);
                });
            });
        });
        request.on('error',function(err){        	
        });
        request.end();
    }
    else{
        return callback(realPath);
    }
}

function saveMetadata(assetId,questionId,filename,mimetype,asset_type,req){
    var assetBasePath = pathHelper.getQuestionRefBase(questionId);
    var localPath = getQuestionPackagePath(questionId,req);	
	var folder = localPath+"/resources/";
    var suffix = filename.substring(filename.lastIndexOf("."));
	var path = "/resources/"+assetId+suffix;	   
    var href = assetBasePath+path;		
    var data = {
        identifier: assetId,
        title: filename,
        tech_info : {
            href : {
                "format" : mimetype,
                "location":href,
                requirements:[{
                    type:"QUOTA",
                    name:"resolution"
                }]
            }
        },
        type:asset_type
    };	
    if(asset_type == '$RA0101'){
        //var dimensions =  sizeOf(file.path);
        var dimensions =  sizeOf(localPath+path);			
        data.tech_info.href.requirements[0].value =dimensions.width+"*"+dimensions.height; 
    }   
    return data;
}

var renameFile = function(source,target){
	var defer = Q.defer();
	var readStream = fs.createReadStream(source)
	var writeStream = fs.createWriteStream(target);
	readStream.pipe(writeStream).on('finish', function(err) {		
		if(err){
			defer.reject("保存文件错误",err);
			return;
		}		
	    fs.unlinkSync(source);	    
	    defer.resolve();
	});
	return defer.promise;
}
exports.upload = function(req, res, next) {	
	var file = req.file;  
	var id = req.query.question_id;
	var type = req.query.asset_type;
	var tempId = new Date().getTime()+""+Math.floor(Math.random()*100);
	var assetBasePath = "${ref-path}/"+getQuestionBase(id)+"/"+id+".pkg";
	var suffix = file.originalname.substring(file.originalname.lastIndexOf("."));
	var prefix = file.originalname.substring(0,file.originalname.lastIndexOf("."));	
	
	var localPath = getQuestionPackagePath(id,req);	
	var folder = localPath+"/resources/";
	var path = "/resources/"+tempId+suffix;
	mkdir(folder,function(){
		renameFile(file.path, localPath+path).then(function(){
			var data = saveMetadata(tempId,id,file.originalname,file.mimetype,req.query.asset_type,req);			
			res.send(data);			
		});        	
	});
	return;
}; 



