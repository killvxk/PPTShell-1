var refbase = "${ref-base}";
var fs = require("fs");
var Q = require("q");
exports.toRefpath = function(data,questionId){
	data = data.replace(/\/v1\.3\/assets\/get\?(.*?)filepath=(.*?)['|"|\\|>]/gi,function(str){
		var prefix = "filepath=";
		var index = str.indexOf(prefix);
		str = str.substring(index+prefix.length);
		return refbase+str;
	});
	//handle last one 
	data = data.replace(/\/v1\.3\/assets\/get\?(.*?)filepath=(.*?)/gi,function(str){
		var prefix = "filepath=";
		var index = str.indexOf(prefix);
		str = str.substring(index+prefix.length);
		return refbase+str;
	});
    return data;
}
exports.fromRefpath = function(data,questionId,req){	
	var base = req.param('question_base');
	var baseparam = base ? '&question_base='+base:'';
	var newParam =data.replace(refbase,"/v1.3/assets/get?question_id="+questionId+baseparam+"&filepath=");
	while(newParam!=data){
		data = newParam;
		newParam = data.replace(refbase,"/v1.3/assets/get?question_id="+questionId+baseparam+"&filepath=");
	}
	return data;
}
var createMoveFile = function(filepath,namePrefix){
	var prefix = "${ref-path}";
	var index = filepath.indexOf(prefix);
	var filename = filepath.substring(filepath.lastIndexOf("/")+1);
	str = filepath.substring(index+prefix.length);
	var lastchar = str.substring(str.length-1);
	if(lastchar == '"'||lastchar=="/"||lastchar=="'"||lastchar=="\\"||lastchar==">"){
		str = str.substring(0,str.length-1);
	}
	return {
		source: str,
		target: namePrefix+"_"+filename
	};
}

var formtFilePath = function(url){
	if(url.indexOf("?")!=-1){
		url = url.substring(0,url.indexOf("?"));
	}
	return url;
}

var moveOneFile = function(source,target,questionId,pathHelper,req){
	var defer = Q.defer();
	var base = pathHelper.getQuestionBase(questionId,req); 
	var sourcePath = base+"/_ref"+source;
	var lastchar = target.substring(target.length-1);	 
	if(lastchar == '"'||lastchar=="/"||lastchar=="'"||lastchar=="\\"||lastchar==">"){		
		target = target.substring(0,target.length-1);
	}	
	var targetPath = base+"/resources/"+target;
	var readStream = fs.createReadStream(formtFilePath(sourcePath))
	var writeStream = fs.createWriteStream(formtFilePath(targetPath));
	readStream.pipe(writeStream).on('finish', function(err) {		
		if(err){
			defer.reject("保存文件错误",err);
			return;
		}		
	    try{
	    	fs.unlinkSync(sourcePath);	    
	    }
	    catch(ex){};
	    defer.resolve();
	});
	return defer.promise;
}
exports.refPathToRefBase = function(data,questionId,pathHelper,req){ 	
	var waitMove = [];
	var prefix = new Date().getTime();
	var count = 1;
	data = data.replace(/\$\{ref-path\}(.*?)['|"|\\|>]/gi,function(str){
		var localResourceFolder = questionId+".pkg/";
		if(str.indexOf(localResourceFolder)!=-1){
			return refbase+"/"+str.substring(str.lastIndexOf(localResourceFolder)+localResourceFolder.length);
		}
		var item = createMoveFile(str,prefix+"_"+count)
		waitMove.push(item);
		count++;
		return refbase+"/resources/"+item.target;
	});
	//handle last one 
	data = data.replace(/\$\{ref-path\}(.*?)/gi,function(str){		
		var localResourceFolder = questionId+".pkg/";
		if(str.indexOf(localResourceFolder)!=-1){
			return refbase+"/"+str.substring(str.lastIndexOf(localResourceFolder)+localResourceFolder.length);
		}
		var item = createMoveFile(str,prefix+"_"+count)
		waitMove.push(item);
		count++;
		return refbase+"/resources/"+item.target;
	});
	var all = [];
    for(var i=0;i<waitMove.length;i++){
       console.log("move file ",waitMove[i].source,waitMove[i].target,questionId);
       all.push(moveOneFile(waitMove[i].source,waitMove[i].target,questionId,pathHelper,req)); 
    }
    return Q.all(all).then(function(){
    	return data;
    });
}