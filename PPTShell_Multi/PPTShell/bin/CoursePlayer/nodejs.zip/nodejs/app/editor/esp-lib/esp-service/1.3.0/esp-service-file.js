/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
    'jquery',
    'espEnvironment',
    'espService/../esp-service-exceptions'
], function (
    $,
    espEnvironment,
    EspExceptions
) {
    var fileService = {};
    fileService.coursewareobject = {
        create: function (coursewareObject) {
            return EspExceptions.NOT_SUPPORT_OPERATION.reject();
        },
        createByTemplate: function (templateCode) {
            return EspExceptions.NOT_SUPPORT_OPERATION.reject();
        },
        get: function (coursewareObjectId) {
            return $.ajax({
                type: 'GET',
                url: espEnvironment.url.coursewareobjectRoot(coursewareObjectId)('/metadata.json'),
                dataType: 'json'
            }).then(null, EspExceptions.GET_COURSEWAREOBJECT.asFail(coursewareObjectId));
        },
        getMainXml: function (coursewareObjectId) {
            return $.ajax({
                type: 'GET',
                url: espEnvironment.url.coursewareobjectRoot(coursewareObjectId)('/main.xml')
            }).then(null, EspExceptions.GET_COURSEWAREOBJECT_MAIN_XML.asFail(coursewareObjectId));
        },
        updateMainXml: function (coursewareObjectId, mainXml) {
            return EspExceptions.NOT_SUPPORT_OPERATION.reject();
        },
        getPageXml: function (coursewareObjectId, pageId) {
            return $.ajax({
                type: 'GET',
                url: espEnvironment.url.coursewareobjectRoot(coursewareObjectId)('/pages/{0}.xml', pageId)
            }).then(null, EspExceptions.GET_COURSEWAREOBJECT_PAGE_XML.asFail(pageId));
        },
        createPageXml: function (coursewareObjectId, pageXml) {
            return EspExceptions.NOT_SUPPORT_OPERATION.reject();
        },
        updatePageXml: function (coursewareObjectId, pageId, pageXml) {
            return EspExceptions.NOT_SUPPORT_OPERATION.reject();
        },
        copyAs: function (coursewareObjectId, newCoursewareObjectId) {
            return EspExceptions.NOT_SUPPORT_OPERATION.reject();
        },
        getAssetFileWriter: function (coursewareObjectId) {
            return null;
        },
        listAssets: function (coursewareObjectId) {
            return EspExceptions.NOT_SUPPORT_OPERATION.reject();
        }
    };
    fileService.asset = {
        list: function (params) {
            return EspExceptions.NOT_SUPPORT_OPERATION.reject();
        },
        getUploadUrl: function (){
            return '/';
        }
    };

    return fileService;
});
