define(['jquery'],function($){
	var tempates = {
		button:'<div class="slides-toolbar-button"><span></span><img/></div>'
	};
	function ToolbarView(bundleContext){
		this.name = 'workbench.ToolbarView';
		this.title = 'Toolbar';

		var buttonDefs = [];
		this.registerButton = function(buttonDef){
			if($.isArray(buttonDef)){
				for(var i=0;i<buttonDef.length;i++){
					this.registerButton(buttonDef[i]);
				}
			}else{
				if($.isFunction(buttonDef)){
					buttonDef = new buttonDef();
				}
				buttonDefs.push(buttonDef||{});
			}
		};

		this.render = function(view){
			var el = $(view.getElement());
			for(var i=0;i<buttonDefs.length;i++){
				var def = buttonDefs[i];
				var buttonEl = $(tempates.button).appendTo(el);
				buttonEl.children('span').text(def.label||'');
				buttonEl.children('img').attr('src',def.icon);
				buttonEl.on('click',$.proxy(function(){
					view.getWorkbench().executeAction(this.action);
				},def));
			}
		};
	};
	return ToolbarView;
});