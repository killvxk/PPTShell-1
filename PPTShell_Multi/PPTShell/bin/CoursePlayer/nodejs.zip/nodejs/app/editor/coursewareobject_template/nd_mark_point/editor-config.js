/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
    'jquery'
], function (
    $
) {
    return {
        editorType: 'interactionQ',
        editorVersions: [
            {id: 'Background', version: '1.0.0'},
            {id: 'GameQuestionTimer', version: '1.0.0'},
            {id: 'GameQuestionSubmit', version: '1.0.0'},
            {id: 'MarkPoint', version: '1.0.0'},
        ],
        tools:['skin',{
            name: 'description',
            title: '标点题型描述',
            content: '1.本题型适用于语文学科，主要应用于学生对于标点符号的学习。<br>2.本题型自动识别文本中的标点符号，用户可将需要考察学生的标点符号设为选项，也可一键将所有标点符号设为选项。<br>3.本题型支持添加干扰项，选项及干扰项皆不限制数量。<br>4.学生答题时，可将正确选项拖动到文本中的对应位置或在文本的标点位置点选正确的选项完成答题。'
        },'time','preview','save','insert']
    };
});
