define([], function () {
var templates = {};

templates["template.html"] = "<div class=\"GameQuestionTimer_container\">\n" +
   "	<div class=\"com_lay_header\">\n" +
   "        <div class=\"com_u_timebox\"> \n" +
   "            <span class=\"time_1 GameQuestionTimer_minute\" ></span>\n" +
   "            <span class=\"time_2\">:</span> \n" +
   "            <span class=\"time_1 GameQuestionTimer_second\"></span>\n" +
   "        </div>\n" +
   "    </div> \n" +
   "</div> \n" +
   "\n" +
   "";
return templates;});