/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
    './Customization',
    'espService',
    'espModel',
    'prompter'
],function(
    Customization,
    espService,
    espModel,
    prompter
){
    function getQueryParam(name){
        var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
        var r = window.location.search.substr(1).match(reg);
        return (r && decodeURIComponent(r[2])) || '';
    }
    return {
        requires:['nd.esp.coursewareobject','nd.esp.resource'],
        activator : function(bundleContext){
        },
        extensions :  [{
            targetBundle:'workbench',
            point:'event',
            config:{
                afterBootstrap:function(workbench){
                    var identifier = getQueryParam('id'), template = getQueryParam('template');
                    if(identifier){
                        espService.coursewareobject.get(identifier).then(function (coursewareobjectMetadata) {
                            Customization.process(workbench, coursewareobjectMetadata);
                        },prompter.errorIf());
                    }else if(template){
                        espService.coursewareobject.createByTemplate(template).then(function (coursewareobjectMetadata) {
                            window.location.search = 'id=' + coursewareobjectMetadata.identifier + '&interaction';
                        },prompter.errorIf()).always(prompter.wait('正在创建颗粒'));
                    }else{
                        prompter.error('未指定颗粒ID，请在地址栏上添加参数：id');
                    }
                }
            }
        }]
    };
});