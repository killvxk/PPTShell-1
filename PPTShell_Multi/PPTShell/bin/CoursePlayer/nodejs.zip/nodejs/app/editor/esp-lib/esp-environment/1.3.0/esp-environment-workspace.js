/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
], function (
) {
    var reg = new RegExp("(^|&)workspace=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    var workspace = (r && decodeURIComponent(r[2])) || null;
    if(workspace){
        return {
            writeMode: 'no',
            service: 'http',
            serviceConfig: {
                server: workspace
            },
            coursewareobjectPreview: workspace + '/index.html?type=coursewareobject&ref-path=/cs&main=/coursewareobject/{id}.pkg/main.xml',
            modulePresenterRoot: '/presenters/{id}',
            coursewareobjectTemplateRoot: workspace + '/coursewareobject_template/{id}',
            coursewareobjectRoot: workspace + '/coursewareobject/{id}.pkg',
            moduleEditorRoot: workspace + '/modules/{id}',
            referencePath: workspace + '/cs',
            "supports": {
                "asset": false
            }
        };
    }else{
        return false;
    }
});