/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
    'jquery',
    'espService',
    'espModel',
    'prompter'
],function(
    $,
    espService,
    espModel,
    prompter
){
    return function(config, workbench, coursewareobjectMetadata){
        prompter.error('标准颗粒编辑器正在开发中...');
    };
});