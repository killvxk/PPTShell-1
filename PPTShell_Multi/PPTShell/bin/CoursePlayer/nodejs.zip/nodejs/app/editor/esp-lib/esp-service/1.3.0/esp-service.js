/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
    'jquery',
    'espEnvironment',
    'espService/../esp-service-http',
    'espService/../esp-service-file',
    'espService/../esp-service-node'
], function (
    $,
    espEnvironment,
    EspServiceHttp,
    EspServiceFile,
    EspServiceNode
) {
    var services = {
        http: EspServiceHttp,
        file: EspServiceFile,
        node: EspServiceNode
    };

    var serviceKey = espEnvironment.service;
    serviceKey ||  (serviceKey =  'http');
    var service = services[serviceKey] || services['http'];

    return $.isFunction(service) ? new service(espEnvironment.serviceConfig) : service;
});
