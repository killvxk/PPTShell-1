define([
	'jlang',
	'jquery',
	'prompter',
	'slides',
	'css!./workbench.css',
],function(
	jlang,
	$,
	prompter,
	slides
){
	function isPromise(obj){
		return obj && $.isFunction(obj.resolve) && $.isFunction(obj.reject);
	}
	var templates = {
		workbench : '<div class="slides-workbench">'+
						'<div class="slides-workbench-header">'+
						'</div>'+
						'<div class="slides-workbench-toolbar">'+
						'</div>'+
					'</div>',
		perspectiveWrap : '<div class="slides-workbench-perspective-wrap"></div>',
		perspective : '<div class="slides-workbench-perspective"></div>',
		perspectiveLayout : '<div class="slides-layout-border"></div>',
		regionWrap : {
			left : '<div class="_left" style="width:{size}px;"></div>',
			right : '<div class="_right" style="width:{size}px;"></div>',
			top : '<div class="_top" style="height:{size}px;"></div>',
			bottom : '<div class="_bottom" style="height:{size}px;"></div>',
			center : '<div class="_center"></div>',
		},
		region : '<div class="slides-workbench-region"></div>',
		regionLayout : {
			vertical : {
				layout : '<div class="slides-layout-vertical"></div>',
				wrap : '<div class="_box slides-workbench-view-wrap"><div class="_header"></div><div class="_body"></div></div>'
			},
			tab : {
				layout : '<div class="slides-layout-tab"><div class="_header"></div><div class="_body"></div></div>',
				headerWrap : '<div class="slides-workbench-view-wrap"></div>',
				bodyWrap : '<div class="slides-workbench-view-wrap"></div>'
			},
			fit : {
				layout : '<div class="slides-layout-fit"></div>',
				wrap : '<div class="slides-workbench-view-wrap"></div>'
			}
		},
		view: '<div class="slides-workbench-view"></div>',
		editor: '<div class="slides-workbench-editor"></div>'
	};
	function Workbench(rootElement){
		/***************************** Register *************************************/
		var eventManager = jlang.EventManager(['afterBootstrap']);
		var actionDefs = [],
			perspectiveDefs = [],
			viewDefs = [],
			editorDefs = [],
			editorSupportTypes = {},
			editorAssociateTypes = {},
			dialogDefs = [];

		function registerAction(actionDef){
			if(actionDef){
				actionDefs.push(actionDef);
			}
		}
		function registerPerspective(perspectiveDef){
			if($.isArray(perspectiveDef)){
				for(var i=0;i<perspectiveDef.length;i++){
					registerPerspective(perspectiveDef[i]);
				}
			}else{
				perspectiveDefs.push(perspectiveDef||{});
			}
		}
		function registerView(viewDef){
			if($.isArray(viewDef)){
				for(var i=0;i<viewDef.length;i++){
					registerView(viewDef[i]);
				}
			}else{
				if($.isFunction(viewDef)){
					viewDef = new viewDef();
				}
				viewDefs.push(viewDef||{});
			}
		}
		function findViewDef(name){
			for(var i=0;i<viewDefs.length;i++){
				var viewDef = viewDefs[i];
				if(viewDef.name == name){
					return viewDef;
				}
			}
		}
		function registerEditor(editorDef){
			if($.isArray(editorDef)){
				for(var i=0;i<editorDef.length;i++){
					registerEditor(editorDef[i]);
				}
			}else{
				if($.isFunction(editorDef)){
					editorDef = new editorDef();
				}
				if(!editorDef || !editorDef.name) return;
				var supportTypes = editorDef.supportTypes;
				if(!$.isArray(supportTypes)){
					supportTypes=[supportTypes];
				}
				var types=[];
				for(var i=0;i<supportTypes.length;i++){
					var type=supportTypes[i];
					if(type.indexOf('^')==0){
						type=type.substring(1);
						editorAssociateTypes[type]=editorDef.name;
					}
					types[i]=type;
				}
				editorSupportTypes[editorDef.name]=types;
				editorDefs.push(editorDef);
			}
		}
		function findEditorDef(name){
			for(var i=0;i<editorDefs.length;i++){
				var editorDef = editorDefs[i];
				if(editorDef.name == name){
					return editorDef;
				}
			}
		}
		function registerDialog(dialogDef){
			if($.isArray(dialogDef)){
				for(var i=0;i<dialogDef.length;i++){
					registerDialog(dialogDef[i]);
				}
			}else{
				if($.isFunction(dialogDef)){
					dialogDef = new dialogDef();
				}
				dialogDefs.push(dialogDef||{});
			}
		}
		function findDialogDef(name){
			for(var i=0;i<dialogDefs.length;i++){
				var dialogDef = dialogDefs[i];
				if(dialogDef.name == name){
					return dialogDef;
				}
			}
		}
		/*************************** Classes ********************************/
		function Action(actionDef){
			var handle = (actionDef && actionDef.handle) || $.noop;
			this.execute = function(){
				handle.apply(this,arguments);
			};
		}
		function Perspective(perspectiveDef, wrapEl){
			this.name = perspectiveDef.name;
			var regions = {};
			var prespectiveEl = $(templates.perspective).appendTo(wrapEl);
			var layoutEl = $(templates.perspectiveLayout).appendTo(prespectiveEl);
			var regionDefs = perspectiveDef.regions||{};
			for(var key in regionDefs){
				var regionDef = regionDefs[key],
					template = templates.regionWrap[key];
				if(template){
					var regionWrapEl = $(template.replace('{size}',regionDef.size||200)).appendTo(layoutEl);
					var region = new Region(regionDef,regionWrapEl);
					regions[key] = region;
				}
			}
			resetLayout();

			this.getRegion = function(r){
				return regions[r];
			};
			this.getEditorRegion = function(){
				return regions[perspectiveDef.editorRegion || 'center'];
			};
			this.removeView = function(viewId){
				for(var key in regions){
					regions[key].removeView(viewId);
				}
			}
			this.activeView = function(viewId){
				for(var key in regions){
					regions[key].activeView(viewId);
				}
			}

			function resetLayout(){
				var left = (layoutEl.children('._left').outerWidth()||0) + 'px';
				var right = (layoutEl.children('._right').outerWidth()||0) + 'px';
				var top = (layoutEl.children('._top').outerHeight()||0) + 'px';
				var bottom = (layoutEl.children('._bottom').outerHeight()||0) + 'px';

				layoutEl.children('._left').nextAll('._top,._bottom').css('left',left);
				layoutEl.children('._right').nextAll('._top,._bottom').css('right',right);
				layoutEl.children('._top').nextAll('._left,._right').css('top',top);
				layoutEl.children('._bottom').nextAll('._left,._right').css('bottom',bottom);
				layoutEl.children('._center').css({
					left : left,
					right : right,
					top : top,
					bottom : bottom,
				});
			}
		}
		function VerticalRegionLayout(regionEl, layoutConfig){
			var layoutEl = $(templates.regionLayout.vertical.layout).appendTo(regionEl);
			this.renderView = function(view){
				var wrapEl = $(templates.regionLayout.vertical.wrap).appendTo(layoutEl);
				wrapEl.attr('view-id',view.id);
				view.renderTo(wrapEl.children('._body'));
				wrapEl.children('._header').text(view.getTitle());
			};
			this.removeView = function(viewId){
				layoutEl.children('[view-id="'+viewId+'"].slides-workbench-view-wrap').remove();
			};
			this.activeView = function(viewId){
				var viewWrapEl = layoutEl.children('[view-id="'+viewId+'"].slides-workbench-view-wrap');
				if(viewWrapEl.length){
					layoutEl.children('.slides-workbench-view-wrap').removeClass('_actived');
					viewWrapEl.addClass('_actived');
					return true;
				}
				return false;
			};
		}
		function TabRegionLayout(regionEl, layoutConfig){
			var _this = this;

			var activeHistory = [];

			var layoutEl = $(templates.regionLayout.tab.layout).appendTo(regionEl);
			layoutEl.children('._header').delegate('>.slides-workbench-view-wrap','click',function(){
				activeView($(this).attr('view-id'));
			}).delegate('>.slides-workbench-view-wrap','dblclick',function(){
				removeView($(this).attr('view-id'));
			});
			if(layoutConfig && layoutConfig.hideHeader === true){
				layoutEl.children('._header').hide();
			}
			this.renderView = function(view){
				var headerWrapEl = $(templates.regionLayout.tab.headerWrap).appendTo(layoutEl.children('._header'));
				var bodyWrapEl = $(templates.regionLayout.tab.bodyWrap).appendTo(layoutEl.children('._body'));
				headerWrapEl.attr('view-id',view.id);
				bodyWrapEl.attr('view-id',view.id);
				view.renderTo(bodyWrapEl);
				headerWrapEl.text(view.title);
			};
			this.removeView = function(viewId){
				layoutEl.find('[view-id="'+viewId+'"].slides-workbench-view-wrap').remove();
				this.activePreviousView();
			};
			this.activeView = function(viewId){
				var viewWrapEl = layoutEl.find('[view-id="'+viewId+'"].slides-workbench-view-wrap');
				if(viewWrapEl.length){
					layoutEl.find('>*>.slides-workbench-view-wrap').removeClass('_actived');
					viewWrapEl.addClass('_actived');
					activeHistory.unshift(viewId);
					return true;
				}
				return false;
			};
			this.activePreviousView = function(){
				var viewId = activeHistory.shift();
				if(viewId){
					if(this.activeView(viewId)===false){
						this.activePreviousView();
					}
				}
			}
		}
		var regionLayouts = {'vertical': VerticalRegionLayout, 'tab': TabRegionLayout};
		function Region(regionDef, wrapEl){
			var regionEl = $(templates.region).appendTo(wrapEl);
			var layout = new (regionLayouts[regionDef.layout] || VerticalRegionLayout)(regionEl,regionDef.layoutConfig);

			this.addView = function(view){
				layout.renderView(view);
			};
			this.removeView = function(viewId){
				layout.removeView(viewId);
			};
			this.activeView = function(viewId){
				var result = layout.activeView(viewId);
				return result;
			};

			var viewConfigs = regionDef.views || [];
			if(!$.isArray(viewConfigs)) viewConfigs = [viewConfigs];
			for(var i=0;i<viewConfigs.length;i++){
				var viewDef, viewConfig = viewConfigs[i];
				if(typeof viewConfig =='string'){
					viewDef = viewConfig;
					viewConfig = null;
				}else{
					viewDef = viewConfig.name;
				}
				var view = createView(viewDef,viewConfig);
				if(view){
					this.addView(view);
				}
			}
		}
		function View(viewDef, viewConfig){
			this._id = $.isFunction(viewDef.id) ? viewDef.id() : viewDef.id;
			this._name = viewDef.name;
			this._viewDef = viewDef;
			this._viewConfig =viewConfig;
			this._ctrl = $.extend({},viewDef.ctrl);
		}
		View.prototype.renderTo = function (wrapEl) {
			if(!this._viewEl){
				this._viewEl = $(templates.view).appendTo(wrapEl);
				(this._viewDef.render||$.noop).call(this._viewDef, this, this._viewConfig);
			}else{
				this._viewEl.appendTo(wrapEl);
			}
		};
		View.prototype.destroy = function () {
			(this._viewDef.destroy||$.noop).call(this._viewDef, this, this._viewConfig);
		};
		View.prototype.save = function () {
			var result = (this._viewDef.save||$.noop).call(this._viewDef);
			if(!isPromise(result)){
				result = $.when(result);
			}
			return result;
		};
		Object.defineProperties(View.prototype, {
			id: {
				get: function () {
					return this._id;
				}
			},
			name: {
				get: function () {
					return this._name;
				}
			},
			title: {
				get: function () {
					var t = this._title || this._viewDef.title;
					if($.isFunction(t)){
						t = t();
					}
					return t;
				},
				set: function (val) {
					this._title = val;
				}
			},
			element: {
				get: function () {
					return this._viewEl[0];
				}
			},
			workbench: {
				get: function () {
					return workbenchCtrl;
				}
			},
			ctrl: {
				get: function () {
					return this._ctrl;
				},
				set: function (val) {
					this._ctrl = val || {};
				}
			}
		});
		function EditorViewDef(editorDef, resource, editorConfig){
			var editor = new Editor(editorDef, resource, editorConfig);
			this.id = editor.name + ':' + editor.key;
			this.title = $.proxy(editor,'getTitle');
			this.render = function(view){
				editor.renderTo(view.element);
			};
			this.destroy = function(view){
				console.log('destroy view...');
				editor.destroy();
			};
			this.save = editorDef.save;
			this.ctrl = {
				editor: editor
			};
		}
		function Editor(editorDef, resource, editorConfig){
			this._name = editorDef.name;
			this._type = resource.type;
			this._key = resource.key;
			this._data = resource.data;
			this._editorDef = editorDef;
			this._resource = resource;
			this._editorConfig = editorConfig;

			this.destroy = function(){
				(editorDef.destroy||$.noop).call(editorDef,this, resource);
			};
			this._ctrl = $.extend({}, editorDef.ctrl);
		}
		Editor.prototype.renderTo = function (wrapEl) {
			this._editorEl = $(templates.editor).appendTo(wrapEl);
			(this._editorDef.render||$.noop).call(this._editorDef, this, this._resource, this._editorConfig);
		};
		Editor.prototype.destroy = function () {
			(this._editorDef.destroy||$.noop).call(this._editorDef, this, this._resource);
		};
		Object.defineProperties(Editor.prototype, {
			name: {
				get: function () {
					return this._name;
				}
			},
			type: {
				get: function () {
					return this._type;
				}
			},
			key: {
				get: function () {
					return this._key;
				}
			},
			data: {
				get: function () {
					return this._data;
				}
			},
			title: {
				get: function () {
					var t = this._title || this._editorDef.title || this.key;
					if($.isFunction(t)){
						t = t();
					}
					return t;
				},
				set: function (val) {
					this._title = val;
				}
			},
			element: {
				get: function () {
					return this._editorEl[0];
				}
			},
			workbench: {
				get: function () {
					return workbenchCtrl;
				}
			},
			ctrl: {
				get: function () {
					return this._ctrl;
				},
				set: function (val) {
					this._ctrl = val || {};
				}
			}
		});
		/***************************** Bootstrap *************************************/
		var workbenchEl;
		var actions = {}, perspectives = {}, views = {}, dialogs = {};
		var viewIdPrefix = ':workbench:view:', viewIdIndex = 1;

		function bootstrap(rootElement){
			initActions();
			workbenchEl = $(templates.workbench).appendTo($(rootElement));
			eventManager.trigger('afterBootstrap',workbenchCtrl);
		}

		function initActions(){
			for(var i=0;i<actionDefs.length;i++){
				var actionDef = actionDefs[i];
				if($.isFunction(actionDef)){
					actionDef = actionDef(workbenchCtrl);
				}
				if(!actionDef) continue;
				if(!$.isArray(actionDef)){
					actionDef = [actionDef];
				}
				for(var j=0;j<actionDef.length;j++){
					var def = actionDef[j];
					if(!def || !def.name) continue;
					actions[def.name] = new Action(def);
				}
			}
		}
		function executeAction(name){
			var action = actions[name];
			if(!action) throw 'no action named with: '+name;
			var args = [];
			for(var i=1;i<arguments.length;i++){
				args.push(arguments[i]);
			}
			action.execute.apply(action,args);
		}

		function switchPerspective(perspectiveName){
			var perspective = perspectives[perspectiveName];
			if(!perspective){
				for(var i=0;i<perspectiveDefs.length;i++){
					var perspectiveDef = perspectiveDefs[i];
					if(perspectiveDef.name == perspectiveName){
						var wrapEl = $(templates.perspectiveWrap).appendTo(workbenchEl);
						wrapEl.attr('perspective-name',perspectiveName);
						perspective = new Perspective(perspectiveDef,wrapEl);
						perspectives[perspectiveName] = perspective;
					}
				}
			}
			workbenchEl.children('.slides-workbench-perspective-wrap').removeClass('_actived');
			workbenchEl.children('[perspective-name="'+perspectiveName+'"].slides-workbench-perspective-wrap').addClass('_actived');
		}
		function getCurrentPerspective(){
			var perspectiveName = workbenchEl.children('.slides-workbench-perspective-wrap._actived').attr('perspective-name');
			return perspectives[perspectiveName];
		}
		function createView(viewDef, viewConfig){
			if(typeof viewDef =='string'){
				viewDef = findViewDef(viewDef);
			}
			if(!viewDef) return false;
			if(viewDef.name){
				for(var key in views){
					if(views[key].name === viewDef.name){
						return views[key];
					}
				}
			}
			var view = new View(viewDef, viewConfig);
			if(!view.id){
				view.id = viewIdPrefix + viewIdIndex++;
			}
			views[view.id] = view;
			return view;
		}
		function removeView(viewId){
			if(typeof viewId ==='string'){
				var view = views[viewId];
				if(!view) return false;
				view.destroy();
				delete views[viewId];
				for(var key in perspectives){
					perspectives[key].removeView(viewId);
				}
				return true;
			}else if($.isFunction(viewId)){
				var result = true;
				for(var key in views){
					var view = views[key];
					if(viewId(view) === true){
						result = removeView(view.id) && result;
					}
				}
				return result;
			}
		}
		function activeView(viewId){
			for(var key in perspectives){
				perspectives[key].activeView(viewId);
			}
		}
		function getView(viewId){
			return views[viewId];
		}
		function getViewByName(viewName){
			for(var key in views){
				if(views[key].name === viewName){
					return views[key];
				}
			}
		}
		function openEditor(resource, name, editorConfig){
			if(!resource || !resource.key){
				return false;
			}
			if(!name){
				name=editorAssociateTypes[resource.type];
			}
			if(!name){
				outer:for(var key in editorSupportTypes){
					var types=editorSupportTypes[key];
					for(var i=0;i<types.length;i++){
						if(types[i]==resource.type){
							name=key;
							break outer;
						}
					}
				}
			}
			var viewId = name + ':' + resource.key;
			var view = views[viewId];
			if(!view){
				var editorDef = findEditorDef(name);
				if(!editorDef) return false;
				view = createView(new EditorViewDef(editorDef,resource,editorConfig));
				getCurrentPerspective().getEditorRegion().addView(view,true);
			}
			getCurrentPerspective().getEditorRegion().activeView(view.id);
			return view.ctrl.editor;
		}
		function closeEditor(editor){
			if(!editor) return false;
			return removeView(function(view){
				return view.ctrl.editor == editor;
			});
		}
		function closeEditorByName(editorName){
			if(!editorName) return false;
			return removeView(function(view){
				var editor = view.ctrl.editor;
				return editor && editor.name === editorName;
			});
		}
		function closeEditorByType(editorType){
			if(!editorType) return false;
			return removeView(function(view){
				var editor = view.ctrl.editor;
				return editor && editor.type === editorType;
			});
		}
		function closeEditorByKey(resourceKey){
			if(!resourceKey) return false;
			return removeView(function(view){
				var editor = view.ctrl.editor;
				return editor && editor.key === resourceKey;
			});
		}

		 function openDialog(name, dialogOptions, contentOptions){
			 var dialog = dialogs[name];
			 if(!dialog || dialog.destroyed){
				 var dialogDef = findDialogDef(name);
				 if(!dialogDef) throw 'no dialog with name: ' + name;
				 dialog = prompter.createDialog($.extend({}, dialogDef, dialogOptions), contentOptions);
				 dialogs[dialogDef.name] = dialog;
			 }
			 return dialog.open();
		 }

		function saveAll(){
			for(var key in views){
				var view = views[key];
				var promise = view.save();
			}
		}
		/***************************** API *************************************/
		this.registerAction = registerAction;
		this.registerPerspective = registerPerspective;
		this.registerView = registerView;
		this.registerEditor = registerEditor;
		this.registerDialog = registerDialog;
		this.on = $.proxy(eventManager,'on');
		this.off = $.proxy(eventManager,'off');
		this.bootstrap = bootstrap;

		var workbenchCtrl = {
			switchPerspective : switchPerspective,
			createView : createView,
			getView : getView,
			getViewByName : getViewByName,
			removeView : removeView,
			activeView : activeView,
			openEditor : openEditor,
			closeEditor : closeEditor,
			closeEditorByName : closeEditorByName,
			closeEditorByType : closeEditorByType,
			closeEditorByKey : closeEditorByKey,
			openDialog: openDialog,
			executeAction : executeAction,
			saveAll : saveAll
		};

	}
	return Workbench;
});