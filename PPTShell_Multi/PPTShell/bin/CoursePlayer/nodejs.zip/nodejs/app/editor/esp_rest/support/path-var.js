/**
 * Created by ChenST on 2016/1/19.
 */

module.exports.PathVar = {
    refPath: '${ref-path}',
    refQuestion: '${ref-question}',
    refPathAddon: '${ref-path-addon}',
    refRelative: '${ref-relative}}'
}