/**
 * Created by ChenST on 2016/1/21.
 */

var mime = require('mime');
var sizeOf = require('image-size');
var path = require('path');
var Q = require('q');

var CONST = {
    '.bmp': {ndCode: '$RA0101'},
    '.gif': {ndCode: '$RA0101'},
    '.jpeg': {ndCode: '$RA0101'},
    '.jpg': {ndCode: '$RA0101'},
    '.png': {ndCode: '$RA0101'},
    '.webp': {ndCode: '$RA0101'},
    '.mp3': {ndCode: '$RA0102'},
    '.mp4': {ndCode: '$RA0103'},
    '.swf': {ndCode: '$RA0104'}
};

var parseAsset = function (_path) {

    var deferred = Q.defer();

    var result = {
        path: '',
        ndCode: '',
        mime: ''
    };

    var ext = path.extname(_path).toLowerCase();

    // 设置mime&nocde.
    result.path = _path;
    result.mime = mime.lookup(_path);

    if (CONST[ext]) {
        result.ndCode = CONST[ext].ndCode || ''
    } else {
        result.ndCode = '';
    }

    // 图片,计算大小.
    if (result.ndCode === '$RA0101') {

        sizeOf(_path, function (err, dimensions) {

            if (err) {
                deferred.reject(err);
            }

            result.width = dimensions.width;
            result.height = dimensions.height;

            deferred.resolve(result);

        });
    } else {
        deferred.resolve(result);
    }

    return deferred.promise

};

var getNdCode = function (_path) {
    var ext = path.extname(_path).toLowerCase();
    if (CONST[ext]) {
        return CONST[ext].ndCode || '';
    }
    return '';
};

module.exports.parseAsset = parseAsset;
module.exports.getNdCode = getNdCode;