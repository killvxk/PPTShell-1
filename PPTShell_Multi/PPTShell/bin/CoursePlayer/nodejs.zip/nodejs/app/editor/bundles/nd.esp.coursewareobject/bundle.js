define([
	'./PageExplorerView/script',
	'./GeneralPageEditor/script',
	'./InteractionQEditor/script',
	'./ResourceStore'
],function(
	PageExplorerView,
	GeneralPageEditor,
	InteractionQEditor,
	ResourceStore
){
	return {
		requires:['workbench', 'nd.esp.resource'],
		activator : function(bundleContext){
		},
		extensions :  [{
			targetBundle:'workbench',
			point:'perspective',
			config:[{
				name:'nd.esp.coursewareobject.general',
				regions:{
					top:{
						size:110,
						views:'workbench.ToolbarView'
					},
					left:{
						views:['nd.esp.coursewareobject.PageExplorerView']
					},
					right:{
						size:110,
						views:'nd.esp.resource.ResourceExplorerView'
					},
					center:{
						layout:'tab'
					}
				},
				editorRegion:'center'
			},{
				name:'nd.esp.coursewareobject.interactionQ',
				regions:{
					center:{
						layout:'tab',
						layoutConfig:{
							hideHeader:true
						}
					}
				},
				editorRegion:'center'
			}]
		},{
			targetBundle:'workbench',
			point:'view',
			config:PageExplorerView
		},{
			targetBundle:'workbench',
			point:'editor',
			config:GeneralPageEditor
		},{
			targetBundle:'workbench',
			point:'editor',
			config:InteractionQEditor
		},{
			targetBundle:'workbench',
			point:'toolbar',
			config:[{
				label:'New',
				icon:'new.png',
				action:'new'
			}]
		},{
			targetBundle: 'nd.esp.resource',
			point: 'store',
			config:[new ResourceStore()]
		}]
	};
});