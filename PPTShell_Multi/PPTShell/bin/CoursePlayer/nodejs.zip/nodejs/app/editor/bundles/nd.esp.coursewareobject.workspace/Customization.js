/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
    'require',
    'jquery',
    'espEnvironment',
    'espService',
    'espModel',
    'prompter'
],function(
    require,
    $,
    espEnvironment,
    espService,
    espModel,
    prompter
){
    var defaultEditorConfig = {
        editorType: 'general'
    };

    function getEditorConfig(templateIdentifier){
        var deferred = $.Deferred();
        requirejs([espModel.repository.coursewareobjectTemplate(templateIdentifier).getResourceUrl('editor-config.js')], function (editorConfig) {
            deferred.resolve(editorConfig);
        }, function () {
            deferred.resolve(null);
        });
        return deferred.promise();
    }
    var Customization = {
        process: function(workbench, coursewareobjectMetadata){
            var templateIdentifier = coursewareobjectMetadata.custom_properties && coursewareobjectMetadata.custom_properties.template_code;
            if(!templateIdentifier){
                prompter.error('该颗粒不知道是哪个模板创建，无法打开');
                return;
            }
            getEditorConfig(templateIdentifier).then(function (editorConfig) {
                if(!editorConfig){
                    console.warn('该模板[' + templateIdentifier + ']未配置定制编辑器，将使用默认编辑器');
                    editorConfig = defaultEditorConfig;
                }
                if(typeof editorConfig === 'string'){
                    editorConfig = {editorType: editorConfig};
                }
                espEnvironment.declareModuleEditorVersion(editorConfig.editorVersions);
                require(['./implements/' + editorConfig.editorType + '.js'], function(customization){
                    customization(editorConfig, workbench, coursewareobjectMetadata);
                }, prompter.errorIf('不存在该名称的颗粒编辑器 ['+editorConfig.editorType+']，请检查定制编辑器的配置'));
            });
        }
    };

    return Customization;
});