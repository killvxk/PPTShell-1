/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
    'jquery',
    'espEnvironment',
    'espEnvironment/../UrlHelper',
    'espService/../esp-service-exceptions'
], function (
    $,
    espEnvironment,
    UrlHelper,
    EspExceptions
) {
    function get(url, settings) {
        return $.ajax(url, $.extend({
            type: 'GET'
        }, settings));
    }

    function post(url, data, settings) {
        settings = $.extend({
            type: 'POST',
            data: data,
            contentType: 'application/json'
        }, settings);
        if (settings.contentType == 'application/json' && settings.data) {
            settings.data = JSON.stringify(settings.data);
        }
        return $.ajax(url, settings);
    }

    function put(url, data, settings) {
        settings = $.extend({
            type: 'PUT',
            data: data,
            contentType: 'application/json'
        }, settings);
        if (settings.contentType == 'application/json' && settings.data) {
            settings.data = JSON.stringify(settings.data);
        }
        return $.ajax(url, settings);
    }

    function del(url, data, settings) {
        return $.ajax(url, $.extend({
            type: 'DELETE'
        }, settings));
    }

    function httpService(serviceConfig) {
        var url = UrlHelper.root(serviceConfig.server);
        var service = {};
        service.coursewareobject = {
            create: function (coursewareObject) {
                return post(url('/v2.0/courseware_objects'), coursewareObject)
                    .then(null, EspExceptions.CREATE_COURSEWAREOBJECT.asFail());
            },
            createByTemplate: function (templateCode) {
                return post(url('/v2.0/courseware_objects/actions/from_template?template_code={0}', templateCode))
                    .then(null, EspExceptions.CREATE_COURSEWAREOBJECT.asFail());
            },
            get: function (coursewareObjectId) {
                return get(url('/v2.0/courseware_objects/{0}', coursewareObjectId))
                    .then(null, EspExceptions.GET_COURSEWAREOBJECT.asFail(coursewareObjectId));
            },
            getMainXml: function (coursewareObjectId) {
                return get(url('/v2.0/courseware_objects/{0}/main', coursewareObjectId), {dataType: 'text'})
                    .then(null, EspExceptions.GET_COURSEWAREOBJECT_MAIN_XML.asFail(coursewareObjectId));
            },
            updateMainXml: function (coursewareObjectId, mainXml) {
                return put(url('/v2.0/courseware_objects/{0}/main', coursewareObjectId), mainXml, {
                    contentType: 'text/plain'
                }).then(null, EspExceptions.UPDATE_COURSEWAREOBJECT_MAIN_XML.asFail(coursewareObjectId));
            },
            getPageXml: function (coursewareObjectId, pageId) {
                return get(url('/v2.0/courseware_objects/{0}/pages/{1}', [coursewareObjectId, pageId]))
                    .then(null, EspExceptions.GET_COURSEWAREOBJECT_PAGE_XML.asFail(pageId));
            },
            createPageXml: function (coursewareObjectId, pageXml) {
                return post(url('/v2.0/courseware_objects/{0}/pages', coursewareObjectId), pageXml, {
                    contentType: 'text/plain'
                }).then(null, EspExceptions.CREATE_COURSEWAREOBJECT_PAGE_XML.asFail(coursewareObjectId));
            },
            updatePageXml: function (coursewareObjectId, pageId, pageXml) {
                return put(url('/v2.0/courseware_objects/{0}/pages/{1}', [coursewareObjectId, pageId]), pageXml, {
                    contentType: 'text/plain'
                }).then(null, EspExceptions.UPDATE_COURSEWAREOBJECT_PAGE_XML.asFail(pageId));
            },
            copyAs: function (coursewareObjectId, newCoursewareObjectId) {
                return post(url('/v2.0/courseware_objects/{0}/actions/copy?to={1}', [coursewareObjectId, newCoursewareObjectId]))
                    .then(null, EspExceptions.COPY_COURSEWAREOBJECT.asFail([coursewareObjectId, newCoursewareObjectId]));
            },
            getAssetUploadUrl: function (coursewareObjectId) {
                return url('/v2.0/courseware_objects/{0}/resource_files/actions/upload', coursewareObjectId);
            },
            listAssets: function (coursewareObjectId, params) {
                return get(url('/v2.0/courseware_objects/{0}/resource_files', coursewareObjectId, params))
                    .then(null, EspExceptions.LIST_COURSEWAREOBJECT_ASSETS.asFail(coursewareObjectId));
            }
        };
        service.asset = {
            list: function (params) {
                return get(url('/v2.0/assets', params))
                    .then(null, EspExceptions.LIST_ASSET);
            },
            getUploadUrl: function () {
                return url('/v2.0/assets/actions/upload');
            }
        };
        return service;
    }

    return httpService;
});
