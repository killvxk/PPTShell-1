/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
    'jquery',
    'angular',
    'espEnvironment',
    'espService',
    'espModel',
    'prompter',
    '../PageStage/script',
    'css!./style.css',
],function(
    $,
    angular,
    espEnvironment,
    espService,
    espModel,
    prompter,
    PageStage
){
    var templates = {
        editor: '<div class="slides-interaction-q-page-editor">' +
                    '<div class="_body">' +
                        '<div class="_stage-wrap"></div>' +
                        '<div class="_toolbar"></div>' +
                    '</div>'+
                '</div>',
        button: '<div class="_btn"><div class="_icon"></div><div class="_label"></div></div>',
        panel:  '<div class="_pop-panel">' +
                    '<div class="_header"></div>' +
                    '<div class="_body"></div>' +
                    '<div class="_footer"></div>' +
                '</div>',
        panel_button: '<div class="_btn _hover"></div>',
        panel_body_skin: '<ul><li class="_wood"><a href="javascript:void(0)"></a></li></ul>',
        panel_body_description: '<video src=""></video><div class="_text"></div>',
        panel_body_time: '<div class="_form-row _on"><span class="_radio" value="sequence">顺计时</span></div>'+
                        '<div class="_form-row"><span class="_radio" value="countdown">倒计时</span>' +
                            '<input name="minute" type="number" max="59" min="0" class="_text" value="0"/><label class="_label">分</label>' +
                            '<input name="second" type="number" max="59" min="0" class="_text" value="0"/><label class="_label">秒</label>' +
                        '</div>'
    };

    function createPanel(name, parentEl, title, body, buttons, init){
        var panelEl = $(parentEl).find('._pop-panel');
        if(panelEl.length && panelEl.is(':visible')){
            $(document).off('._pop-panel');
        }
        if(!panelEl.length){
            panelEl = $(templates.panel).addClass('_' + name).appendTo(parentEl);
            panelEl.on('click', function (event) {
                event.stopPropagation();
            });
            title ? panelEl.find('._header').append(title) : panelEl.find('._header').hide();
            panelEl.find('._body').append(body);
            buttons && $.each(buttons, function (i, btn) {
                var btnEl = $(templates.panel_button).appendTo(panelEl.find('._footer'));
                btnEl.text(btn.label);
                btn.primary && btnEl.addClass('_primary');
                btnEl.on('click', $.proxy(function (event) {
                    var result = (this.handle || $.noop)(event, panelEl);
                    if(result!==false){
                        panelEl.hide();
                        $(parentEl).removeClass('_on');
                        $(document).off('._pop-panel');
                    }
                }, btn));
            });
            $.isFunction(init) && init(panelEl);
        }
        panelEl.show();
        $(parentEl).addClass('_on');
        setTimeout(function(){
            $(document).one('click._pop-panel', function () {
                console.log('click document');
                panelEl.hide();
                $(parentEl).removeClass('_on');
            });
        },0);
        return panelEl;
    }

    return function(){
        this.name = 'nd.esp.coursewareobject.InteractionQEditor';
        this.supportTypes = ['coursewareobject'];
        this.render = function(editor,resource,config){
            var editorEl = $(templates.editor).appendTo(editor.element);

            function resetSize(){
                var width = editorEl.width(),
                    height = editorEl.height();
                var scale = Math.min(width/1600, height/1000);
                editorEl.children('._body').css('transform','scale(' + scale + ')');
            }
            setTimeout(function () {
                resetSize();
            },0);
            $(window).resize(resetSize);

            var coursewareobjectMetadata = resource.data;
console.log(coursewareobjectMetadata);
            var outerMessage = {
                "message": "QuestionSaved",
                "id": coursewareobjectMetadata.identifier,
                "action": "save",
                "question_type": coursewareobjectMetadata.custom_properties && coursewareobjectMetadata.custom_properties.question_type,
                "question_code": coursewareobjectMetadata.categories
                                    && coursewareobjectMetadata.categories.res_type
                                    && coursewareobjectMetadata.categories.res_type[0]
                                    && coursewareobjectMetadata.categories.res_type[0].taxoncode,
                "file_path": coursewareobjectMetadata.physics_path || espModel.repository.coursewareobject(coursewareobjectMetadata.identifier).getResourceUrl()
            };
            var pageStage;
            espModel.repository.coursewareobject(coursewareobjectMetadata.identifier).get().then(function (coursewareobject) {
                var pr = coursewareobject.getPageReferenceAt(0);
                if (pr) {
                    pageStage = new PageStage(coursewareobject.id, pr.id, editorEl.find('._body>._stage-wrap'), {
                        apiProxy: {
                            selectResource: function (options, dialogOptions) {
                                return editor.workbench.openDialog('nd.esp.resource.select', dialogOptions, $.extend({
                                    type: '$RA0101',
                                    storeParams: {
                                        coursewareobject: {
                                            coursewareobjectId: coursewareobject.id
                                        }
                                    }
                                }, options)).promise();
                            }
                        }
                    });
                } else {
                    prompter.error('该课件中没有任何页');
                }
            }, prompter.errorIf());

            var toolbarEL = editorEl.find('._body>._toolbar');

            function save(){
                if(!pageStage){
                    return $.Deferred().reject('页面尚未加载完成');
                }
                var writeMode = espEnvironment.writeMode || '';
                if(writeMode === 'yes'){
                    return pageStage.save().then(function () {
                        return coursewareobjectMetadata.identifier;
                    });
                }else if(writeMode.indexOf('copy') === 0){
                    var newIdentifier = writeMode.substring(5) || '$temp';
                    return espModel.repository.coursewareobject(coursewareobjectMetadata.identifier).copyAs(newIdentifier).then(function (identifier) {
                        return pageStage.save().then(function () {
                            return identifier;
                        });
                    });
                }else{
                    return $.Deferred().reject('该环境不允许写入');
                }
            }
            var buttons = [
                {name:'skin', label: '换肤', iconClass: 'skin', handle: function (event) {
                    createPanel(
                        'skin',
                        event.currentTarget,
                        null,
                        templates.panel_body_skin
                    );
                }},
                {name:'description', label: '题型描述', iconClass: 'description', handle: function (event) {
                    createPanel(
                        'description',
                        event.currentTarget,
                        this.title || '题型描述',
                        templates.panel_body_description,
                        [{label: '我知道了', primary: true}],
                        $.proxy(function (panelEl) {
                            panelEl.find('._text').html(this.content);
                        },this)
                    );
                }},
                {name:'time', label: '时间设置', iconClass: 'time', handle: function(event){
                    if(pageStage){
                        var panelEl = createPanel(
                            'time',
                            event.currentTarget,
                            '计时方式选择',
                            templates.panel_body_time,
                            [{label: '确定', primary: true, handle: function (event, panelEl) {
                                var type = panelEl.find('._form-row._on>._radio').attr('value');
                                gameQuestionTimer.call('setType', type);
                                if(type == 'countdown'){
                                    var minute = parseInt(panelEl.find('input[name="minute"]').val());
                                    var second = parseInt(panelEl.find('input[name="second"]').val());
                                    var invalid = false;
                                    if(isNaN(minute) || minute < 0 || minute > 59){
                                        panelEl.find('input[name="minute"]').val(0);
                                        invalid = true;
                                    }
                                    if(isNaN(second) || second < 0 || second > 59){
                                        panelEl.find('input[name="second"]').val(0);
                                        invalid = true;
                                    }
                                    if(invalid) return false;
                                    gameQuestionTimer.call('setDuration', minute * 60 + second);
                                }else{
                                    gameQuestionTimer.call('setDuration', 0);
                                }
                            }}, {label: '取消'}],
                            function (panelEl) {
                                panelEl.find('._form-row').click(function (event) {
                                    panelEl.find('._form-row').removeClass('_on');
                                    $(this).addClass('_on');
                                });
                            }
                        );
                        var gameQuestionTimer = pageStage.getModuleInterfaces('.GameQuestionTimer');
                        var type = gameQuestionTimer.call('getType')[0] || 'sequence';
                        panelEl.find('._form-row').removeClass('_on');
                        panelEl.find('._form-row>._radio[value="' + type + '"]').parent().addClass('_on');
                        if(type == 'countdown'){
                            var duration = parseInt(gameQuestionTimer.call('getDuration')[0]) || 0;
                            panelEl.find('input[name="minute"]').val(parseInt(duration/60));
                            panelEl.find('input[name="second"]').val(duration % 60);
                        }else{
                            panelEl.find('input[name="minute"]').val(0);
                            panelEl.find('input[name="second"]').val(0);
                        }
                    }
                }},
                {name:'preview', label: '预览', iconClass: 'preview', handle: function () {
                    save().done(function (identifier) {
                        prompter.dialog({
                            title:'预览',
                            state:'default',
                            size:'full',
                            showClose:true,
                            backdrop:'static',
                            autoDestroy:true,
                            width: 1280,
                            height: 841,
                            src: espEnvironment.url.coursewareobjectPreview(identifier)
                        });
                        console.log(JSON.stringify($.extend({}, outerMessage ,{"message":"QuestionSaved", "action":"save"})));
                    }).fail(prompter.errorIf());
                }},
                {name:'save', label: '保存', iconClass: 'save', handle: function () {
                    save().done(function(){
                        prompter.success('保存成功');
                        console.log(JSON.stringify($.extend({}, outerMessage ,{"message":"QuestionSaved", "action":"save"})));
                    }).fail(prompter.errorIf());
                }},
                {name:'insert', label: '插入', iconClass: 'insert', handle: function(){
                    save().done(function () {
                        console.log(JSON.stringify($.extend({}, outerMessage ,{"message":"QuestionAdd", "action":"insert"})));
                    }).fail(prompter.errorIf());
                }}
            ];
            var tools = (config && config.tools) || [];
            $.each(tools, function (i, tool) {
                var btn = {name: typeof tool === 'string' ? tool : tool.name};
                if(!btn.name) return;
                $.each(buttons, function (ii, button) {
                    if(button.name == btn.name){
                        $.extend(btn, button);
                        return false;
                    }
                });
                if(typeof tool !== 'string'){
                    $.extend(btn, tool);
                }
                var btnEl = $(templates.button).appendTo(toolbarEL);
                btnEl.children('._icon').addClass('_' + btn.iconClass);
                btnEl.children('._label').text(btn.label);
                btnEl.on('click', $.proxy(function (event) {
                    (this.handle || $.noop).apply(this, [event]);
                }, btn));
            });
        };
        this.save = function(editor,resource){
            console.log('saving...');
        };
        this.destroy = function(editor,resource){
            console.log('destroy editor...',editor);
        };
    };
});