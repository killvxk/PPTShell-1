/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
    'jquery',   
    'css!./style.css',
    './js/templates.js'
],function($,css,templates){  
	
    function GameQuestionTimerModuleEditor(){
    	var format =function(value){
    		value = value*1;
    		if(value<10){
    			value = '0'+value;
    		}
    		return value;
    	}
        var module, stage, config;
        //设置关联值
        this.init = function(m,s,c){
            module = m;
            stage = s;
            config = c;              
        };
        //初始化默认值
        this.initDefault = function(moduleWrap){            
                              
        };
        //绘制交互页面
        this.render = function(moduleWrap){
            this.element = $(moduleWrap.getElement());  
            this.render_internal();  
        };
        this.render_internal = function(){
        	$(this.element).html(templates['template.html']);
            var minute = module.getPropertyValue("minute");
            var second = module.getPropertyValue("second");
            var type = module.getPropertyValue("type");
            $(this.element).find('.GameQuestionTimer_minute').html(type=='sequence' ? '00' : format(minute));
            $(this.element).find('.GameQuestionTimer_second').html(type=='sequence' ? '00' :format(second));    
        }
        var type = 'countdown', duration = 0;
        this.getInterfaceDefinition = function(){
        	var _this = this;
            return ['.', {
                getType: function(){
                    return module.getPropertyValue("type");
                },
                getDuration: function(){
                     var minute = module.getPropertyValue("minute");
                     var second = module.getPropertyValue("second");
                     var duration =  minute*60+second*1;
                     console.log("duration is ",duration);
                     return duration;
                },
                setType: function (t) {                	
                    return module.setPropertyValue("type",t);
                    _this.render_internal();
                },
                setDuration: function (d) {
                     var minute = Math.floor(d/60);
                     var second = d%60;
                     module.setPropertyValue("minute",minute)
                     module.setPropertyValue("second",second);
                     _this.render_internal();
                }
            }];
        };

    }
    return GameQuestionTimerModuleEditor;
});