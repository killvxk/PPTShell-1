define([
	'./ResourceStore'
],function(
	ResourceStore
){
	return function(){
		return {
			requires:'nd.esp.resource',
			activator : function(bundleContext){
				
			},
			extensions :  function(bundleContext){
				return [{
					targetBundle: 'nd.esp.resource',
					point: 'store',
					config:[
						new ResourceStore('personal', '个人库', 'User/771510/OWNER'),
						new ResourceStore('public', '101库', 'Org/nd/OWNER')
					]
				}];
			}
		};
	};
});