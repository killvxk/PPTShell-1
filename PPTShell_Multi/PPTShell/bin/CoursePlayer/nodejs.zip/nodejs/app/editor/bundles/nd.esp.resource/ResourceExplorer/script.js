/**
 * Created by chenyoudong on 2015/12/30.
 */
define([
    'jlang',
    'jquery',
    'prompter',
    'espService',
    'espModel',
    'angular',
    'slides-angular',
    'css!./style.css',
],function(
    jlang,
    $,
    prompter,
    espService,
    espModel,
    angular
){
    var assetTypes={
        $RA0101:{typeName:'image', title:'图片', defaultThumbHref:'bundles/nd.esp.resource/ResourceExplorer/images/picture.png', uploadFilters: {mime_types: [{title : '图片文件', extensions : 'jpg,jpeg,gif,png,bmp'}]}},
        $RA0102:{typeName:'audio', title:'音频', defaultThumbHref:'bundles/nd.esp.resource/ResourceExplorer/images/audio.png', uploadFilters: {mime_types: [{title : 'mp3文件', extensions : 'mp3'}]}},
        $RA0103:{typeName:'video', title:'视频', defaultThumbHref:'bundles/nd.esp.resource/ResourceExplorer/images/video_none.png', uploadFilters: {mime_types: [{title : 'mp4文件', extensions : 'mp4'}]}},
        $RA0104:{typeName:'flash', title:'Flash', defaultThumbHref:'bundles/nd.esp.resource/ResourceExplorer/images/flash.png', uploadFilters: {mime_types: [{title : 'Flash文件', extensions : 'swf'}]}}
    };
    function ResourceExplorer(wrapEl, type, stores, storeParams){
        var eventManager = jlang.EventManager(this, ['select']);
        angular.quickstart(wrapEl, {
            templateUrl: 'bundles/nd.esp.resource/ResourceExplorer/template.html',
            controller: ['$scope', '$timeout', '$q', function ($scope, $timeout, $q) {
                $scope.assetType = assetTypes[type] || assetTypes['$RA0101'];
                $scope.stores = [];
                stores = !stores ? [] : (angular.isArray(stores) ? stores : [stores]);
                angular.forEach(stores, function (s) {
                    var store = angular.extend({
                        title: '未命名',
                        datas: [],
                        order: 1,
                        uploadItems: [],
                        uploadEnabled: false,
                        processUploadResponse: angular.noop,
                        getDataList: function (params) {
                            return $.when([]);
                        }
                    }, s);
                    if(s.paging){
                        store.pagination = {page:1, size: parseInt(s.paging) || 20};
                    }
                    if(s.uploadOptions){
                        try{
                            store.uploadOptions = angular.isFunction(s.uploadOptions) ? s.uploadOptions(storeParams && storeParams[s.name]) : s.uploadOptions;
                        }catch(e){
                            console.error('获取上传选项发生错误：' + e);
                            store.uploadEnabled = false;
                        }
                    }
                    if(angular.isFunction(s.getFileWriter)){
                        try{
                            store.fileWriter = s.getFileWriter(storeParams && storeParams[s.name]);
                        }catch(e){
                            console.error('获取 FileWriter 发生错误：' + e);
                            store.uploadEnabled = false;
                        }
                    }
                    $scope.stores.push(store);
                });
                $scope.stores.sort(function (a, b) {
                    var a = parseFloat(a.order),
                        b = parseFloat(b.order);
                    return (isNaN(a) ? 1 : a) - (isNaN(b) ? 1 : b);
                });

                $scope.currentStore;
                $scope.selectedData;

                function fireSelectChange(){
                    if(!$scope.currentStore) return;
                    eventManager.trigger('select', $scope.selectedData ? angular.extend({}, $scope.selectedData) : null);
                }

                $scope.doSearch = function (page) {
                    var store = $scope.currentStore;
                    if(!store) return;
                    var params = angular.extend({
                        type: type,
                        keyword: $scope.keyword
                    }, storeParams && storeParams[$scope.currentStore.name]);
                    if(store.pagination){
                        params.page = store.pagination.page = page || store.pagination.page;
                        params.size = store.pagination.size;
                    }
                    $q.proxy(store.getDataList(params)).then(function (result) {
                        if(store.pagination){
                            store.datas = result['items'];
                            store.pagination.totalSize = result['total_count'];
                        }else{
                            store.datas = !result ? [] : (angular.isArray(result) ? result : [result]);
                        }
                    }, prompter.errorIf()).finally(prompter.wait('正在加载...', false));
                };

                $scope.select = function(data){
                    if(!$scope.currentStore) return;
                    $scope.selectedData = data;
                    fireSelectChange();
                };

                $scope.preview = function(data){
                    console.log(data);
                };

                function prepareUpload(){
                    if(!$scope.currentStore || $scope.currentStore.uploadEnabled!==true){
                        for(var i=0;i<$scope.stores.length;i++){
                            if($scope.stores[i].uploadEnabled === true){
                                $scope.currentStore = $scope.stores[i];
                            }
                        }
                    }
                }
                function checkFile(item){
                    var deferred=$q.defer();
                    deferred.resolve();
                    return deferred.promise;
                }
                $scope.uploadConfig = {
                    filters: $scope.assetType.uploadFilters,
                    onAdded: function(item){
                        prepareUpload();
                        item.promise = checkFile(item);
                        item.promise.then(function(){
                            item.writer = $scope.currentStore.fileWriter && function (item, file) {
                                return $scope.currentStore.fileWriter(file);
                            };
                            item.options = $scope.currentStore.uploadOptions;
                            $scope.currentStore.uploadItems.push(item);
                        },function(error){
                            prompter.message(error);
                        });
                    },
                    onUploaded: function(item){
                        try{
                            var data = $scope.currentStore.processUploadResponse(item.response, type, storeParams && storeParams[$scope.currentStore.name]);
                            data && $scope.currentStore.datas.unshift(data) && $scope.select(data);
                        }catch(e){
                            console.error('解析上传结果发生错误：' + e);
                        }
                        item.remove();
                    },
                    onError: function(item){
                        //item.remove();
                    },
                    onRemove: function(item){
                        for(var i=0;i<$scope.currentStore.uploadItems.length;i++){
                            if(item == $scope.currentStore.uploadItems[i]){
                                $scope.currentStore.uploadItems.splice(i,1);
                            }
                        }
                    }
                };

                $scope.switchStore = function (store) {
                    $scope.currentStore = store;
                    if(!store) return;
                    $scope.doSearch();
                };
                $timeout(function(){
                    $scope.switchStore($scope.stores[0]);
                },0);
            }]
        }, ['slides']);
    }
    return ResourceExplorer;
});