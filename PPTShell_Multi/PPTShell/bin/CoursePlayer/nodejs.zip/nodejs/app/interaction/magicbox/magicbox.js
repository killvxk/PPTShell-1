/**
 *
 */
define(['app', 'magicbox/directive/magicbox.directive'
], function (app) {
    'use strict';
    app.controller('magicbox_ctrl', [
        '$scope', 'skin_service', '$stateParams', 'CustomEditorService', 'CharsetService', 'UserDataService', '$rootScope', "$filter", "$timeout",
        function ($scope, skin_service, $stateParams, CustomEditorService, CharsetService, UserDataService, $rootScope, $filter, $timeout) {
            //常量定义
            var DIRECTION = {
                HORIZONTAL: "horizontal",
                VERTICAL: "vertical"
            };
            $scope.LANGUAGE = {
                CHINESE: "chinese",
                ENGLISH: "english"
            };
            //最大行列
            var MAX_WIDTH = 10, MAX_HEIGHT = 10;


            $scope.errorModel = {};
            $scope.model = {
                "title": "",         //标题
                "skin": {
                    code: "wood",
                    css_url: "${ref-path}/edu/esp/preparecustomeditor/magicbox/wood/css/wood.css",
                    name: $filter('translate')('magicbox.muwen'),
                    package_url: "${ref-path}/edu/esp/preparecustomeditor/magicbox/wood"
                },
                "timer": {
                    "timer_type": "countdown",  //计时器类型: ["sequence", "countdown"]
                    "time_minute": "1",    //倒计时初始设置-分钟，timer_type="countdown"时有效
                    "time_second": "0"     //倒计时初始设置-秒，timer_type="countdown"时有效
                },
                border: {"width": 5, "height": 5},
                words: [],
                chars: []
            };

            var loadingData = function (id) {
                $scope.isloadingData = true;
                CustomEditorService.getQuestionInfoById(id)
                    .then(function (rtnData) {
                        if (!rtnData) {
                            $scope.errorModel.errorText = $filter('translate')('magicbox.unvalidno');
                        } else {
                            if (rtnData.skin.code != '') {
                                $scope.model = $scope.decodeData(rtnData);
                                skin_service.set_skin_by_code($scope.model.skin.code, 'v1');
                            } else {

                                $scope.showGuide = true;
                                $scope.model.id = rtnData.id;
                                skin_service.set_skin_by_code($scope.model.skin.code, 'v1');
                            }
                            $scope.errorModel.errorText = "";
                            $scope.isloadingData = false;

                            setValues(false);
                        }
                    }, function (error) {
                        $scope.errorModel.errorText = $filter('translate')('magicbox.get_title_error');
                    })
            };

            $scope.wordTips = []; //提示
            $scope.rows = [];     //单元格
            var isHorizontal = function (direction) {
                return direction == DIRECTION.HORIZONTAL;
            };

            var isNotEmptyArray = function (array) {
                return $.isArray(array) && array.length > 0;
            };

            var mapKey = function (x, y) {
                return x + "&" + y;
            };

            $scope.typebox = "largeBox";

            var setValues = function (isNew) {
                if (isNew) {
                    //单元格
                    var rowNum = Math.min($scope.model.border.height, MAX_HEIGHT);
                    var colNum = Math.min($scope.model.border.width, MAX_WIDTH);
                    var cols;
                    for (var i = 1; i <= rowNum; i++) {
                        $scope.rows.push((cols = []));
                        for (var j = 1; j <= colNum; j++) {
                            cols.push({
                                x: i,
                                y: j,
                                tipsLinked: []
                            });
                        }
                    }
                } else {
                    //判断语言
                    $scope.language = CharsetService.isChineseChar($scope.model.chars[0]) ? $scope.LANGUAGE.CHINESE : $scope.LANGUAGE.ENGLISH;

                    //单元格
                    var rowNum = Math.min($scope.model.border.height, MAX_HEIGHT);
                    var colNum = Math.min($scope.model.border.width, MAX_WIDTH);
                    var cols, charIndex = 0;
                    for (var i = 1; i <= rowNum; i++) {
                        $scope.rows.push((cols = []));
                        for (var j = 1; j <= colNum; j++) {
                            cols.push({
                                x: i,
                                y: j,
                                char: $scope.model.chars.length > charIndex ? $scope.model.chars[charIndex++] : "",
                                tipsLinked: []
                            });
                        }
                    }
                    adjustSize(rowNum > colNum ? rowNum : colNum);
                    //提示
                    angular.forEach($scope.model.words, function (item, index) {
                        var tip = angular.extend(item);
                        $scope.wordTips.push(tip);
                        tip.boxesLinked = [];

                        //提示、单词双向关联
                        for (var i = 0; i < tip.word.length; i++) {
                            if (isHorizontal(tip.direction)) {
                                var box = $scope.rows[tip.x - 1][tip.y - 1 + i];
                                tip.boxesLinked.push(box);
                                box.tipsLinked.push(tip);

                                $scope.rows[item.x - 1][item.y - 1].horizontalIndex = index + 1;
                            } else {
                                var box = $scope.rows[tip.x - 1 + i][tip.y - 1];
                                tip.boxesLinked.push(box);
                                box.tipsLinked.push(tip);

                                $scope.rows[item.x - 1][item.y - 1].verticalIndex = index + 1;
                            }
                        }
                    });
                }
            };

            //入口
            if (!$stateParams.id) {
                //新增
                $scope.showGuide = true;
                skin_service.set_skin_by_code($scope.model.skin.code, 'v1');
                setValues(true);
            } else {
                //修改
                $scope.showGuide = false;
                loadingData($stateParams.id);
            }

            //选择语言模式
            $scope.setQuestionLang = function (language) {
                $scope.showGuide = false;
                $scope.language = language;
            };

            $scope.$on('changgedSkin', function () {
                $rootScope.scaleHtml();
            });

            //数据验证
            $scope.validPostData = function () {
                var modelData = $scope.model;
                if ($.trim(modelData.title) == '') {
                    $scope.errorModel.errorText = $filter('translate')('magicbox.no_title');
                } else {
                    var isOk = true;
                    if ($scope.wordTips.length < 3) {
                        $scope.errorModel.errorText = $filter('translate')('magicbox.least_tips');
                        isOk = false;
                    } else {
                        $.each($scope.wordTips, function (index, tip) {
                            if (!tip.hint || tip.hint.length == 0) {
                                $scope.errorModel.errorText = $filter('translate')('magicbox.empty_tip');
                                tip.actived = true;
                                focusElement($(".com_m_sidecon li input")[index]);
                                isOk = false;

                                return false;
                            }
                        });

                        if (isOk) {
                            isOk = !checkDuplicateAnswer();
                        }
                    }

                    return isOk;
                }
            };

            $scope.encodeData = function (model) {
                //系统自动填充空白格
                autoFillBoxes();

                var newModel = angular.copy(model);
                newModel.title = window.customHtmlEncode(newModel.title);
                newModel.border.width = $scope.rows[0].length;
                newModel.border.height = $scope.rows.length;

                //chars
                newModel.words = [];
                newModel.chars = [];
                angular.forEach($scope.rows, function (row) {
                    angular.forEach(row, function (col) {
                        newModel.chars.push(col.char);
                    });
                });

                //words
                angular.forEach($scope.wordTips, function (tip) {
                    newModel.words.push({
                        x: tip.x,
                        y: tip.y,
                        word: tip.word,
                        hint: tip.hint,
                        direction: tip.direction
                    });
                });

                return newModel;
            };

            $scope.decodeData = function (model) {
                var newModel = angular.copy(model);
                newModel.title = window.customHtmlDecode(newModel.title);
                angular.forEach(newModel.words, function (item) {
                    item.hint = window.customHtmlDecode(item.hint);
                });

                return newModel;
            };

            //重复答案检测
            var timer, interval;

            function checkDuplicateAnswer() {
                angular.forEach($scope.wordTips, function (item, index) {
                    item.selected = false;
                });
                angular.forEach($scope.rows, function (row) {
                    angular.forEach(row, function (col) {
                        col.selectedH = col.selectedV = col.duplicated = false;
                    });
                });

                var userInputWords = getUserInputWords();
                var isExisted = false;
                angular.forEach($scope.wordTips, function (item, index) {
                    if (!isExisted) {
                        var matchCount = 0, wordBoxs = [], length = item.word.length;
                        angular.forEach(userInputWords, function (userInputWord) {
                            var matchIndex = userInputWord.chars.indexOf(item.word);
                            while (matchIndex > -1) {
                                matchCount++;

                                if (isHorizontal(userInputWord.direction)) {
                                    for (var i = 0; i < length; i++) {
                                        wordBoxs.push($scope.rows[userInputWord.x][userInputWord.y + matchIndex + i]);
                                    }
                                } else {
                                    for (var i = 0; i < length; i++) {
                                        wordBoxs.push($scope.rows[userInputWord.x + matchIndex + i][userInputWord.y]);
                                    }
                                }

                                matchIndex = userInputWord.chars.indexOf(item.word, matchIndex + 1);
                            }
                        });
                        isExisted = matchCount > 1;

                        //存在重复答案!
                        if (isExisted) {
                            $scope.tipOnOver(item);
                            $scope.errorModel.errorText = $filter('translate')('magicbox.duplicate_answer');

//            				angular.forEach(wordBoxs, function(box){ box.duplicated = true; });
                            $timeout.cancel(timer);
                            clearInterval(interval);
                            interval = setInterval(function () {
                                if (wordBoxs[0].duplicated) {
                                    $scope.$apply(function () {
                                        angular.forEach(wordBoxs, function (box) {
                                            box.duplicated = false;
                                        });
                                    });
                                } else {
                                    $scope.$apply(function () {
                                        angular.forEach(wordBoxs, function (box) {
                                            box.duplicated = true;
                                        });
                                    });
                                }
                            }, 300);

                            timer = $timeout(function () {
                                clearInterval(interval);
                                angular.forEach(wordBoxs, function (box) {
                                    box.duplicated = false;
                                });
                            }, 2000);
                        }
                    }
                });

                return isExisted;
            }

            //获取用户输入的单词或词语
            function getUserInputWords() {
                var userInputWords = [], tempWord, cell;
                var rowNum = $scope.rows.length, colNum = $scope.rows[0].length;

                //横向
                for (var i = 0; i < rowNum; i++) {
                    tempWord = {direction: DIRECTION.HORIZONTAL, chars: ""};
                    for (var j = 0; j < colNum; j++) {
                        cell = $scope.rows[i][j];

                        if (cell.char) {
                            if (!tempWord.chars) {
                                tempWord.x = i;
                                tempWord.y = j;
                            }

                            tempWord.chars += cell.char;
                        } else {
                            if (tempWord.chars && tempWord.chars.length > 1) {
                                userInputWords.push(tempWord);
                            }

                            tempWord = {direction: DIRECTION.HORIZONTAL, chars: ""};
                        }
                    }

                    if (tempWord.chars && tempWord.chars.length > 1) {
                        userInputWords.push(tempWord);
                    }
                }

                //纵向
                for (var j = 0; j < colNum; j++) {
                    tempWord = {direction: DIRECTION.VERTICAL, chars: ""};
                    for (var i = 0; i < rowNum; i++) {
                        cell = $scope.rows[i][j];

                        if (cell.char) {
                            if (!tempWord.chars) {
                                tempWord.x = i;
                                tempWord.y = j;
                            }

                            tempWord.chars += cell.char;
                        } else {
                            if (tempWord.chars && tempWord.chars.length > 1) {
                                userInputWords.push(tempWord);
                            }

                            tempWord = {direction: DIRECTION.VERTICAL, chars: ""};
                        }
                    }

                    if (tempWord.chars && tempWord.chars.length > 1) {
                        userInputWords.push(tempWord);
                    }
                }

                return userInputWords;
            }

            /* ============================ 填字区操作  ============================ */
            /* 按下鼠标并滑动，选择需要提示的单词或语句  */
            var isMouseDown = false, slidingDirection, startBox, boxesSelected;
            $scope.mousedown = function ($event) { //需要解决与click事件的冲突
                var coordinate = getBoxCoordinate($event.target);
                if (coordinate && coordinate.x && coordinate.y) {
                    startBox = $scope.rows[coordinate.x - 1][coordinate.y - 1];

                    if (startBox.char) {
                        isMouseDown = true;
                        boxesSelected = [];

                        slidingDirection = null;
                        startBox.forNewtipH = true;

                        if ($.inArray(startBox, boxesSelected) <= -1) {
                            boxesSelected.push(startBox);
                        }
                    }
                }
            };

            //单元格 鼠标滑过事件
            $scope.mouseover = function ($event) {
                var coordinate = getBoxCoordinate($event.target);
                if (isMouseDown) {
                    if (slidingDirection == null && boxesSelected.length > 1) { //判断用户滑动方向
                        if (boxesSelected[0].x == boxesSelected[1].x) {
                            slidingDirection = DIRECTION.HORIZONTAL;
                        } else if (boxesSelected[0].y == boxesSelected[1].y) {
                            slidingDirection = DIRECTION.VERTICAL;
                        } else {
                            stopSliding(true);

                            return false;
                        }
                    }

                    if (coordinate && coordinate.x && coordinate.y) {
                        var box = $scope.rows[coordinate.x - 1][coordinate.y - 1];
                        //判断当前滑动到的单元格是否偏离了方向
                        if (!box.char ||
                            (slidingDirection != null && !onRightDirection(slidingDirection, boxesSelected[boxesSelected.length - 1], box))) {
                            stopSliding();
                        } else {
                            selectBox(box);
                        }
                    } else {
                        stopSliding();

                        angular.forEach(boxesSelected, function (box) {
                            box.forNewtipH = box.forNewtipV = false;
                        });
                    }
                }

                //高亮显示单元格关联的提示
                if (!isMouseDown && coordinate && coordinate.x && coordinate.y) {
                    var box = $scope.rows[coordinate.x - 1][coordinate.y - 1];
                    if (isNotEmptyArray(box.tipsLinked)) {
                        angular.forEach(box.tipsLinked, function (tip) {
                            tip.selected = true;

                            angular.forEach(tip.boxesLinked, function (box) {
                                if (isHorizontal(tip.direction)) {
                                    box.selectedH = true;
                                } else {
                                    box.selectedV = true;
                                }
                            });
                        });
                    }
                }
            };

            //单元格 鼠标放开事件
            $scope.mouseup = function ($event) {
                if (isMouseDown) {
                    var coordinate = getBoxCoordinate($event.target);
                    selectBox($scope.rows[coordinate.x - 1][coordinate.y - 1]);

                    stopSliding();
                }
            };

            //单元格 鼠标离开事件
            $scope.mouseleave = function ($event, item) {
                if (isNotEmptyArray(item.tipsLinked)) {
                    angular.forEach(item.tipsLinked, function (tip) {
                        tip.selected = false;
                        if (tip.chars) tip.actived = false;

                        angular.forEach(tip.boxesLinked, function (box) {
                            box.selectedH = false;
                            box.selectedV = false;

                            if (!isMouseDown) {
                                box.forNewtipH = box.forNewtipV = false;
                            }
                        });
                    });
                }
            };

            //聚焦到元素
            function focusElement(element, immediate) {
                if (element) {
                    if (immediate) {
                        element.focus();
                    } else {
                        $timeout(function () {
                            element.focus();
                        }, 100);
                    }
                }
            }

            //获取单元格坐标
            function getBoxCoordinate(target) {
                var $box;
                if (angular.uppercase(target.tagName) == "DIV") {
                    $box = $(target);
                } else {
                    $box = $(target).parents("div:first");
                }

                if ($box.hasClass("wordBox") && !$box.hasClass("delete")) {
                    return {x: $box.attr("boxX"), y: $box.attr("boxY")};
                }

                return null;
            }

            //判断选择单元格过程中是否偏离原来的方向，如横向跨行、纵向跨列
            function onRightDirection(direction, boxSrc, boxDest) {
                return isHorizontal(direction) ? boxSrc.x == boxDest.x : boxSrc.y == boxDest.y;
            }

            //选择单元格
            function selectBox(box) {
                if ($.inArray(box, boxesSelected) <= -1) {
                    if (slidingDirection != null) {
                        if (isHorizontal(slidingDirection)) {
                            var startY = boxesSelected[boxesSelected.length - 1].y;
                            for (var i = startY; i < box.y; i++) { //弥补鼠标滑过却没有被触发mouseover的单元格
                                var box = $scope.rows[box.x - 1][i];
                                box.forNewtipH = true;
                                boxesSelected.push(box);
                            }
                        } else {
                            var startX = boxesSelected[boxesSelected.length - 1].x;
                            for (var i = startX; i < box.x; i++) { //弥补鼠标滑过却没有被触发mouseover的单元格
                                var box = $scope.rows[i][box.y - 1];

                                startBox.forNewtipH = false;
                                startBox.forNewtipV = true;
                                box.forNewtipV = true;

                                boxesSelected.push(box);
                            }
                        }
                    } else {
                        box.forNewtipH = true;
                        boxesSelected.push(box);

                        if (slidingDirection == null && boxesSelected.length > 1) {
                            if (boxesSelected[0].x == boxesSelected[1].x) {
                                slidingDirection = DIRECTION.HORIZONTAL;
                            } else if (boxesSelected[0].y == boxesSelected[1].y) {
                                slidingDirection = DIRECTION.VERTICAL;

                                startBox.forNewtipH = false;
                                startBox.forNewtipV = true;
                                box.forNewtipH = false;
                                box.forNewtipV = true;
                            }
                        } else {
                            stopSliding(true);
                        }
                    }
                }
            }

            //结束单元格选择
            function stopSliding(cancel) {
                isMouseDown = false;

                if (cancel) {
                    angular.forEach(boxesSelected, function (box) {
                        box.forNewtipH = box.forNewtipV = false;
                    });
                } else {
                    if (boxesSelected.length < 2) { //Click Event
                        startBox.forNewtipH = startBox.forNewtipV = false;
                    } else {
                        var endBox = boxesSelected[boxesSelected.length - 1];
                        addTip(startBox.x == endBox.x ? DIRECTION.HORIZONTAL : DIRECTION.VERTICAL,
                            boxesSelected);
                    }
                }
            }

            //获取当前选中单元格中的第一个单元格
            function getBeginBox(direction, boxesSelected) {
                var boxFirst = boxesSelected[0];
                var boxLast = boxesSelected[boxesSelected.length - 1];

                if (isHorizontal(direction)) {
                    return boxLast.y > boxFirst.y ? boxFirst : boxLast;
                } else {
                    return boxLast.x > boxFirst.x ? boxFirst : boxLast;
                }
            }

            //单个单元格重复定义同向提示检测
            function checkDuplicateTips(direction, boxesSelected) {
                var isValid = true;
                var wordsSelected = "";
                if (isHorizontal(direction)) {
                    angular.forEach(boxesSelected, function (box) {
                        wordsSelected += box.char;
                        if (isNotEmptyArray(box.tipsLinked)) {
                            angular.forEach(box.tipsLinked, function (tip) {
                                if (isHorizontal(tip.direction)) {
                                    $scope.errorModel.errorText = $filter('translate')('magicbox.duplicate_tips_onbox');

                                    isValid = false;
                                    return false;
                                }
                            });
                        }
                    });
                } else {
                    angular.forEach(boxesSelected, function (box) {
                        wordsSelected += box.char;
                        if (isNotEmptyArray(box.tipsLinked)) {
                            angular.forEach(box.tipsLinked, function (tip) {
                                if (!isHorizontal(tip.direction)) {
                                    $scope.errorModel.errorText = $filter('translate')('magicbox.duplicate_tips_onbox');

                                    isValid = false;
                                    return false;
                                }
                            });
                        }
                    });
                }

                if (isValid) {
                    angular.forEach($scope.wordTips, function (tip) {
                        if (tip.word == wordsSelected) {
                            $scope.errorModel.errorText = $filter('translate')('magicbox.duplicate_word');

                            isValid = false;
                            return false;
                        }
                    });
                }

                if (!isValid) {
                    angular.forEach(boxesSelected, function (box) {
                        box.forNewtipH = box.forNewtipV = false;
                    });
                }

                return isValid;
            }

            //新建提示
            function addTip(direction, boxesSelected) {
                if (!checkDuplicateTips(direction, boxesSelected)) return false;

                var beginBox = getBeginBox(direction, boxesSelected);
                var newTip = {
                    actived: true,
                    x: beginBox.x,
                    y: beginBox.y,
                    word: "",
                    direction: direction,
                    boxesLinked: boxesSelected
                };
                angular.forEach(boxesSelected, function (box) {
                    box.tipsLinked.push(newTip);
                    newTip.word += box.char;
                });

                $scope.wordTips.push(newTip);
                if (isHorizontal(direction)) {
                    beginBox.horizontalIndex = $scope.wordTips.length;
                } else {
                    beginBox.verticalIndex = $scope.wordTips.length;
                }

                $timeout(function () {
                    focusElement($('.com_m_sidecon li:last-child input'), true);
                }, 100);
            }

            //聚焦单元格
            function focusWordBox(wordBox) {
                if (currentWordBox != null) currentWordBox.actived = false;
                wordBox.actived = true;
                currentWordBox = wordBox;

                focusElement($($(".wordboard .wordshow")[wordBox.x - 1]).find("input")[wordBox.y - 1]);
            }

            //扩展单元格
            function extendsWordBox(direction, fromBox, boxNum, chars) {
                if (isHorizontal(direction)) { //扩展列
                    for (var i = 1; i <= boxNum; i++) {
                        angular.forEach($scope.rows, function (row, index) {
                            row.push({
                                x: index + 1,
                                y: fromBox.y + i,
                                tipsLinked: []
                            });
                        });

                        if (chars && chars.length >= i) {
                            $scope.rows[fromBox.x - 1][fromBox.y + i - 1].char = chars.charAt(i - 1);
                        }
                    }
                    adjustSize($scope.rows[0].length > $scope.rows.length ? $scope.rows[0].length : $scope.rows.length);
                    $timeout(function () {
                        focusWordBox($scope.rows[fromBox.x - 1][fromBox.y + boxNum - 1]);
                    }, 100);
                } else { //扩展行
                    var cols = $scope.rows[0].length, newRow;
                    for (var i = 1; i <= boxNum; i++) {
                        newRow = [];
                        for (var j = 0; j < cols; j++) {
                            newRow.push({
                                x: fromBox.x + i,
                                y: j + 1,
                                tipsLinked: []
                            });
                        }
                        $scope.rows.push(newRow);

                        if (chars && chars.length >= i) {
                            $scope.rows[fromBox.x + i - 1][fromBox.y - 1].char = chars.charAt(i - 1);
                        }
                    }
                    adjustSize($scope.rows[0].length > $scope.rows.length ? $scope.rows[0].length : $scope.rows.length);
                    $timeout(function () {
                        focusWordBox($scope.rows[fromBox.x + boxNum - 1][fromBox.y - 1]);
                    }, 100);
                }
            }

            function adjustSize(num) {
                if (num < 7) {
                    $scope.typebox = "largeBox";
                } else if (num >= 7 && num < 9) {
                    $scope.typebox = "normalBox";
                } else if (num >= 9 && num <= 11) {
                    $scope.typebox = "smallBox";
                }
            }

            //填字区操作 - 单元格激活
            var currentWordBox = null;
            $scope.activeWordBox = function (item, $event) {
                if (!item.actived) {
                    if (currentWordBox != null) currentWordBox.actived = false;
                    item.actived = true;
                    currentWordBox = item;

                    $scope.textDirection = DIRECTION.HORIZONTAL; //书写方向，默认从左到右
                    if (angular.uppercase($event.target.tagName) == "DIV") {
                        focusElement($($event.target).find("input"));
                    } else {
                        focusElement($($event.target).parents("div:first").find("input"));
                    }
                }
            };

            //填字区操作 - 上下左右移动、回车
            $scope.keydownOnBoard = function ($event) {
                if ($event.keyCode == 229 || $event.keyCode == 197) { //中文输入法
                    isChineseInput = true;
                    shouldIgnoreTextChange = false;
                } else {
                    isChineseInput = false;
                    if (currentWordBox) {
                        switch ($event.keyCode) {
                            case 8: //回退按钮
                                if(!currentWordBox.char && currentWordBox.y > 1) {
                                    focusWordBox($scope.rows[currentWordBox.x - 1][currentWordBox.y - 2]);
                                }
                                break;
                            case 13: //回车键 切换书写方向为从上到下
                                $scope.textDirection = DIRECTION.VERTICAL; //书写方向，默认从上到下
                                break;
                            case 37: //LEFT
                                if (currentWordBox.y > 1) {
                                    focusWordBox($scope.rows[currentWordBox.x - 1][currentWordBox.y - 2]);
                                }
                                break;
                            case 38: //UP
                                if (currentWordBox.x > 1) {
                                    focusWordBox($scope.rows[currentWordBox.x - 2][currentWordBox.y - 1]);
                                }
                                break;
                            case 39: //RIGHT
                                if (currentWordBox.y < $scope.rows[0].length) {
                                    focusWordBox($scope.rows[currentWordBox.x - 1][currentWordBox.y]);
                                } else if (currentWordBox.y < MAX_WIDTH) { //扩展列
                                    extendsWordBox(DIRECTION.HORIZONTAL, currentWordBox, 1)
                                }

                                break;
                            case 40: //DOWN
                                if (currentWordBox.x < $scope.rows.length) {
                                    focusWordBox($scope.rows[currentWordBox.x][currentWordBox.y - 1]);
                                } else if (currentWordBox.x < MAX_HEIGHT) { //扩展行
                                    extendsWordBox(DIRECTION.VERTICAL, currentWordBox, 1)
                                }
                                break;
                            default:
                        }
                    }
                }
            };

            /**
             * 填字区操作 - 单元格输入内容
             *
             * c) 每个单元格内只能输入一个字母或汉字，当从输入法中接收到一串字符时，将其拆散按书写方向排列
             * d) 在当前单元格输入内容后，系统按当前书写顺序自动激活下一个单元格，当输入的矩阵空间不足时，自动按书写方向向右或向下增行/列
             *
             */
            var isChineseInput = false, shouldIgnoreTextChange = false; //中文输入标识
            function shouldIgnoreChange(item) {
                /**
                 * 单元格，在中文输入下，会触发两次change事件
                 *  第一次，是拼音，第二次，是拼音对应的中文，所以：
                 *  1. 英文模式，对第一次做响应
                 *  2. 中文模式，对第二次做响应
                 */
                if(isChineseInput) {
                    if($scope.language == $scope.LANGUAGE.CHINESE) { //中文模式
                        isChineseInput = false;
                        item.char = ""; //防止用户直接回车，因为回车不会触发第二次change事件

                        return true;
                    } else {  //英文模式
                        if(shouldIgnoreTextChange) {
                            var theChars = CharsetService.getAlphabets(item.char).toLowerCase();
                            if(theChars.length > 0) {
                                item.char = theChars.charAt(0);
                            }

                            return true;
                        }
                    }
                }

                return false;
            }
            $scope.changeOnBox = function ($event, item) {
                if(shouldIgnoreChange(item)) return;
                shouldIgnoreTextChange = true;

                var chars;
                if ($scope.language == $scope.LANGUAGE.CHINESE) { //语言为中文
                    chars = CharsetService.getChineses(item.char);
                } else {
                    chars = CharsetService.getAlphabets(item.char).toLowerCase();
                }

                if (isHorizontal($scope.textDirection)) { //左右方向书写
                    var colNum = $scope.rows[0].length, fromBox = item;
                    if (chars.length > 0) {
                        if (item.y == MAX_WIDTH) { //最后一列
                            item.char = chars.charAt(chars.length - 1);
                        } else {
                            //当从输入法中接收到一串字符时，将其拆散按书写方向排列
                            item.char = chars.charAt(0);
                            for (var i = 0; i < chars.length - 1; i++) {
                                if (item.y + i < colNum) {
                                    fromBox = $scope.rows[item.x - 1][item.y + i];
                                    fromBox.char = chars.charAt(i + 1);
                                }
                            }

                            //当输入的矩阵空间不足时，自动按书写方向向右或向下增行/列
                            if (item.y + chars.length > colNum && colNum < MAX_WIDTH) {
                                var extendNum = Math.min(MAX_WIDTH - colNum, item.y + chars.length - colNum - 1);
                                extendsWordBox($scope.textDirection, fromBox, extendNum, chars.substring(fromBox.y - item.y + 1));
                            } else if (fromBox != item) {
                                focusWordBox(fromBox);
                            }
                        }
                    } else { //上下方向书写
                        item.char = "";
                    }
                } else {
                    var rowNum = $scope.rows.length, fromBox = item;
                    if (chars.length > 0) {
                        if (item.x == MAX_HEIGHT) { //最后一行
                            item.char = chars.charAt(chars.length - 1);
                        } else {
                            //当从输入法中接收到一串字符时，将其拆散按书写方向排列
                            item.char = chars.charAt(0);
                            for (var i = 0; i < chars.length - 1; i++) {
                                if (item.x + i < rowNum) {
                                    fromBox = $scope.rows[item.x + i][item.y - 1];
                                    fromBox.char = chars.charAt(i + 1);
                                }
                            }

                            //当输入的矩阵空间不足时，自动按书写方向向右或向下增行/列
                            if (item.x + chars.length > rowNum && rowNum < MAX_HEIGHT) {
                                var extendNum = Math.min(MAX_HEIGHT - rowNum, item.x + chars.length - rowNum - 1);
                                extendsWordBox($scope.textDirection, fromBox, extendNum, chars.substring(fromBox.x - item.x + 1));
                            } else if (fromBox != item) {
                                focusWordBox(fromBox);
                            }
                        }
                    } else {
                        item.char = "";
                    }
                }

                //当前单元格关联的提示单词可能需要变更
                angular.forEach($scope.wordTips, function (tip) {
                    var word = "";
                    angular.forEach(tip.boxesLinked, function (box) {
                        word += box.char;
                    });

                    tip.word = word;
                });
            };

            //单元格失去焦点：如果已关联提示，并且将单元格内容清空，则删除关联提示
            $scope.blurOnBox = function ($event, item) {
                item.actived = false;
                if (!item.char || item.char.length == 0) {
                    item.horizontalIndex = null;
                    item.verticalIndex = null;

                    var length = item.tipsLinked.length;
                    for (var i = 0; i < length; i++) {
                        var tip = item.tipsLinked[0];
                        deleteTip(tip, $.inArray(tip, $scope.wordTips));
                    }
                }
            };

            //删除行
            $scope.removeRow = function ($event, item, $index) {
                //删除关联的提示
                angular.forEach($scope.rows[$index], function (box) {
                    var length = box.tipsLinked.length;
                    for (var i = 0; i < length; i++) {
                        var tip = box.tipsLinked[0];

                        var tipIndex = $.inArray(tip, $scope.wordTips);
                        if (tipIndex > -1) {
                            deleteTip(tip, tipIndex);
                        }
                    }
                });

                //删除行
                var row = $scope.rows.splice($index, 1)[0];
                adjustSize($scope.rows.length > $scope.rows[0].length ? $scope.rows.length : $scope.rows[0].length);

                updateXY();
            };

            //删除列
            $scope.removeCol = function ($event, $index) {
                //删除关联的提示
                angular.forEach($scope.rows, function (row) {
                    var box = row[$index];
                    var length = box.tipsLinked.length;
                    for (var i = 0; i < length; i++) {
                        var tip = box.tipsLinked[0];
                        var tipIndex = $.inArray(tip, $scope.wordTips);
                        if (tipIndex > -1) {
                            deleteTip(tip, tipIndex);
                        }
                    }
                });

                //删除列
                angular.forEach($scope.rows, function (row) {
                    row.splice($index, 1);
                });

                adjustSize($scope.rows.length > $scope.rows[0].length ? $scope.rows.length : $scope.rows[0].length);

                updateXY();
            };

            //清空填字区、提示区
            $scope.clearWords = function () {
                $scope.wordTips = [];
                angular.forEach($scope.rows, function (row, indexX) {
                    angular.forEach(row, function (col, indexY) {
                        col.char = "";
                        col.tipsLinked = [];
                        col.horizontalIndex = null;
                        col.verticalIndex = null;
                    });
                });
            };

            //更新单元格的XY坐标、更新提示的XY
            function updateXY() {
                //更新单元格的XY坐标
                angular.forEach($scope.rows, function (row, indexX) {
                    angular.forEach(row, function (col, indexY) {
                        col.x = indexX + 1;
                        col.y = indexY + 1;
                    });
                });

                //更新提示的XY
                angular.forEach($scope.wordTips, function (tip, index) {
                    var beginBox = getBeginBox(tip.direction, tip.boxesLinked);
                    tip.x = beginBox.x;
                    tip.y = beginBox.y;
                });
            }

            /**
             * 系统自动填充填字区的空白格
             * 1. 中文模式，填充的汉字必须老师未输入的
             * 2. 英语模式，填充的字母必须是小写的非元音字母
             */
            function autoFillBoxes() {
                if ($scope.language == $scope.LANGUAGE.CHINESE) {
                    //Step1. 统计老师输入的汉字
                    var userInputChars = [];
                    angular.forEach($scope.rows, function (row, indexX) {
                        angular.forEach(row, function (col, indexY) {
                            if (col.char) {
                                userInputChars.push(col.char);
                            }
                        });
                    });

                    //Step2. 逐个填充空白格
                    angular.forEach($scope.rows, function (row, indexX) {
                        angular.forEach(row, function (col, indexY) {
                            if (!col.char || col.char.length == 0) {
                                col.char = generateChinese(userInputChars);
                            }
                        });
                    });
                } else {
                    angular.forEach($scope.rows, function (row, indexX) {
                        angular.forEach(row, function (col, indexY) {
                            if (!col.char || col.char.length == 0) {
                                col.char = CharsetService.getRandomAlphabet(true).toLowerCase();
                            }
                        });
                    });
                }
            }

            //生成随机汉字，且不在userInputChars范围内
            function generateChinese(userInputChars) {
                var rdChar = CharsetService.getRandomChineseChar();
                var isExisted = ($.inArray(rdChar, userInputChars) > -1);
                while (isExisted) {
                    rdChar = CharsetService.getRandomChineseChar();
                    isExisted = ($.inArray(rdChar, userInputChars) > -1);
                }

                return rdChar;
            }

            /* ============================ 提示区操作  ============================ */
            //提示区操作 - 提示信息输入框激活
            var currentTipBox;
            $scope.activeTipBox = function (item, $event) {
                if (currentTipBox) currentTipBox.actived = false;
                item.actived = true;
                currentTipBox = item;

                if (angular.uppercase($event.target.tagName) == "LI") {
                    focusElement($($event.target).find("input"));
                } else {
                    focusElement($($event.target).parents("li:first").find("input"));
                }
            };
            //提示区 操作 - 提示信息输入框失去焦点
            $scope.tipOnBlur = function (item) {
                item.actived = false;
            };
            //提示区 操作 - 提示信息鼠标MouseOver事件
            $scope.tipOnOver = function (item) {
                item.selected = true;

                angular.forEach(item.boxesLinked, function (box) {
                    if (isHorizontal(item.direction)) {
                        box.selectedH = true;
                    } else {
                        box.selectedV = true;
                    }
                });
            };
            //提示区 操作 - 提示信息鼠标MouseOut事件
            $scope.tipOnOut = function (item) {
                item.selected = false;

                angular.forEach(item.boxesLinked, function (box) {
                    if (isHorizontal(item.direction)) {
                        box.selectedH = box.forNewtipH = false;
                    } else {
                        box.selectedV = box.forNewtipV = false;
                    }
                });
            };
            //提示区操作 - 保存提示（按回车）
            $scope.saveTip = function ($event, item) {
                if ($event.keyCode == 13) {
                    item.actived = false;
                }
            };
            //提示区操作 - 移除提示
            $scope.removeTip = function ($event, tip, $index) {
                deleteTip(tip, $index);

                if ($event.stopPropagation) $event.stopPropagation();
                if ($event.preventDefault) $event.preventDefault();
                $event.cancelBubble = true;
                $event.returnValue = false;
            };
            //删除提示操作
            function deleteTip(tip, $index) {
                //Step1. 删除提示
                $scope.wordTips.splice($index, 1);

                //Step2. 删除填字区的关联项
                var matchIndex;
                angular.forEach($scope.rows, function (row) {
                    angular.forEach(row, function (col) {
                        matchIndex = $.inArray(tip, col.tipsLinked);
                        if (matchIndex > -1) {
                            col.tipsLinked.splice($.inArray(tip, col.tipsLinked), 1);
                        }

                        col.selectedH = false;
                        col.selectedV = false;
                        col.forNewTipH = false;
                        col.forNewTipV = false;
                    });
                });

                //Step3. 更新提示信息索引
                if (isHorizontal(tip.direction)) {
                    $scope.rows[tip.x - 1][tip.y - 1].horizontalIndex = null;
                } else {
                    $scope.rows[tip.x - 1][tip.y - 1].verticalIndex = null;
                }
                if ($scope.wordTips.length > $index) { //不是删除最后一个
                    angular.forEach($scope.wordTips, function (item, index) {
                        if (isHorizontal(item.direction)) {
                            $scope.rows[item.x - 1][item.y - 1].horizontalIndex = index + 1;
                        } else {
                            $scope.rows[item.x - 1][item.y - 1].verticalIndex = index + 1;
                        }
                    });
                }
            }
        }
    ]);
});
