/**
 *
 */
define(['app', 'probabilitycard/directive/probabilitycard.directive'], function (app) {
    'use strict';
    app.controller('probabilitycard_ctrl', [
        '$scope', 'skin_service', '$stateParams', 'CustomEditorService','$rootScope', '$filter',
        function ($scope, skin_service, $stateParams, CustomEditorService, $rootScope, $filter) {
        	$rootScope.moduleScope = $scope;
            $scope.errorModel = {};
            
            $scope.minCardCount = 3;
            $scope.maxCardCount = 6;
            $scope.newCardTemplate = function(initIndex) {
            	var card = { text: '', text_style: { 'font-family':'microsoft yahei', 'font-size':26, 'color':'#825318', direction:'vertical'} };
            	if(initIndex) {
            		switch(initIndex) {
            		case 1:
            			card.text = '唱歌';
            			card.hasText = true;
            			break;
            		case 2:
            			card.text = '跳舞';
            			card.hasText = true;
            			break;
            		case 3:
            			card.text = '朗诵';
            			card.hasText = true;
            			break;
            		default:
            			;
            		}
            	}
            	
            	return card;
            };
            $scope.model = {
            	"id": "",
            	"module_code": "nd_probabilitycard", // 题目类型
            	"title": "", //标题
                "skin": {
                    code: "wood",
                    css_url: "",
                    name:  $filter('translate')('probabilitycard.muwen'),
                    package_url: "${ref-path}/edu/esp/preparecustomeditor/probabilitycard/wood"
                },
                "timer": {
                    "timer_type":"sequence",  //计时器类型: ["sequence", "countdown"]
                    "time_minute":"0",    //倒计时初始设置-分钟，timer_type="countdown"时有效
                    "time_second":"0"     //倒计时初始设置-秒，timer_type="countdown"时有效
                },
                "properties": [	//模块静态数据模型
					{
						"name": "question_id",
						"display_name": "题目ID",
						"type": "string",
						"value": "",
						"is_localized": false
					},
					{
						"name": "question_url",
						"display_name": "题目内容",
						"type": "jsonFile",
						"value": "",
						"is_localized": false
					}
                ],
                "content": {
                	items: [
                	   $scope.newCardTemplate(1), 
                	   $scope.newCardTemplate(2), 
                	   $scope.newCardTemplate(3)
                	],
                	cards:[],
                	attach_info: ""
                }
            };
            
            //数据加载
            var loadingData = function(id){
            	$scope.isloadingData=true;
                CustomEditorService.getQuestionInfoById(id)
                    .then(function(rtnData){
                        if(!rtnData){
                            $scope.errorModel.errorText = $filter('translate')('probabilitycard.unvalidno');
                        }else{
                            if(rtnData.skin.code!=''){
                                $scope.model=$scope.decodeData(rtnData, true);
                            }else{
                                $scope.model.id=rtnData.id;
                                $scope.model.title=rtnData.title;
                            }
                            
                            skin_service.set_skin_by_code($scope.model.skin.code, "v1");
                            $scope.errorModel.errorText = "";
                            $scope.isloadingData=false;
                        }
                    },function(error){
                        $scope.errorModel.errorText = $filter('translate')('probabilitycard.get_title_error');
                    })
            };
            
            //入口
            if(!$stateParams.id) { //新增
                skin_service.set_skin_by_code($scope.model.skin.code, "v1");
            } else { //修改
                loadingData($stateParams.id);
            }
            
            //数据验证
            $scope.validPostData = function() {
            	var isValid = true;
            	
            	var emptyCards = [];
            	angular.forEach($scope.model.content.items, function(item, index){
            		if(!item.href && !item.text) {
            			item.isEmpty = true;
            			emptyCards.push(index + 1);
            		} else {
            			item.isEmpty = false;
            		}
            	});
            	if(emptyCards.length > 0) {
            		$scope.errorModel.errorText = $filter('translate')('probabilitycard.card_is_empty', { cardIndex: emptyCards.join(', ')});
            		isValid = false;
            	}
            	
            	
            	return isValid;
            };
            
            //数据模型 编码
            var CARD_TEMPLATE_TEXT = '<span class="text" style="${textStyle}">${text}</span>';
            var CARD_TEMPLATE_IMAGE = '<img src="${image}" alt="" class="card_bg">';
            $scope.encodeData = function(model) {
            	model.content.cards = [];
            	model.title = "";
            	model.packages = []; //addon 课件打包配置信息，上传依赖外部系统的资源文件
            	
            	var card, textStyle, image;
            	angular.forEach(model.content.items, function(item, index) {
            		card = {
            			card_number: index + 1,
            			content_text: ""
            		};
            		
            		if(item.text) {
            			var text = CARD_TEMPLATE_TEXT
            			              .replace("${text}", window.customHtmlEncode(item.text).replace(/\s/g, "&nbsp;"))
            			              .replace("${textStyle}", $("#carditem_" + index + " .text").attr("style").replace("height:", ""));
            			
            			card.content_text += text;
            			model.title += item.text + "、 ";
            		}
            		
            		if(item.href) {
            			card.content_text += CARD_TEMPLATE_IMAGE.replace("${image}", item.href);
            			model.packages.push({
            				"src": item.href,
            				"type": "file"
            			});
            		}
            		
            		model.content.cards.push(card);
            	});
            	
            	if(model.title === "") {
            		try{
            			model.title = "ND概率卡牌工具题 " + new Date().Format("yyyy-MM-dd hh:mm:ss");
            		}catch(e){}
            	}
            	
            	return model;
            };
            
            //数据模型 解码
            $scope.decodeData = function(model, isInitLoad) {
            	angular.forEach(model.content.items, function(item) {
            		if(item.actived) {
            			$scope.currentCard = item;
            			$scope.focusCurrentCardText();
            		}
            		
            		if(isInitLoad) { //初次加载
            			item.hasText = item.text || false;
            		}
            	});
            	
            	return model;
            };
            
            $scope.currentCard = null;
            $scope.selectCard = function(card) {
            	if($scope.currentCard != card) {
            		if($scope.currentCard) {
                		$scope.currentCard.actived = false;
                	} else {
                		angular.forEach($scope.model.content.items, function(item) {
                    		item.actived = false;
                    	});
                	};
                	
                	$scope.currentCard = card;
                	$scope.currentCard.actived = true;
                	$scope.focusCurrentCardText();
            	}
            };
            
            //当前卡牌的文字编辑框获取焦点
            $scope.focusCurrentCardText = function() {
            	if($scope.currentCard.hasText) {
                	var index = $.inArray($scope.currentCard, $scope.model.content.items);
        		    $("#carditem_" + index + " .text").focus();
            	}
            };
            
            //添加卡牌
            $scope.addCard = function() {
            	$scope.model.content.items.push($scope.newCardTemplate());
            };
            
            //删除卡牌
            $scope.deleteCard = function(index) {
            	if($scope.currentCard == $scope.model.content.items[index]) {
            		$scope.currentCard = null;
            	}
            	
            	$scope.model.content.items.splice(index, 1);
            };
        } 
    ]);
});
