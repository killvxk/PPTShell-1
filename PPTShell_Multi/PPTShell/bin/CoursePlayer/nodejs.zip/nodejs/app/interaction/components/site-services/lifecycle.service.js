/**
 * Created by lxq on 2015/09/18.
 */
define(['angularAMD'], function(angularAMD) {
    'use strict';

    	angularAMD.service('LifecycleService', ['RestAngularLifecycle', '$stateParams', '$filter',
		    function( RestAngularLifecycle,   $stateParams,   $filter) {
		        return {
		        	getResourceTechInfo: function(uuid) {
		                return RestAngularLifecycle("v0.6").one("assets").one(uuid + "?include=TI").get();
		            },getWordsResourceByChapterId: function(chapterId) {
		            	var URL = 'list?include=TI,LC&rid=ad7e5fb6-ca4c-4016-ac09-b28b0574eb86&rid=89632d66-51f4-4c62-ba02-67fcff12452e&rid=850eddf5-7f09-4309-bdef-8cd35096439f&rid=857d955e-3683-428e-a46f-d5c27ac5e70a&rid=0fce38c0-5729-4c31-8435-a1f94b6667c7&rid=81db230e-d448-40fb-ac4f-61067e21b574&rid=42b26b43-e33c-422e-8691-642673549340&rid=064c7d3e-5d02-47d5-a82e-f343075039f0&rid=850f96ad-dd5b-4e12-a4fe-e4b860db6fd6&rid=8f62e53d-e90e-4689-a03c-b92efc3df7a1' ;
		            	return RestAngularLifecycle("v0.6").one("assets").one(URL).get();
		            	//var url=URL.replace(/{{charpter_id}}/g,chapterId);
		                //return RestAngularLifecycle("v0.6").one("coursewareobjects").one('actions').one(url).get();
		            },
		            /**
		             * 获取词汇卡信息 - 接口都还没有测试，因为这个接口都还没有上
		             * 如果有章节的话，就获取本章节下面的所有英语词汇
		             * 如果没有传章节，而传搜索单词的话，就在所有章节下面搜索
		             *
		             * @param chapterId 章节ID
		             * @param searchWords 搜索单词
		             */
		            'getEnglishVocabularyCards' : function(chapterId, searchWords, limit){
		            	//默认获取200个词汇
		            	limit = limit || '(0, 200)';

		            	if(chapterId) {
		            		//获取本章节下面的所有英语词汇
		            		var param = 'search?include=TI,EDU,LC,CG&limit='+ limit +'&&relation=chapters/'+ chapterId +'/wq';
		            		return RestAngularLifecycle("v0.6").one("vocabularies").one('actions').one(param).get();
		            	} else if(searchWords) {
		            		//在所有章节下面搜索
		            		var param = 'search?include=TI,EDU,LC,CG&limit='+ limit +'&words='+ searchWords +'&';
		            		return RestAngularLifecycle("v0.6").one("vocabularies").one('actions').one(param).get();
		            	} else {
		            		return false;
		            	}
		            },
					/**
					 * @param chapterId
					 * @param searchWord
					 * @param limit : (0,4)
					 * @returns {*}
					 */
					'getChineseVocabularyCards' : function(chapterId, searchWord, startIndex , count){
						//if(chapterId) {
						//获取本章节下面的所有英语词汇
						//var searchWord = '拌,草,拆,弹,掂,沸,划,鸡,鲫,夹,剪,掘,烤,露,剖,燃,塞,诵,系,溢,砸,炸,滋'
						//if( !searchWord ){
						//	var tempArr = ['list?include=TI,LC,EDU,CG,CR&coverage=RSD/workspace/ASSEMBLE&rid=40fd392f-02eb-4b18-b081-0523f70fdd81&rid=d7b95b63-8b91-4b9b-9e86-3ba4f62f8b5f&rid=fb264652-2d02-48e2-82d7-b3d74870293a&rid=b6746f44-7e47-4208-8efa-3769d49feb2e&rid=b6e48bb6-9032-4a61-a9a7-0cf85546c62a&rid=dfb9703e-b54f-46c2-a29e-0d86276df5c3&rid=b6ccf2eb-39d1-41bc-907b-3aefa982d713&rid=1b2a6836-45d7-4733-a990-c3d644769777&rid=e499f04d-2425-4941-895c-dae5e8784416&rid=1b0a8490-f05f-4ba4-9b57-afcdbd2076fc&rid=dfc4ee9d-3cee-4df7-afdf-fb11b1ea562f&rid=2061c489-86be-476e-a0d2-6858b592d539&rid=95f3dd78-a8ae-421d-8511-8ab1dc5828d9&rid=2b9c766b-a5b2-4eb0-9462-f85c2715bd1d&rid=aafc60f7-7a4b-4559-a781-dfaf7ef7af21&rid=f2103ffe-4bfc-4f1a-886a-3efdcffeb33d&rid=e36f2095-2120-4028-b619-7ac630afa08a&rid=a413a7b5-1347-4ec4-a47d-93c40b6d7fc9&rid=ee17d53d-bf8f-4f7c-ad3f-df4fc602cc1a&rid=a851367d-d0da-4182-affb-8262b94a2c52&rid=40fd392f-02eb-4b18-b081-0523f70fdd81&rid=1921e9a6-1568-4b59-9df2-b5e1908d938d' ]
						//	var param = tempArr.join('');
						//	return RestAngularLifecycle("v0.6").one("coursewareobjects").one(param).get();
						//}
						var tempArr = ['query?include=TI,LC,EDU,CG,CR&coverage=RSD/workspace/ASSEMBLE&words=',searchWord ,'&limit=(',startIndex,',',count,')&category=$RT0301' ]
						var param = tempArr.join('');
						return RestAngularLifecycle("v0.6").one("coursewareobjects").one('actions').one(param).get();
						//}
					}
		        };
		    }
    	])
});
