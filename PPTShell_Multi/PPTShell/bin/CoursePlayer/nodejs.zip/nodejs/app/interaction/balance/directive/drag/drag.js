define(['angularAMD'], function(angularAMD) {
	'use strict';
	var Common = {
		getEvent: function() { //ie/ff
			if (document.all) {
				return window.event;
			}
			func = getEvent.caller;
			while (func != null) {
				var arg0 = func.arguments[0];
				if (arg0) {
					if ((arg0.constructor == Event || arg0.constructor == MouseEvent) || (typeof(arg0) == "object" && arg0.preventDefault && arg0.stopPropagation)) {
						return arg0;
					}
				}
				func = func.caller;
			}
			return null;
		},
		getMousePos: function(ev) {
			if (!ev) {
				ev = this.getEvent();
			}
			if (ev.pageX || ev.pageY) {
				return {
					x: ev.pageX,
					y: ev.pageY
				};
			}

			if (document.documentElement && document.documentElement.scrollTop) {
				return {
					x: ev.clientX + document.documentElement.scrollLeft - document.documentElement.clientLeft,
					y: ev.clientY + document.documentElement.scrollTop - document.documentElement.clientTop
				};
			} else if (document.body) {
				return {
					x: ev.clientX + document.body.scrollLeft - document.body.clientLeft,
					y: ev.clientY + document.body.scrollTop - document.body.clientTop
				};
			}
		},
		getMousePos1: function(ev) {
			if (!ev) {
				ev = this.getEvent();
			}
		},
		getObjectPos: function(obj) {
			var offsetObject = obj.offsetParent;
			var left = obj.offsetLeft;
			var top = obj.offsetTop;
			while (offsetObject && (!offsetObject.id || offsetObject.id != "content-body")) {
				left += offsetObject.offsetLeft;
				top += offsetObject.offsetTop;
				offsetObject = offsetObject.offsetParent;
			}
			return {
				left: left,
				top: top
			};
		},
		getParent: function(obj) {
			var offsetObject = obj.offsetParent;
			while (offsetObject && (!offsetObject.id || offsetObject.id != "content-body")) {
				offsetObject = offsetObject.offsetParent;
			}
			return offsetObject;
		},
		getItself: function(id) {
			return "string" == typeof id ? document.getElementById(id) : id;
		},
		isIE: document.all ? true : false,
		setOuterHtml: function(obj, html) {
			var Objrange = document.createRange();
			var frag = Objrange.extractContents();
			Common.getParent(obj).insertBefore(frag, obj);
			Common.getParent(obj).removeChild(obj);
			obj.innerHTML = html;
			Objrange.selectNodeContents(obj);
		}
	};

	///------------------------------------------------------------------------------------------------------
	var Class = {
		create: function() {
			return function() {
				this.init.apply(this, arguments);
			}
		}
	};
	var Drag = Class.create();
	Drag.prototype = {
		init: function(element, Options) {
			//设置点击是否透明，默认不透明
			var titleBar = element[0];
			var dragDiv = element[0];
			var $dragDiv = $(dragDiv);
			if (!titleBar) return;
			if (Options) {
				this.opacity = Options.opacity ? (isNaN(parseInt(Options.opacity)) ? 100 : parseInt(Options.opacity)) : 100;
				this.keepOrigin = Options.keepOrigin ? ((Options.keepOrigin == true || Options.keepOrigin == false) ? Options.keepOrigin : false) : false;
				if (this.keepOrigin) {
					this.opacity = 50;
				}
			} else {
				this.opacity = 100, this.keepOrigin = false;
			}
			this.copyDragDiv = null;
			this.originDragDiv = null;
			this.tmpX = 0;
			this.tmpY = 0;
			this.moveable = false;
			this.callback = Options.callback;

			var dragObj = this;

			titleBar.onmousedown = function(e) {
				var ev = e || window.event || Common.getEvent();
				//只允许通过鼠标左键进行拖拽,IE鼠标左键为1 FireFox为0
				if (Common.isIE && ev.button == 1 || !Common.isIE && ev.button == 0) {} else {
					return false;
				}



				var objectPos = Common.getObjectPos(dragDiv);

				dragObj.moveable = true;

				var downPos = Common.getMousePos(ev);
				if ($(dragDiv).attr('data-type') == 'leverage' || dragDiv.id) {
					dragObj.tmpX = downPos.x - objectPos.left;
				} else {
					dragObj.tmpX = downPos.x - objectPos.left + $("#footerGoods")[0].scrollLeft;
				}
				dragObj.tmpY = downPos.y - objectPos.top;
				dragObj.orgX = downPos.x;
				dragObj.orgY = downPos.y;

				titleBar.style.cursor = "move";


				var target = angular.element(ev.target);
				if (target.hasClass("item_text")) {
					return;
				}
				//FireFox 去除容器内拖拽图片问题
				if (ev.preventDefault) {
					ev.preventDefault();
					ev.stopPropagation();
				}
				document.onmousemove = function(e) {
					var ev = e || window.event || Common.getEvent();
					var movePos = Common.getMousePos(ev);
					if (Math.abs(movePos.x - dragObj.orgX) > 5 || Math.abs(movePos.y - dragObj.orgY) > 5) {
						if (dragObj.moveable) {
							this.originDragDiv = dragDiv;
							if (!dragObj.copyDragDiv) {
								if (dragObj.keepOrigin) {
									dragObj.copyDragDiv = $(dragDiv).clone()[0];
									dragObj.copyDragDiv.style.position = "absolute";
									if ($(dragDiv).attr('data-type') == 'leverage' || dragDiv.id) {
										dragObj.copyDragDiv.style.left = objectPos.left + "px";
									} else {
										dragObj.copyDragDiv.style.left = objectPos.left - $("#footerGoods")[0].scrollLeft + "px";
									}
									dragObj.copyDragDiv.style.top = objectPos.top + "px";
									Common.getParent(dragDiv).appendChild(dragObj.copyDragDiv);
									dragObj.copyDragDiv.style.zIndex = dragObj.GetZindex() + 1;
									if (Common.isIE) {
										dragObj.copyDragDiv.setCapture();
									} else {
										window.captureEvents(Event.MOUSEMOVE);
									}
									dragObj.SetOpacity(dragObj.copyDragDiv, dragObj.opacity);
								}
							}
							dragObj.copyDragDiv.style.left = (movePos.x - dragObj.tmpX) + "px";
							dragObj.copyDragDiv.style.top = (movePos.y - dragObj.tmpY) + "px";
						}
					}
				};

				document.onmouseup = function(e) {
					if (dragObj.copyDragDiv) {
						if (dragObj.callback) dragObj.callback(e, Options.index, dragObj.copyDragDiv, dragObj.originDragDiv);

						if (dragObj.keepOrigin) {
							if (Common.isIE) {
								dragObj.copyDragDiv.outerHTML = "";
							} else {
								Common.setOuterHtml(dragObj.copyDragDiv, "");
							}
							dragObj.copyDragDiv = null;
						}
						if (dragObj.moveable) {
							titleBar.style.cursor = "default";
							dragObj.moveable = false;
							dragObj.tmpX = 0;
							dragObj.tmpY = 0;
						}
					}
					if (Common.isIE) {
						if (dragObj.copyDragDiv) dragObj.copyDragDiv.releaseCapture();
						document.onmouseup = null;
						document.onmousemove = null;
					} else {
						window.releaseEvents(Event.MOUSEMOVE);
						window.releaseEvents(Event.MOUSEUP);
						document.onmouseup = null;
						document.onmousemove = null;
					}
				};
			}
		},
		SetOpacity: function(dragDiv, n) {
			if (Common.isIE) {
				dragDiv.filters.alpha.opacity = n;
			} else {
				dragDiv.style.opacity = n / 100;
			}

		},
		GetZindex: function() {
			var maxZindex = 0;
			var divs = document.getElementsByTagName("div");
			for (var z = 0; z < divs.length; z++) {
				maxZindex = Math.max(maxZindex, divs[z].style.zIndex);
			}
			return maxZindex;
		}
	};

	function Plugin(option) {

		option = option || {};
		var $this = angular.element(this);
		var data = $this.data('my.drag');
		var options = angular.extend({}, $this.data(), typeof option == 'object' && option)
			//插件缓存
		if (!data) {
			data = new Drag($this, option);
			$this.data('my.drag', data);
		}


	}

	angularAMD.directive('drag', [

		function() {
			return {
				restrict: 'A',
				scope: {
					options: "=options",
					index: "=index"
				},
				link: function(scope, element) {
					Plugin.apply(element, [angular.extend({
						index: scope.index
					}, scope.options)]);

				}
			};
		}
	]);

});