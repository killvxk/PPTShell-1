var AddonLego_create =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _appPresenter = __webpack_require__(1);

	var _appPresenter2 = _interopRequireDefault(_appPresenter);

	exports['default'] = function () {
		return _appPresenter2['default'];
	};

	module.exports = exports['default'];

/***/ },
/* 1 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenterRun = __webpack_require__(2);

	var _presenterRun2 = _interopRequireDefault(_presenterRun);

	//import createPreview from './presenter/createPreview'

	var _presenterSetState = __webpack_require__(39);

	var _presenterSetState2 = _interopRequireDefault(_presenterSetState);

	var _presenterGetState = __webpack_require__(40);

	var _presenterGetState2 = _interopRequireDefault(_presenterGetState);

	var _presenterProjectionInitProjectionMobile = __webpack_require__(41);

	var _presenterProjectionInitProjectionMobile2 = _interopRequireDefault(_presenterProjectionInitProjectionMobile);

	var _presenterPageChange = __webpack_require__(44);

	var _presenterPageChange2 = _interopRequireDefault(_presenterPageChange);

	var _presenterPageLeave = __webpack_require__(45);

	var _presenterPageLeave2 = _interopRequireDefault(_presenterPageLeave);

	var _presenterGetQuestionInfo = __webpack_require__(46);

	var _presenterGetQuestionInfo2 = _interopRequireDefault(_presenterGetQuestionInfo);

	var _presenterSetPlayerController = __webpack_require__(47);

	var _presenterSetPlayerController2 = _interopRequireDefault(_presenterSetPlayerController);

	var _presenterOnEventReceived = __webpack_require__(48);

	var _presenterOnEventReceived2 = _interopRequireDefault(_presenterOnEventReceived);

	var _presenterPageShow = __webpack_require__(49);

	var _presenterPageShow2 = _interopRequireDefault(_presenterPageShow);

	var _presenterDestroy = __webpack_require__(50);

	var _presenterDestroy2 = _interopRequireDefault(_presenterDestroy);

	exports['default'] = {
		run: _presenterRun2['default'],
		//createPreview,
		setState: _presenterSetState2['default'],
		getState: _presenterGetState2['default'],
		pageChange: _presenterPageChange2['default'],
		pageLeave: _presenterPageLeave2['default'],
		initProjectionMobile: _presenterProjectionInitProjectionMobile2['default'],
		getQuestionInfo: _presenterGetQuestionInfo2['default'],
		setPlayerController: _presenterSetPlayerController2['default'],
		onEventReceived: _presenterOnEventReceived2['default'],
		pageShow: _presenterPageShow2['default'],
		destroy: _presenterDestroy2['default']
	};
	module.exports = exports['default'];

/***/ },
/* 2 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 运行环境下, 初始化Module的方法
	 * @param view 运行视图(DOM对象)
	 * @param model Module的模型, Key-Value结构
	 * @remark 该方法为Module生命周期方法,仅在Module初始化时执行一次
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});
	exports['default'] = run;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenterLogic = __webpack_require__(3);

	var _presenterLogic2 = _interopRequireDefault(_presenterLogic);

	function run(view, model) {
	  (0, _presenterLogic2['default'])(view, model, false);
	}

	module.exports = exports['default'];

/***/ },
/* 3 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Module的逻辑
	 * @param view 视图对象, 根据是否为预览状态传入不同的视图对象
	 * @param model 模型对象
	 * @param isPreview 是否为编辑环境, true=编辑环境, false=运行环境
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _handleCallback = __webpack_require__(4);

	var _handleCallback2 = _interopRequireDefault(_handleCallback);

	var _constants = __webpack_require__(8);

	var _runtime = __webpack_require__(7);

	var _runtime2 = _interopRequireDefault(_runtime);

	var _controlBar = __webpack_require__(10);

	var _controlBar2 = _interopRequireDefault(_controlBar);

	var _controlPatch = __webpack_require__(17);

	var _controlPatch2 = _interopRequireDefault(_controlPatch);

	var _controlMain = __webpack_require__(16);

	var _controlMain2 = _interopRequireDefault(_controlMain);

	var _controlNormalize = __webpack_require__(24);

	var _controlNormalize2 = _interopRequireDefault(_controlNormalize);

	var _controlCacheVnode = __webpack_require__(23);

	var _controlCacheVnode2 = _interopRequireDefault(_controlCacheVnode);

	var _controlCounterList = __webpack_require__(25);

	var _controlCounterList2 = _interopRequireDefault(_controlCounterList);

	var _utilsPerspectiveViewHelper = __webpack_require__(34);

	var _utilsPerspectiveViewHelper2 = _interopRequireDefault(_utilsPerspectiveViewHelper);

	exports['default'] = function (view, model, isPreview) {
		var $ = window.$;
		var $view = $(view);
		//create prespectiveView
		var perspectiveViewHelper = new _utilsPerspectiveViewHelper2['default']();
		_presenter2['default'].perspectiveViewHelper = perspectiveViewHelper;
		perspectiveViewHelper.createPerspectiveView($view);

		// 将 model 值赋给 this
		_presenter2['default'].model = model;
		// 将 view 赋值给 this
		_presenter2['default'].view = view;
		if (_constants.isTeacherMobile) {
			// 结束任务
			$view.on('click', '.js-stop-sync-button', function (e) {
				_presenter2['default'].eventBus.sendEvent('Sync', {
					source: model.ID,
					type: 'cancel',
					value: {
						syncId: _presenter2['default'].syncId
					}
				});
			});
		}

		if (window.icCreatePlayer) {
			if (_runtime2['default'] === window.icCreatePlayer.RUNTIME.TEACHER_MOBILE) {
				window.bridgeListener = window.Bridge.registerListener(_constants.eventName, _handleCallback2['default']);
			} else if (_runtime2['default'] === window.icCreatePlayer.RUNTIME.WEB) {
				$view.find('.js-lego-view').removeClass('is-hide');
			}
			// 将 bar 插入相应 DOM，备课系统不执行
			//const RUNTIME = window.icCreatePlayer.RUNTIME
			var barVisibleRuntimes = []; // [RUNTIME.TEACHER_MOBILE, RUNTIME.STUDENT_MOBILE, RUNTIME.PROJECTION_MOBILE]
			if (window.icCreatePlayer && barVisibleRuntimes.indexOf(_runtime2['default']) !== -1) {
				(0, _controlPatch2['default'])($view.find('.js-lego-view-bar').get(0), _controlBar2['default']);
				$view.find('.js-lego-view').css('background', '#f0f0f0');
			}
		}
		var gridArr = (0, _controlNormalize2['default'])(perspectiveViewHelper.gridData.getGridCubeArr());
		gridArr[0].active = true;
		_controlCacheVnode2['default'].current = $view.find('.js-lego-view-panel > div').get(0);
		(0, _controlMain2['default'])(gridArr, _controlCacheVnode2['default'].current, _controlCounterList2['default']);
	};

	module.exports = exports['default'];

/***/ },
/* 4 */
/***/ function(module, exports, __webpack_require__) {

	/* global $ */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _projectionUserInput = __webpack_require__(5);

	var _projectionUserInput2 = _interopRequireDefault(_projectionUserInput);

	var _projectionActions = __webpack_require__(9);

	exports['default'] = function (eventData) {
		if (typeof eventData.value === 'undefined') {
			return;
		}
		// 显示方块塔
		$(_presenter2['default'].view).find('.js-lego-view').removeClass('is-hide');
		(0, _projectionUserInput2['default'])({
			type: _projectionActions.showModule,
			payload: null
		});
	};

	module.exports = exports['default'];

/***/ },
/* 5 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _nativeCallNative = __webpack_require__(6);

	var _nativeCallNative2 = _interopRequireDefault(_nativeCallNative);

	var _runtime = __webpack_require__(7);

	var _runtime2 = _interopRequireDefault(_runtime);

	var _constants = __webpack_require__(8);

	/**
	 @param action {Object} 用户的动作
	 @example
	 {
	   type: 'init.lego.teacher',
	   payload: {}
	}
	 */

	exports['default'] = function (action) {
		if (window.icCreatePlayer && _runtime2['default'] !== window.icCreatePlayer.RUNTIME.TEACHER_MOBILE) return;
		(0, _nativeCallNative2['default'])('sendEvent', {
			'eventName': 'UserInput',
			'eventData': {
				source: _constants.addonName,
				action: action
			}
		});
	};

	module.exports = exports['default'];

/***/ },
/* 6 */
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	exports['default'] = function (eventName, data) {
		if (window.isApp && window.Bridge && window.Bridge.callNative) {
			return window.Bridge.callNative('com.nd.pad.icr.ui.IcrJsBridge', eventName, data);
		}
		return false;
	};

	module.exports = exports['default'];

/***/ },
/* 7 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	var runtime = null;
	if (window.icCreatePlayer) {
		runtime = window.player.getPlayerServices().getRuntime();
	}
	exports["default"] = runtime;
	module.exports = exports["default"];

/***/ },
/* 8 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 @author 陈小锋 2015/11/10
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _runtime = __webpack_require__(7);

	var _runtime2 = _interopRequireDefault(_runtime);

	// 定义网格方块数量
	var GRID_SETTING = {
		row: 4,
		column: 4,
		h: 4
	};

	exports.GRID_SETTING = GRID_SETTING;
	// 与 native 通信的事件名
	var eventName = 'drawLego';
	exports.eventName = eventName;
	// addon 的名称
	var addonName = 'Lego';
	exports.addonName = addonName;
	var isTeacherMobile = window.icCreatePlayer && _runtime2['default'] === window.icCreatePlayer.RUNTIME.TEACHER_MOBILE;
	exports.isTeacherMobile = isTeacherMobile;
	var isStudentMobile = window.icCreatePlayer && _runtime2['default'] === window.icCreatePlayer.RUNTIME.STUDENT_MOBILE;
	exports.isStudentMobile = isStudentMobile;
	var isProjectionMobile = window.icCreatePlayer && _runtime2['default'] === window.icCreatePlayer.RUNTIME.PROJECTION_MOBILE;
	exports.isProjectionMobile = isProjectionMobile;
	var isWeb = window.icCreatePlayer && _runtime2['default'] === window.icCreatePlayer.RUNTIME.WEB;
	exports.isWeb = isWeb;
	var isTeacherPc = window.icCreatePlayer && _runtime2['default'] === window.icCreatePlayer.RUNTIME.TEACHER_PC;
	exports.isTeacherPc = isTeacherPc;

/***/ },
/* 9 */
/***/ function(module, exports) {

	// 显示模块
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});
	var showModule = 'show.lego.teacher';
	exports.showModule = showModule;
	// 隐藏模块
	var hideModule = 'hide.lego.teacher';
	exports.hideModule = hideModule;
	// 移动模块
	var moveModule = 'move.lego.teacher';
	exports.moveModule = moveModule;
	// 方格点击修改 (x, y) 坐标上的方块数量
	var modifyCubeCountByGrid = 'modifyCubeCountByGrid.lego.teacher';
	exports.modifyCubeCountByGrid = modifyCubeCountByGrid;
	var addCubeCountByAdjuster = 'addCubeCountByAdjuster.lego.teacher';
	exports.addCubeCountByAdjuster = addCubeCountByAdjuster;
	var minusCubeCountByAdjuster = 'minusCubeCountByAdjuster.lego.teacher';
	exports.minusCubeCountByAdjuster = minusCubeCountByAdjuster;
	var addCubeByClickPlane = 'addCubeByClickPlane.lego.teacher';
	exports.addCubeByClickPlane = addCubeByClickPlane;
	var deleteCubeByClickPlane = 'deleteCubeByClickPlane.lego.teacher';
	exports.deleteCubeByClickPlane = deleteCubeByClickPlane;
	var highlightCubeByClickPlane = 'highlightCubeByClickPlane.lego.teacher';
	exports.highlightCubeByClickPlane = highlightCubeByClickPlane;
	var modifyView = 'modifyView.lego.teacher';
	exports.modifyView = modifyView;

/***/ },
/* 10 */
/***/ function(module, exports, __webpack_require__) {

	/* global $ */
	/**
	 @author 陈小锋 2015-11-11
	 可拖动的标题栏
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _snabbdomH = __webpack_require__(11);

	var _snabbdomH2 = _interopRequireDefault(_snabbdomH);

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _projectionUserInput = __webpack_require__(5);

	var _projectionUserInput2 = _interopRequireDefault(_projectionUserInput);

	var _projectionActions = __webpack_require__(9);

	var _reset = __webpack_require__(14);

	var _reset2 = _interopRequireDefault(_reset);

	var _constants = __webpack_require__(8);

	var _throttle = __webpack_require__(33);

	var _throttle2 = _interopRequireDefault(_throttle);

	// 定义拖动开关
	var dragging = false;
	var moveableObj = null;
	var moveableObjTransformXY = null;
	var downPoint = null;
	var handleClick = function handleClick(e) {
		// 阻止事件冒泡到父节点
		e.stopPropagation();
		(0, _reset2['default'])();
		// 隐藏 view
		$(_presenter2['default'].view).find('.js-lego-view').addClass('is-hide');
		if (_constants.isTeacherMobile) {
			(0, _projectionUserInput2['default'])({
				type: _projectionActions.hideModule
			});
		}
	};
	// 按下鼠标
	var handleMousedown = function handleMousedown(e) {
		e.preventDefault();
		dragging = true;
		// mouseup 与 mousemove 事件由 view 监听
		_presenter2['default'].view.addEventListener('mousemove', handleMousemove);
		_presenter2['default'].view.addEventListener('touchmove', handleMousemove);
		_presenter2['default'].view.addEventListener('touchend', handleMouseup);
		_presenter2['default'].view.addEventListener('mouseup', handleMouseup);
		moveableObj = $(_presenter2['default'].view).find('.js-lego-view').get(0);
		if ($(moveableObj).css('transform') === 'none') return; // for what??
		var transformXY = $(moveableObj).css('transform').split('(')[1].split(')')[0].split(',');
		moveableObjTransformXY = {
			x: parseInt(transformXY[4], 10),
			y: parseInt(transformXY[5], 10)
		};
		downPoint = {
			x: e.clientX || e.touches[0].clientX,
			y: e.clientY || e.touches[0].clientY
		};
	};
	// 释放鼠标，清理
	var handleMouseup = function handleMouseup(e) {
		dragging = false;
		moveableObj = null;
		moveableObjTransformXY = null;
		_presenter2['default'].view.removeEventListener('touchend', handleMouseup);
		_presenter2['default'].view.removeEventListener('mouseup', handleMouseup);
		_presenter2['default'].view.removeEventListener('touchmove', handleMousemove);
		_presenter2['default'].view.removeEventListener('mousemove', handleMousemove);
	};
	// 移动鼠标
	var handleMousemove = function handleMousemove(e) {
		if (!dragging || !moveableObj || !downPoint || !moveableObjTransformXY) {
			return;
		}
		e.preventDefault();
		var deltaX = (e.clientX || e.touches[0].clientX) - downPoint.x;
		var deltaY = (e.clientY || e.touches[0].clientY) - downPoint.y;
		var transformValue = 'translateX(' + (moveableObjTransformXY.x + deltaX) + 'px) translateY(' + (moveableObjTransformXY.y + deltaY) + 'px) translateZ(0)';
		moveableObj.style.transform = transformValue;
		var throttleUserInput = (0, _throttle2['default'])(function () {
			(0, _projectionUserInput2['default'])({
				type: _projectionActions.moveModule,
				payload: transformValue
			});
		}, 100);
		if (_constants.isTeacherMobile) {
			// 节流
			throttleUserInput();
		}
	};
	var bar = (0, _snabbdomH2['default'])('div', {
		'class': {
			'lego-view__titleBar': true
		},
		on: {
			mousedown: handleMousedown,
			touchstart: handleMousedown
		}
	}, [(0, _snabbdomH2['default'])('a', {
		props: {
			href: '#',
			title: '点击关闭窗口'
		},
		on: {
			click: handleClick,
			touchstart: handleClick
		},
		'class': {
			'lego-view__closeButton': true
		}
	}, 'x')]);
	exports['default'] = bar;
	module.exports = exports['default'];

/***/ },
/* 11 */
/***/ function(module, exports, __webpack_require__) {

	var VNode = __webpack_require__(12);
	var is = __webpack_require__(13);

	module.exports = function h(sel, b, c) {
	  var data = {}, children, text, i;
	  if (arguments.length === 3) {
	    data = b;
	    if (is.array(c)) { children = c; }
	    else if (is.primitive(c)) { text = c; }
	  } else if (arguments.length === 2) {
	    if (is.array(b)) { children = b; }
	    else if (is.primitive(b)) { text = b; }
	    else { data = b; }
	  }
	  if (is.array(children)) {
	    for (i = 0; i < children.length; ++i) {
	      if (is.primitive(children[i])) children[i] = VNode(undefined, undefined, undefined, children[i]);
	    }
	  }
	  return VNode(sel, data, children, text, undefined);
	};


/***/ },
/* 12 */
/***/ function(module, exports) {

	module.exports = function(sel, data, children, text, elm) {
	  var key = data === undefined ? undefined : data.key;
	  return {sel: sel, data: data, children: children,
	          text: text, elm: elm, key: key};
	};


/***/ },
/* 13 */
/***/ function(module, exports) {

	module.exports = {
	  array: Array.isArray,
	  primitive: function(s) { return typeof s === 'string' || typeof s === 'number'; },
	};


/***/ },
/* 14 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _controlNotify = __webpack_require__(15);

	var _controlNotify2 = _interopRequireDefault(_controlNotify);

	var _controlRotateGrid = __webpack_require__(29);

	var _controlRotateGrid2 = _interopRequireDefault(_controlRotateGrid);

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	exports['default'] = function (isRemoveAll) {
		_presenter2['default'].perspectiveViewHelper.resetCubeStatus(isRemoveAll);
		(0, _controlNotify2['default'])(0, 0);
		// 恢复平面视图的旋转
		(0, _controlRotateGrid2['default'])(window.$(_presenter2['default'].view).find('.lego-view-counter-list'), 0);
	};

	module.exports = exports['default'];

/***/ },
/* 15 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _main = __webpack_require__(16);

	var _main2 = _interopRequireDefault(_main);

	//import { gridData } from '../constants'

	var _normalize = __webpack_require__(24);

	var _normalize2 = _interopRequireDefault(_normalize);

	var _counterList = __webpack_require__(25);

	var _counterList2 = _interopRequireDefault(_counterList);

	var _cacheVnode = __webpack_require__(23);

	var _cacheVnode2 = _interopRequireDefault(_cacheVnode);

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	exports['default'] = function (row, column) {
		var gridArr = (0, _normalize2['default'])(_presenter2['default'].perspectiveViewHelper.gridData.getGridCubeArr());
		gridArr[row * 4 + column]['active'] = true;
		(0, _main2['default'])(gridArr, _cacheVnode2['default'].current, _counterList2['default']);
	};

	module.exports = exports['default'];

/***/ },
/* 16 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 @author 陈小锋 2015-11-13
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});
	exports['default'] = main;

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _patch = __webpack_require__(17);

	var _patch2 = _interopRequireDefault(_patch);

	var _cacheVnode = __webpack_require__(23);

	var _cacheVnode2 = _interopRequireDefault(_cacheVnode);

	function main(state, oldVnode, _ref) {
		var view = _ref.view;
		var update = _ref.update;

		var newVnode = view(state, function (e) {
			var newState = update(state, e);
			main(newState, newVnode, { view: view, update: update });
		});
		_cacheVnode2['default'].current = (0, _patch2['default'])(oldVnode, newVnode);
	}

	module.exports = exports['default'];

/***/ },
/* 17 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _snabbdom = __webpack_require__(18);

	var _snabbdom2 = _interopRequireDefault(_snabbdom);

	exports['default'] = _snabbdom2['default'].init([__webpack_require__(19), __webpack_require__(20), __webpack_require__(21), __webpack_require__(22)]);
	module.exports = exports['default'];

/***/ },
/* 18 */
/***/ function(module, exports, __webpack_require__) {

	// jshint newcap: false
	/* global require, module, document, Element */
	'use strict';

	var VNode = __webpack_require__(12);
	var is = __webpack_require__(13);

	function isUndef(s) { return s === undefined; }
	function isDef(s) { return s !== undefined; }

	function emptyNodeAt(elm) {
	  return VNode(elm.tagName, {}, [], undefined, elm);
	}

	var emptyNode = VNode('', {}, [], undefined, undefined);

	function sameVnode(vnode1, vnode2) {
	  return vnode1.key === vnode2.key && vnode1.sel === vnode2.sel;
	}

	function createKeyToOldIdx(children, beginIdx, endIdx) {
	  var i, map = {}, key;
	  for (i = beginIdx; i <= endIdx; ++i) {
	    key = children[i].key;
	    if (isDef(key)) map[key] = i;
	  }
	  return map;
	}

	function createRmCb(childElm, listeners) {
	  return function() {
	    if (--listeners === 0) childElm.parentElement.removeChild(childElm);
	  };
	}

	var hooks = ['create', 'update', 'remove', 'destroy', 'pre', 'post'];

	function init(modules) {
	  var i, j, cbs = {};
	  for (i = 0; i < hooks.length; ++i) {
	    cbs[hooks[i]] = [];
	    for (j = 0; j < modules.length; ++j) {
	      if (modules[j][hooks[i]] !== undefined) cbs[hooks[i]].push(modules[j][hooks[i]]);
	    }
	  }

	  function createElm(vnode, insertedVnodeQueue) {
	    var i, data = vnode.data;
	    if (isDef(data)) {
	      if (isDef(i = data.hook) && isDef(i = i.init)) i(vnode);
	      if (isDef(i = data.vnode)) vnode = i;
	    }
	    var elm, children = vnode.children, sel = vnode.sel;
	    if (isDef(sel)) {
	      // Parse selector
	      var hashIdx = sel.indexOf('#');
	      var dotIdx = sel.indexOf('.', hashIdx);
	      var hash = hashIdx > 0 ? hashIdx : sel.length;
	      var dot = dotIdx > 0 ? dotIdx : sel.length;
	      var tag = hashIdx !== -1 || dotIdx !== -1 ? sel.slice(0, Math.min(hash, dot)) : sel;
	      elm = vnode.elm = isDef(data) && isDef(i = data.ns) ? document.createElementNS(i, tag)
	                                                          : document.createElement(tag);
	      if (hash < dot) elm.id = sel.slice(hash + 1, dot);
	      if (dotIdx > 0) elm.className = sel.slice(dot+1).replace(/\./g, ' ');
	      if (is.array(children)) {
	        for (i = 0; i < children.length; ++i) {
	          elm.appendChild(createElm(children[i], insertedVnodeQueue));
	        }
	      } else if (is.primitive(vnode.text)) {
	        elm.appendChild(document.createTextNode(vnode.text));
	      }
	      for (i = 0; i < cbs.create.length; ++i) cbs.create[i](emptyNode, vnode);
	      i = vnode.data.hook; // Reuse variable
	      if (isDef(i)) {
	        if (i.create) i.create(emptyNode, vnode);
	        if (i.insert) insertedVnodeQueue.push(vnode);
	      }
	    } else {
	      elm = vnode.elm = document.createTextNode(vnode.text);
	    }
	    return vnode.elm;
	  }

	  function addVnodes(parentElm, before, vnodes, startIdx, endIdx, insertedVnodeQueue) {
	    for (; startIdx <= endIdx; ++startIdx) {
	      parentElm.insertBefore(createElm(vnodes[startIdx], insertedVnodeQueue), before);
	    }
	  }

	  function invokeDestroyHook(vnode) {
	    var i = vnode.data, j;
	    if (isDef(i)) {
	      if (isDef(i = i.hook) && isDef(i = i.destroy)) i(vnode);
	      for (i = 0; i < cbs.destroy.length; ++i) cbs.destroy[i](vnode);
	      if (isDef(i = vnode.children)) {
	        for (j = 0; j < vnode.children.length; ++j) {
	          invokeDestroyHook(vnode.children[j]);
	        }
	      }
	    }
	  }

	  function removeVnodes(parentElm, vnodes, startIdx, endIdx) {
	    for (; startIdx <= endIdx; ++startIdx) {
	      var i, listeners, rm, ch = vnodes[startIdx];
	      if (isDef(ch)) {
	        if (isDef(ch.sel)) {
	          invokeDestroyHook(ch);
	          listeners = cbs.remove.length + 1;
	          rm = createRmCb(ch.elm, listeners);
	          for (i = 0; i < cbs.remove.length; ++i) cbs.remove[i](ch, rm);
	          if (isDef(i = ch.data) && isDef(i = i.hook) && isDef(i = i.remove)) {
	            i(ch, rm);
	          } else {
	            rm();
	          }
	        } else { // Text node
	          parentElm.removeChild(ch.elm);
	        }
	      }
	    }
	  }

	  function updateChildren(parentElm, oldCh, newCh, insertedVnodeQueue) {
	    var oldStartIdx = 0, newStartIdx = 0;
	    var oldEndIdx = oldCh.length - 1;
	    var oldStartVnode = oldCh[0];
	    var oldEndVnode = oldCh[oldEndIdx];
	    var newEndIdx = newCh.length - 1;
	    var newStartVnode = newCh[0];
	    var newEndVnode = newCh[newEndIdx];
	    var oldKeyToIdx, idxInOld, elmToMove, before;

	    while (oldStartIdx <= oldEndIdx && newStartIdx <= newEndIdx) {
	      if (isUndef(oldStartVnode)) {
	        oldStartVnode = oldCh[++oldStartIdx]; // Vnode has been moved left
	      } else if (isUndef(oldEndVnode)) {
	        oldEndVnode = oldCh[--oldEndIdx];
	      } else if (sameVnode(oldStartVnode, newStartVnode)) {
	        patchVnode(oldStartVnode, newStartVnode, insertedVnodeQueue);
	        oldStartVnode = oldCh[++oldStartIdx];
	        newStartVnode = newCh[++newStartIdx];
	      } else if (sameVnode(oldEndVnode, newEndVnode)) {
	        patchVnode(oldEndVnode, newEndVnode, insertedVnodeQueue);
	        oldEndVnode = oldCh[--oldEndIdx];
	        newEndVnode = newCh[--newEndIdx];
	      } else if (sameVnode(oldStartVnode, newEndVnode)) { // Vnode moved right
	        patchVnode(oldStartVnode, newEndVnode, insertedVnodeQueue);
	        parentElm.insertBefore(oldStartVnode.elm, oldEndVnode.elm.nextSibling);
	        oldStartVnode = oldCh[++oldStartIdx];
	        newEndVnode = newCh[--newEndIdx];
	      } else if (sameVnode(oldEndVnode, newStartVnode)) { // Vnode moved left
	        patchVnode(oldEndVnode, newStartVnode, insertedVnodeQueue);
	        parentElm.insertBefore(oldEndVnode.elm, oldStartVnode.elm);
	        oldEndVnode = oldCh[--oldEndIdx];
	        newStartVnode = newCh[++newStartIdx];
	      } else {
	        if (isUndef(oldKeyToIdx)) oldKeyToIdx = createKeyToOldIdx(oldCh, oldStartIdx, oldEndIdx);
	        idxInOld = oldKeyToIdx[newStartVnode.key];
	        if (isUndef(idxInOld)) { // New element
	          parentElm.insertBefore(createElm(newStartVnode, insertedVnodeQueue), oldStartVnode.elm);
	          newStartVnode = newCh[++newStartIdx];
	        } else {
	          elmToMove = oldCh[idxInOld];
	          patchVnode(elmToMove, newStartVnode, insertedVnodeQueue);
	          oldCh[idxInOld] = undefined;
	          parentElm.insertBefore(elmToMove.elm, oldStartVnode.elm);
	          newStartVnode = newCh[++newStartIdx];
	        }
	      }
	    }
	    if (oldStartIdx > oldEndIdx) {
	      before = isUndef(newCh[newEndIdx+1]) ? null : newCh[newEndIdx+1].elm;
	      addVnodes(parentElm, before, newCh, newStartIdx, newEndIdx, insertedVnodeQueue);
	    } else if (newStartIdx > newEndIdx) {
	      removeVnodes(parentElm, oldCh, oldStartIdx, oldEndIdx);
	    }
	  }

	  function patchVnode(oldVnode, vnode, insertedVnodeQueue) {
	    var i, hook;
	    if (isDef(i = vnode.data) && isDef(hook = i.hook) && isDef(i = hook.prepatch)) {
	      i(oldVnode, vnode);
	    }
	    if (isDef(i = oldVnode.data) && isDef(i = i.vnode)) oldVnode = i;
	    if (isDef(i = vnode.data) && isDef(i = i.vnode)) vnode = i;
	    var elm = vnode.elm = oldVnode.elm, oldCh = oldVnode.children, ch = vnode.children;
	    if (oldVnode === vnode) return;
	    if (isDef(vnode.data)) {
	      for (i = 0; i < cbs.update.length; ++i) cbs.update[i](oldVnode, vnode);
	      i = vnode.data.hook;
	      if (isDef(i) && isDef(i = i.update)) i(oldVnode, vnode);
	    }
	    if (isUndef(vnode.text)) {
	      if (isDef(oldCh) && isDef(ch)) {
	        if (oldCh !== ch) updateChildren(elm, oldCh, ch, insertedVnodeQueue);
	      } else if (isDef(ch)) {
	        addVnodes(elm, null, ch, 0, ch.length - 1, insertedVnodeQueue);
	      } else if (isDef(oldCh)) {
	        removeVnodes(elm, oldCh, 0, oldCh.length - 1);
	      }
	    } else if (oldVnode.text !== vnode.text) {
	      elm.textContent = vnode.text;
	    }
	    if (isDef(hook) && isDef(i = hook.postpatch)) {
	      i(oldVnode, vnode);
	    }
	  }

	  return function(oldVnode, vnode) {
	    var i;
	    var insertedVnodeQueue = [];
	    for (i = 0; i < cbs.pre.length; ++i) cbs.pre[i]();
	    if (oldVnode instanceof Element) {
	      if (oldVnode.parentElement !== null) {
	        createElm(vnode, insertedVnodeQueue);
	        oldVnode.parentElement.replaceChild(vnode.elm, oldVnode);
	      } else {
	        oldVnode = emptyNodeAt(oldVnode);
	        patchVnode(oldVnode, vnode, insertedVnodeQueue);
	      }
	    } else {
	      patchVnode(oldVnode, vnode, insertedVnodeQueue);
	    }
	    for (i = 0; i < insertedVnodeQueue.length; ++i) {
	      insertedVnodeQueue[i].data.hook.insert(insertedVnodeQueue[i]);
	    }
	    for (i = 0; i < cbs.post.length; ++i) cbs.post[i]();
	    return vnode;
	  };
	}

	module.exports = {init: init};


/***/ },
/* 19 */
/***/ function(module, exports) {

	function updateClass(oldVnode, vnode) {
	  var cur, name, elm = vnode.elm,
	      oldClass = oldVnode.data.class || {},
	      klass = vnode.data.class || {};
	  for (name in klass) {
	    cur = klass[name];
	    if (cur !== oldClass[name]) {
	      elm.classList[cur ? 'add' : 'remove'](name);
	    }
	  }
	}

	module.exports = {create: updateClass, update: updateClass};


/***/ },
/* 20 */
/***/ function(module, exports) {

	function updateProps(oldVnode, vnode) {
	  var key, cur, old, elm = vnode.elm,
	      oldProps = oldVnode.data.props || {}, props = vnode.data.props || {};
	  for (key in props) {
	    cur = props[key];
	    old = oldProps[key];
	    if (old !== cur) {
	      elm[key] = cur;
	    }
	  }
	}

	module.exports = {create: updateProps, update: updateProps};


/***/ },
/* 21 */
/***/ function(module, exports) {

	var raf = requestAnimationFrame || setTimeout;
	var nextFrame = function(fn) { raf(function() { raf(fn); }); };

	function setNextFrame(obj, prop, val) {
	  nextFrame(function() { obj[prop] = val; });
	}

	function updateStyle(oldVnode, vnode) {
	  var cur, name, elm = vnode.elm,
	      oldStyle = oldVnode.data.style || {},
	      style = vnode.data.style || {},
	      oldHasDel = 'delayed' in oldStyle;
	  for (name in style) {
	    cur = style[name];
	    if (name === 'delayed') {
	      for (name in style.delayed) {
	        cur = style.delayed[name];
	        if (!oldHasDel || cur !== oldStyle.delayed[name]) {
	          setNextFrame(elm.style, name, cur);
	        }
	      }
	    } else if (name !== 'remove' && cur !== oldStyle[name]) {
	      elm.style[name] = cur;
	    }
	  }
	}

	function applyDestroyStyle(vnode) {
	  var style, name, elm = vnode.elm, s = vnode.data.style;
	  if (!s || !(style = s.destroy)) return;
	  for (name in style) {
	    elm.style[name] = style[name];
	  }
	}

	function applyRemoveStyle(vnode, rm) {
	  var s = vnode.data.style;
	  if (!s || !s.remove) {
	    rm();
	    return;
	  }
	  var name, elm = vnode.elm, idx, i = 0, maxDur = 0,
	      compStyle, style = s.remove, amount = 0, applied = [];
	  for (name in style) {
	    applied.push(name);
	    elm.style[name] = style[name];
	  }
	  compStyle = getComputedStyle(elm);
	  var props = compStyle['transition-property'].split(', ');
	  for (; i < props.length; ++i) {
	    if(applied.indexOf(props[i]) !== -1) amount++;
	  }
	  elm.addEventListener('transitionend', function(ev) {
	    if (ev.target === elm) --amount;
	    if (amount === 0) rm();
	  });
	}

	module.exports = {create: updateStyle, update: updateStyle, destroy: applyDestroyStyle, remove: applyRemoveStyle};


/***/ },
/* 22 */
/***/ function(module, exports, __webpack_require__) {

	var is = __webpack_require__(13);

	function arrInvoker(arr) {
	  return function() {
	    // Special case when length is two, for performance
	    arr.length === 2 ? arr[0](arr[1]) : arr[0].apply(undefined, arr.slice(1));
	  };
	}

	function fnInvoker(o) {
	  return function(ev) { o.fn(ev); };
	}

	function updateEventListeners(oldVnode, vnode) {
	  var name, cur, old, elm = vnode.elm,
	      oldOn = oldVnode.data.on || {}, on = vnode.data.on;
	  if (!on) return;
	  for (name in on) {
	    cur = on[name];
	    old = oldOn[name];
	    if (old === undefined) {
	      if (is.array(cur)) {
	        elm.addEventListener(name, arrInvoker(cur));
	      } else {
	        cur = {fn: cur};
	        on[name] = cur;
	        elm.addEventListener(name, fnInvoker(cur));
	      }
	    } else if (is.array(old)) {
	      // Deliberately modify old array since it's captured in closure created with `arrInvoker`
	      old.length = cur.length;
	      for (var i = 0; i < old.length; ++i) old[i] = cur[i];
	      on[name]  = old;
	    } else {
	      old.fn = cur;
	      on[name] = old;
	    }
	  }
	}

	module.exports = {create: updateEventListeners, update: updateEventListeners};


/***/ },
/* 23 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	var vnode = null;
	exports["default"] = Object.defineProperties({}, {
		current: {
			get: function get() {
				return vnode;
			},
			set: function set(v) {
				vnode = v;
			},
			configurable: true,
			enumerable: true
		}
	});
	module.exports = exports["default"];

/***/ },
/* 24 */
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	exports['default'] = function (arrData) {
		if (arrData.length !== 4) {
			throw new Error('方格数据有错');
		}
		var output = [];
		arrData.forEach(function (row, rowIndex) {
			row.forEach(function (cell, columnIndex) {
				output.push({
					id: rowIndex * 4 + columnIndex + 1,
					counter: cell
				});
			});
		});
		return output;
	};

	module.exports = exports['default'];

/***/ },
/* 25 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _snabbdomH = __webpack_require__(11);

	var _snabbdomH2 = _interopRequireDefault(_snabbdomH);

	var _counter2 = __webpack_require__(26);

	var _counter3 = _interopRequireDefault(_counter2);

	var _adjuster = __webpack_require__(32);

	var _adjuster2 = _interopRequireDefault(_adjuster);

	/**
	 state : [{id: Number, counter: counter.state, active: true}]
	*/
	var UPDATE = 'UPDATE_COUNTER';
	var ADJUST = 'ADJUST_COUNTER';
	function view(state, handler) {
		var activeCounter = null;
		var _iteratorNormalCompletion = true;
		var _didIteratorError = false;
		var _iteratorError = undefined;

		try {
			for (var _iterator = state[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
				var _counter = _step.value;

				if (_counter.active && _counter.active === true) {
					activeCounter = _counter;
				}
			}
		} catch (err) {
			_didIteratorError = true;
			_iteratorError = err;
		} finally {
			try {
				if (!_iteratorNormalCompletion && _iterator['return']) {
					_iterator['return']();
				}
			} finally {
				if (_didIteratorError) {
					throw _iteratorError;
				}
			}
		}

		if (!activeCounter) {
			activeCounter = { id: 0, counter: 0, active: true };
		}
		return (0, _snabbdomH2['default'])('div', {
			style: {
				height: '100%'
			}
		}, [(0, _snabbdomH2['default'])('div.table', [(0, _snabbdomH2['default'])('div.content.clearfix.lego-view-counter-list', state.map(function (item) {
			return _counter3['default'].view(item, function (counterAction) {
				return handler({ type: UPDATE, id: item.id, data: counterAction });
			});
		}))]), _adjuster2['default'].view(activeCounter, function (adjusterAction) {
			return handler({ type: ADJUST, id: activeCounter.id, data: adjusterAction });
		})]);
	}

	function update(state, action) {
		switch (action.type) {
			case UPDATE:
				return state.map(function (item) {
					if (item.id !== action.id) {
						return _extends({}, item, { active: false });
					} else {
						return _counter3['default'].update(item, action.data);
					}
				});
			case ADJUST:
				return state.map(function (item) {
					if (item.id !== action.id) {
						return item;
					} else {
						return _adjuster2['default'].update(item, action.data);
					}
				});
			default:
				return state;
		}
	}
	exports['default'] = { view: view, update: update, actions: { UPDATE: UPDATE, ADJUST: ADJUST } };
	module.exports = exports['default'];

/***/ },
/* 26 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _snabbdomH = __webpack_require__(11);

	var _snabbdomH2 = _interopRequireDefault(_snabbdomH);

	var _listener = __webpack_require__(27);

	var _listener2 = _interopRequireDefault(_listener);

	// state : {id: Number, counter: Number, active: true}

	var ADD_CUBE = 'ADD_CUBE';
	function view(state, handler) {
		return (0, _snabbdomH2['default'])('span.lego-view__panel__cell.cell', {
			key: state.id,
			on: {
				click: function click(e) {
					e.stopPropagation();
					handler.bind(null, { type: 'ADD_CUBE' })();
				}
			},
			'class': {
				'on': state.active, // 激活状态下添加此 css 类名
				'add': state.counter > 0
			}
		}, [(0, _snabbdomH2['default'])('span', {
			style: {
				display: 'inline-block'
			}
		}, state.counter === 0 ? '' : state.counter)]);
	}
	function update(state, action) {
		var newState = null;
		switch (action.type) {
			case ADD_CUBE:
				if (!state.active) {
					// 激活方格
					newState = _extends({}, state, { active: true });
				} else {
					if (state.counter === 4) {
						newState = _extends({}, state, { counter: 0 });
					} else {
						newState = _extends({}, state, { counter: state.counter + 1 });
					}
				}
				_listener2['default'].trigger('sideEffectByGrid', { payload: {
						id: newState.id,
						counter: newState.counter
					}
				});
				return newState;
			default:
				return state;
		}
	}
	exports['default'] = { view: view, update: update, actions: { ADD_CUBE: ADD_CUBE } };
	module.exports = exports['default'];

/***/ },
/* 27 */
/***/ function(module, exports, __webpack_require__) {

	/* global $ */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _microevent = __webpack_require__(28);

	var _microevent2 = _interopRequireDefault(_microevent);

	/**
	 @author 陈小锋
	`npm test` 时暂且清理以下内容
	*/

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _projectionUserInput = __webpack_require__(5);

	var _projectionUserInput2 = _interopRequireDefault(_projectionUserInput);

	var _projectionActions = __webpack_require__(9);

	var _rotateGrid = __webpack_require__(29);

	var _rotateGrid2 = _interopRequireDefault(_rotateGrid);

	var _operateCube = __webpack_require__(30);

	var _operateCube2 = _interopRequireDefault(_operateCube);

	var _constants = __webpack_require__(8);

	var listener = _microevent2['default'].mixin({});
	exports['default'] = listener;

	listener.bind('sideEffectByGrid', function (action) {
		var _action$payload = action.payload;
		var id = _action$payload.id;
		var counter = _action$payload.counter;

		(0, _operateCube2['default'])(id, counter);
		if (_constants.isTeacherMobile) {
			(0, _projectionUserInput2['default'])({
				type: 'modifyCubeCountByGrid.lego.teacher',
				payload: {
					id: id,
					counter: counter
				}
			});
		}
	});
	listener.bind('sideEffectByAdjuster', function (action) {
		var type = action.type;
		var payload = action.payload;
		var id = payload.id;
		var counter = payload.counter;

		(0, _operateCube2['default'])(id, counter, type);
		if (_constants.isTeacherMobile) {
			(0, _projectionUserInput2['default'])({
				type: type + 'CubeCountByAdjuster.lego.teacher',
				payload: {
					id: id,
					counter: counter
				}
			});
		}
	});
	listener.bind('rotateCubeView', function (targetRotation, targetY, isYFirst, rotation, override) {
		var $view = $(_presenter2['default'].view);
		// 旋转平面方格
		var $target = $view.find('.lego-view-counter-list');
		if (typeof override !== 'undefined') {
			(0, _rotateGrid2['default'])($target, override);
		} else {
			(0, _rotateGrid2['default'])($target, rotation - _presenter2['default'].perspectiveViewHelper.GRIDVIEW_ROTATIONS.INIT_ROTATION);
		}
		if (_constants.isTeacherMobile) {
			(0, _projectionUserInput2['default'])({
				type: _projectionActions.modifyView,
				payload: {
					targetRotation: targetRotation, targetY: targetY, isYFirst: isYFirst, override: override
				}
			});
		}
	});
	module.exports = exports['default'];

/***/ },
/* 28 */
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});
	var MicroEvent = function MicroEvent() {};
	MicroEvent.prototype = {
		bind: function bind(event, fct) {
			this._events = this._events || {};
			this._events[event] = this._events[event] || [];
			this._events[event].push(fct);
		},
		unbind: function unbind(event, fct) {
			this._events = this._events || {};
			if (event in this._events === false) return;
			this._events[event].splice(this._events[event].indexOf(fct), 1);
		},
		trigger: function trigger(event /* , args... */) {
			this._events = this._events || {};
			if (event in this._events === false) return;
			for (var i = 0; i < this._events[event].length; i++) {
				this._events[event][i].apply(this, Array.prototype.slice.call(arguments, 1));
			}
		}
	};
	MicroEvent.mixin = function (destObject) {
		var props = ['bind', 'unbind', 'trigger'];
		for (var i = 0; i < props.length; i++) {
			if (typeof destObject === 'function') {
				destObject.prototype[props[i]] = MicroEvent.prototype[props[i]];
			} else {
				destObject[props[i]] = MicroEvent.prototype[props[i]];
			}
		}
		return destObject;
	};
	exports['default'] = MicroEvent;
	module.exports = exports['default'];

/***/ },
/* 29 */
/***/ function(module, exports) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	exports['default'] = function ($target, deg) {
		$target.css('transform', 'rotate(' + deg + 'deg)');
		// 数据的容器需要保持竖直
		$target.find('.lego-view__panel__cell').children('span').each(function (index, element) {
			window.$(element).css('transform', 'rotate(' + -deg + 'deg)');
		});
	};

	module.exports = exports['default'];

/***/ },
/* 30 */
/***/ function(module, exports, __webpack_require__) {

	//import { setCubeCountInPosition, highlightCubeInPosition } from '../utils/CubeOperation'
	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _transform2 = __webpack_require__(31);

	var _transform3 = _interopRequireDefault(_transform2);

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	// 操作立体方块

	exports['default'] = function (id, count) {
		var _transform = (0, _transform3['default'])(id);

		var row = _transform.row;
		var column = _transform.column;

		_presenter2['default'].perspectiveViewHelper.highlightCubeInPosition(row, column);
		_presenter2['default'].perspectiveViewHelper.setCubeCountInPosition(row, column, count);
	};

	module.exports = exports['default'];

/***/ },
/* 31 */
/***/ function(module, exports) {

	/**
	 0 基
	 将 id 转为格子上的坐标
	 */
	"use strict";

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	exports["default"] = function (id) {
		var gridLength = 4;
		var division = id / gridLength;
		var modulo = id % gridLength;
		if (modulo === 0) {
			return {
				row: Math.floor(division) - 1,
				column: 3
			};
		} else {
			return {
				row: Math.floor(division),
				column: id % 4 - 1
			};
		}
	};

	module.exports = exports["default"];

/***/ },
/* 32 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _snabbdomH = __webpack_require__(11);

	var _snabbdomH2 = _interopRequireDefault(_snabbdomH);

	var _listener = __webpack_require__(27);

	var _listener2 = _interopRequireDefault(_listener);

	/**
	 state: {id: Number, counter: Number}
	*/

	var ADD_NUM = 'ADD_NUM';
	var MINUS_NUM = 'MINUS_NUM';
	function view(state, update) {
		return (0, _snabbdomH2['default'])('div.contbox.clearfix', { style: {} }, [(0, _snabbdomH2['default'])('a.contl', {
			on: {
				click: function click(e) {
					e.stopPropagation();
					update.bind(null, { type: MINUS_NUM })();
				}
			},
			style: {
				cursor: 'pointer'
			},
			props: {
				href: 'javascript:void(0);'
			}
		}, '-'), (0, _snabbdomH2['default'])('span.contm', {}, state.counter), (0, _snabbdomH2['default'])('a.contr', {
			on: {
				click: function click(e) {
					e.stopPropagation();
					update.bind(null, { type: ADD_NUM })();
				}
			},
			style: {
				cursor: 'pointer'
			},
			props: {
				href: 'javascript:void(0);'
			}
		}, '+')]);
	}
	function update(state, action) {
		var newState = null;
		switch (action.type) {
			case ADD_NUM:
				if (state.counter === 4) {
					newState = _extends({}, state, { counter: 0 });
				} else {
					newState = _extends({}, state, { counter: state.counter + 1 });
				}
				_listener2['default'].trigger('sideEffectByAdjuster', { type: 'add', payload: {
						id: newState.id,
						counter: newState.counter
					} });
				return newState;
			case MINUS_NUM:
				if (state.counter === 0) {
					newState = _extends({}, state, { counter: 4 });
				} else {
					newState = _extends({}, state, { counter: state.counter - 1 });
				}
				_listener2['default'].trigger('sideEffectByAdjuster', { type: 'minus', payload: {
						id: newState.id,
						counter: newState.counter
					} });
				return newState;
			default:
				return state;
		}
	}
	exports['default'] = { view: view, update: update, actions: { ADD_NUM: ADD_NUM, MINUS_NUM: MINUS_NUM } };
	module.exports = exports['default'];

/***/ },
/* 33 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	exports["default"] = function (callback, limit) {
		var wait = false; // Initially, we're not waiting
		return function () {
			// We return a throttled function
			if (!wait) {
				// If we're not waiting
				callback.call(); // Execute users function
				wait = true; // Prevent future invocations
				setTimeout(function () {
					// After a period of time
					wait = false; // And allow future invocations
				}, limit);
			}
		};
	};

	module.exports = exports["default"];

/***/ },
/* 34 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by wuyukun on 2015/12/12.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	var _slicedToArray = (function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i['return']) _i['return'](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError('Invalid attempt to destructure non-iterable instance'); } }; })();

	var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

	function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj['default'] = obj; return newObj; } }

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

	var _THREE = __webpack_require__(35);

	var _THREE2 = _interopRequireDefault(_THREE);

	var _GridData = __webpack_require__(36);

	var _GridData2 = _interopRequireDefault(_GridData);

	var _GridHelper = __webpack_require__(37);

	var _GridHelper2 = _interopRequireDefault(_GridHelper);

	var _projectionUserInput = __webpack_require__(5);

	var _projectionUserInput2 = _interopRequireDefault(_projectionUserInput);

	var _controlNotify = __webpack_require__(15);

	var _controlNotify2 = _interopRequireDefault(_controlNotify);

	var _projectionActions = __webpack_require__(9);

	var actions = _interopRequireWildcard(_projectionActions);

	var _controlListener = __webpack_require__(27);

	var _controlListener2 = _interopRequireDefault(_controlListener);

	var _controlRotateGrid = __webpack_require__(29);

	var _controlRotateGrid2 = _interopRequireDefault(_controlRotateGrid);

	var _destroyThreeObject = __webpack_require__(38);

	var _destroyThreeObject2 = _interopRequireDefault(_destroyThreeObject);

	var _constants = __webpack_require__(8);

	var PerspectiveViewHelper = (function () {
		function PerspectiveViewHelper() {
			_classCallCheck(this, PerspectiveViewHelper);

			this.PERSPECTIVE_CAMERA_INIT_POSITION = {
				x: 100,
				y: 80,
				z: 100
			};
			this.GRIDVIEW_ROTATIONS = {
				INIT_ROTATION: 105,
				LEFT_VIEW_ROTATION: 0,
				FRONT_VIEW_ROTATION: 90,
				VERTICAL_VIEW_ROTATION: 90
			};
			this.ROTATION_SPEED = {
				ySpeed: 35,
				rSpeed: 10
			};
			this.CubeSize = 50;
			this.CubeColor = 0x7298C0;
			this.CubeHighlightColor = 0x88afdb;
			this.CubeBorderColor = 0xE2F1FF;
			// 定义画布尺寸
			this.REAL_ESTATE = {
				width: 500,
				height: 500
			};
			//相机视角原点
			this.ZERO_POINT = new _THREE2['default'].Vector3(0, 0, 0);
			//网格帮助类
			this.gridHelper = new _GridHelper2['default'](_constants.GRID_SETTING.row, _constants.GRID_SETTING.column, this.CubeSize, this.CubeSize);
			//方块数据类
			this.gridData = new _GridData2['default'](_constants.GRID_SETTING.row, _constants.GRID_SETTING.column, _constants.GRID_SETTING.h);
			//相机距离
			this.CAMERA_DISTANCE = Math.sqrt(Math.pow(this.PERSPECTIVE_CAMERA_INIT_POSITION.x, 2) + Math.pow(this.PERSPECTIVE_CAMERA_INIT_POSITION.y, 2) + Math.pow(this.PERSPECTIVE_CAMERA_INIT_POSITION.z, 2));
			this.CubeMaterial = new _THREE2['default'].MeshBasicMaterial({
				color: this.CubeColor
			});
			this.CubeHighlightMaterial = new _THREE2['default'].MeshBasicMaterial({
				color: this.CubeHighlightColor
			});
			this.CubeGeometry = new _THREE2['default'].BoxGeometry(this.CubeSize, this.CubeSize, this.CubeSize);
			this.timeoutId = 0;
			this.yDiff = 0;
			this.rotationDiff = 0;
		}

		_createClass(PerspectiveViewHelper, [{
			key: 'createPerspectiveView',
			value: function createPerspectiveView(view) {
				this.container = view;
				this.initThree();
				this.initThreeData();
				this.initView();
			}
		}, {
			key: 'initThree',
			value: function initThree() {
				this.perspectiveViewCamera = new _THREE2['default'].OrthographicCamera(this.REAL_ESTATE.width / -2, this.REAL_ESTATE.width / 2, this.REAL_ESTATE.height / 2, this.REAL_ESTATE.height / -2, -500, 500);
				this.perspectiveViewScene = new _THREE2['default'].Scene();
				this.perspectiveViewRenderer = new _THREE2['default'].WebGLRenderer({ antialias: true, alpha: true });

				this.perspectiveViewCamera.position.x = this.PERSPECTIVE_CAMERA_INIT_POSITION.x;
				this.perspectiveViewCamera.position.y = this.PERSPECTIVE_CAMERA_INIT_POSITION.y;
				this.perspectiveViewCamera.position.z = this.PERSPECTIVE_CAMERA_INIT_POSITION.z;
				this.perspectiveViewCamera.lookAt(this.ZERO_POINT);

				// Add axes
				//let axeLen = (GRID_SETTING.column > GRID_SETTING.row ? GRID_SETTING.column : GRID_SETTING.row) * this.CubeSize;
				//let axes = new THREE.AxisHelper(axeLen);
				//this.perspectiveViewScene.add(axes);
				this.perspectiveViewRenderer.setClearColor(0xf0f0f0, 0);
				this.perspectiveViewRenderer.setPixelRatio(window.devicePixelRatio);
				this.perspectiveViewRenderer.setSize(this.REAL_ESTATE.width, this.REAL_ESTATE.height);

				this.mouse = new _THREE2['default'].Vector2();
				this.raycaster = new _THREE2['default'].Raycaster();
			}
		}, {
			key: 'initThreeData',
			value: function initThreeData() {
				this.planeGeometry = new _THREE2['default'].PlaneBufferGeometry(_constants.GRID_SETTING.row * this.CubeSize, _constants.GRID_SETTING.column * this.CubeSize);
				this.planeGeometry.rotateX(-Math.PI / 2);
				//网格白色底层
				var gridBackground = new _THREE2['default'].Mesh(this.planeGeometry, new _THREE2['default'].MeshBasicMaterial({
					color: 0xe5c591,
					visible: true
				}));
				//y不能为0，否则和网格一层，会造成渲染不完全
				gridBackground.position.y = -0.3;
				this.perspectiveViewScene.add(gridBackground);

				//透明底层
				var plane = new _THREE2['default'].Mesh(this.planeGeometry, new _THREE2['default'].MeshBasicMaterial({ visible: false }));
				//高亮层
				var shape = new _THREE2['default'].Shape();
				shape.moveTo(0, 0);
				shape.lineTo(0, this.CubeSize);
				shape.lineTo(this.CubeSize, this.CubeSize);
				shape.lineTo(this.CubeSize, 0);
				shape.lineTo(0, 0);
				var points = shape.createPointsGeometry();
				points.rotateX(-Math.PI / 2);
				var highlightPlane = new _THREE2['default'].Line(points, new _THREE2['default'].LineBasicMaterial({ color: 0x567190, linewidth: 3 }));
				highlightPlane.position.y = 0.01;

				//this.highlightPlaneGeometry = new THREE.PlaneBufferGeometry(this.CubeSize, this.CubeSize);
				//this.highlightPlaneGeometry.rotateX(-Math.PI / 2);
				//let highlightPlane = new THREE.Mesh(this.highlightPlaneGeometry, new THREE.MeshBasicMaterial({
				//    visible: true,
				//    color: 0xB3D1F2
				//}));

				// Perspective View
				this.perspectiveViewScene.add(this.gridHelper.createView());

				this.perspectiveViewScene.add(plane);
				this.gridData.setPlane(plane);

				//y不能为0，否则和网格一层，会造成渲染不完全
				highlightPlane.position.y = 0.01;
				this.perspectiveViewScene.add(highlightPlane);
				this.gridData.setHighlightPlane(highlightPlane);

				this.setHighlightPlanePosition(0, 0);
				this.rotateCube(this.GRIDVIEW_ROTATIONS.INIT_ROTATION);
			}
		}, {
			key: 'initView',
			value: function initView() {

				var $view = $(this.container).find('.js-lego-canvas');
				var $obj = this;

				//insert canvas
				$view.find(".canvasbox").find('.main').append(this.perspectiveViewRenderer.domElement);
				//透视图操作
				$(this.perspectiveViewRenderer.domElement).on('click', function (e) {
					e.stopPropagation();
					//窗口移动，有偏移量，需要和画布的偏移一起计算
					$obj.mouse.x = (event.clientX - $obj.perspectiveViewRenderer.domElement.getBoundingClientRect().left) / $obj.perspectiveViewRenderer.domElement.clientWidth * 2 - 1;
					$obj.mouse.y = -((event.clientY - $obj.perspectiveViewRenderer.domElement.getBoundingClientRect().top) / $obj.perspectiveViewRenderer.domElement.clientHeight) * 2 + 1;
					$obj.raycaster.setFromCamera($obj.mouse, $obj.perspectiveViewCamera);
					var intersects = $obj.raycaster.intersectObjects($obj.gridData.getMeshObjects(), true);
					if (intersects.length > 0) {
						var intersect = intersects[0];
						if ($obj.gridHelper.isPointInGrid(intersect.point.x, intersect.point.z) && intersect.face != null) {
							//console.log('x:' + intersect.point.x + ',y:' + intersect.point.y + ',z:' + intersect.point.z + ',face x->' + intersect.face.normal.x + ', y->' + intersect.face.normal.y + ', z->' + intersect.face.normal.z);

							var _$obj$gridHelper$getIndexByPosition = $obj.gridHelper.getIndexByPosition(intersect.point.x, intersect.point.z, intersect.face.normal.x, intersect.face.normal.z);

							var _$obj$gridHelper$getIndexByPosition2 = _slicedToArray(_$obj$gridHelper$getIndexByPosition, 2);

							var xIndex = _$obj$gridHelper$getIndexByPosition2[0];
							var zIndex = _$obj$gridHelper$getIndexByPosition2[1];

							//var yIndex = Math.floor(intersect.point.y / cubeSize);
							//console.log('xIndex : ' + xIndex + ',zIndex : ' + zIndex + ',yIndex :' + yIndex);
							if ($obj.gridData.highlightPosition.row != xIndex || $obj.gridData.highlightPosition.column != zIndex) {
								$obj.highlightCubeInPosition(xIndex, zIndex);
								if (_constants.isTeacherMobile) {
									(0, _projectionUserInput2['default'])({
										type: actions.highlightCubeByClickPlane,
										payload: {
											xIndex: xIndex,
											zIndex: zIndex
										}
									});
								}
							} else {
								if (intersect.face.normal.y == 1 || intersect.face.normal.y == -1) {
									$obj.addCube(xIndex, zIndex);
									if (_constants.isTeacherMobile) {
										(0, _projectionUserInput2['default'])({
											type: actions.addCubeByClickPlane,
											payload: {
												xIndex: xIndex,
												zIndex: zIndex,
												counter: $obj.gridData.getObjectCountAtPosition(xIndex, zIndex)
											}
										});
									}
								} else if (intersect.object != $obj.plane) {
									$obj.deleteCube(xIndex, zIndex);
									if (_constants.isTeacherMobile) {
										(0, _projectionUserInput2['default'])({
											type: actions.deleteCubeByClickPlane,
											payload: {
												xIndex: xIndex,
												zIndex: zIndex,
												counter: $obj.gridData.getObjectCountAtPosition(xIndex, zIndex)
											}
										});
									}
								}
							}
							(0, _controlNotify2['default'])(xIndex, zIndex);
						}
					}
					intersects = null;
				});
				$view.find('.rotation-control').click(function (e) {
					e.stopPropagation();
					if ($obj.perspectiveViewCamera.position.y == $obj.CAMERA_DISTANCE || $obj.perspectiveViewCamera.position.x == $obj.CAMERA_DISTANCE || $obj.perspectiveViewCamera.position.z == $obj.CAMERA_DISTANCE) {
						$obj.setCubeStatus($obj.GRIDVIEW_ROTATIONS.INIT_ROTATION, $obj.PERSPECTIVE_CAMERA_INIT_POSITION.y, true);
					} else {
						$obj.setCubeStatus($obj.gridHelper.ROTATION + ($(this).hasClass('btn-arrow-left') ? 90 : -90), $obj.PERSPECTIVE_CAMERA_INIT_POSITION.y, true);
					}
				});
				$view.find('.btn-vertical-view').click(function (e) {
					e.stopPropagation();
					if ($obj.gridHelper.ROTATION == 90 && $obj.perspectiveViewCamera.position.y == $obj.CAMERA_DISTANCE) return;
					if ($obj.gridHelper.ROTATION % 360 == 0 || $obj.gridHelper.ROTATION % 360 == $obj.GRIDVIEW_ROTATIONS.INIT_ROTATION) {
						$obj.setCubeStatus($obj.GRIDVIEW_ROTATIONS.VERTICAL_VIEW_ROTATION, $obj.CAMERA_DISTANCE, false, 0);
					} else {
						$obj.setCubeStatus($obj.GRIDVIEW_ROTATIONS.VERTICAL_VIEW_ROTATION, $obj.CAMERA_DISTANCE, true, 0);
					}
				});
				$view.find('.btn-origin-view').click(function (e) {
					e.stopPropagation();
					$obj.setCubeStatus($obj.GRIDVIEW_ROTATIONS.INIT_ROTATION, $obj.PERSPECTIVE_CAMERA_INIT_POSITION.y, true, 0);
				});

				$view.find('.btn-left-view').click(function (e) {
					e.stopPropagation();
					if ($obj.gridHelper.ROTATION % 360 == 90) {
						$obj.setCubeStatus($obj.GRIDVIEW_ROTATIONS.LEFT_VIEW_ROTATION, 0, true, 0);
					} else {
						$obj.setCubeStatus($obj.GRIDVIEW_ROTATIONS.LEFT_VIEW_ROTATION, 0, false, 0);
					}
				});
				$view.find('.btn-front-view').click(function (e) {
					e.stopPropagation();
					$obj.setCubeStatus($obj.GRIDVIEW_ROTATIONS.FRONT_VIEW_ROTATION, 0, false, 0);
				});
				this.render();
			}
		}, {
			key: 'render',
			value: function render() {
				this.perspectiveViewRenderer.render(this.perspectiveViewScene, this.perspectiveViewCamera);
			}

			/**
	   * 设置高亮层在格子中的位置
	   * @param row 行
	   * @param column 列
	   */

		}, {
			key: 'setHighlightPlanePosition',
			value: function setHighlightPlanePosition(row, column) {
				var _gridHelper$getCubePosition = this.gridHelper.getCubePosition(row, column);

				var _gridHelper$getCubePosition2 = _slicedToArray(_gridHelper$getCubePosition, 2);

				var x = _gridHelper$getCubePosition2[0];
				var z = _gridHelper$getCubePosition2[1];

				var plane = this.gridData.getHighlightPlane();
				plane.position.copy(new _THREE2['default'].Vector3(x - this.gridHelper.rSize / 2, 0.01, z + this.gridHelper.cSize / 2));
				this.render();
			}

			/**
	   * 设置方块塔状态公共接口
	   * @param targetRotation {Number} 旋转最终角度
	   * @param targetY {Number} camera位置最终y值
	   * @param isYFirst {boolean} 是否优先旋转camera的Y轴
	   * @param overrideRotation {Number} 覆盖 gridViewHelper.ROTATION 旋转角度
	   */
		}, {
			key: 'setCubeStatus',
			value: function setCubeStatus(targetRotation, targetY, isYFirst, overrideRotation) {
				this.timeoutId = 0;
				this.yDiff = this.perspectiveViewCamera.position.y - targetY;
				this.rotationDiff = targetRotation - this.gridHelper.ROTATION;
				this.rotationDiff %= 360;
				this.setButtonStatus(true);
				if (typeof overrideRotation !== 'undefined') {
					_controlListener2['default'].trigger('rotateCubeView', targetRotation, targetY, isYFirst, this.gridHelper.ROTATION + this.rotationDiff, overrideRotation);
				} else {
					_controlListener2['default'].trigger('rotateCubeView', targetRotation, targetY, isYFirst, this.gridHelper.ROTATION + this.rotationDiff);
				}
				this.rotateView(isYFirst, overrideRotation);
			}
		}, {
			key: 'rotateView',
			value: function rotateView(isYFirst, overrideRotation) {
				var $obj = this;
				this.timeoutId = setTimeout(function () {
					$obj.rotateView(isYFirst, overrideRotation);
				}, 48);
				if (isYFirst) {
					if (Math.abs(this.yDiff) < this.ROTATION_SPEED.ySpeed) {
						this.perspectiveViewCamera.position.y -= this.yDiff;
						this.yDiff = 0;
					} else {
						this.perspectiveViewCamera.position.y += this.yDiff > 0 ? -this.ROTATION_SPEED.ySpeed : this.ROTATION_SPEED.ySpeed;
						this.yDiff += this.yDiff > 0 ? -this.ROTATION_SPEED.ySpeed : this.ROTATION_SPEED.ySpeed;
					}
					if (this.yDiff == 0 && this.rotationDiff != 0) {
						if (Math.abs(this.rotationDiff) < this.ROTATION_SPEED.rSpeed) {
							this.gridHelper.ROTATION += this.rotationDiff;
							this.rotationDiff = 0;
						} else {
							this.gridHelper.ROTATION -= this.rotationDiff > 0 ? -this.ROTATION_SPEED.rSpeed : this.ROTATION_SPEED.rSpeed;
							this.rotationDiff += this.rotationDiff > 0 ? -this.ROTATION_SPEED.rSpeed : this.ROTATION_SPEED.rSpeed;
						}
					}
				} else {
					if (Math.abs(this.rotationDiff) < this.ROTATION_SPEED.rSpeed) {
						this.gridHelper.ROTATION += this.rotationDiff;
						this.rotationDiff = 0;
					} else {
						this.gridHelper.ROTATION -= this.rotationDiff > 0 ? -this.ROTATION_SPEED.rSpeed : this.ROTATION_SPEED.rSpeed;
						this.rotationDiff += this.rotationDiff > 0 ? -this.ROTATION_SPEED.rSpeed : this.ROTATION_SPEED.rSpeed;
					}
					if (this.yDiff != 0 && this.rotationDiff == 0) {
						if (Math.abs(this.yDiff) < this.ROTATION_SPEED.ySpeed) {
							this.perspectiveViewCamera.position.y -= this.yDiff;
							this.yDiff = 0;
						} else {
							this.perspectiveViewCamera.position.y += this.yDiff > 0 ? -this.ROTATION_SPEED.ySpeed : this.ROTATION_SPEED.ySpeed;
							this.yDiff += this.yDiff > 0 ? -this.ROTATION_SPEED.ySpeed : this.ROTATION_SPEED.ySpeed;
						}
					}
				}
				if (this.perspectiveViewCamera.position.y == this.CAMERA_DISTANCE && this.rotationDiff != 0 && isYFirst) {
					var xzLen = this.CAMERA_DISTANCE / 2;
					this.perspectiveViewCamera.position.x = xzLen * Math.sin(this.gridHelper.ROTATION / 180 * Math.PI);
					this.perspectiveViewCamera.position.z = xzLen * Math.cos(this.gridHelper.ROTATION / 180 * Math.PI);
				} else {
					var xzLen = Math.sqrt(Math.pow(this.CAMERA_DISTANCE, 2) - Math.pow(this.perspectiveViewCamera.position.y, 2));
					this.perspectiveViewCamera.position.x = xzLen * Math.sin(this.gridHelper.ROTATION / 180 * Math.PI);
					this.perspectiveViewCamera.position.z = xzLen * Math.cos(this.gridHelper.ROTATION / 180 * Math.PI);
				}
				//每次旋转完成将旋转角归一到0~360之间
				this.gridHelper.ROTATION %= 360;
				if (this.gridHelper.ROTATION < 0) this.gridHelper.ROTATION += 360;
				this.perspectiveViewCamera.lookAt(this.ZERO_POINT);
				this.render();
				if (this.yDiff == 0 && this.rotationDiff == 0) {
					this.setButtonStatus(false);
					clearTimeout(this.timeoutId);
					return;
				}
			}

			/**
	   * 点击Canvas网格事件
	   * @param event
	   */
		}, {
			key: 'renderDomElemetClickEventListener',
			value: function renderDomElemetClickEventListener(event) {}
		}, {
			key: 'highlightCubeInPosition',
			value: function highlightCubeInPosition(row, column) {
				var _this = this;

				this.setHighlightPlanePosition(row, column);
				var gridCubeArr = this.gridData.getGridCubeArr();
				gridCubeArr.forEach(function (rowObjects, rowIndex) {
					rowObjects.forEach(function (h, columnIndex) {
						for (var i = 0; i < h; i++) {
							var _gridData$getGridObject = _this.gridData.getGridObject(rowIndex, columnIndex, i);

							var _gridData$getGridObject2 = _slicedToArray(_gridData$getGridObject, 2);

							var cube = _gridData$getGridObject2[0];
							var cubeBorder = _gridData$getGridObject2[1];

							if (cube != undefined && cubeBorder != undefined) {
								if (rowIndex == row && columnIndex == column) {
									cube.material = _this.CubeHighlightMaterial;
								} else {
									cube.material = _this.CubeMaterial;
								}
							}
						}
					});
				});
				this.gridData.highlightPosition = { row: row, column: column };
				this.render();
			}

			/**
	   * 删除方块公共接口
	   * @param row 行
	   * @param column 列
	   * @returns {boolean} true 删除成功;false 删除失败
	   */
		}, {
			key: 'deleteCube',
			value: function deleteCube(row, column) {
				var _gridData$popObjectAtPosition = this.gridData.popObjectAtPosition(row, column);

				var _gridData$popObjectAtPosition2 = _slicedToArray(_gridData$popObjectAtPosition, 2);

				var toDeleteObj = _gridData$popObjectAtPosition2[0];
				var toDeleteBorder = _gridData$popObjectAtPosition2[1];

				if (toDeleteObj != undefined && toDeleteBorder != undefined) {
					this.perspectiveViewScene.remove(toDeleteObj);
					this.perspectiveViewScene.remove(toDeleteBorder);
					(0, _destroyThreeObject2['default'])(toDeleteObj);
					(0, _destroyThreeObject2['default'])(toDeleteBorder);
					this.render();
					return true;
				}
				return false;
			}

			/**
	   * 添加方块公共接口
	   * @param row 行
	   * @param column 列
	   */
		}, {
			key: 'addCube',
			value: function addCube(row, column) {
				//方格中已经添加的方块数
				var cubeCount = this.gridData.getObjectCountAtPosition(row, column);
				if (cubeCount < _constants.GRID_SETTING.h) {
					//构造方块，方块中心点决定方块位置
					var cube = new _THREE2['default'].Mesh(this.CubeGeometry, this.CubeHighlightMaterial);

					var _gridHelper$getCubePosition3 = this.gridHelper.getCubePosition(row, column);

					var _gridHelper$getCubePosition32 = _slicedToArray(_gridHelper$getCubePosition3, 2);

					var x = _gridHelper$getCubePosition32[0];
					var z = _gridHelper$getCubePosition32[1];

					var point = new _THREE2['default'].Vector3(x, (cubeCount + 0.5) * this.CubeSize, z);
					cube.position.copy(point).add(new _THREE2['default'].Vector3(0, 1, 0));
					cube.position.divideScalar(this.CubeSize).floor().multiplyScalar(this.CubeSize).addScalar(this.CubeSize / 2);
					var cubeBorder = new _THREE2['default'].BoxHelper(cube);
					cubeBorder.material.color.setHex(this.CubeBorderColor);
					cube.scale.multiplyScalar(0.98);
					this.perspectiveViewScene.add(cube);
					this.perspectiveViewScene.add(cubeBorder);
					this.gridData.pushObjectAtPosition(row, column, cube, cubeBorder);
					this.render();
				}
			}

			/**
	   * 修改四面旋转按钮的状态
	   * @param state {Boolean}
	   */
		}, {
			key: 'setButtonStatus',
			value: function setButtonStatus(state) {
				$(this.container).find('.js-lego-canvas').find('button').each(function () {
					$(this).attr('disabled', state);
				});
			}

			/**
	   * 旋转方块
	   * @param rotation 旋转角度
	   */
		}, {
			key: 'rotateCube',
			value: function rotateCube(rotation) {
				this.gridHelper.ROTATION = rotation % 360;
				var alpha = rotation % 360 / 180 * Math.PI;
				var xzLen = Math.sqrt(Math.pow(this.perspectiveViewCamera.position.x, 2) + Math.pow(this.perspectiveViewCamera.position.z, 2));
				this.perspectiveViewCamera.position.x = Math.sin(alpha) * xzLen;
				this.perspectiveViewCamera.position.z = Math.cos(alpha) * xzLen;
				this.perspectiveViewCamera.lookAt(this.perspectiveViewScene.position);
				this.render();
			}

			/**
	   * 设置某一格子方块数量
	   * @param row 行
	   * @param column 列
	   * @param count 方块数
	   * @returns {boolean} false 设置失败；true 设置成功
	   */
		}, {
			key: 'setCubeCountInPosition',
			value: function setCubeCountInPosition(row, column, count) {
				if (row > _constants.GRID_SETTING.row || row < 0 || column > _constants.GRID_SETTING.column || column < 0 || count < 0 || count > _constants.GRID_SETTING.h) return false;
				//方格中已经添加的方块数
				var curCount = this.gridData.getObjectCountAtPosition(row, column);
				for (var i = 0, l = Math.abs(curCount - count); i < l; i++) {
					if (curCount > count) {
						this.deleteCube(row, column);
					} else if (curCount < count) {
						this.addCube(row, column);
					}
				}
				return true;
			}

			/**
	   * 重置方块塔状态
	   */
		}, {
			key: 'resetCubeStatus',
			value: function resetCubeStatus(isRemoveAll) {
				for (var r = 0; r < this.gridData.row; r++) {
					for (var c = 0; c < this.gridData.column; c++) {
						this.setCubeCountInPosition(r, c, 0);
					}
				}
				this.perspectiveViewCamera.position.x = this.PERSPECTIVE_CAMERA_INIT_POSITION.x;
				this.perspectiveViewCamera.position.y = this.PERSPECTIVE_CAMERA_INIT_POSITION.y;
				this.perspectiveViewCamera.position.z = this.PERSPECTIVE_CAMERA_INIT_POSITION.z;
				this.rotateCube(this.GRIDVIEW_ROTATIONS.INIT_ROTATION);
				this.perspectiveViewCamera.lookAt(this.ZERO_POINT);
				if (isRemoveAll) {
					this.gridData.ROTATION = 0;
					for (var index = this.perspectiveViewScene.children.length; index > 0; index--) {
						var child = this.perspectiveViewScene.children[index - 1];
						this.perspectiveViewScene.remove(child);
						(0, _destroyThreeObject2['default'])(child);
					}
					(0, _destroyThreeObject2['default'])(this.gridData.plane);
					this.gridData.plane = null;
					(0, _destroyThreeObject2['default'])(this.gridData.highlightPlane);
					this.gridData.highlightPlane = null;
					$(this.perspectiveViewRenderer.domElement).off('click');
				} else {
					this.setHighlightPlanePosition(0, 0);
				}
				this.render();
			}

			/**
	   * 初始化方块塔状态
	   * @param gridCubeData {Object} 格子中方块数据，方块高亮点
	   * @param gridRotation {Number} 方块旋转角度
	   * @param cameraPosition {Object} 相机位置
	   */
		}, {
			key: 'initCubeData',
			value: function initCubeData(gridCubeData, gridRotation, cameraPosition) {
				var _this2 = this;

				gridCubeData.gridCubeArr.forEach(function (rowArr, row) {
					rowArr.forEach(function (count, column) {
						_this2.setCubeCountInPosition(row, column, count);
					});
				});
				this.gridData.highlightPosition.row = gridCubeData.highlightPosition.row;
				this.gridData.highlightPosition.column = gridCubeData.highlightPosition.column;
				this.highlightCubeInPosition(gridCubeData.highlightPosition.row, gridCubeData.highlightPosition.column);
				this.rotateCube(gridRotation);
				this.perspectiveViewCamera.position.x = cameraPosition.positionX;
				this.perspectiveViewCamera.position.y = cameraPosition.positionY;
				this.perspectiveViewCamera.position.z = cameraPosition.positionZ;
				this.perspectiveViewCamera.lookAt(this.ZERO_POINT);
				this.render();
				// 初始化平面格子
				(0, _controlNotify2['default'])(gridCubeData.highlightPosition.row, gridCubeData.highlightPosition.column);
				// 旋转平面格子 初始化时不应该触发 userInput 的动作
				if (gridRotation % 90 == 0) {
					(0, _controlRotateGrid2['default'])($(this.container).find('.lego-view-counter-list'), 0); // 左面·正面·等，平面格子不旋转
				} else {
						(0, _controlRotateGrid2['default'])($(this.container).find('.lego-view-counter-list'), gridRotation - this.GRIDVIEW_ROTATIONS.INIT_ROTATION);
					}
			}
		}, {
			key: 'zoomCamera',
			value: function zoomCamera() {
				//this.perspectiveViewCamera.setZoo
			}
		}, {
			key: 'destroy',
			value: function destroy() {
				$(this.perspectiveViewRenderer.domElement).off('click');
				$(this.perspectiveViewRenderer.domElement).remove();
				(0, _destroyThreeObject2['default'])(this.perspectiveViewScene);
				this.perspectiveViewScene = null;
				(0, _destroyThreeObject2['default'])(this.perspectiveViewRenderer);
				this.perspectiveViewRenderer = null;
				(0, _destroyThreeObject2['default'])(this.perspectiveViewCamera);
				this.perspectiveViewCamera = null;
				(0, _destroyThreeObject2['default'])(this.CubeMaterial);
				this.CubeMaterial = null;
				(0, _destroyThreeObject2['default'])(this.CubeHighlightMaterial);
				this.CubeHighlightMaterial = null;
				(0, _destroyThreeObject2['default'])(this.CubeGeometry);
				this.CubeGeometry = null;

				this.mouse = null;
				this.raycaster = null;

				this.gridHelper.destroy();
				this.gridHelper = null;
				this.gridData = null;
				$(this.container).find('button').off('click');
				this.container = null;
			}
		}]);

		return PerspectiveViewHelper;
	})();

	exports['default'] = PerspectiveViewHelper;
	module.exports = exports['default'];

/***/ },
/* 35 */
/***/ function(module, exports) {

	// const three = require('three') // 测试环境使用
	"use strict";

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	var three = window.THREE; // 正式环境使用
	exports["default"] = three;
	module.exports = exports["default"];

/***/ },
/* 36 */
/***/ function(module, exports) {

	/**
	 * @author 吴玉坤 on 2015/11/11.
	 * 记录4*4网格每个格子的方块数
	 */
	"use strict";

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var GridData = (function () {
		/**
	  * 构造 row * column * h 网格
	  * @param row 行数
	  * @param column 列数
	  * @param h 每个格子最多几个方块
	  */

		function GridData(row, column, h) {
			_classCallCheck(this, GridData);

			this.row = row;
			this.column = column;
			this.h = h;
			this.grid = new Array();
			this.plane = null;
			this.highlightPlane = null;
			this.meshObjects = [];
			this.highlightPosition = { row: 0, column: 0 };
			this.initGridData();
		}

		/**
	  * 初始化网格
	  */

		_createClass(GridData, [{
			key: "initGridData",
			value: function initGridData() {
				for (var i = 0; i < this.row; i++) {
					this.grid[i] = new Array();
					for (var j = 0; j < this.column; j++) {
						this.grid[i][j] = new Array();
					}
				}
			}

			/**
	   * 添加底部平面层
	   * @param object
	   */
		}, {
			key: "setPlane",
			value: function setPlane(object) {
				this.plane = object;
			}

			/**
	   * 添加高亮层
	   * @returns {null|*}
	   */
		}, {
			key: "setHighlightPlane",
			value: function setHighlightPlane(object) {
				this.highlightPlane = object;
			}

			/**
	   * 获取高亮层
	   * @returns {object} 高亮层Mesh
	   */
		}, {
			key: "getHighlightPlane",
			value: function getHighlightPlane() {
				return this.highlightPlane;
			}

			/**
	   * 在某个位置上添加方块
	   * @param row 行
	   * @param column 列
	   * @param cube 方块对象
	   * @returns {boolean} true 添加成功；false 添加失败
	   */
		}, {
			key: "pushObjectAtPosition",
			value: function pushObjectAtPosition(row, column, cube, cubeBorder) {
				if (row < 0 || row >= this.row || column < 0 || column >= this.column) return false;
				this.meshObjects.push(cube);
				this.meshObjects.push(cubeBorder);
				this.grid[row][column].push(this.meshObjects.length - 1);
				return true;
			}

			/**
	   * 减少某个位置上的方块
	   * @param row 行
	   * @param column 列
	   * @returns [object1,object2]，从网格删除，并返回，undefined表示越界，不在网格内。object1 方块，object2 方块边界
	   */
		}, {
			key: "popObjectAtPosition",
			value: function popObjectAtPosition(row, column) {
				if (row < 0 || row >= this.row || column < 0 || column >= this.column) return [undefined, undefined];

				var hLen = this.grid[row][column].length;
				var index = this.grid[row][column][hLen - 1];
				if (index == undefined) return [undefined, undefined];
				var cubeBorder = this.meshObjects[index];
				var cube = this.meshObjects[index - 1];
				if (cube != undefined) {
					this.grid[row][column].splice(hLen - 1, 1);
					//each obj's index in meshObjects changed,need reindex the grid
					for (var i = 0; i < this.row; i++) {
						for (var j = 0; j < this.column; j++) {
							for (var k = 0, l = this.grid[i][j].length; k < l; k++) {
								var val = this.grid[i][j][k];
								if (val > 1 && val > index) this.grid[i][j][k] = val - 2;
							}
						}
					}
					this.meshObjects.splice(index - 1, 2);
				}
				return [cube, cubeBorder];
			}

			/**
	   * 获取某个位置的方块
	   * @param row 行
	   * @param column 列
	   * @param h 高度，纵向第几个方块，
	   * @returns [object1,object2]， 方块和网格对象，undefined表示越界，不在网格内
	   */
		}, {
			key: "getGridObject",
			value: function getGridObject(row, column, h) {
				if (row < 0 || row >= this.row || column < 0 || column >= this.column) return [undefined, undefined];
				var index = this.grid[row][column][h];
				if (index == undefined) return [undefined, undefined];
				return [this.meshObjects[index - 1], this.meshObjects[index]];
			}

			/**
	   * 获取第row行,第column列上的方块个数
	   * @param row 行
	   * @param column 列
	   * @returns {int} 方块数,undefined表示越界，不在网格内
	   */
		}, {
			key: "getObjectCountAtPosition",
			value: function getObjectCountAtPosition(row, column) {
				if (row < 0 || row >= this.row || column < 0 || column >= this.column) return undefined;
				return this.grid[row][column].length;
			}

			/**
	   * 放回网格上的所有mesh对象
	   * @returns {Array} 所有mesh对象
	   */
		}, {
			key: "getMeshObjects",
			value: function getMeshObjects() {
				var objects = [];
				objects.push(this.plane);
				objects.push(this.highlightPlane);
				return objects.concat(this.meshObjects);
			}

			/**
	   * 获取网格所有方块数量
	   */
		}, {
			key: "getGridCubeTotalCount",
			value: function getGridCubeTotalCount() {
				var totalCount = 0;
				for (var i = 0; i < this.row; i++) {
					for (var j = 0; j < this.column; j++) {
						totalCount += this.grid[i][j].length;
					}
				}
				return totalCount;
			}

			/**
	   * 获取网格上每个格子方块数量
	   * @returns {Array} 网格上每个格子方块数量
	   */
		}, {
			key: "getGridCubeArr",
			value: function getGridCubeArr() {
				var gridCubeArr = new Array();
				for (var i = 0; i < this.column; i++) {
					var columnArr = new Array();
					for (var j = 0; j < this.row; j++) {
						columnArr.push(this.grid[i][j].length);
					}
					gridCubeArr.push(columnArr);
				}
				return gridCubeArr;
			}
		}]);

		return GridData;
	})();

	exports["default"] = GridData;
	module.exports = exports["default"];

/***/ },
/* 37 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * @author 吴玉坤 on 2015/11/11.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

	var _THREE = __webpack_require__(35);

	var _THREE2 = _interopRequireDefault(_THREE);

	var _destroyThreeObject = __webpack_require__(38);

	var _destroyThreeObject2 = _interopRequireDefault(_destroyThreeObject);

	var GridHelper = (function () {
		function GridHelper(row, column, rSize, cSize) {
			_classCallCheck(this, GridHelper);

			this.row = row;
			this.column = column;
			this.rSize = rSize;
			this.cSize = cSize;
			this.ROTATION = 0;
		}

		_createClass(GridHelper, [{
			key: 'createView',
			value: function createView() {
				if (!this.line) {
					var geometry = new _THREE2['default'].Geometry();
					this.rStart = -Math.floor(this.row / 2) * this.rSize;
					this.rEnd = this.row * this.rSize + this.rStart;

					this.cStart = Math.floor(this.column / 2) * this.cSize;
					this.cEnd = -this.column * this.cSize + this.cStart;

					for (var i = this.cStart; i >= this.cEnd; i -= this.cSize) {
						geometry.vertices.push(new _THREE2['default'].Vector3(this.rStart, 0, i));
						geometry.vertices.push(new _THREE2['default'].Vector3(this.rEnd, 0, i));
					}
					for (var i = this.rStart; i <= this.rEnd; i += this.rSize) {
						geometry.vertices.push(new _THREE2['default'].Vector3(i, 0, this.cStart));
						geometry.vertices.push(new _THREE2['default'].Vector3(i, 0, this.cEnd));
					}
					this.material = new _THREE2['default'].LineBasicMaterial({ color: 0x8f644b, linewidth: 1 });
					this.line = new _THREE2['default'].LineSegments(geometry, this.material);
				}
				return this.line;
			}
		}, {
			key: 'getRowStart',
			value: function getRowStart() {
				return this.rStart;
			}
		}, {
			key: 'getRowEnd',
			value: function getRowEnd() {
				return this.rStart;
			}
		}, {
			key: 'getColumnStart',
			value: function getColumnStart() {
				return this.cStart;
			}
		}, {
			key: 'getColumnEnd',
			value: function getColumnEnd() {
				return this.cStart;
			}
		}, {
			key: 'isPointInGrid',
			value: function isPointInGrid(positionRow, positionColumn) {
				return positionColumn <= this.cStart && positionColumn >= this.cEnd && positionRow >= this.rStart && positionRow <= this.rEnd;
			}
		}, {
			key: 'getIndexByPosition',
			value: function getIndexByPosition(positionRow, positionColumn, faceRow, faceColumn) {
				//特殊处理，纠正鼠标事件误差。
				if ((faceRow == 1 || faceRow == -1) && (Math.abs(Math.abs(positionRow % this.rSize) - this.rSize) < 0.000001 || Math.abs(Math.abs(positionRow % this.rSize) - this.rSize) > 40 - 0.000001)) {
					positionRow = faceRow == 1 ? Math.floor(positionRow) : Math.ceil(positionRow);
				}
				if ((faceColumn == 1 || faceColumn == -1) && (Math.abs(Math.abs(positionColumn % this.cSize) - this.cSize) < 0.000001 || Math.abs(Math.abs(positionColumn % this.cSize) - this.cSize) > 40 - 0.000001)) {
					positionColumn = faceColumn == -1 ? Math.ceil(positionColumn) : Math.floor(positionColumn);
				}
				var rIndex = faceRow > 0 ? Math.ceil((positionRow - this.rStart) / this.rSize) - 1 : Math.floor((positionRow - this.rStart) / this.rSize);
				var cIndex = faceColumn < 0 ? Math.ceil((this.cStart - positionColumn) / this.cSize) - 1 : Math.floor((this.cStart - positionColumn) / this.cSize);
				return [rIndex, cIndex];
			}

			/**
	   * @param row 第几行
	   * @param column 第几列
	   * @returns {*[]} 方格的中心点
	   */
		}, {
			key: 'getCubePosition',
			value: function getCubePosition(row, column) {
				return [(row + 0.5) * this.rSize + this.rStart, this.cStart - (column + 0.5) * this.cSize];
			}
		}, {
			key: 'destroy',
			value: function destroy() {
				if (!this.line) {
					(0, _destroyThreeObject2['default'])(this.line);
					this.line = null;
					this.material = null;
				}
				this.row = null;
				this.column = null;
				this.rSize = null;
				this.cSize = null;
				this.ROTATION = null;
				this.rStart = null;
				this.rEnd = null;
				this.cStart = null;
				this.cEnd = null;
			}
		}]);

		return GridHelper;
	})();

	exports['default'] = GridHelper;
	module.exports = exports['default'];

/***/ },
/* 38 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
		value: true
	});
	exports["default"] = destroyThreeObj;

	function destroyThreeObj(obj) {
		if (!obj) return;
		if (Object.keys(obj).length < 1) return;
		if (obj.children && obj.children.length > 0) {
			for (var i = 0; i < obj.children.length; i++) {
				destroyThreeObj(obj.children[i]);
			}
		}
		if (obj.geometry) obj.geometry.dispose();
		if (obj.material) {
			obj.material.dispose();
			if (obj.material.map && obj.material.map.dispose) {
				obj.material.map.dispose();
			}
		}
	}

	module.exports = exports["default"];

/***/ },
/* 39 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
		value: true
	});

	exports["default"] = function (state) {
		var currentState;
		if (state) {
			currentState = JSON.parse(state);
			// ToDo:处理Module的状态恢复
		}
	};

	module.exports = exports["default"];

/***/ },
/* 40 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 获得当前Module的状态信息
	 * 可用于Module的状态恢复和保存
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	exports['default'] = function () {
		// TODO: 添加符合Module需求的状态对象
		var moduleState = JSON.stringify({
			module_id: _presenter2['default'].model.hasOwnProperty('ID') ? _presenter2['default'].model.ID : null
		});
		return moduleState;
	};

	module.exports = exports['default'];

/***/ },
/* 41 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _runtime = __webpack_require__(7);

	var _runtime2 = _interopRequireDefault(_runtime);

	var _nativeRegisterNativeListener = __webpack_require__(42);

	var _nativeRegisterNativeListener2 = _interopRequireDefault(_nativeRegisterNativeListener);

	var _triggerUserInput = __webpack_require__(43);

	var _triggerUserInput2 = _interopRequireDefault(_triggerUserInput);

	/**
	 *  移动环境投影端
	 */

	exports['default'] = function () {
		if (window.icCreatePlayer && _runtime2['default'] === window.icCreatePlayer.RUNTIME.PROJECTION_MOBILE) {
			(0, _nativeRegisterNativeListener2['default'])('TriggerUserInput', _triggerUserInput2['default']);
		}
	};

	module.exports = exports['default'];

/***/ },
/* 42 */
/***/ function(module, exports) {

	/**
	   * 投影端注册原生事件监听
	   * @param eventName
	   * @param callback
	   */
	"use strict";

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});

	exports["default"] = function (eventName, callback) {
	  if (window.isApp && window.Bridge && window.Bridge.registerListener) {
	    window.Bridge.registerListener(eventName, callback);
	  }
	};

	module.exports = exports["default"];

/***/ },
/* 43 */
/***/ function(module, exports, __webpack_require__) {

	/* global $ */
	/**
	 * 投影端接受指令
	 * 投影端应该接收教师端状态的 snapshot，而不仅仅只是模拟动作，否则网络掉包的情况下，会完全不可用
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj['default'] = obj; return newObj; } }

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _runtime = __webpack_require__(7);

	var _runtime2 = _interopRequireDefault(_runtime);

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _actions = __webpack_require__(9);

	var actions = _interopRequireWildcard(_actions);

	var _controlTransform = __webpack_require__(31);

	var _controlTransform2 = _interopRequireDefault(_controlTransform);

	var _controlNotify = __webpack_require__(15);

	var _controlNotify2 = _interopRequireDefault(_controlNotify);

	var _reset = __webpack_require__(14);

	var _reset2 = _interopRequireDefault(_reset);

	var _controlOperateCube = __webpack_require__(30);

	var _controlOperateCube2 = _interopRequireDefault(_controlOperateCube);

	/**
	 * @param data {Object} 消息对象
	 * @param data.source {String} 消息来源
	 * @param data.action {Object} 消息内容
	 */

	exports['default'] = function (data) {
		// 不为本模块指令不操作
		if (window.icCreatePlayer && (data.source !== 'Lego' || _runtime2['default'] !== window.icCreatePlayer.RUNTIME.PROJECTION_MOBILE)) {
			return;
		}
		console.log('this is projection');
		var $target = $(_presenter2['default'].view).find('.js-lego-view');
		var action = data.action;
		var payload = action.payload;
		/**
	  * 投影教师在 Grid 上的动作
	  */
		var projectTeacherModifyByGrid = function projectTeacherModifyByGrid(payload) {
			var id = payload.id;
			var counter = payload.counter;

			var _transform = (0, _controlTransform2['default'])(id);

			var row = _transform.row;
			var column = _transform.column;

			(0, _controlOperateCube2['default'])(id, counter);
			(0, _controlNotify2['default'])(row, column);
		};
		/**
	  * 投影教师在 Plane 上的动作
	  */
		var projectTeacherModifyByPlane = function projectTeacherModifyByPlane(payload) {
			var xIndex = payload.xIndex;
			var zIndex = payload.zIndex;
			var counter = payload.counter;

			var id = xIndex * 4 + zIndex + 1;
			(0, _controlOperateCube2['default'])(id, counter);
			(0, _controlNotify2['default'])(xIndex, zIndex);
		};
		switch (action.type) {
			case actions.showModule:
				// 显示模块
				$target.removeClass('is-hide');
				break;
			case actions.hideModule:
				// 隐藏模块
				(0, _reset2['default'])();
				$target.addClass('is-hide');
				break;
			case actions.moveModule:
				// 移动模块
				$target.get(0).style.transform = payload;
				break;
			case actions.modifyCubeCountByGrid:
				// 操作方格
				projectTeacherModifyByGrid(payload);
				break;
			case actions.addCubeCountByAdjuster:
			case actions.minusCubeCountByAdjuster:
				// 操作方格
				projectTeacherModifyByGrid(payload);
				break;
			case actions.modifyView:
				// 旋转视图
				var targetRotation = payload.targetRotation,
				    targetY = payload.targetY,
				    isYFirst = payload.isYFirst,
				    override = payload.override;

				_presenter2['default'].perspectiveViewHelper.setCubeStatus(targetRotation, targetY, isYFirst, override);
				break;
			case actions.addCubeByClickPlane:
			case actions.deleteCubeByClickPlane:
				projectTeacherModifyByPlane(payload);
				break;
			case actions.highlightCubeByClickPlane:
				// 高亮
				_presenter2['default'].perspectiveViewHelper.highlightCubeInPosition(payload.xIndex, payload.zIndex);
				break;
			default:
		}
	};

	module.exports = exports['default'];

/***/ },
/* 44 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 作为学科工具，翻页调用
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var _reset = __webpack_require__(14);

	var _reset2 = _interopRequireDefault(_reset);

	exports['default'] = function () {
	  (0, _reset2['default'])(false);
	  window.$(_presenter2['default'].view).find('.js-lego-view').addClass('is-hide');
	};

	module.exports = exports['default'];

/***/ },
/* 45 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * 作为互动题型，翻页调用，在备课系统预览，教师端，投影端，学生端都有调用
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
	  value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _reset = __webpack_require__(14);

	var _reset2 = _interopRequireDefault(_reset);

	exports['default'] = function () {
	  (0, _reset2['default'])(true);
	};

	module.exports = exports['default'];

/***/ },
/* 46 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	exports['default'] = function () {
		var question_id = '',
		    question_url = '';
		if (_presenter2['default'].model !== undefined) {
			try {
				question_id = _presenter2['default'].model.question_id;
				question_url = JSON.stringify(_presenter2['default'].model.question_url);
			} catch (e) {
				// console.log('json stringify failed')
			}
		}

		return {
			id: question_id,
			dispatchOnly: true,
			type_code: 'nd_lego',
			type_name: '方块塔',
			statistics_type: 'no_need', question_url: question_url
		};
	};

	module.exports = exports['default'];

/***/ },
/* 47 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	exports['default'] = function (controller) {
		_presenter2['default'].controller = controller;
		_presenter2['default'].eventBus = controller.getEventBus();
		_presenter2['default'].eventBus.addEventListener('SyncCallback', _presenter2['default']);
		_presenter2['default'].eventBus.addEventListener('PageLoaded', _presenter2['default']);
	};

	module.exports = exports['default'];

/***/ },
/* 48 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	var SyncCallback = function SyncCallback(eventData) {
		var type = eventData.type;
		var value = eventData.value;

		var $view = window.$(_presenter2['default'].view);
		switch (type) {
			case 'request':
				// 发送任务
				_presenter2['default'].syncId = value.syncId;
				if (value.result) {
					// 成功
					$view.find('.js-stop-sync-button').show();
				} else {
					window.ClassroomUtils.showTipMessageBox('同步题目失败');
				}
				break;
			case 'cancel':
				// 结束同步
				if (value.result) {
					$view.find('.js-stop-sync-button').hide();
				} else {
					window.ClassroomUtils.showMessageBox([{
						html: '关闭'
					}, {
						html: '重试',
						target: 'h5',
						callback: {
							eventName: 'Lego',
							eventData: {
								source: _presenter2['default'].model.ID,
								item: 'retry'
							}
						}
					}], '结束任务失败！');
				}
				break;
		}
	};

	exports['default'] = function (eventName, eventData) {
		switch (eventName) {
			case 'SyncCallback':
				SyncCallback(eventData);
				break;
			case 'PageLoaded':
				//console.log('PageLoaded');
				break;
			default:
			// console.log nothing
		}
	};

	module.exports = exports['default'];

/***/ },
/* 49 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by wuyukun on 2015/12/10.
	 */
	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	exports['default'] = function (view, model) {
		// 初始化数据
		if (model !== undefined && model.hasOwnProperty('question_url')) {
			try {
				var content = model.question_url.content;
				_presenter2['default'].perspectiveViewHelper.initCubeData(content.gridData, content.gridRotation, content.cameraPosition);
			} catch (e) {}
		}
	};

	module.exports = exports['default'];

/***/ },
/* 50 */
/***/ function(module, exports, __webpack_require__) {

	/**
	 * Created by wuyukun on 2015/12/11.
	 */

	'use strict';

	Object.defineProperty(exports, '__esModule', {
		value: true
	});

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

	var _presenter = __webpack_require__(1);

	var _presenter2 = _interopRequireDefault(_presenter);

	exports['default'] = function () {
		_presenter2['default'].perspectiveViewHelper.destroy();
		_presenter2['default'].perspectiveViewHelper = null;
		_presenter2['default'].view = null;
		_presenter2['default'].model = null;
	};

	module.exports = exports['default'];

/***/ }
/******/ ]);