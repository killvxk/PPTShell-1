/**
 *
 */
define(['app', 'classified/directive/classified.directive',
], function (app) {
    'use strict';
    app.controller('classified_ctrl', [
        '$scope','skin_service','$stateParams','CustomEditorService','UtilsService', '$rootScope',"$filter","$timeout",
        function ($scope,skin_service,$stateParams,CustomEditorService,UtilsService, $rootScope,$filter,$timeout) {
        	$rootScope.moduleScope = $scope;
        	$scope.errorModel = {};
            $scope.model = {
            	"title": "",
                "skin": {
                    code: "wood",
                    css_url: "${ref-path}/edu/esp/preparecustomeditor/classified/wood/css/wood.css",
                    name:  $filter('translate')('classified.muwen'),
                    package_url: "${ref-path}/edu/esp/preparecustomeditor/classified/wood"
                },
                "timer": {
                	"timer_type":"sequence",  //计时器类型: ["sequence", "countdown"]
                    "time_minute":"0",    //倒计时初始设置-分钟，timer_type="countdown"时有效
                    "time_second":"0"     //倒计时初始设置-秒，timer_type="countdown"时有效
                },
                "categories": [{},{},{}], //默认显示三个分类编辑框和添加按钮
                "classified_options": []
            };
            
            //最小、最大分类数
            $scope.MIN_SIZE = 2, $scope.MAX_SIZE = 5;
            
            var loadingData = function(id){
            	$scope.isloadingData=true;
                CustomEditorService.getQuestionInfoById(id)
                    .then(function(rtnData){
                        if(!rtnData){
                            $scope.errorModel.errorText = $filter('translate')('classified.unvalidno');
                        }else{
                            if(rtnData.skin.code!=''){
                                $scope.model=$scope.decodeData(rtnData);
                                skin_service.set_skin_by_code($scope.model.skin.code, 'v1');
                            }else{
                                $scope.model.id=rtnData.id;
                                skin_service.set_skin_by_code($scope.model.skin.code, 'v1');
                            }
                            $scope.errorModel.errorText = "";
                            $scope.isloadingData=false;
                            
                            setValues();
                        }
                    },function(error){
                        $scope.errorModel.errorText = $filter('translate')('classified.get_title_error');
                    })
            };
            
            var setValues = function() {
            };
            
            //入口
            if(!$stateParams.id) {
                skin_service.set_skin_by_code($scope.model.skin.code, 'v1');
                setValues();
            } else {
                loadingData($stateParams.id);
            }
            $scope.$on('changgedSkin',function(){
                $rootScope.scaleHtml();
            })

			//设置对象无效
			function setInvalidAttr(entity, attr) {
				entity[attr] = true;
				$timeout(function() { entity[attr] = false; }, 2500);
			}

            //数据验证
            $scope.validPostData = function() {
            	$scope.errorModel.errorText = "";
            	
            	var modelData = $scope.model;
                if($.trim(modelData.title) === '') {
                    $scope.errorModel.errorText =  $filter('translate')('classified.no_title');
					$("#modelTitle").focus();

					setInvalidAttr($scope, 'invalidTitle');
                } else {
                	var isValid = true;
                	if(!modelData.categories || modelData.categories.length < 2) {
                		$scope.errorModel.errorText =  $filter('translate')('classified.class_mincount_hint');
                		isValid = false;
                	}
                	
                	if(isValid) {
                		var categoryName = [];
                		angular.forEach(modelData.categories, function(category, categoryIndex) {
							if(isValid) {
								if(!category.name || category.name == '') {
									$('.classify_title:eq(' + categoryIndex + ')').focus();
									setInvalidAttr(category, 'invalidName');

									$scope.errorModel.errorText =  $filter('translate')('classified.classname_is_empty', {classIndex: categoryIndex + 1});
									isValid = false;

									return false;
								} else if(categoryName[category.name]) {
									$scope.errorModel.errorText =  $filter('translate')('classified.classname_duplicated', {classIndexI: categoryName[category.name], classIndexJ: categoryIndex + 1});
									isValid = false;

									return false;
								} else if(!category.items || category.items.length < 1) {
									setInvalidAttr(category, 'invalid');
									$scope.errorModel.errorText =  $filter('translate')('classified.card_mincount_hint');
									isValid = false;

									return false;
								} else {
									angular.forEach(category.items, function(item, itemIndex) {
										if(!item.content || item.content == '') {
											if(item.type == 'image') {
												$scope.errorModel.errorText =  $filter('translate')('classified.imagecard_empty_hint', {classIndex: categoryIndex + 1, cardIndex: itemIndex + 1});
											} else {
												setInvalidAttr(item, 'invalidContent');
												$scope.errorModel.errorText =  $filter('translate')('classified.textcard_empty_hint', {classIndex: categoryIndex + 1, cardIndex: itemIndex + 1});
											}

											isValid = false;
											return false;
										}
									});

									if(!isValid) return false;
								}

								categoryName[category.name] = categoryIndex + 1;
							}
                		});
                	}

                	return isValid;
                }
            };

            var categoryIdPrefix = "C", itemIdPrefix = "I";
            $scope.encodeData = function(model){
            	var newModel = angular.copy(model);
            	
            	newModel.classified_options = [];
            	angular.forEach(newModel.categories, function(category, index) {
            		category.id = categoryIdPrefix + (index + 1);
            		
            		var itemidArray = [];
            		angular.forEach(category.items, function(item, itemIndex) {
            			item.id = category.id + itemIdPrefix + (itemIndex + 1);
            			
            			itemidArray.push(item.id);
            			newModel.classified_options.push(item);
            		});
            		
            		category.items = itemidArray;
            	});
            	
            	//乱序处理
            	UtilsService.shuffleArray(newModel.classified_options);
            	
            	return newModel;
            };
            
            $scope.decodeData = function(model){
            	var newModel = angular.copy(model);
            	
            	var optionsMap = [];
            	angular.forEach(newModel.classified_options, function(item) {
            		optionsMap[item.id] = item;
            	});
            	
            	angular.forEach(newModel.categories, function(category) {
            		var items = [];
            		angular.forEach(category.items, function(item) {
            			items.push(optionsMap[item]);
            		});
            		
            		category.items = items;
            	});
            	
            	return newModel;
            };

            //新增分类
            $scope.addCategory = function() {
            	$scope.model.categories.push({items:[]});
            };

			$scope.removeCategory = function() {
				$scope.model.categories.splice($.inArray($scope.category2Deleted, $scope.model.categories), 1);
				$scope.closeDelCategoryPopBox();
			};

			$scope.openDelCategoryPopBox = function(category) {
				$scope.category2Deleted = category;
				$scope.delCategoryPopBoxVisible = true;
			};

			$scope.closeDelCategoryPopBox = function() {
				$scope.delCategoryPopBoxVisible = false;
			};
            
            //排序
            $scope.sortCategoryItem = {
        		start: function(e, ui) {
            		if(!ui.item.sortable.model) {
                		ui.item.sortable.cancel();
                	}
	            },
	            stop: function(e, ui) {
                	ui.item.scope().$index;
                }
            };
        }
    ]);
});
