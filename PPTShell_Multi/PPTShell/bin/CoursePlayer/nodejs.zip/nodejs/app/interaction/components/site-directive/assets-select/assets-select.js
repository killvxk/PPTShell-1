/**
 * Created by px on 2015/6/10.
 */
define(['angularAMD','css!components/site-directive/assets-select/assets-select', 'lifecycle.service'
], function (angularAMD) {
    angularAMD .directive('assetsSelect', ['LifecycleService', 'Upload', '$rootScope', '$stateParams','ngDialog','$filter', '$q', '$timeout',
		function (LifecycleService, Upload, $rootScope, $stateParams,ngDialog,$filter, $q, $timeout) {
        return {
            restrict:'EA',
            scope:{
                imageDataNew:'=imageData',
                imageColumn:'@',
                imageSize:'@',
                afterAdd:'&',
				afterClose:'&',
                isCommonValid:'@',
                commonValidParam:'=',
				uuidAsName:'@'
            },
            link: function (scope, element, attrs) {
				//console.log("scope.uuidAsName",scope.$id,scope.uuidAsName);
				scope.uploadFiles = function(file, errFiles) {
					scope.errFile = errFiles && errFiles[0];
					if(!!scope.errFile) {
						scope.previewUrl = null;

						switch(scope.errFile.$error) {
							case 'maxSize':
								scope.errorMsg = scope.errFile.name + ': 文件大小不得超过' + scope.errFile.$errorParam;
								break;
							case 'maxHeight':
								break;
							default:;
						}

						return;
					}

					scope.f = file;
					if (file) {
						file.uuidAsName = true;
						file.upload = Upload.upload({
							url: window.location.protocol + "//" + window.location.host +  '/v0.1/interaction/upload/' + $stateParams.id,
							data: {file: file,"uuidAsName":scope.uuidAsName,question_base:$stateParams.question_base || ''}
						});
						file.upload.then(function (response) {
							$timeout(function () {
								file.result = response.data;
								scope.previewUrl = response.data;
							},100);
						}, function (response) {
							if (response.status > 0)
								scope.errorMsg = response.status + ': ' + response.data;
						}, function (evt) {
							file.progress = Math.min(100, parseInt(100.0 *
								evt.loaded / evt.total));
						});
					}
				};

				scope.insertAssert = function($event){
					//回调
					scope.imageDataNew[scope.imageColumn] = scope.previewUrl;
					scope.afterAdd();
					ngDialog.close();
				}

                attrs.itemType = !attrs.itemType?'image':attrs.itemType;
                attrs.selectType = !attrs.selectType?'single':attrs.selectType;
                scope.model = {
                    item_type :attrs.itemType
                };
                
                element.click(function(){
                	var cancelClick = element.attr("cancelClick");
                	if(cancelClick === 'true' || cancelClick === true) return;

					ngDialog.open({
						templateUrl: 'interaction/components/site-directive/assets-select/assets-select.html',
						scope: scope,
						className: "bk-dialog ",
						overlay:false
					}).closePromise.then(function (data) {
						scope.afterClose();
					});
                    if(window.messageIframe) {
                        window.messageIframe.doMessage = function (dataMessage) {
                            if (dataMessage.message == "AssetsSelected") {
                                scope.$apply(function(){
                                	resoureValid(dataMessage).then(function() {
                                		scope.imageDataNew[scope.imageColumn] = dataMessage.data.length == 1 ? dataMessage.data[0] : dataMessage.data;
										scope["$$childTail"].closeThisDialog();
										scope.afterAdd();
                                	});
                                });
                            }
                        };
                    }
                });
            }
        };
    }])

});