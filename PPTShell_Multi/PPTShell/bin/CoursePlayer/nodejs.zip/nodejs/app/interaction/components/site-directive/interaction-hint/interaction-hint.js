define(['angularAMD',
    'css!components/site-directive/interaction-hint/assets/css/style',
    'components/site-directive/contenteditable/contenteditable'
], function(angularAMD) {
    angularAMD.directive('interactionHint', ['ngDialog','$timeout', function(ngDialog, $timeout) {
        return {
            restrict: 'E',
            templateUrl: 'interaction/components/site-directive/interaction-hint/interaction-hint.html',
            scope: true,
            controller: ['$scope', function($scope) {
                var CSS_HIGHLIGHT_TIP = 'highlight_tip';
                $scope.MAX_HINT_AMOUNT = 4;
                $scope.MAX_TEXT_LENGTH = 100;

                if($scope.model.interaction_hints && $scope.model.interaction_hints.length > 0) {
                    $.each($scope.model.interaction_hints, function() {
                        if(this.content) {
                            this.rows = Math.max(2, this.content.replace(/[^\n]/g, '').replace(/\n/g, '$').length + 1);
                        }
                    });
                }

                var validateHints = function() {
                    var isValid = true;
                    if($scope.model.interaction_hints) {
                        $.each($scope.model.interaction_hints, function(index, hint) {
                            hint.index = index + 1;

                            if(!!!hint.content) {
                                $scope.errorModel.errorText = "提示信息不能为空";
                                highlightWarn(index);

                                isValid = false;

                                return false;
                            }
                        });
                    }

                    return isValid;
                };

                //高亮提示
                var highlightWarn = function(index) {
                    var focusTip = angular.element('.com_m_pop_hits .text_input_area:eq(' + index + ') textarea');

                    if(focusTip.hasClass(CSS_HIGHLIGHT_TIP)) {
                        focusTip.removeClass(CSS_HIGHLIGHT_TIP);
                        $timeout(function() {
                            focusTip.addClass(CSS_HIGHLIGHT_TIP).focus();
                        }, 100);
                    } else {
                        focusTip.addClass(CSS_HIGHLIGHT_TIP).focus();
                    }
                };

                var newHint = function(index, autoFocus) {
                    $scope.model.interaction_hints.push({index: index + 1, content: "", rows: 2});

                    !!autoFocus && $timeout(function() {
                        angular.element('.com_m_pop_hits .text_input_area:last textarea').focus();
                    }, 200);
                };

                $scope.onTextChange = function(hint, index) {
                    if(hint && hint.content) {
                        hint.rows = Math.max(2, hint.content.replace(/[^\n]/g, '').replace(/\n/g, '$').length + 1);
                    }

                    if(hint.content && hint.content.length >= $scope.MAX_TEXT_LENGTH) {
                        highlightWarn(index);
                    }
                };
                $scope.onKeydown = function(hint, index) {
                    if(hint.content && hint.content.length >= $scope.MAX_TEXT_LENGTH) {
                        highlightWarn(index);
                    }
                };
                $scope.openEditor = function() {
                    if(!$scope.model.interaction_hints || $scope.model.interaction_hints.length === 0) {
                        $scope.model.interaction_hints = [];
                        newHint(0);
                    } else {
                        $scope.interaction_hints_temp = angular.copy($scope.model.interaction_hints);
                    }

                    $scope.isEditing = true;
                };

                $scope.addHint = function() {
                    var index = 0;
                    if($scope.model.interaction_hints) {
                        index = $scope.model.interaction_hints.length;
                    }

                    newHint(index, true);
                };
                $scope.remove = function(index) {
                    $scope.model.interaction_hints.splice(index, 1);
                };
                $scope.errorModel = {};
                $scope.save = function() {
                    if(validateHints()) {
                        $scope.isEditing = false;
                    }
                };
                $scope.cancel = function() {
                    $scope.model.interaction_hints = $scope.interaction_hints_temp;
                    $scope.isEditing = false;
                };
            }]
        };
    }]);
});