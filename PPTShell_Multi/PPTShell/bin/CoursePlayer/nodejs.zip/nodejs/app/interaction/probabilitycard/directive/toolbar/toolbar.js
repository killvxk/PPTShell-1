/**
 * Created by px on 2015/6/15.
 */
define(['angularAMD'
], function (angularAMD) {
    angularAMD
        .directive('toolbar', [ function () {
            return {
                restrict: 'E',
                replace: true,
                templateUrl: 'interaction/probabilitycard/directive/toolbar/toolbar.html',
                scope: {itemData: '=itemData', focusCurrentCard: '&'},
                controller: ['$scope', '$filter', function ($scope, $filter) {
                	$scope.imageData = {};
                	

			        $scope.systemFonts = [ 
			            "方正舒体", "方正姚体", "仿宋", "黑体",
						"华文彩云", "华文仿宋", "华文行楷", "华文琥珀", "华文楷体", "华文隶书", "华文宋体", "华文细黑", "华文新魏", "华文中宋", 
						"楷体", "隶书", "宋体", "微软雅黑", "新宋体", "幼圆" 
					];
                	
                	// 插入底图
                	$scope.insertImage = function() {
                		if($scope.itemData) {
                			$scope.itemData.imageHref = $filter('filterRefPath')($scope.imageData.href);
                    		$scope.itemData.hasImage = true;
                		}
                	};
                	
                	// 插入文本
                	$scope.insertText = function() {
                		if($scope.itemData) {
                			$scope.itemData.hasText = true;
                		}
                	};
                	
                	//字体大小范围限制
                	$scope.minFontSize = 16;
                	$scope.maxFontSize = 40;
                	$scope.onFontSizeBlur = function() {
                		var fontSize = $("#fontSizeCtrl").val();
                		
                		if(fontSize < $scope.minFontSize) {
                			$scope.itemData.text_style['font-size'] = $scope.minFontSize;
                		} else if(fontSize > $scope.maxFontSize) {
                			$scope.itemData.text_style['font-size'] = $scope.maxFontSize;
                		}
                	};
                	
                	//颜色
                	$scope.onColorChange = function() {
                		$scope.focusCurrentCard();
                	};
                	
                	//粗体
                	$scope.setBold = function() {
                		$scope.itemData.text_style['font-weight'] = ($scope.itemData.text_style['font-weight'] === 'bold' ? '' : 'bold');
                		$scope.focusCurrentCard();
                	};
                	
                	//斜体
                	$scope.setItalic = function() {
                		$scope.itemData.text_style['font-style'] = ($scope.itemData.text_style['font-style'] === 'italic' ? '' : 'italic');
                		$scope.focusCurrentCard();
                	};
                	
                	//下划线
                	$scope.setUnderline = function() {
                		$scope.itemData.text_style['text-decoration'] = ($scope.itemData.text_style['text-decoration'] === 'underline' ? '' : 'underline');
                		$scope.focusCurrentCard();
                	};
                	
                	//文字横排
                	$scope.horizontalText = function() {
                		if($scope.itemData) {
                			$scope.itemData.text_style.direction = 'horizontal';
                		}
                	};
                	
                	//文字竖排
                	$scope.verticalText = function() {
                		if($scope.itemData) {
                			$scope.itemData.text_style.direction = 'vertical';
                		}
                	};
                }]
            };
        }])
});