/**
 * Created by tinler on 2016/01/04.
 */
define(['angularAMD', 'css!components/site-directive/confirm-popup/asset/confirm-popup'], function (angularAMD) {
    angularAMD.directive('confirmPopup', [ function () {
        return {
            restrict: 'E',
            templateUrl: 'interaction/components/site-directive/confirm-popup/confirm-popup.html',
            scope: {
            	title: '@',
            	text: '@',
            	itemData:'=',
            	confirmAction: '&onConfirm',
            	cancelAction: '&onCancel',
            	closeAction: '&onClose'
            },
            
            controller: ['$scope', '$timeout',
                function ($scope, $timeout) {
            		$scope.close = function() {
            			$scope.closeAction($scope.itemData);
            		};
            		
            		$scope.cancel = function() {
            			$scope.cancelAction($scope.itemData);
            		};
            		
            		$scope.confirm = function() {
            			$scope.confirmAction($scope.itemData);
            		};
                }
            ]
        };
    }])

});