/**
 * Created by zy on 2015/7/6.
 */
define(['angularAMD'
], function (angularAMD) {
    angularAMD .directive('multiplyPanel', [ function () {
        return {
            restrict:'E',
            templateUrl:'interaction/arithmetic/directive/multiply-panel/multiply-panel.html',
            scope: {
            	calNum:'=calNum',
            },
            link:function(scope,element,attrs){
            
                scope.checkNum = function( item ){
                	
                	item.hide = !item.hide;
                	//console.log(scope.calNum);
   
                }
            }
            
        };
    }])

});
