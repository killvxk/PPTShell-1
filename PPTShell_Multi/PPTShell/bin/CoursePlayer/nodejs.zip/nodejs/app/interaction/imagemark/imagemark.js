/**
 *
 */
define(['app', 'imagemark/directive/imagemark.directive'
], function (app) {
    'use strict';
    app.controller('imagemark_ctrl', [
        '$scope', 'skin_service', '$stateParams', 'CustomEditorService', '$rootScope', "$filter",
        function ($scope, skin_service, $stateParams, CustomEditorService, $rootScope, $filter) {
            $rootScope.moduleScope = $scope;
            $scope.errorModel = {};
            $scope.showGuide = true;
            $scope.MARK_TYPE = {LINE: 'line', AREA: 'area'};

            $scope.model = {
                "title": "",         //标题
                "skin": {
                    code: "wood",
                    css_url: "${ref-path}/edu/esp/preparecustomeditor/imagemark/wood/css/wood.css",
                    name: $filter('translate')('imagemark.muwen'),
                    package_url: "${ref-path}/edu/esp/preparecustomeditor/imagemark/wood"
                },
                "timer": {
                    "timer_type": "sequence",  //计时器类型: ["sequence", "countdown"]
                    "time_minute": "0",    //倒计时初始设置-分钟，timer_type="countdown"时有效
                    "time_second": "0"     //倒计时初始设置-秒，timer_type="countdown"时有效
                },
                "image_item": {
                    "asset_type": "",
                    "asset": "",
                    "other": {},
                },
                "mark_type": $scope.MARK_TYPE.LINE,
                "tags": []
            };
            var loadingData = function (id) {
                $scope.isloadingData = true;
                CustomEditorService.getQuestionInfoById(id)
                    .then(function (rtnData) {
                        if (!rtnData) {
                            $scope.errorModel.errorText = $filter('translate')('imagemark.unvalidno');
                        } else {
                            if (rtnData.skin.code != '') {
                                $scope.model = $scope.decodeData(rtnData);
                                skin_service.set_skin_by_code($scope.model.skin.code, "v1");
                                $scope.showGuide = false;
                            } else {
                                $scope.showGuide = true;
                                $scope.model.id = rtnData.id;
                                skin_service.set_skin_by_code($scope.model.skin.code, "v1");
                            }
                            $scope.errorModel.errorText = "";
                            $scope.isloadingData = false;
                        }
                    }, function (error) {
                        $scope.errorModel.errorText = $filter('translate')('imagemark.get_title_error');
                    })
            };

            //入口
            if (!$stateParams.id) {
                //新增
                skin_service.set_skin_by_code($scope.model.skin.code, "v1");
            } else {
                //修改
                loadingData($stateParams.id);
            }

            $scope.$on('changgedSkin', function () {
                $rootScope.scaleHtml();
            })
            //数据验证
            $scope.validMarkHandler = {run: null};
            $scope.validPostData = function () {
                var modelData = $scope.model;
                if ($.trim(modelData.title) == '') {
                    $scope.errorModel.errorText = $filter('translate')('imagemark.no_title');

                    return false;
                }

                if (modelData.tags.length == 0) {
                    $scope.errorModel.errorText = $filter('translate')('imagemark.no_content');

                    return false;
                } else {
                    if ($scope.validMarkHandler.run && !$scope.validMarkHandler.run()) {
                        if ($scope.model.mark_type == $scope.MARK_TYPE.LINE) {
                            $scope.errorModel.errorText = $filter('translate')('imagemark.tag_origin_invalid');
                        } else {
                            $scope.errorModel.errorText = $filter('translate')('imagemark.tag_area_invalid');
                        }

                        return false;
                    }

                    var isValid = true;
                    for (var i = 0; i < modelData.tags.length; i++) {
                        if (!modelData.tags[i].value) {
                            $scope.errorModel.errorText = $filter('translate')('imagemark.tag_is_empty', {index: i + 1});
                            isValid = false;

                            return false;
                        }
                    }

                    return isValid;
                }

                return true;
            };

            $scope.encodeData = function (model) {
                var newModel = angular.copy(model);
                angular.forEach(newModel.tags, function (tag, $index) {
                    tag.serial_num = $index + 1;
                });

                newModel.mark_type += "&NEW";
                newModel.image_item.other["max-width"] = "679px";
                newModel.image_item.other["max-height"] = "416px";

                //if(!newModel.image_item.other.style ||
                //    newModel.image_item.other.style.indexOf("width") < 0) {
                //    if(!newModel.image_item.other.style) {
                //        newModel.image_item.other.style = "";
                //    }
                //
                //    var img = angular.element("#insertImgDiv img");
                //    newModel.image_item.other.style += ("width:" + img.width() + "px; height:" + img.height() + "px");
                //}

                return newModel;
            };

            $scope.decodeData = function (model) {
                var index = model.mark_type.indexOf("&");
                if(index > -1) {
                    model.mark_type = model.mark_type.substring(0, index);
                } else {
                    var horizontaRate = 1131 / 1000, verticalRate = 416 / 500;
                    angular.forEach(model.tags, function(tag) {
                        tag.x = tag.x * horizontaRate;
                        tag.y = tag.y * verticalRate;
                        tag.rec_x = tag.rec_x * horizontaRate;
                        tag.rec_y = tag.rec_y * verticalRate;
                    });
                }

                if ($scope.model.tags.length == 0) { //点击编辑题目时
                    return model;
                } else {
                    $scope.model.id = model.id;
                    $scope.model.interaction_hints = model.interaction_hints;
                    return $scope.model;
                }
            };

            //设置标签形式
            $scope.setMarkType = function (markType, isRemoveTags) {
                $scope.model.mark_type = markType;
                $scope.showGuide = false;

                if (isRemoveTags) {
                    $scope.model.tags = [];
                }
            };

            $scope.onMousedown = function(event) {
                var $target = $(event.target);
                if(!$target.hasClass("mousedownable") && $target.parents("mousedownable").length === 0) {
                    event.preventDefault();
                    event.stopPropagation();
                }
            };
        }
    ]);
});
