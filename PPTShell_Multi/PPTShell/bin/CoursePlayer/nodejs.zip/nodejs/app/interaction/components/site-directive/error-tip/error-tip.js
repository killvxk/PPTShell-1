/**
 * Created by px on 2015/5/15.
 */
define(['angularAMD', 'css!components/site-directive/error-tip/error-tip'
], function (angularAMD) {
    angularAMD.directive('errorTip', [ function () {
        return {
            restrict: 'EA',
            templateUrl: 'interaction/components/site-directive/error-tip/error-tip.html',
            scope:{errorData:'='},
            controller: ['$scope', '$timeout',
                function ($scope, $timeout) {
                    if(!$scope.errorData){
                        $scope.errorData = {};
                    }
                    if(!$scope.errorData.errorType){
                        $scope.errorData.errorType = 'info';
                    }
                    
//                    $scope.errorTips = [];
//                    $scope.$watch("errorData.errorText", function(newVal, oldVal) {
//                    	if($scope.errorData.errorText) {
//                    		$scope.errorTips.push(newVal);
//                    	}
//                    });
                    
                    $scope.closeErrorTip = function($index) {
                    	$scope.errorData.errorText = '';
//                    	$scope.errorTips.splice($index, 1);
                    }
                    
                    var timer;
                    $scope.$watch("errorData.errorText", function(val) {
                    	if(val) {
                    		timer && $timeout.cancel(timer);
                    		timer = $timeout(function() {
                    			$scope.closeErrorTip();
                    		}, 3000);
                    	}
                    });
                }
            ]
        };
    }])

});