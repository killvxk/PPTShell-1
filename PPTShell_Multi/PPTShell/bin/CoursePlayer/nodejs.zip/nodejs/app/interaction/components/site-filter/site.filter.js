/**
 * Created by px on 2015/6/10.
 */
define(['angularAMD'
], function (angularAMD) {

    var getRefPath = function ($stateParams) {
        var refPath, questionBase = $stateParams.question_base;
        if (!!questionBase) {
            questionBase = "file:///" + questionBase.trim();
            if (questionBase.charAt(questionBase.length - 1) === '/') { //�ⲿ·������"/"
                refPath = questionBase + $stateParams.id + ".pkg/_ref";
            } else {
                refPath = questionBase + '/' + $stateParams.id + ".pkg/_ref";
            }
        } else {
            refPath = config.ref_path.replace('${courseware_object_id}', $stateParams.id + '.pkg');
        }

        return refPath;
    };

    var getRefAsset = function ($stateParams, assetPath) {
        if(assetPath) {
            if(assetPath.indexOf('${ref-path}') > -1) {
                assetPath = assetPath.replace('${ref-path}', '');
            }

            return "/v0.1/interaction_ref_assets/" + $stateParams.id +
                "?question_base=" + ($stateParams.question_base || '') +
                "&filepath=" + assetPath;
        }

        return "";
    };

    angularAMD

        .filter('filterGetAPIRouteByWebRoute', ['EnumsRouteQuestionType', function (EnumsRouteQuestionType) {
            return function (input) {
                if (input && EnumsRouteQuestionType[input]) {
                    return EnumsRouteQuestionType[input].api_route;
                } else {
                    return "";
                }
            };
        }])
        .filter('filterGetAPIRouteByWebRouteV2', ['EnumsRouteQuestionType', function (EnumsRouteQuestionType) {
            return function (input) {
                if (input && EnumsRouteQuestionType[input]) {
                    return EnumsRouteQuestionType[input].question_type;
                } else {
                    return "";
                }
            };
        }])
        .filter('filterGetWebRouteByQuestionType', ['EnumsRouteQuestionType', function (EnumsRouteQuestionType) {
            return function (input) {
                if (input) {
                    var webRoute = "";
                    angular.forEach(EnumsRouteQuestionType, function (value, key) {
                        if (value.question_type == input) {
                            webRoute = key;
                        }
                    });
                    return webRoute;
                } else {
                    return "";
                }
            };
        }])
        .filter('filterRefPath', ['$stateParams', function ($stateParams) {
            return function (input) {
                if (input) {
                    var paramIndex = input.lastIndexOf("?"), paramString = "";
                    if (paramIndex > -1) {
                        paramString = input.substring(paramIndex);
                        input = input.substring(0, paramIndex);
                    }

                    return getRefAsset($stateParams, input);
                    //return encodeURIComponent(input).replace(encodeURIComponent('${ref-path}'), getRefPath($stateParams)).replace(/%2F/g, '/') + paramString;
                } else {
                    return ""; //"interaction/i18n/zh_CN/common/assets/images/loading.jpg";
                }
            };
        }])
        .filter('filterRefPathThumb', ['$stateParams', function ($stateParams) {
            return function (input) {
                if (input) {
                    //return (encodeURIComponent(input).replace(encodeURIComponent('${ref-path}'), getRefPath($stateParams)).replace(/%2F/g, '/')) + '?size=160';
                    return getRefAsset($stateParams, input);
                } else {
                    return "";
                }
            };
        }])
        .filter('guesswordFilterRefPathThumb', ['$stateParams', function ($stateParams) {
            return function (input) {
                if (input) {
                    var paramIndex = input.lastIndexOf("?");
                    if (paramIndex > -1) {
                        input = input.substring(0, paramIndex);
                    }

                    //return encodeURIComponent(input).replace(encodeURIComponent('${ref-path}'), getRefPath($stateParams)).replace(/%2F/g, '/') + "?size=80";
                    return getRefAsset($stateParams, input);
                } else {
                    return "i18n/zh_CN/common/assets/images/loading.jpg";
                }
            };
        }])
        .filter('filterEnumCategory', [function () {
            return function (input) {
                if (input) {
                    return {"image": 'filter.picture', "video": "filter.video", "audio": "filter.audio"}[input];
                } else {
                    return input;
                }
            };
        }])
        .filter('filterPreviewUrl', ['$stateParams', function ($stateParams) {
            return function (rid, param) {
                if (rid) {
                    var mainPath, questionBase = $stateParams.question_base;
                    if(!!questionBase) {
                        questionBase = "file:///" + questionBase.trim();
                        if(questionBase.charAt(questionBase.length - 1) === '/') { //�ⲿ·������"/"
                            mainPath = questionBase + rid + ".pkg/main.xml";
                        } else {
                            mainPath = questionBase + '/'  + rid + ".pkg/main.xml";
                        }
                    } else {
                        mainPath = "../userdatas/edu/esp/interaction/" + rid + ".pkg/main.xml";
                    }

                    return (!rid ? '' : [config.editor_host + '/player/index.html?main=' + mainPath,
                                         '&player-code=teacher&hidePage=toolbar,footer',
                                         '&_lang_=', $stateParams._lang_,
                                         '&sys=', $stateParams.sys,
                                         '&rnd=', new Date().getTime()].join(''));
                } else {
                    return '';
                }
            };
        }])
        .filter('zeroFill', [function () {
            return function (val) {
                try {
                    val = parseInt(val, 10);
                    if (val < 10 && val > -1) {
                        return "0" + val;
                    } else {
                        return val;
                    }
                } catch (err) {
                    return "0";
                }
            };
        }])
});
