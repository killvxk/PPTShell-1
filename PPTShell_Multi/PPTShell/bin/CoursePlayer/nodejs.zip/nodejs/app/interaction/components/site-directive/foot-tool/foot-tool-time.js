

define(['angularAMD'], function (angularAMD) {
    angularAMD.directive('footToolTime', ['$filter',function ($filter) {
        return {
            restrict: 'E',
            templateUrl: 'interaction/components/site-directive/foot-tool/foot-tool-time.html',
            scope: {
                timer:"=timer"
            },
            replace:true,
            link: function ($scope) {
                var  old_time={};
                $scope.model = angular.extend({
                    timer_type:'sequence',//计时器类型: ["sequence", "countdown"]
                    time_minute:0,
                    time_second:10
                },$scope.timer);
                $scope.opts = {
                    model:angular.extend({},$scope.model)
                }
                //限制输入的时间数值大于0 小于60
                function limit_input(property){
                    old_time[property] = 0;
                    return function(val){
                        if(val){
                            var result = parseInt(val);
                            if(result.toString().length == val.toString().length && val.toString().length<=2 && result>=0 && result < 60){
                                old_time[property] = val;
                            }else{
                                $scope.model[property] = old_time[property];
                            }
                        }else{
                            old_time[property] = "";
                        }
//                        console.log(property+':'+val);
                    }
                }
                $scope.timeClick = function(){
                    if( $('#timesetId').hasClass('on') === false ){
                        $scope.opts.model = angular.extend({},$scope.model) ;
                    }

                }
                $scope.$watch('model.time_minute',limit_input('time_minute'));
                $scope.$watch('model.time_second',limit_input('time_second'));
                //修复bug-36594: 习题编辑状态下，如果该指令执行在获取习题数据前，就会发生该bug
                $scope.$watch('timer', function() {
                    $scope.model = angular.extend({
                        timer_type:'sequence',//计时器类型: ["sequence", "countdown"]
                        time_minute:0,
                        time_second:10
                    }, $scope.timer);
                });

                $scope.close_popup = function(){
                    angular.element("#timesetId").has(".toolpop").removeClass("on");
                    angular.element('.exam_wood').off("click");

                }

                $scope.changgeType = function(type){
                    $scope.model.timer_type = type;
                    if(type == 'countdown'){
                        if(angular.element(window.event.target).hasClass('time_second')){
                            return false ;
                        }
                        if(!$scope.model.time_minute || ($scope.model.time_minute == 0 &&  $scope.model.time_second == 0)){

                            $scope.model.time_minute = 1 ;
                            $scope.model.time_second = 0 ;
                        }
                    }else if($scope.model.timer_type == 'sequence'){
                        $scope.model.time_minute = 0;
                        $scope.model.time_second = 0;
                    }

                }

                $scope.cancel = function(){
                    $scope.model =  $scope.opts.model ;
                }
                angular.element('#timesetId').on("resetTime",function(){
                    $scope.cancel();
                });
                $scope.ok = function(){
                    //TODO:保存时间数据
                    if($scope.model.timer_type == 'countdown'){
                        if(!$scope.model.time_minute || ($scope.model.time_minute == 0 &&  $scope.model.time_second == 0)){
                            $scope.model.time_minute = 1;
                        }
                        if(!$scope.model.time_second){
                            $scope.model.time_second = 0;
                        }
                    }else if($scope.model.timer_type == 'sequence'){
                        $scope.model.time_minute = 0;
                        $scope.model.time_second = 0;
                    }
                    angular.extend($scope.timer,$scope.model);
                    $scope.close_popup();
                    $scope.timer.timer_type = $scope.model.timer_type;
                }

            }
        };
    }]);
});