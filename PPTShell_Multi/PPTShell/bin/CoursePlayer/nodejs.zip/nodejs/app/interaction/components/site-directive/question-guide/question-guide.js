/**
 * Created by lxq on 2015/12/07.
 */
define([
    'angularAMD', 
    'css!components/site-directive/question-guide/assets/css/style.css'
], function (angularAMD) {
    angularAMD .directive('questionGuide', [ function () {
        return {
            restrict:'E',
            templateUrl:'interaction/components/site-directive/question-guide/question-guide.html',
            replace: true,
            transclude: false,
            scope: {
            	imageRoot:'@',
            	imagePreview: '@',
            	imageList:'=',
            	imagePrefix:'@',
            	imageSuffix:'@',
            	imageAmount: '@',
            	interval: '@',
            	autoSwitch: '@'
            },
            controller:['$scope','$rootScope', '$timeout',function($scope, $rootScope, $timeout){
            	$scope.GUIDE_MODE = {PREVIEW: 'preview', EDITOR: 'editor'};
            	$scope.currentMode = $scope.GUIDE_MODE.PREVIEW;
            	$scope.guideImgIndex = 0;
            	
            	/***************** 数据组装 Begin *****************/
            	if($scope.imagePreview) {
            		$scope.previewImage = $scope.imageRoot + "/" + $scope.imagePreview;
            	} else {
            		$scope.previewImage = $scope.imageRoot + "/" + $scope.imagePrefix + $scope.imageSuffix;
            	}
            	
            	$scope.editorImages = [];
            	if(angular.isArray($scope.imageList)) {
            		$scope.imageAmount = $scope.imageList.length;
            		angular.forEach($scope.imageList, function(item, index) {
            			$scope.editorImages.push({
                			actived: (index === 0),
                			src: $scope.imageRoot + "/" + item
                		});
            		});
            	} else {
            		for(var i = 0; i < $scope.imageAmount; i++) {
                		$scope.editorImages.push({
                			actived: (i === 0),
                			src: $scope.imageRoot + "/" + $scope.imagePrefix + (i + 1) + $scope.imageSuffix
                		});
                	}
            	}
            	$scope.editorImages.length > 0 && ($scope.currentImageEditor = $scope.editorImages[0]);
            	/***************** 数据组装 END. *****************/
            	
            	var setGuideImgSrc = function(guideImgIndex) {
            		$scope.currentImageEditor && ($scope.currentImageEditor.actived = false);
            		$scope.currentImageEditor = $scope.editorImages[guideImgIndex];
            		$scope.currentImageEditor.actived = true;
            	};
            	
                var startQuestionGuidePlayer = function() {
                	stopQuestionGuidePlayer();
                	
                	$rootScope.questionGuidePlayer = setInterval(function() {
                		if($scope.guideImgIndex + 1 == $scope.imageAmount) { //最后一张暂停：3s
                			stopQuestionGuidePlayer();
                			$timeout(function(){
                				setGuideImgSrc(0);
                				startQuestionGuidePlayer();
                			}, 3000);
                		} else {
                			setGuideImgSrc(++$scope.guideImgIndex);
                        	$scope.$apply();
                		}
                    }, $scope.interval || 1500);
                };
                var stopQuestionGuidePlayer = function() {
                	$rootScope.questionGuidePlayer && clearInterval($rootScope.questionGuidePlayer);
                	$rootScope.questionGuidePlayer = null;
                	$scope.guideImgIndex = 0;
                };
                $rootScope.stopQuestionGuidePlayer = stopQuestionGuidePlayer;
                
                /***************************************************
                 * 开启自动模式切换
                 * 查看方式：老师可以左右切换查看题型预览与编辑引导，5s后自行切换；
                 */
                var modeSwitchPromise;
                var startModeSwitchPromise = function() {
                	modeSwitchPromise = $timeout(function() {
                		stopModeSwitchPromise();
                    	$scope.switchToEditor();
                    }, 5000);
                };
                var stopModeSwitchPromise = function() {
                	if(modeSwitchPromise) {
                		$timeout.cancel(modeSwitchPromise);
                    	modeSwitchPromise = null;
                	}
                };
                /******************* End. *******************/
                
                /***************** 模式切换动作 *****************/
                //切换到题型预览图模式
                $scope.switchToPreview = function(event) {
                	if(event) {
                		event.stopPropagation();
                    	event.preventDefault();
                	}
                	
                	stopQuestionGuidePlayer();
                	$scope.currentMode = $scope.GUIDE_MODE.PREVIEW;
                };
                //切换到题型编辑引导模式
                $scope.switchToEditor = function(event) {
                	if(event) {
                		event.stopPropagation();
                    	event.preventDefault();
                	}
                	
                	stopModeSwitchPromise();
                	setGuideImgSrc(0);
                	startQuestionGuidePlayer();
                	
                	$scope.currentMode = $scope.GUIDE_MODE.EDITOR;
                };
                /******************* End. *******************/
                
                $scope.$watch('$root.QuestionGuideOpenTime', function() {
                	if($rootScope.QuestionGuideOpenTime) {
                		$scope.switchToPreview();
                		startModeSwitchPromise();
                	}
                });
                $scope.$on('$destroy', function onDestroyTooltip() {
                	stopQuestionGuidePlayer();
                });
                
                
                /***************** 初始化 *****************/
                //开启自动模式切换
                $scope.autoSwitch === 'true' && startModeSwitchPromise();
            }]
        };
    }])

});