/**
 * planting
 * 2015-11-02 17:10:44
 */
define(['app', 'planting/directive/planting.directive'], function(app) {
	'use strict';
	app.controller('planting_ctrl', [
		'$scope', 'skin_service', '$stateParams', 'CustomEditorService', '$rootScope', '$filter',
		function($scope, skin_service, $stateParams, CustomEditorService, $rootScope, $filter) {
			$rootScope.moduleScope = $scope;
			$scope.errorModel = {};

			$scope.model = {
				"id": "",
				"module_code": "nd_planting", // 题目类型
				"title": "", //标题
				"skin": {
					code: "wood",
					css_url: "",
					name: $filter('translate')('app.skin.wood'),
					package_url: ""
				},
				"timer": {
					"timer_type": "sequence", //计时器类型: ["sequence", "countdown"]
					"time_minute": "0", //倒计时初始设置-分钟，timer_type="countdown"时有效
					"time_second": "0" //倒计时初始设置-秒，timer_type="countdown"时有效
				},
				"properties": [ //模块静态数据模型
					{
						"name": "question_id",
						"display_name": "题目ID",
						"type": "string",
						"value": "",
						"is_localized": false
					}, {
						"name": "question_url",
						"display_name": "题目内容",
						"type": "jsonFile",
						"value": "",
						"is_localized": false
					}
				],
				"content": { //Editor数据模型正文
					"interval": 4.0,
					"distance": 16.0,
					"plantingMode": 2
				}
			};

			//数据加载
			var loadingData = function(id) {
				$scope.isloadingData = true;
				CustomEditorService.getQuestionInfoById(id)
					.then(function(rtnData) {
						if (!rtnData) {
							$scope.errorModel.errorText = $filter('translate')('app.unvalidno');
						} else {
							if (rtnData.skin.code != '') {
								$scope.model = $scope.decodeData(rtnData, true);
							} else {
								$scope.model.id = rtnData.id;
							}

							skin_service.set_skin_by_code($scope.model.skin.code, "v1");
							$scope.errorModel.errorText = "";
							$scope.isloadingData = false;
						}
					}, function(error) {
						$scope.errorModel.errorText = $filter('translate')('app.question.get.error');
					})
			};

			//入口
			if (!$stateParams.id) { //新增
				skin_service.set_skin_by_code($scope.model.skin.code, "v1");
			} else { //修改
				loadingData($stateParams.id);
			}

			$scope.$on('changgedSkin', function() {
				$rootScope.scaleHtml();
			});

			function changeHoleHouse() {
				var html = '';
				var num = parseInt($scope.distance / $scope.interval);
				var inter = parseInt($scope.distance / $scope.interval);
				if ($scope.model.content.plantingMode == 0 && $scope.distance % $scope.interval != 0) {
					num = num + 2;
				} else {
					num++;
				}
				for (var i = 0; i < num; i++) {
					if (i + 1 == num) {
						if ($scope.model.content.plantingMode == 0) {
							html += '<p class="treebox" style="width:0;left:' + (0.8 * $scope.distance) + '%"><i class="tree"></i><i class="hole"></i><i class="line"></i></p>';
						} else {

							html += '<p class="treebox" style="width:0;left:' + (0.8 * $scope.interval * i) + '%"><i class="tree"></i><i class="hole"></i><i class="line"></i></p>';
						}
					} else if (i + 2 == num) {
						if ($scope.model.content.plantingMode == 0 && inter + 2 == num) {
							html += '<p class="treebox" style="width:' + (0.8 * $scope.distance - 0.8 * inter * $scope.interval) + '%"><i class="tree"></i><i class="hole"></i><i class="line"></i></p>';
						} else {
							html += '<p class="treebox" style="width:' + (0.8 * $scope.interval) + '%"><i class="tree"></i><i class="hole"></i><i class="line"></i></p>';
						}
					} else {
						html += '<p class="treebox" style="width:' + (0.8 * $scope.interval) + '%"><i class="tree"></i><i class="hole"></i><i class="line"></i></p>';
					}
				}
				$('.tree_wrap').html(html);
				//$(".tree_wrap .treebox").removeClass("starthouse").removeClass("stophouse");
				switch ($scope.model.content.plantingMode) {
					case 0:
						$(".tree_wrap .treebox:first").addClass("starthouse");
						$(".tree_wrap .treebox:last").addClass("stophouse");
						break;
					case 1:
						$(".tree_wrap .treebox:first").addClass("starthouse");
						break
					case 2:
						break;
					default:
						break;
				}
			}

			//切换种数方式
			$scope.choosePlantingMode = function(mode) {
				$scope.model.content.plantingMode = mode;
				changeHoleHouse();
			};
			//路长滑动
			$scope.distance = 20;
			$scope.distanceSliding = function(ele, e) {
				var degreeRate = $('.scale').width() / 120;
				var oldX = e.clientX;
				document.onmousemove = function(e) {
					var newX = e.clientX;
					if (newX > oldX + degreeRate) {
						$scope.distance++;
						$scope.model.content.distance = $scope.model.content.distance + 0.8;

						if ($scope.model.content.distance >= 96) {
							$scope.distance = 120;
							$scope.model.content.distance = 96;
						}
						oldX = newX;
						changeHoleHouse();
					} else if (newX < oldX - degreeRate) { //一个单位是宽度0.8%，路长下限是3个单位
						$scope.distance--;
						$scope.model.content.distance = $scope.model.content.distance - 0.8;

						if ($scope.model.content.distance <= $scope.model.content.interval) {
							$scope.distance = $scope.interval;
							$scope.model.content.distance = $scope.model.content.interval;
						}
						oldX = newX;
						changeHoleHouse();
					}
					$scope.$apply();
				};
				document.onmouseup = function(e) {
					document.onmousemove = null;
					document.onmouseup = null;
				};
				document.onmouseleave = function(e) {
					document.onmousemove = null;
					document.onmouseup = null;
				};
			};

			//间隔滑动
			$scope.interval = 5;
			$scope.intervalSliding = function(ele, e) {
				var degreeRate = $('.scale').width() / 120;
				var oldX = e.clientX;
				document.onmousemove = function(e) {
					var newX = e.clientX;
					if (newX > oldX + degreeRate) {
						$scope.interval++;
						$scope.model.content.interval = $scope.model.content.interval + 0.8;
						if ($scope.model.content.interval >= $scope.model.content.distance) {
							$scope.interval = $scope.distance;
							$scope.model.content.interval = $scope.model.content.distance;
						}
						oldX = newX;
						changeHoleHouse();
					} else if (newX < oldX - degreeRate) {
						$scope.interval--;
						$scope.model.content.interval = $scope.model.content.interval - 0.8;
						if ($scope.model.content.interval <= 2.4) { //一个单位是宽度0.8%，间隔下限是3个单位
							$scope.interval = 3;
							$scope.model.content.interval = 2.4;
						}
						oldX = newX;
						changeHoleHouse();
					}

					$scope.$apply();
				};
				document.onmouseup = function(e) {
					document.onmousemove = null;
					document.onmouseup = null;
				};
				document.onmouseleave = function(e) {
					document.onmousemove = null;
					document.onmouseup = null;
				};
			};

			//数据验证
			$scope.validPostData = function() {
				if ($.trim($scope.model.title) === '') {
					$scope.errorModel.errorText = $filter('translate')('planting.no_title');
					$("#moduleTitle").focus();
					return false;
				}
				return true;
			};

			//数据模型-编码
			$scope.encodeData = function(model) {

				return model;
			};

			//数据模型-解码
			$scope.decodeData = function(model, isInitLoad) {
				$scope.distance = Math.round(model.content.distance / 0.8);
				$scope.interval = Math.round(model.content.interval / 0.8);
				$scope.model = model;
				changeHoleHouse();
				return model;
			};
		}
	]);
});