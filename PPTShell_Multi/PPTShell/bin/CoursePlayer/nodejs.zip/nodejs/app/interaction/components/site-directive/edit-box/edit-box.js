/**
 * 编辑框指令插件
 * 
 */
define(['angularAMD', 'css!components/site-directive/edit-box/edit-box.css'
], function (angularAMD) {
    angularAMD.directive('editbox', [function () {
    	var oTime1;
        var timeList = new Array();
        return {
			restrict: 'EA',
			scope: {maxSize:'=maxSize',minSize:'=minSize',maxLength:'=maxLength',title:'='},
            link: function(scope, element, attr, ng) {
            	element.removeAttr("title"); //修复bug22182
            	
            	var MAX_LENGTH = scope.maxLength || 75;
            	var maxFontSize = scope.maxSize;
            	var minFontSize = scope.minSize;
//            	var maxLength = scope.maxLength;
            	
            	if(MAX_LENGTH > 100) MAX_LENGTH = 100; //最多不超过100个字
            	element.attr("maxlength", MAX_LENGTH); //修复bug10124:当标题区输入的文字超过规定字数，将鼠标定位至文本中间，发现仍可输入数字、英文字母或其他字符。
            	
//            	var minFontSize = 0;
                scope.$watch('title', function (newValue, oldValue) {
                    if (newValue && newValue != oldValue) {
                        fun();
                    }
                });
                scope.$on('changgedSkin',fun);
                scope.$watch('element.width()', function (newValue, oldValue) {
                    if (newValue && newValue != oldValue) {
                        fun();
                    }
                });
                var currentFontSize = element.css('fontSize');

				//中文环境下, 样式中 一个中文字符占1个fontsize的宽度，一个英文字符算0.5个fontsize的宽度
				function getStringLength(str){
					if(str){
						var strLen = str.length,count = 0;
						for(var i = 0; i < strLen; i++){
							count+=1;
						}
						return count;
					}
					return 0;
				}
				
				
				function getEditString(str,maxLength){
					var result = "";
					var strLen = str.length,count = 0;
					for(var i = 0; i <= strLen - 1; i++){
						if (count >= maxLength) {
							return result;
							break;
						}
						count+=1;
						result += str.charAt(i);
					}
					return result;
				}
				
				function resetBoxStyle() {
					element.rows = 1;
                	element.css('line-height', '65px');
				}
				
                function fun(){
                    var maxLength = MAX_LENGTH;//element.width() / minFontSize * 2;
                    
                    minFontSize = Math.floor(element.width() * 2 / (maxLength + 1)); 
                    var titleValue = element.val();//30px

                    var length = titleValue.length;//getStringLength(titleValue);

                    if(length == 0) resetBoxStyle();
                    
                	var fontSize  = parseFloat(((element.width()-length) / length).toFixed(2));
                    if(length >= maxLength){
                        var result=getEditString(titleValue,maxLength);
//                            element.val(result);
                        scope.title = result;

                        tip();
                    }
                    if(fontSize <= maxFontSize && currentFontSize!= fontSize && fontSize >= minFontSize){
                        currentFontSize = fontSize;
                        element.css('fontSize',fontSize);
                        resetBoxStyle();
                    }
                    if(fontSize <= maxFontSize && currentFontSize!= fontSize && fontSize >= minFontSize){
                        currentFontSize = fontSize;
                        element.css('line-height',1.0);
                        element.css('fontSize',fontSize);
                    }

                    if (fontSize <= minFontSize ) {
                        element.css('fontSize',minFontSize);
                        element.rows = 2;
                        element.css('line-height',1.0);
                        element.css('text-align','center');
                        element.css('vertical-align','middle');
                    }
                    
                    if (fontSize >= minFontSize && currentFontSize!= fontSize) {
                        if (fontSize > maxFontSize) {
                            element.css('fontSize',maxFontSize);
                            resetBoxStyle();
                        }else{
                            element.css('fontSize',fontSize);
                        }
                    }
                }
                
				//每次输入的时候改变字体小小（未准确考虑间距距）
                element.bind('input enterKey', function(event) {
                	//minFontSize = parseFloat(((element.width() * lineCount ) / maxLength).toFixed(2));va
                	fun();
                });
                
                //修复bug：当编辑框达到最大字数后，
                element.bind('keydown', function(event) {
                	if(element.val().length >= MAX_LENGTH) {
                		if(event.which != 8 && event.which != 46) { //后退按钮或删除键
                			if(element[0].selectionStart == element[0].selectionEnd) {
                    			event.cancelable = true;
                        		event.preventDefault();
                        		
                        		return false;
                    		}
                		}
                	}
                });

                if(attr.placeholder) {
                    //元素获取焦点后, 不显示placeholder
					element.on('focus', function(event) {
						element.attr('placeholder', '');
					});

					//元素失去焦点后, 显示placeholder
					element.on('blur', function(event) {
						element.attr('placeholder', attr.placeholder);
					});
                }

                //字体太小时闪烁输入框 提示用户内容太多
				var timeout= 0, interval = 0, borderColorEqRed = false;
				function tip(){
					clearTimeout(timeout);
					clearInterval(interval);
					timeout = setTimeout(function(){
						clearInterval(interval);
						element.css('border','1px solid transparent');
					},3000);
					interval = setInterval(loopShow,300);
				}
				function loopShow(){
					if (borderColorEqRed) {
						element.css('border','1px solid transparent');
						borderColorEqRed = false;
        			} else {
						element.css('border',"1px solid red");
						borderColorEqRed = true;
        			}
				}
            }
        };
        
        
    }]);

});
