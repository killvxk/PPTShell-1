/**
 *
 */
define(['app'], function (app) {
    'use strict';
    app
        .controller('home_ctrl', [
            '$scope', '$location', '$stateParams', '$filter',
            function ($scope, $location, $stateParams, $filter) {
                var qtype = $filter("filterGetWebRouteByQuestionType")($stateParams.question_type);

                if (!$stateParams.question_type) {
                    $scope.errorInfo = "question_type不能为空";
                } else if (!qtype) {
                    $scope.errorInfo = "无效的自定义题型";
                } else {
                    //2015-07-31 添加space参数指明从教学资源管理系统的哪个库上选取多媒体资源[personal:个人库;public:ND库]
//                $location.url(["/", qtype, "?id=", !$stateParams.id ? "" : $stateParams.id, "&question_type=",
//                    $stateParams.question_type,"&token_info=", encodeURIComponent($stateParams.token_info),'&rnd=',new Date().getTime(),'&_lang_=',$stateParams["_lang_"],'&space=',$stateParams["space"]].join(''));
                    var url = "/" + qtype + "?rnd=" + new Date().getTime();
                    for (var key in $stateParams) {
                        switch (key) {
                            default:
                                url += ("&" + key + "=" + (!$stateParams[key] ? "" : $stateParams[key]));
                        }
                    }

                    $location.url(url);
                }
            }
        ]);

});
