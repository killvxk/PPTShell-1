requirejs.config({
//require.config({
    waitSeconds: 0,
    baseUrl: '/interaction',
    paths: {
        'css': 'bower_components/require-css/css.min',
        'css-builder': 'bower_components/require-css/css-builder',
        'normalize': 'bower_components/require-css/normalize',
        'angular': 'bower_components/angular/angular.min',
        'angular-ui-router': 'bower_components/angular-ui-router/angular-ui-router.min',
        'angular-bindonce': 'bower_components/angular-bindonce/bindonce.min',
        'angularAMD': 'bower_components/angularAMD/angularAMD.min',
        'restangular': 'bower_components/restangular/restangular.min',
        'lodash': 'bower_components/lodash/lodash.min',
        'angular-cookies': 'bower_components/angular-cookies/angular-cookies.min',
        'moment': 'bower_components/moment/mymoment',
        'angular-ui-select': 'bower_components/angular-ui-select/dist/select',
        'angular-ui-select-css': 'bower_components/angular-ui-select/dist/select',
        'angular.drag.drop': 'bower_components/angular-drag-and-drop-lists-master/angular-drag-and-drop-lists',
        'jquery': 'bower_components/jquery/jquery.min',
        'jqueryui': 'bower_components/jqueryui/jquery-ui',
        'jquery.ui.core': 'bower_components/jqueryui/jquery.ui.core',
        'jquery.ui.mouse': 'bower_components/jqueryui/jquery.ui.mouse',
        'jquery.ui.sortable': 'bower_components/jqueryui/jquery.ui.sortable',
        'jquery.ui.widget': 'bower_components/jqueryui/jquery.ui.widget',
        'tripledes': 'bower_components/encrypt/tripledes',
        'uuid': 'bower_components/node-uuid/uuid',
        'angular-translate': 'bower_components/angular-translate/angular-translate.min',
        'angular-file-upload': 'bower_components/angular-file-upload/ng-file-upload.min',
        'jquery.mousewheel': 'components/jquery-plugin/jquery.mousewheel/jquery.mousewheel-3.1.12',
        'placeholder': 'components/placeholder/placeholder',
        'sortable': 'components/sortable/sortable',
        'messenger': 'components/messenger/messenger',
        'utils': 'components/utility/utils',
        'cors-custom': 'components/cors-custom/cors-custom',
        'ngDialog': 'components/ngDialog/ngDialog',
        'enc-base64': 'components/http-auth/enc-base64-min',
        'hmac-auth': 'components/http-auth/hmac-auth',
        'hmac-sha256': 'components/http-auth/hmac-sha256',
        'http-auth': 'components/http-auth/http-auth'
        , 'site-directive': 'components/site-directive/site-directive'
        , 'userdata.service': 'components/site-services/userdata.service'
        , 'site.filter': 'components/site-filter/site.filter'
        , 'customeditor.service': 'components/site-services/customeditor.service'
        ,'diskpath.service':'components/site-services/diskpath.service'
        , 'lifecycle.service': 'components/site-services/lifecycle.service',
        'locale_es': 'i18n/es/angular_locale',
        'locale_zh_CN': 'i18n/zh_CN/angular_locale'
        , 'common': 'common'
        , 'table': 'table'
        , 'table-options': 'table/directive/options/options',
        'threejs': 'bower_components/three.js/three.min',
        'threex_dynamictexture':'bower_components/threex_dynamictexture/threex.dynamictexture',
        'mobiscroll': 'bower_components/mobiscroll.select/js/mobiscroll.custom-2.6.2.min',
        'addon-lego': 'lego/directive/addon-lego',
        'addon-clock': 'clock/directive/addon-clock',
        'addon-puzzle': 'puzzle/directive/addon-puzzle',
        'addon-mathaxis': 'mathaxis/directive/addon-mathaxis',
    },
    shim: {
        'messenger': {
            exports: 'messenger'
        },
        'moment': {
            exports: 'moment'
        },
        'angular': {
            exports: 'angular',
            deps: ['jquery']
        },
        'lodash': {
            exports: '_'
        },
        'enc-base64': {
            deps: ['hmac-sha256']
        },
        'tripledes': {
            exports: 'tripledes',
            deps: ['hmac-sha256']
        },
        'hmac-auth': {
            deps: ['enc-base64']
        },
        'angular-ui-router': ['angular'],
        'restangular': ['angular', 'lodash'],
        'angularAMD': ['angular', 'jquery'],
        'angular-translate': ['angular'],
        'angular-file-upload': ['angular'],
        'angular-ui-select': ['angular'],
        'http-auth': ['enc-base64', 'enc-base64', 'hmac-auth'],
        'jquery.mousewheel': ['jquery'],
        'jqueryui': ['jquery'],
        'jquery.ui.core': ['jquery'],
        'jquery.ui.mouse': ['jquery.ui.core', 'jquery.ui.widget'],
        'jquery.ui.widget': ['jquery.ui.core'],
        'jquery.ui.sortable': ['jquery.ui.core', 'jquery.ui.widget', 'jquery.ui.mouse'],
        'angular.drag.drop': ['angular'],
        'sortable': ['angular', 'jquery.ui.core', 'jquery.ui.widget', 'jquery.ui.mouse', 'jquery.ui.sortable']
        , 'angular-bindonce': ['angular']
        , 'table': ['angular.drag.drop']
        , 'table-options': ['angular.drag.drop'],
        'addon-lego': ['threejs'],
        'addon-puzzle': ['threejs'],
        'addon-puzzle': ['mobiscroll','threejs'],
        'addon-mathaxis':['mobiscroll','threejs','threex_dynamictexture'],
    },
    deps: ['app'],
    urlArgs: "v=" + config.js_version
});