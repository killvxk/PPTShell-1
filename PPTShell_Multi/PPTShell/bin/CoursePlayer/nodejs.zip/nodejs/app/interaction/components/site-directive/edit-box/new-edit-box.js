/**
 * 编辑框指令插件
 * 
 */
define(['angularAMD', 'css!components/site-directive/edit-box/edit-box.css'
], function (angularAMD) {
    angularAMD.directive('newEditBox', [function () {
    	var oTime1;
        var timeList = new Array();
        return {
			require:"?ngModel",
			restrict: 'EA',
			scope: {maxSize:'=maxSize',minSize:'=minSize',maxLength:'=maxLength',title:'='},
            link: function(scope, element, attr, ngModel) {
            	element.removeAttr("title"); //修复bug22182
            	
            	var MAX_LENGTH = scope.maxLength || 70;
            	var maxFontSize = scope.maxSize;
            	var minFontSize = scope.minSize;
//            	var maxLength = scope.maxLength;
            	
            	if(MAX_LENGTH > 100) MAX_LENGTH = 100; //最多不超过100个字
            	element.attr("maxlength", MAX_LENGTH); //修复bug10124:当标题区输入的文字超过规定字数，将鼠标定位至文本中间，发现仍可输入数字、英文字母或其他字符。
            	
//            	var minFontSize = 0;
                scope.$watch('title', function (newValue, oldValue) {
                    if (newValue && newValue != oldValue) {
                        fun();
                    }
                });
                scope.$on('changgedSkin',fun);
                scope.$watch('element.width()', function (newValue, oldValue) {
                    if (newValue && newValue != oldValue) {
                        fun();
                    }
                });
                var currentFontSize = element.css('fontSize');

				
				
				function getEditString(str,maxLength){
					var result = "";
					var strLen = str.length,count = 0;
					for(var i = 0; i <= strLen - 1; i++){
						if (count >= maxLength) {
							return result;
							break;
						}
						count+=1;
						result += str.charAt(i);
					}
					return result;
				}
				
				function resetBoxStyle() {
					element.rows = 1;
                	element.css('line-height', '42px');
				}
                //获取字符串长度，包括中文
                var getStrLeng =  function(str){
                    var realLength = 0;
					if(str === undefined){
						return realLength;
					}
                    var len = str.length;
                    var el = 0 ,cl = 0; 
                    
                    var charCode = -1;
                    for(var i = 0; i < len; i++){
                        charCode = str.charCodeAt(i);
                        if (charCode >= 0 && charCode <= 128) { 
                            realLength += 1;
                            el++ ; 
                        }else{ 
                            // 如果是中文则长度加3
                        	realLength+=2;
                        	cl++ ;
                        }
                    } 
                    return {
                    	l:realLength,
                    	enLength:el,
                    	chLength:cl
                    };
                }  
                function fun(){
                	setTimeout(function(){
                    	var  titleStr = element.val() ;
                    	titleStr = titleStr.replace(/<\/?.+?>/g,""); 
                    	titleStr = titleStr.replace(/[\r\n]/g, ""); 
                    	element.val(titleStr) ;
                        var maxLength = MAX_LENGTH;//element.width() / minFontSize * 2;
                        var width = element.width() ; 
                        var titleValue = element.val();//
                        var $parent = element.parent();
                        var ob = getStrLeng(titleValue);
                       // console.log("h",$parent.height())
                        if( maxFontSize * ob.chLength + parseInt(maxFontSize*39*ob.enLength/65)  > width ){
                        	minFontSize = Math.floor($parent.height() / 2 - 3 ); 
                        	element.css('fontSize',minFontSize);
                        	element.css('line-height',$parent.height()/2-2 + 'px' );
                        	currentFontSize = minFontSize;
                        }else {
                        	element.css('fontSize',maxFontSize);
                        	element.css('line-height',$parent.height()-2 + 'px');
                        }
                        if(titleValue.length >= maxLength){
                            var result=getEditString(titleValue,maxLength);
//                                element.val(result);
                            scope.title = result;

                            tip();
                        }
                	},300);

                }
                //改变窗口大小的时候重新适应
                angular.element(window).resize(fun);
                
				//每次输入的时候改变字体小小（未准确考虑间距距）
                element.bind('input enterKey', function(event) {
                	//minFontSize = parseFloat(((element.width() * lineCount ) / maxLength).toFixed(2));va
                	fun();
                });
                
                //修复bug：当编辑框达到最大字数后，
                element.bind('keydown', function(event) {
                	if(element.val().length >= MAX_LENGTH) {
                		if(event.which != 8 && event.which != 46) { //后退按钮或删除键
                			if(element[0].selectionStart == element[0].selectionEnd) {
                    			event.cancelable = true;
                        		event.preventDefault();
                        		
                        		return false;
                    		}
                		}
                	}
                });

				if(ngModel && (attr.escapseBlank === "true" || attr.escapseBlank === true)) {
					element.on('blur', function(event) {
						if($.trim(event.target.value) === '') {
							event.target.value = '';
							scope.$apply(function(){
								ngModel.$setViewValue('');
							});
						}
					});
				}

                
                if(attr.placeholder) {
                    //元素获取焦点后, 不显示placeholder
					element.on('focus', function(event) {
						element.attr('placeholder', '');
					});

					//元素失去焦点后, 显示placeholder
					element.on('blur', function(event) {
						element.attr('placeholder', attr.placeholder);
					});
                }

                //字体太小时闪烁输入框 提示用户内容太多
				var timeout= 0, interval = 0, borderColorEqRed = false;
				function tip(){
					clearTimeout(timeout);
					clearInterval(interval);
					timeout = setTimeout(function(){
						clearInterval(interval);
						element.css('border','1px solid transparent');
					},3000);
					interval = setInterval(loopShow,300);
				}
				function loopShow(){
					if (borderColorEqRed) {
						element.css('border','1px solid transparent');
						borderColorEqRed = false;
        			} else {
						element.css('border',"1px solid red");
						borderColorEqRed = true;
        			}
				}
            }
        };
        
        
    }]);

});
