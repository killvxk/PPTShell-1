/**
 *
 */

define(['app', 'textselect/directive/textselect.directive'], function (app) {
    'use strict';
    app.controller('textselect_ctrl', [
        '$scope', 'skin_service', '$stateParams', 'CustomEditorService', '$rootScope', '$filter',
        function ($scope, skin_service, $stateParams, CustomEditorService, $rootScope, $filter) {

            var isSpan = false, currentTarget = null, ismousedown = false;

            $scope.errorModel = {};

            $scope.optionItems = [];

            $scope.model = {
                "id": "",
                "title": "",
                "skin": {
                    code: "wood",
                    css_url: "${ref-path}/edu/esp/preparecustomeditor/compare/wood/css/wood.css",
                    name: $filter('translate')('linkup.muwen'),
                    package_url: "${ref-path}/edu/esp/preparecustomeditor/compare/wood"
                },
                "timer": {
                    "timer_type": "sequence", //计时器类型: ["sequence", "countdown"]
                    "time_minute": "0", //倒计时初始设置-分钟，timer_type="countdown"时有效
                    "time_second": "0" //倒计时初始设置-秒，timer_type="countdown"时有效
                },
                "prompt": {
                    "content": "",
                    "candidates": []
                }
            };

            $scope.view = {
                showButton: false,
                left: 0,
                top: 0,
                selection: null,
                content: "",
                showHolder: true
            };
            var loadingData = function (id) {
                CustomEditorService.getQuestionInfoById(id)
                    .then(function (rtnData) {
                        if (!rtnData) {
                            $scope.errorModel.errorText = $filter('translate')('linkup.unvalidno');
                        } else {
                            if (rtnData.skin.code != '') {
                                //有数据
                                angular.extend($scope.model, rtnData);
                                $scope.view.content = getContent();
                                $scope.view.showHolder = false;
                            } else {
                                //没数据
                                $scope.model.id = rtnData.id;
                                $scope.view.showHolder = true;
                            }

                            $scope.errorModel.errorText = "";
                            skin_service.set_skin_by_code($scope.model.skin.code, 'v1');
                        }
                    }, function () {
                        $scope.errorModel.errorText = $filter('translate')('linkup.get_title_error');
                    });
            };
            $scope.$on('changgedSkin', function () {
                $rootScope.scaleHtml();
            });

            $scope.encodeData = function (model1) {
                var model = angular.copy(model1),
                    content = getContentByHtml(),
                    result = [], res,
                    cacheContent = content,
                    reg = /<span.*?>.*?<\/span>/g,
                    index = 0;

                while (res = reg.exec(content)) {
                    result.push(res[0]);
                    cacheContent = cacheContent.replace(res[0], '{' + index + '}');
                    index++;
                }

                model.prompt.content = cacheContent;
                for (var i = 0; i < result.length; i++) {
                    model.prompt.content = model.prompt.content.replace(result[i], '{' + i + '}');
                    if (result[i].indexOf('textselect_correct') > 0) {
                        model.prompt.candidates[i] = {
                            "num": i,
                            "value": result[i].match(/<span.*?>([^>]+)<\/span>/)[1],
                            "correct": true
                        };
                    } else {
                        model.prompt.candidates[i] = {
                            "num": i,
                            "value": result[i].match(/<span.*?>([^>]+)<\/span>/)[1],
                            "correct": false
                        };
                    }
                }

//                console.log('post data');
//                console.log(model);

                return model;
            };

            $scope.decodeData = function (data) {
//                console.log(data);
                $scope.model.id = data.id;
            };

            $scope.validPostData = function () {
                var modelData = $scope.model;
                if ($.trim(modelData.title) == '') {
                    $scope.errorModel.errorText = $filter('translate')('textselect.no_title');
                    return false;
                }

                var $span = $(".textselect_edit").find("span"), correctCount = 0, errorCount = 0;
                $span.each(function (index, value) {
                    if ($(value).hasClass('textselect_correct'))
                        correctCount++;
                    if ($(value).hasClass('textselect_error'))
                        errorCount++;
                });

                if (correctCount == 0) {
                    $scope.errorModel.errorText = $filter('translate')('textselect.invalidate');
                    return false;
                }

                if (correctCount == 1 && errorCount == 0) {
                    $scope.errorModel.errorText = $filter('translate')('textselect.invalidate1');
                    return false;
                }


                return true;
            };


            if (!$stateParams.id) {
                skin_service.set_skin_by_code($scope.model.skin.code, 'v1');
                $scope.view.content = getContent();
                $scope.view.showHolder = true;
            } else {
                loadingData($stateParams.id);
            }

            $scope.blur = function () {
                if (getContentByText().length <= 0)
                    $scope.view.showHolder = true;
            };

            $scope.focus = function () {
                $scope.view.showHolder = false;
            };

            $scope.mousedown = function () {
                window.getSelection().removeAllRanges();
                $scope.cancel();
                ismousedown = true;
                $scope.view.selection = null;
                //$scope.view.showHolder = false;
            };

            $scope.mousemove = function (evt) {
                if (ismousedown)
                    isSpan = false;
            };

            $scope.mouseup = function (evt) {
                ismousedown = false;
                var selection = window.getSelection();
                if (selection.toString() == "")
                    return;

                var offset = $(evt.currentTarget).offset();
                var maxLeft = $(".textselect_edit").width() - 170;
                var setLeft = evt.pageX - offset.left;
                $scope.view.selection = selection;
                $scope.view.left = setLeft > maxLeft ? maxLeft : setLeft;
                $scope.view.top = evt.pageY - offset.top - 24;
                $scope.view.showButton = true;
            };

            $scope.correct = function () {
                if (!isSpan)
                    setOptions(1);
                else
                    setOptionsWithSpan(1)
            };

            $scope.error = function () {
                if (!isSpan)
                    setOptions(0);
                else
                    setOptionsWithSpan(0);
            };

            $scope.cancel = function () {
                isSpan = false;
                currentTarget = null;
                $scope.view.left = 0;
                $scope.view.top = 0;
                $scope.view.showButton = false;
            };

            $scope.keydown = function (evt) {
                var text = getContentByText();
                if (text.length >= 200 && evt.keyCode != 8) {
                    evt.preventDefault();
                    $scope.errorModel.errorText = "超过200字符";
                    $("#hidefocus").focus();
                }
            };

            $scope.keyup = function (evt) {
                if (evt.keyCode == 13) {
                    $(".textselect_edit >div").each(function (index, value) {
                        $(value).attr('class', 'children');
                        $(value).attr('id', 'childrenId_' + index);
                    });
                }
                if (evt.keyCode == 8) {
                    $(".textselect_edit span").each(function (index, value) {
                        if (!$(value).attr('class')) {
                            $scope.view.content = getContentByHtml().replace(value.outerHTML, $(value).text());
                        }
                    });
                }
            };

            $(".textselect_edit").on('input', function (evt) {
                if (evt.currentTarget.innerText.length >= 200) {
                    evt.currentTarget.innerText = evt.currentTarget.innerText.substr(0, 200);
                    $scope.errorModel.errorText = "超过200字符";
                    $("#hidefocus").focus();
                    return;
                }
            });

            $scope.dblclick = function (evt) {
                evt.preventDefault();
                window.getSelection().removeAllRanges();
                $scope.cancel();
            };

            $scope.paste = function (event) {
                var result = event.clipboardData.getData('text/html');
                if (result != "") {
                    event.preventDefault();
                    $scope.errorModel.errorText = "请打开纯文本文件过滤非法内容"
                }
            };

            $scope.click = function (event) {
                $scope.view.showHolder = false;
                $(".textselect_edit").focus();
            };

            function uuid() {
                var s = [];
                var hexDigits = "0123456789abcdef";
                for (var i = 0; i < 36; i++) {
                    s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
                }
                s[14] = "4";  // bits 12-15 of the time_hi_and_version field to 0010
                s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1);  // bits 6-7 of the clock_seq_hi_and_reserved to 01
                s[8] = s[13] = s[18] = s[23] = "-";

                var uuid = s.join("");
                return uuid;
            }

            function setOptions(m) {
                var selection = $scope.view.selection,
                    range = selection.getRangeAt(0), content = "";

                if (!checkData(range)) {
                    $scope.errorModel.errorText = $filter('translate')('textselect.body_error');
                    return;
                }

                content = range.startContainer.textContent;

                var start = content.substring(0, range.startOffset);
                var selected = content.substring(range.startOffset, range.endOffset)
                var end = content.substring(range.endOffset);

                var str = start + '<span contenteditable="false" class="'
                    + (m ? "textselect_correct" : "textselect_error")
                    + '"' + ' id="' + uuid() + '"'
                    + '><a class="delete_select"></a>' + selected + '</span>'
                    + $.trim(end);

                //$scope.view.content = escapeHtml(getContentByHtml()).replace(content, str);

                var result = complexReplace(escapeHtml(getContentByHtml()), content, str, range.startContainer.previousSibling, range);
                $scope.view.content = result;
                $scope.cancel();
            }

            function complexReplace(originContent, content, str, previousSibling, range) {
                //每次先用indexOf和length判断是否匹配的词已经被设置了（相同选项），如果已经设置则先保存下来然后进行递归；
                var id = previousSibling ? previousSibling.id : "", index = 0;

                if (id) {
                    index = originContent.indexOf(id);
                    for (var i = index; i < originContent.length - 7; i++) {
                        if (originContent.substr(i, 7) === '</span>') {
                            break;
                        }
                    }
                    return originContent.substring(0, i + 7) + originContent.substr(i + 7).replace(content, str);
                }
                else if (range.startContainer.parentElement.className == 'children') {
                    id = range.startContainer.parentElement.id;
                    index = originContent.indexOf(id);
                    return originContent.substring(0, index) + originContent.substr(index).replace(content, str);
                }
                else {
                    return originContent.replace(content, str);
                }
            }

            function stop() {
                return false;
            }

            //$(".textselect_content")[0].oncontextmenu = stop;
            //字符串转义
            function escapeHtml(text) {
                return text.replace(/&nbsp;/g, String.fromCharCode(160)).replace(/&amp;/g, '&');
            }

            function setOptionsWithSpan(m) {
                $(currentTarget).removeClass('textselect_correct textselect_error').addClass(m ? "textselect_correct" : "textselect_error");
                $scope.cancel();
            }

            function getContentByHtml() {
                return $(".textselect_edit").html();
            }

            function getContentByText() {
                return $(".textselect_edit").text();
            }

            function checkData(range) {
                if (range.startContainer === range.endContainer && range.startContainer.parentElement.tagName == "DIV")
                    return true;
                return false;
            }

            function getContent() {
                var q = $scope.model.prompt,
                    result = q.content;
                for (var i = 0; i < q.candidates.length; i++) {
                    var c = q.candidates[i];
                    if (c.correct)
                        result = result.replace('{' + c.num + '}', '<span class="textselect_correct" data-num="' + c.num + '"><a></a>' + c.value + '</span>');
                    else
                        result = result.replace('{' + c.num + '}', '<span class="textselect_error" data-num="' + c.num + '"><a></a>' + c.value + '</span>');
                }
                return result;
            }

            $(".textselect_edit").on('click', "span a", function (evt) {
                evt.stopPropagation();
                evt.preventDefault();

                var $target = $(evt.currentTarget).parent(),
                    text = $target.text();
                $target.before(text);
                $target.remove();
                $(".textselect_edit").html($(".textselect_edit").html());
                //$scope.view.content = escapeHtml(getContentByHtml()).replace(content, str);
            });

            $(".textselect_edit").on('click', "span", function (evt) {
                evt.stopPropagation();
                evt.preventDefault();

                isSpan = true;
                currentTarget = evt.currentTarget;

                var offset = $(".textselect_edit").offset();
                var maxLeft = $(".textselect_edit").width() - 170;
                var setLeft = evt.pageX - offset.left;
                $scope.view.left = setLeft > maxLeft ? maxLeft : setLeft;
                $scope.view.top = evt.pageY - offset.top - 24;
                $scope.view.showButton = true;
            });
        }
    ]);

});
