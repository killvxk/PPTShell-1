/**
 *
 */
define(['app', 'memorycard/directive/memorycard.directive'
], function (app) {
    'use strict';
    app.controller('memorycard_ctrl', [
        '$scope','skin_service','$stateParams','CustomEditorService','$rootScope',"$filter",
        function ($scope,skin_service,$stateParams,CustomEditorService, $rootScope,$filter) {
        	$rootScope.moduleScope = $scope;
            $scope.errorModel = {};
            $scope.delData = {data:{}};
            $scope.model = {
                "module_subtype":"",//子类型:["image2image","image2text","text2text"]
                "title":"",         //标题
                "skin": {
                    code: "wood",
                    css_url: "${ref-path}/edu/esp/preparecustomeditor/memorycard/wood/css/wood.css",
                    name:  $filter('translate')('memorycard.muwen'),
                    package_url: "${ref-path}/edu/esp/preparecustomeditor/memorycard/wood"
                },
                "timer":{
                    "timer_type":"sequence",  //计时器类型: ["sequence", "countdown"]
                    "time_minute":"0",    //倒计时初始设置-分钟，timer_type="countdown"时有效
                    "time_second":"0"     //倒计时初始设置-秒，timer_type="countdown"时有效
                }
            };
            var initModel = {
                "module_subtype":"image2text",//子类型:["image2image","image2text","text2text"]
                "title":"",         //标题
                "skin": {
                    code: "wood",
                    css_url: "${ref-path}/edu/esp/preparecustomeditor/memorycard/wood/css/wood.css",
                    name: $filter('translate')('memorycard.muwen'),
                    package_url: "${ref-path}/edu/esp/preparecustomeditor/memorycard/wood"
                },
                "timer":{
                    "timer_type":"sequence",  //计时器类型: ["sequence", "countdown"]
                    "time_minute":"0",    //倒计时初始设置-分钟，timer_type="countdown"时有效
                    "time_second":"0"     //倒计时初始设置-秒，timer_type="countdown"时有效
                },
                items: [{},{},{}]
            };
            var loadingData = function(id){
                $scope.isloadingData=true;
                CustomEditorService.getQuestionInfoById(id)
                    .then(function(rtnData){
                        if(!rtnData){
                            $scope.errorModel.errorText = $filter('translate')('memorycard.unvalidno');
                        }else{
                            if(rtnData.skin.code!=''){
                                $scope.model=$scope.decodeOrder(rtnData);
                                skin_service.set_skin_by_code($scope.model.skin.code, "v1");
                            }else{

                                $scope.showGuide = true;
                                initModel.id=rtnData.id;
                                skin_service.set_skin_by_code($scope.model.skin.code, "v1");
                            }
                            $scope.errorModel.errorText = "";
                            $scope.isloadingData=false;
                        }
                    },function(error){
                        $scope.errorModel.errorText = $filter('translate')('memorycard.get_title_error');
                    })
            }

            //入口
            if(!$stateParams.id){
                //新增
                $scope.showGuide = true;
                skin_service.set_skin_by_code(initModel.skin.code, "v1");
            }else{
                //修改
                $scope.showGuide = false;
                loadingData($stateParams.id);
            }
            $scope.setModuleSubtype = function(module_subtype){
                $scope.showGuide = false;
                initModel.module_subtype = module_subtype;
                $scope.model.items = [{},{},{}];
                $scope.model.module_subtype = module_subtype;
                $scope.model.id = initModel.id;
                //$scope.model = initModel;
                //根据子类型设置默认标题
                /*switch($scope.model.module_subtype){
                case "image2image":
                	$scope.model.title = $filter('translate')('memorycard.title.image2image');
                	break;
                case "image2text":
                	$scope.model.title = $filter('translate')('memorycard.title.image2text');
                	break;
                case "text2text":
                	$scope.model.title = $filter('translate')('memorycard.title.text2text');
                	break;
                default:
                }*/
                
                $rootScope.scaleHtml();
            }
            $scope.$on('changgedSkin',function(){
                $rootScope.scaleHtml();
            })
            $scope.addMatchItem = function(){
                $scope.model.items.push(angular.copy($scope.delData.data));
                $scope.delData = {data:{}};
            }
            $scope.validPostData = function(){
                var modelData =$scope.model;
                if($.trim(modelData.title)==''){
                    $scope.errorModel.errorText =  $filter('translate')('memorycard.no_title');
                }else{
                	//重复图片验证
                    var itemsCount = 0;
                    for(var i=0;i<modelData.items.length;i++){
                        if(!(!modelData.items[i].source.href && !modelData.items[i].source.text) && !(!modelData.items[i].target.href && !modelData.items[i].target.text) ){
                            itemsCount++;
                        }else{
                            $scope.errorModel.errorText =  $filter('translate')('memorycard.no_content');
                            return ;
                        }
                    };
                    if(itemsCount<3){
                        $scope.errorModel.errorText =  $filter('translate')('memorycard.content_min');
                    }
                    
                    return checkDuplication(modelData);
                }
            }
            function isSameImageCard(source, target, indexI, indexJ) {
            	if(source.href != "" && target.href != "") {
            		if(source.href == target.href) {
        				if(indexJ) {
        					$scope.errorModel.errorText =  $filter('translate')('memorycard.duplicate_imagecard_between', {indexI: indexI, indexJ: indexJ});
        				}  else if(indexI) {
        					$scope.errorModel.errorText =  $filter('translate')('memorycard.duplicate_imagecard', {index: indexI});
        				}
            			
            			return true;
            		}
            	}
            	
            	return false;
            }
            function isSameTextCard(source, target, indexI, indexJ) {
            	if(source.text != "" && target.text != "") {
            		if(source.text == target.text) {
            			if(indexJ) {
        					$scope.errorModel.errorText =  $filter('translate')('memorycard.duplicate_textcard_between', {indexI: indexI, indexJ: indexJ});
        				} else if(indexI) {
        					$scope.errorModel.errorText =  $filter('translate')('memorycard.duplicate_textcard', {index: indexI});
        				}
            			
            			return true;
            		}
            	}
            	
            	return false;
            }
            function checkDuplication(modelData) {
            	var isValid = true;
            	if(modelData.module_subtype == "image2image") {
            		var itemI, itemJ;
            		for(var i = 0; i < modelData.items.length; i++) {
            			itemI = modelData.items[i];
                		for(var j = i + 1; j < modelData.items.length; j++) {
                			itemJ = modelData.items[j];
                			if(isSameImageCard(itemI.source, itemJ.source, i + 1, j + 1) || 
                				 isSameImageCard(itemI.source, itemJ.target, i + 1, j + 1)) {
                				isValid = false;
                				return false;
                			} else if(isSameImageCard(itemI.target, itemJ.source, i + 1, j + 1) || 
                					    isSameImageCard(itemI.target, itemJ.target, i + 1, j + 1)) {
                				isValid = false;
                				return false;
                			}
                		}
                	}
            	} else if(modelData.module_subtype == "image2text"){
            		for(var i = 0; i < modelData.items.length; i++) {
            			itemI = modelData.items[i];
                		for(var j = i + 1; j < modelData.items.length; j++) {
                			itemJ = modelData.items[j];
                			if(isSameImageCard(itemI.source, itemJ.source, i + 1, j + 1)) {
                				isValid = false;
                				return false;
                			} else if(isSameTextCard(itemI.target, itemJ.target, i + 1, j + 1)) {
                				isValid = false;
                				return false;
                			}
                		}
                	}
            	} else {
            		for(var i = 0; i < modelData.items.length; i++) {
            			itemI = modelData.items[i];
            			for(var j = i + 1; j < modelData.items.length; j++) {
                			itemJ = modelData.items[j];
                			
                			if(isSameTextCard(itemI.source, itemJ.source, i + 1, j + 1) || 
                				 isSameTextCard(itemI.source, itemJ.target, i + 1, j + 1)) {
                				isValid = false;
                				return false;
                			} else if(isSameTextCard(itemI.target, itemJ.source, i + 1, j + 1) || 
                					    isSameTextCard(itemI.target, itemJ.target, i + 1, j + 1)) {
                				isValid = false;
                				return false;
                			}
                		}
                	}
            	}
            	
            	return isValid;
            }
            //图片重复验证
            $scope.addImagePost = function(matchItem, $index){
            	var isValid = true;
            	angular.forEach($scope.model.items, function(item, index){
            		if(item != matchItem) {
            			if($scope.model.module_subtype == "image2image") {
            				if(isSameImageCard(matchItem.source, item.source, index + 1) || 
            					 isSameImageCard(matchItem.source, item.target, index + 1)) {
            					isValid = false;
            					return false;
            				} else if(isSameImageCard(matchItem.target, item.source, index + 1) || 
            						    isSameImageCard(matchItem.target, item.target, index + 1)) {
            					isValid = false;
            					return false;
            				}
            			} else if($scope.model.module_subtype == "image2text") {
            				if(isSameImageCard(matchItem.source, item.source, index + 1)) {
            					isValid = false;
            					return false;
            				}
            			}
            		}
            	});
            	
            	return isValid;
            }
            //文本重复验证
            $scope.addTextPost = function(matchItem, $index){
            	var isValid = true;
            	angular.forEach($scope.model.items, function(item, index){
            		if(item != matchItem) {
            			if($scope.model.module_subtype == "text2text") {
            				if(isSameTextCard(matchItem.source, item.source, index + 1) || 
            					 isSameTextCard(matchItem.source, item.target, index + 1)) {
            					isValid = false;
            					return false;
            				} else if(isSameTextCard(matchItem.target, item.source, index + 1) ||
            						    isSameTextCard(matchItem.target, item.target, index + 1)) {
            					isValid = false;
            					return false;
            				}
            			} else if($scope.model.module_subtype == "image2text") {
            				if(isSameTextCard(matchItem.target, item.target, index + 1)) {
            					isValid = false;
            					return false;
            				}
            			}
            		}
            	});
            	
            	return isValid;
            }

            $scope.encodeOrder = function(model){
                var newModel = angular.copy(model);
                newModel.title = window.customHtmlEncode(newModel.title);
                for(var i=0;i<newModel.items.length;i++) {
                    if (newModel.items[i].source.item_type == 'text') {
                        newModel.items[i].source.text = window.customHtmlEncode(newModel.items[i].source.text);
                    }
                    if (newModel.items[i].target.item_type == 'text') {
                        newModel.items[i].target.text = window.customHtmlEncode(newModel.items[i].target.text);
                    }
                }
                return newModel;
            };
            $scope.encodeData = function(model){
                var newModel = angular.copy(model);
                newModel.title = window.customHtmlEncode(newModel.title);
                for(var i=0;i<newModel.items.length;i++) {
                    if (newModel.items[i].source.item_type == 'text') {
                        newModel.items[i].source.text = window.customHtmlEncode(newModel.items[i].source.text);
                    }
                    if (newModel.items[i].target.item_type == 'text') {
                        newModel.items[i].target.text = window.customHtmlEncode(newModel.items[i].target.text);
                    }
                }
                return newModel;
            }
            $scope.decodeOrder = function(model){
                var newModel = angular.copy(model);
                newModel.title = window.customHtmlDecode(newModel.title);
                for(var i=0;i<newModel.items.length;i++) {
                    if (newModel.items[i].source.item_type == 'text') {
                        newModel.items[i].source.text = window.customHtmlDecode(newModel.items[i].source.text);
                    }
                    if (newModel.items[i].target.item_type == 'text') {
                        newModel.items[i].target.text = window.customHtmlDecode(newModel.items[i].target.text);
                    }
                }
                return newModel;
            };
            $scope.decodeData = function(model){
                var newModel = angular.copy(model);
                newModel.title = window.customHtmlDecode(newModel.title);
                for(var i=0;i<newModel.items.length;i++) {
                    if (newModel.items[i].source.item_type == 'text') {
                        newModel.items[i].source.text = window.customHtmlDecode(newModel.items[i].source.text);
                    }
                    if (newModel.items[i].target.item_type == 'text') {
                        newModel.items[i].target.text = window.customHtmlDecode(newModel.items[i].target.text);
                    }
                }
                return newModel;
            };
            
            //资源文件的限制使用
            $scope.resourceValidParam = {
            	imageType:['image/jpg', 'image/jpeg', 'image/webp', 'image/gif', 'image/png', 'image/bmp'], 
                imageSize:1*1024*1024
            };
            $scope.closeImagePreview = function() {
            	$scope.isImagePreview = false;
            };
        }
    ]);
});
