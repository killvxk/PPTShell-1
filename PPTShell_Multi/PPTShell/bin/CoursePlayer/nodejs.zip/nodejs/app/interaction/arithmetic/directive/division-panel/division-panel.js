/**
 * Created by zy on 2015/7/6.
 */
define(['angularAMD'
], function (angularAMD) {
    angularAMD .directive('divisionPanel', [ function () {
        return {
            restrict:'E',
            templateUrl:'interaction/arithmetic/directive/division-panel/division-panel.html',
            scope: {
            	calNum:'=calNum'
            	
            },
            link:function(scope,element,attrs){
            	//scope.first_num_length = 280-56*(5-calNum.number_first.items.length)
                scope.checkNum = function( item ){
                	
                	item.hide = !item.hide;
                	//console.log(scope.calNum);
   
                }
            }
            
        };
    }])

});
