define([
    'components/site-directive/assets-select/assets-select',
    'components/site-directive/edit-box/new-edit-box',
    'components/site-directive/time-setting-box/time-setting-box',
    'components/site-directive/foot-tool/time-box/new-time-box',
    'components/site-directive/foot-tool/foot-tool',
    'components/site-directive/select-skin/select-skin',
    'components/site-directive/error-tip/error-tip'
], function () {


});