/**
 * Created by Administrator on 2015/12/16.
 */
define(['angularAMD'
], function (angularAMD) {
    angularAMD.directive('clockPanel', [function () {
        return {
            restrict: 'E',
            templateUrl: 'interaction/clock/directive/clock-panel.html',
            link: function ($scope, element) {
                AddonClockThree_create().run($('.addon-clock').get(0));
            }
        };
    }]);
});