/**
 * Lego
 * 2015-11-19 13:49:15
 */
define(['app', 'lego/directive/lego.directive'], function (app) {
    'use strict';
    app.controller('lego_ctrl', [
        '$scope', 'skin_service', '$stateParams', 'CustomEditorService', '$rootScope', '$filter',
        function ($scope, skin_service, $stateParams, CustomEditorService, $rootScope, $filter) {
            $rootScope.moduleScope = $scope;
            $scope.errorModel = {};
            $scope.lego = {
                placeholder: {title: "请输入标题"},
            }
            $scope.model = {
                "id": "",
                "module_code": "nd_lego", // 题目类型
                "title": "", //标题
                "skin": {
                    code: "wood",
                    css_url: "${ref-path}/edu/esp/preparecustomeditor/lego/wood/css/wood.css",
                    name: $filter('translate')('app.skin.wood'),
                    package_url: "${ref-path}/edu/esp/preparecustomeditor/lego/wood"
                },
                "timer": {
                    "timer_type": "sequence",  //计时器类型: ["sequence", "countdown"]
                    "time_minute": "0",    //倒计时初始设置-分钟，timer_type="countdown"时有效
                    "time_second": "0"     //倒计时初始设置-秒，timer_type="countdown"时有效
                },
                "properties": [	//模块静态数据模型
                    {
                        "name": "question_id",
                        "display_name": "题目ID",
                        "type": "string",
                        "value": "",
                        "is_localized": false
                    },
                    {
                        "name": "question_url",
                        "display_name": "题目内容",
                        "type": "jsonFile",
                        "value": "",
                        "is_localized": false
                    }
                ],
                "content": { //Editor数据模型正文
                }
            };

            //数据加载
            var loadingData = function (id) {
                $scope.isloadingData = true;
                CustomEditorService.getQuestionInfoById(id)
                    .then(function (rtnData) {
                        if (!rtnData) {
                            $scope.errorModel.errorText = $filter('translate')('app.unvalidno');
                        } else {
                            if (rtnData.skin.code != '') {
                                $scope.model = $scope.decodeData(rtnData, true);
                            } else {
                                $scope.model.id = rtnData.id;
                            }
                            try {
                                AddonLego_create().perspectiveViewHelper.initCubeData($scope.model.content.gridData, $scope.model.content.gridRotation, $scope.model.content.cameraPosition);
                            } catch (e) {
                            }
                            skin_service.set_skin_by_code($scope.model.skin.code, "v1");
                            $scope.errorModel.errorText = "";
                            $scope.isloadingData = false;
                        }
                    }, function (error) {
                        $scope.errorModel.errorText = $filter('translate')('app.question.get.error');
                    })
            };

            //入口
            if (!$stateParams.id) { //新增
                skin_service.set_skin_by_code($scope.model.skin.code, "v1");
            } else { //修改
                loadingData($stateParams.id);
            }

            $scope.$on('changgedSkin', function () {
                $rootScope.scaleHtml();
            });

            //数据验证
            $scope.validPostData = function () {
                return true;
            };

            //数据模型-编码
            $scope.encodeData = function (model) {
                var addon = AddonLego_create();
                model.content.gridData = new Object();
                model.content.gridData.gridCubeArr = addon.perspectiveViewHelper.gridData.getGridCubeArr();
                model.content.gridData.highlightPosition = addon.perspectiveViewHelper.gridData.highlightPosition;
                model.content.gridRotation = addon.perspectiveViewHelper.gridHelper.ROTATION;
                model.content.cameraPosition = new Object();
                model.content.cameraPosition.positionX = addon.perspectiveViewHelper.perspectiveViewCamera.position.x;
                model.content.cameraPosition.positionY = addon.perspectiveViewHelper.perspectiveViewCamera.position.y;
                model.content.cameraPosition.positionZ = addon.perspectiveViewHelper.perspectiveViewCamera.position.z;
                return model;
            };

            //数据模型-解码
            $scope.decodeData = function (model, isInitLoad) {
                return model;
            };
        }
    ]);
});
