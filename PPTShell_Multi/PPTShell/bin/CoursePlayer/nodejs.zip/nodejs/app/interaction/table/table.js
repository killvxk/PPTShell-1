/**
 * Created by 彭星 on 2015/6/15.
 */

define(['app','table/directive/table.directive'
    ], function (app) {
    'use strict';
    app.controller('table_ctrl', [
        '$scope','skin_service','$stateParams','CustomEditorService','$rootScope','$filter','$timeout',
        function ($scope,skin_service,$stateParams,CustomEditorService,$rootScope,$filter,$timeout) {
        	$rootScope.moduleScope = $scope;
            $scope.errorModel = {};
            $scope.optionItems=[];
            $scope.model = {
                "description": {
                    "text": "",       //题干描述
                    "asset_type": "", //题干相关素材类型 ["image","video","audio"]
                    "asset": ""  ,           //题干相关素材
                    "image_extend":{       //旋转，放大缩小等属性，todo：具体属性唐焱鑫补充
                        "rotate":"",
                        "resize":""
                    }
                },
                "title":$filter('translate')('table.tabletype'),         //标题
                "skin": {
                    code: "wood",
                    css_url: "${ref-path}/edu/esp/preparecustomeditor/table/wood/css/wood.css",
                    name: $filter('translate')('linkup.muwen'),
                    package_url: "${ref-path}/edu/esp/preparecustomeditor/table/wood"
                },
                "timer":{
                    "timer_type":"sequence",  //计时器类型: ["sequence", "countdown"]
                    "time_minute":"0",    //倒计时初始设置-分钟，timer_type="countdown"时有效
                    "time_second":"0"     //倒计时初始设置-秒，timer_type="countdown"时有效
                },
                "horizontal_items":[""], //表格横向元素文字列表
                "vertical_items":["",""],   //表格纵向元素文字列表
                "items":[ ]
            };
            var loadingData = function(id){
                CustomEditorService.getQuestionInfoById(id)
                    .then(function(rtnData){
                        if(!rtnData){
                            $scope.errorModel.errorText = $filter('translate')('linkup.unvalidno');
                        }else{
                            if(rtnData.skin.code!=''){
                                angular.extend($scope.model,$scope.decodeTable(rtnData));
                            }else{
                                $scope.model.id=rtnData.id;
                            }

                            $scope.errorModel.errorText = "";
                            skin_service.set_skin_by_code($scope.model.skin.code,'v1');
                        }
                    },function(){
                        $scope.errorModel.errorText = $filter('translate')('linkup.get_title_error');
                    })
            }

            //入口
            if(!$stateParams.id){
                skin_service.set_skin_by_code($scope.model.skin.code,'v1');
            }else{
                loadingData($stateParams.id);
            }
            $scope.$on('changgedSkin',function(){
                $rootScope.scaleHtml();
            })

            $scope.validPostData = function(){
                var modelData =$scope.model;
                if($.trim(modelData.description.text)==''){
                    $scope.errorModel.errorText =$filter('translate')('table.notnull.desc');
                }
//                else if($.trim(modelData.description.asset)==''){
//                    $scope.errorModel.errorText = "请先在题干区域插入多媒体文件！";
//                }
                else{
                	if($scope.optionItems.length > 0) { //需将所有选项进行分类
                		$scope.errorModel.errorText = $filter('translate')('table.options_unclassified_existed');
                        return false;
                	}

                    for(var i=0;i<modelData.horizontal_items.length;i++){
                        if($.trim(modelData.horizontal_items[i])==''){
                            $scope.errorModel.errorText = $filter('translate')('table.notnull.head');
                            return false;
                        }
                    }
                    for(var i=0;i<modelData.vertical_items.length;i++){
                        if($.trim(modelData.vertical_items[i])==''){
                            $scope.errorModel.errorText = $filter('translate')('table.notnull.head');
                            return false;
                        }
                    }
                    if(modelData.items.length==0){
                        $scope.errorModel.errorText =$filter('translate')('table.notnull.content');
                        return false;
                    }
                    return true;
                }

            }

            $scope.dropCallback = function(item,vindex,hindex){
                //console.log("dropCallback:" + vindex + "," + hindex);
                item.horizontal_index=hindex;
                item.vertical_index=vindex;
                return item;
            }
            var countMax ={
                "51":5,
                "52":2,
                "53":1,
                "54":1,
                "55":1,
                "21":10,
                "22":4,
                "23":2,
                "24":2,
                "25":2
            };


            function isDroppable(vindex, hindex, isOverflow) {
                var item, countNow = 0, capacity = countMax[(($scope.model.vertical_items.length <= 2 ? 2 : 5) * 10 + $scope.model.horizontal_items.length).toString()];
                for (var i = 0; i < $scope.model.items.length; i++) {
                    item = $scope.model.items[i];

                    if (vindex == item.vertical_index &&
                        hindex == item.horizontal_index) {
                        countNow++;

                        if(countNow > capacity) {
                            item.vertical_index = '';
                            item.horizontal_index = '';

                            $scope.model.items.splice(i--, 1);
                            $scope.optionItems.push(item);
                        }
                    }
                }

                if(isOverflow) {
                    return countNow > capacity;
                } else {
                    return countNow < capacity;
                }
            }
            $scope.disableMove = function(items,vcount,hcount,vindex,hindex){
                return !isDroppable(vindex, hindex);
            };
            $scope.delItem = function (items,index,direction) {
                items.splice(index,1);
                var hl = $scope.model.horizontal_items.length;
                var vl = $scope.model.vertical_items.length;
                _.remove($scope.model.items, function(item) {
                    var del = false ;
                    if(    direction === 'horizontal'){
                        if( index===item.horizontal_index ){
                            del=true ;
                        }else if( index<item.horizontal_index ){
                            item.horizontal_index--;
                        }

                    }else if( direction === 'vertical'){
                        if( index===item.vertical_index ){
                            del=true ;
                        }else if( index<item.vertical_index ){
                            item.vertical_index-- ;
                        }
                    }
                    if(del){
                        $scope.optionItems.push(item);
                    }
                    return del ;
                });
            }
            $scope.addItem = function (items) {
                items.push("");

                //扫描各单元格内的选项数量是否超过了其所能容纳的最大值，如果是，将多余的移到底部区域，并提示用户。
                checkOverflow();
            };
            function highlightBox(vindex, hindex) {
                var tableBox = $('.table_lie_box:eq(' + vindex + ') .table_img_box:eq(' + hindex + ')');
                tableBox.removeClass('table_highlight');
                $timeout(function () {
                    tableBox.addClass('table_highlight');
                }, 10);
            }
            function checkOverflow() {
                var rows = $scope.model.vertical_items.length;
                var cols = $scope.model.horizontal_items.length;

                for(var i = 0; i < rows; i++) {
                    for(var j = 0; j < cols; j++) {
                        var isOverflow = isDroppable(i, j, true);
                        //console.log("isOverflow(" + i + "," + j + "):" + isOverflow);
                        if(isOverflow) {
                            highlightBox(i, j);
                        }
                    }
                }
            }
            $scope.encodeTable = function(model){
                var newModel = angular.copy(model);
                
                var new_horizontal_items = [], new_vertical_items=[], new_items=[];
                angular.forEach(newModel.horizontal_items,function(value,index){
                    if($.trim(value)!=='' ){
                        new_horizontal_items.push(window.customHtmlEncode(value));
                    }
                });
                angular.forEach(newModel.vertical_items, function(value,index){
                    if($.trim(value)!=='' ){
                    	new_vertical_items.push(window.customHtmlEncode(value));
                    }
                });
                angular.forEach(newModel.items, function(value,index){
                    if($.trim(value.content)!=='' ){
                    	var new_item = {};
                    	new_item.id = value.id;
                    	new_item.content_type = value.content_type;
                    	new_item.content = window.customHtmlEncode(value.content);
                    	new_item.horizontal_index = value.horizontal_index;
                    	new_item.vertical_index = value.vertical_index;
                    	
                    	new_items.push(new_item);
                    }
                });
                newModel.horizontal_items = new_horizontal_items;
                newModel.vertical_items = new_vertical_items;
                newModel.items = new_items;
                
                newModel.description.text = window.customHtmlEncode(newModel.description.text);
                
                return newModel;
            }
            $scope.decodeTable = function(model){
                var newModel = angular.copy(model);
                var new_horizontal_items = [], new_vertical_items=[], new_items=[];
                angular.forEach(newModel.horizontal_items,function(value,index){
                    if($.trim(value)!=='' ){
                        new_horizontal_items.push(window.customHtmlDecode(value));
                    }
                });
                angular.forEach(newModel.vertical_items, function(value,index){
                    if($.trim(value)!=='' ){
                    	new_vertical_items.push(window.customHtmlDecode(value));
                    }
                });
                angular.forEach(newModel.items, function(value,index){
                    if($.trim(value.content)!=='' ){
                    	var new_item = {};
                    	new_item.id = value.id;
                    	new_item.content_type = value.content_type;
                    	new_item.content = window.customHtmlDecode(value.content);
                    	new_item.horizontal_index = value.horizontal_index;
                    	new_item.vertical_index = value.vertical_index;
                    	
                    	new_items.push(new_item);
                    }
                });
                newModel.horizontal_items = new_horizontal_items;
                newModel.vertical_items = new_vertical_items;
                newModel.items = new_items;
                newModel.description.text = window.customHtmlDecode(newModel.description.text);
                
                return newModel;
            };
        }
    ]);

});
