define(['angularAMD'], function(angularAMD) {
	angularAMD
		.directive('dragItem', [

			function() {
				return {
					restrict: 'E',
					templateUrl: 'interaction/balance/directive/drag-item/drag-item.html',
					replace: true,
					scope: {
						options: '=options',
						dragItems: '=dragItems'
					},
					controller: ['$scope',
						function($scope) {
							
						}
					]
				};
			}
		])
});